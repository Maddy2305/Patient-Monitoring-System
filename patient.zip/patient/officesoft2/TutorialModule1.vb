﻿Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Data.OleDb.OleDbException
Imports MySql.Data.MySqlClient
Module TutorialModule1
    Public con As New SqlConnection("Data Source=GAURANG-PC\ABC;Initial Catalog=Microtrontechnologies;User ID=sa;Password=abc123")
    Public con1 As New OleDb.OleDbConnection("Provider=Microsoft.JET.OLEDB.4.0;Data Source =micro.mdb")
    Public con2 As New OleDb.OleDbConnection("Provider=Microsoft.JET.OLEDB.4.0;Data Source =student.mdb")
    Public mycon As New MySqlConnection("Host=127.0.0.1;User Id=root; Password=; Database=dbpatient; Connect Timeout=10000000 ;pooling=true; sslMode=none")
    'Public mycon As New MySqlConnection("Server=http://192.168.1.6;User Id=microtron;Password=micro@wardha;Database=dbpatient")


    'Dim strConString = "Provider=MS Remote;" & "Remote Server=http://192.168.1.6;" & "Remote Provider=Microsoft.Jet.OLEDB.4.0;" & "Data Source=MyRemoteDB;Persist Security Info=False"
    Public ward As String
    Dim filepath As String
    Dim uploadfilename, randomvalue, uploadimage As String
    Public sqlconn, sqldb, sqluser, sqlpass As String
    Public connetionString As String
    Public cnn As SqlConnection
    Public cmd, cmd1, cmd2 As MySqlCommand

    Public sql, sql1, sql2 As String
    Public reader, reader1 As OleDbDataReader
    Public reader2, reader3, reader4 As MySqlDataReader
    Public read As MySqlDataReader

    Public da, adapter As New OleDbDataAdapter
    Public command As OleDbCommand
    'Public cmd1 As MySqlCommand
    Public ds As New DataSet
    'Public cmd2 As OleDbCommand

    'Public ds As New DataSet
    Public dv As DataView
    Public i, j As Integer

    Public medd1, medd2, medd3 As String
    Public dosee1, dosee2, dosee3 As String
    Public timee1, timee2, timee3 As String
    Public docname, patient, yr As String
    Public mobl, pdisease, pdate As String

End Module
