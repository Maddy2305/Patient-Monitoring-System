﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class Form1
    Dim adap As New MySqlDataAdapter("select * from tblappointment", mycon)
    Dim ds As New DataSet
    Dim dv As New DataView
    Dim cm As CurrencyManager
    'for hardware obj data
    Dim WithEvents SensorComm As New IO.Ports.SerialPort
    Dim SensorDATA As String
    Dim data1 As String = ""
    Dim data2 As String = ""
    Dim vcount As Integer
    Dim Sensorcomdata As String = ""
    Dim id As Integer = 101


    ' patient record
    'for patient
    Public Sub Display_patientdata()

        mycon.Open()

        Dim dt As New DataTable("patientlogin")
        ' Dim rs As New MySqlDataAdapter("select Officer_Id,First_Name,Middle_Name,Last_Name,Gender,Birth_Date,Address1,Address2,City,State,Area,Email,Mobile ,Designation,Aadhar_No,Date1 from tblofficerregistration ", mycon)
        Dim rs As New MySqlDataAdapter("select * from patientlogin", mycon)
        rs.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Refresh()
        'TextBox2.Text = dt.Rows.Count
        BunifuCustomLabel1.Text = dt.Rows.Count
        rs.Dispose()
        mycon.Close()

    End Sub

    Public Sub Display_doctor()

        mycon.Open()

        Dim dt As New DataTable("tbldoctor")
        ' Dim rs As New MySqlDataAdapter("select Officer_Id,First_Name,Middle_Name,Last_Name,Gender,Birth_Date,Address1,Address2,City,State,Area,Email,Mobile ,Designation,Aadhar_No,Date1 from tblofficerregistration ", mycon)
        Dim rs As New MySqlDataAdapter("select Doctor_Id,Name,Birth_Date,Qualification,Mobile,Address,Catagory from tbldoctor", mycon)
        rs.Fill(dt)
        BunifuCustomDataGrid1.DataSource = dt
        BunifuCustomDataGrid1.Refresh()
        BunifuCustomLabel9.Text = dt.Rows.Count
        'BunifuCustomDataGrid1.Text = dt.Rows.Count
        rs.Dispose()
        mycon.Close()

    End Sub
    Public Sub Display_nurse()

        mycon.Open()

        Dim dt As New DataTable("nurse")
        ' Dim rs As New MySqlDataAdapter("select Officer_Id,First_Name,Middle_Name,Last_Name,Gender,Birth_Date,Address1,Address2,City,State,Area,Email,Mobile ,Designation,Aadhar_No,Date1 from tblofficerregistration ", mycon)
        Dim rs As New MySqlDataAdapter("select * from nurse", mycon)
        rs.Fill(dt)
        BunifuCustomDataGrid5.DataSource = dt
        BunifuCustomDataGrid5.Refresh()
        'TextBox2.Text = dt.Rows.Count
        BunifuCustomLabel6.Text = dt.Rows.Count
        rs.Dispose()
        mycon.Close()

    End Sub

    'nurse data display
    Public Sub Display_general()

        mycon.Open()

        Dim dt As New DataTable("ward")
        ' Dim rs As New MySqlDataAdapter("select Officer_Id,First_Name,Middle_Name,Last_Name,Gender,Birth_Date,Address1,Address2,City,State,Area,Email,Mobile ,Designation,Aadhar_No,Date1 from tblofficerregistration ", mycon)
        Dim rs As New MySqlDataAdapter("select * from ward where ward_type='AC Ward'", mycon)
        rs.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Refresh()
        'TextBox2.Text = dt.Rows.Count
        BunifuCustomLabel71.Text = dt.Rows.Count
        rs.Dispose()
        mycon.Close()

    End Sub
    'Public Sub Display_general1()

    '    mycon.Open()

    '    Dim dt As New DataTable("ward")
    '    ' Dim rs As New MySqlDataAdapter("select Officer_Id,First_Name,Middle_Name,Last_Name,Gender,Birth_Date,Address1,Address2,City,State,Area,Email,Mobile ,Designation,Aadhar_No,Date1 from tblofficerregistration ", mycon)
    '    Dim rs As New MySqlDataAdapter("select * from ward where ward_type='AC Ward'", mycon)
    '    rs.Fill(dt)
    '    DataGridView1.DataSource = dt
    '    DataGridView1.Refresh()
    '    'TextBox2.Text = dt.Rows.Count
    '    BunifuCustomLabel71.Text = dt.Rows.Count
    '    rs.Dispose()
    '    mycon.Close()

    'End Sub


    Public Sub Display_acward1()

        mycon.Open()

        Dim dt As New DataTable("ward")
        ' Dim rs As New MySqlDataAdapter("select Officer_Id,First_Name,Middle_Name,Last_Name,Gender,Birth_Date,Address1,Address2,City,State,Area,Email,Mobile ,Designation,Aadhar_No,Date1 from tblofficerregistration ", mycon)
        Dim rs As New MySqlDataAdapter("select * from ward where ward_type='General Ward'", mycon)
        rs.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Refresh()
        'TextBox2.Text = dt.Rows.Count
        BunifuCustomLabel67.Text = dt.Rows.Count
        rs.Dispose()
        mycon.Close()

    End Sub
    Private Sub TabPage2_Click(sender As Object, e As EventArgs) Handles TabPage2.Click

    End Sub

    Private Sub panel1_Paint(sender As Object, e As PaintEventArgs) Handles panel1.Paint

    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub

    Private Sub Form1_Loa(sender As Object, e As EventArgs) Handles MyBase.Load
        docid_data()
        otpgrn()
        Display_doctor()
        doct_pass()
        Display_acward1()
        Display_general()
        Display_nurse()
        nurse_id_select()
        wardname_select()


        'txtselectward.Items.Add("Ward")
        'txtselectward.Items.Add("Room")
        id_data()
        nurse_id_data()


        wardtype_select()



        BunifuThinButton23.Visible = True
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = False

        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = False

        Panel28.Visible = False

        Panel21.Visible = False
        Panel22.Visible = False

        Dim i As Integer
        For i = 5 To 80
            txtage.Items.Add(i)
        Next


        Display_patientdata()

        TabControl1.SelectedTab = TabPage26



        For x As Integer = 0 To My.Computer.Ports.SerialPortNames.Count - 1
            Hcom.Items.Add(Trim(My.Computer.Ports.SerialPortNames(x)))

        Next


    End Sub

    Private Sub Panel7_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub BunifuImageButton2_Click(sender As Object, e As EventArgs) Handles BunifuImageButton2.Click
        'Application.Exit()
        Me.Close()

        mainform.Panel1.Visible = True


    End Sub

    Private Sub BunifuThinButton23_Click(sender As Object, e As EventArgs) Handles BunifuThinButton23.Click

    End Sub

    Private Sub BunifuThinButton24_Click(sender As Object, e As EventArgs) Handles BunifuThinButton24.Click
        BunifuThinButton23.Visible = False
        BunifuThinButton25.Visible = True
        BunifuThinButton27.Visible = False

        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = False
        TabControl2.SelectedTab = TabPage11

    End Sub

    Private Sub BunifuThinButton22_Click(sender As Object, e As EventArgs) Handles BunifuThinButton22.Click
        BunifuThinButton23.Visible = True
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = False

        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = False

        TabControl2.SelectedTab = TabPage7

    End Sub

    Private Sub BunifuThinButton26_Click(sender As Object, e As EventArgs) Handles BunifuThinButton26.Click

        If txtid.Text = "" Then
            MsgBox("please enter id")

        ElseIf txtfirstname.Text = "" Then
            MsgBox("Please enter first name")

        ElseIf txtlastname.Text = "" Then
            MsgBox("Please enter last name")

        ElseIf txtmobile.Text = "" Then
            MsgBox("please enter mobile no")

        ElseIf txtmoble2.Text = "" Then
            MsgBox("please enter mobile no")

        ElseIf txtweight.Text = "" Then
            MsgBox("please enter weight ")

        ElseIf txtheight.Text = "" Then
            MsgBox("please enter height ")

        ElseIf txtemail.Text = "" Then
            MsgBox("please enter email id")

        ElseIf txtbloodgroup.Text = "" Then

            MsgBox("please select blood group")
        ElseIf txtfees.Text = "" Then
            MsgBox("please enter amount")

        End If



        'email validation

        Dim regex As Regex = New Regex("^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")
        Dim isValid As Boolean = regex.IsMatch(txtemail.Text.Trim)

        If txtemail.Text <> "" Then


            If Not isValid Then
                MessageBox.Show("Invalid Email.")

            Else
                Add_Data()
                id_data()
                Display_patientdata()
                BunifuThinButton23.Visible = False
                BunifuThinButton25.Visible = False
                BunifuThinButton27.Visible = True

                BunifuThinButton213.Visible = False
                BunifuThinButton215.Visible = False
            End If


        End If



        'End If








        'Add_Data()


        'Display_patientdata()


        'for design


        'code





        'end code
    End Sub
    'code
    Public Sub Add_Data()

        ' TRUE LOGIC



        Dim a As Integer
        Dim i As Integer
        mycon.Open()

        sql = "Select * from patientlogin where Patient_Id='" & txtid.Text & "'"



        ' sql = "Select * from Tutorial_Micro where Student_Id='" & txtid.Text & "' and Email_Id='" & txtemail.Text & "'"
        cmd = New MySqlCommand(sql, mycon)
        reader2 = cmd.ExecuteReader()

        While reader2.Read()
            a = 1
        End While
        mycon.Close()
        If a = 1 Then
            MsgBox(" ID Already exist.", MsgBoxStyle.Critical)

        Else
            mycon.Open()
            '        Dim rs As New SqlClient.SqlCommand("insert into arrest1 values ('" + ComboBox1.Text + "','" + ComboBox2.Text + "','" + ComboBox3.Text + "','" + date1.Text + "','" + date2.Text + "','" + date3.Text + "','" + TextBox1.Text + "','" + ComboBox4.Text + "','" + ComboBox5.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + ComboBox27.Text + "' )", con)

            'Dim rs As New OleDb.OleDbCommand("insert into arrest1 values ('" + ComboBox1.Text + "','" + ComboBox2.Text + "','" + ComboBox3.Text + "','" + date1.Text + "','" + date2.Text + "','" + date3.Text + "','" + TextBox1.Text + "','" + ComboBox4.Text + "','" + ComboBox5.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + ComboBox27.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + ComboBox6.Text + "','" + ComboBox8.Text + "','" + ComboBox10.Text + "','" + TextBox10.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + date4.Text + "','" + ComboBox7.Text + "' ,'" + ComboBox9.Text + "' ,'" + TextBox11.Text + "','" + TextBox12.Text + "','" + TextBox13.Text + "','" + ComboBox11.Text + "','" + TextBox14.Text + "','" + TextBox15.Text + "','" + TextBox16.Text + "','" + TextBox17.Text + "','" + TextBox18.Text + "','" + TextBox19.Text + "','" + TextBox20.Text + "','" + TextBox21.Text + "','" + date5.Text + "','" + ComboBox12.Text + "','" + date6.Text + "','" + ComboBox13.Text + "','" + TextBox22.Text + "','" + TextBox23.Text + "','" + TextBox24.Text + "','" + TextBox25.Text + "','" + TextBox26.Text + "','" + TextBox27.Text + "','" + TextBox28.Text + "','" + TextBox29.Text + "','" + TextBox30.Text + "','" + TextBox31.Text + "','" + TextBox32.Text + "','" + TextBox33.Text + "','" + TextBox34.Text + "','" + TextBox35.Text + "','" + TextBox36.Text + "','" + TextBox37.Text + "','" + ComboBox14.Text + "','" + ComboBox15.Text + "','" + TextBox38.Text + "','" + ComboBox17.Text + "','" + ComboBox16.Text + "','" + ComboBox18.Text + "','" + ComboBox26.Text + "','" + ComboBox19.Text + "','" + ComboBox25.Text + "','" + ComboBox22.Text + "','" + ComboBox24.Text + "','" + ComboBox21.Text + "','" + ComboBox20.Text + "','" + ComboBox23.Text + "','" + TextBox39.Text + "','" + TextBox40.Text + "','" + TextBox42.Text + "','" + TextBox43.Text + "','" + TextBox44.Text + "','" + date9.Text + "','" + TextBox41.Text + "' )", con)
            '+ TextBox42.Text + "','" + TextBox43.Text + "','" + TextBox44.Text + "','" + date9.Text + "','" + TextBox41.Text + 
            'Dim rs As New MySqlCommand("insert into wardmember Values('" & txtid.Text & "','" & txtname.Text & " ','" & txtadd.Text & " ',' " & txtquali.Text & " ',' " & txtoccu.Text & "','" & txtcity.Text & "','" & txtcountry.Text & "','" & txtgender.Text & "','" & txtmob.Text & "','" & txtuid.Text & "')", mycon)
            Dim rs As New MySqlCommand("insert into  patientlogin Values('" & Trim(txtid.Text) & "','" &
                                       Trim(txtname.Text) & "','" &
                                            Trim(txtage.Text) & "','" &
                                             Trim(txtadd.Text) & "','" &
                                             Trim(txtcity.Text) & "','" &
                                             Trim(txtgender.Text) & "','" &
                                             Trim(txtmobile.Text) & "','" &
                                             Trim(txtmoble2.Text) & "','" &
                                             Trim(txtweight.Text) & "','" &
                                             Trim(txtheight.Text) & "','" &
                                              Trim(txtbloodgroup.Text) & "','" &
                                               Trim(txtselectward.Text) & "','" &
                                                Trim(txtselectwardno.Text) & "','" &
                                                 Trim(txtuid.Text) & "','" &
                                                  Trim(txtfees.Text) & "','" &
                                                   Trim(txtemail.Text) & "','" &
                                             Trim(txtdate1.Text) & "')", mycon)

            'Dim rs As New OleDb.OleDbCommand("insert into Tutorial_Micro Values('" & txtid.Text & "','" & txtfna.Text & " ','" & txtlna.Text & " ',' " & txtadd.Text & " ',' " & txtemail.Text & "','" & txtcno.Text & "','" & txtclgna.Text & "','" & txtbranch.Text & "','" & txtsem.Text & "','" & txtgender.Text & "','" & comboCourse.Text & "','" & DateTimePicker1.Text & "','" & txttotalfee.Text & "','" & txtfirstinstall.Text & "','" & txtsecondinstall.Text & "','" & txtthirdinstall.Text & "','" & txtbalance.Text & "')", con1)


            i = rs.ExecuteNonQuery()
            If i > 0 Then
                MessageBox.Show("Patient Admission Record Successfully.", "Process Completed", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Failed to update record!", "Failed...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

            mycon.Close()
        End If




    End Sub

    'end code

    Private Sub BunifuThinButton28_Click(sender As Object, e As EventArgs)
        BunifuThinButton23.Visible = False
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = False

        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = False
    End Sub

    Private Sub BunifuThinButton212_Click(sender As Object, e As EventArgs) Handles BunifuThinButton212.Click
        BunifuThinButton23.Visible = False
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = False

        BunifuThinButton213.Visible = True
        BunifuThinButton215.Visible = False
        Panel28.Visible = True


        cmbpid.Items.Clear()

        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            query = "select * from patientlogin"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("patient_id")
                Dim r As String

                cmbpid.Items.Add(disea1)

            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try


    End Sub

    Private Sub BunifuThinButton214_Click(sender As Object, e As EventArgs) Handles BunifuThinButton214.Click
        txtid.Text = ""
        txtname.Text = ""
        txtfirstname.Text = ""
        txtlastname.Text = ""

        'TextBox2.Text =
        txtadd.Text = ""


        txtmobile.Text = ""
        txtmoble2.Text = ""

        txtweight.Text = ""
        txtheight.Text = ""



        'txtselectwardno.Text = DataGridView1.Item(12, e.RowIndex).Value

        txtuid.Text = ""
        txtfees.Text = ""

        txtemail.Text = ""



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub bunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton2.Click

        TabControl1.SelectedTab = TabPage6



    End Sub

    Private Sub bunifuThinButton21_Click(sender As Object, e As EventArgs) Handles bunifuThinButton21.Click
        TabControl1.SelectedTab = TabPage1

        If Panel21.Visible = False Then

            BunifuTransition1.ShowSync(Panel21)
            Panel22.Visible = False

        Else

            BunifuTransition1.HideSync(Panel21)


        End If



    End Sub

    Private Sub bunifuImageButton1_Click(sender As Object, e As EventArgs) Handles bunifuImageButton1.Click

    End Sub

    Private Sub BunifuGradientPanel8_Paint(sender As Object, e As PaintEventArgs) Handles BunifuGradientPanel8.Paint

    End Sub

    Private Sub BunifuThinButton211_Click(sender As Object, e As EventArgs) Handles BunifuThinButton211.Click
        BunifuThinButton23.Visible = False
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = False

        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = True

        TabControl2.SelectedTab = TabPage11

    End Sub

    Private Sub BunifuFlatButton31_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton31.Click
        TabControl1.SelectedTab = TabPage5

        If Panel22.Visible = False Then

            BunifuTransition3.ShowSync(Panel22)
            Panel21.Visible = False


        Else

            BunifuTransition3.HideSync(Panel22)


        End If

    End Sub

    Private Sub GroupBox13_Enter(sender As Object, e As EventArgs) 

    End Sub

    Private Sub header_Paint(sender As Object, e As PaintEventArgs) Handles header.Paint

    End Sub

    Private Sub txtlastname_OnValueChanged(sender As Object, e As EventArgs) Handles txtlastname.OnValueChanged
        txtname.Text = txtfirstname.Text & " " & txtlastname.Text
    End Sub

    Private Sub bunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton1.Click
        TabControl1.SelectedTab = TabPage2
        TabControl2.SelectedTab = TabPage7
        Display_patientdata()

    End Sub

    'OTP Generation

    Public Sub otpgrn()
        'Dim charArr As Char() = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray()
        Dim charArr As Char() = My.Settings.otp.ToCharArray()

        Dim strrandom As String = String.Empty
        Dim objran As New Random()
        Dim noofcharacters As Integer = Convert.ToInt32(txtCharacters.Text)
        For i As Integer = 0 To noofcharacters - 1
            'It will not allow Repetation of Characters
            Dim pos As Integer = objran.[Next](1, charArr.Length)
            If Not strrandom.Contains(charArr.GetValue(pos).ToString()) Then
                strrandom += charArr.GetValue(pos)
            Else
                i -= 1
            End If
        Next
        nurpassword.Text = strrandom
    End Sub


    Public Sub doct_pass()
        'Dim charArr As Char() = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray()
        Dim charArr As Char() = My.Settings.otp1.ToCharArray()
        Dim strrandom As String = String.Empty
        Dim objran As New Random()
        Dim noofcharacters As Integer = Convert.ToInt32(txtcharacter2.Text)
        For i As Integer = 0 To noofcharacters - 1
            'It will not allow Repetation of Characters
            Dim pos As Integer = objran.[Next](1, charArr.Length)
            If Not strrandom.Contains(charArr.GetValue(pos).ToString()) Then
                strrandom += charArr.GetValue(pos)
            Else
                i -= 1
            End If
        Next
        txtdocpass.Text = strrandom
    End Sub


    Private Sub BunifuTextbox1_OnTextChange(sender As Object, e As EventArgs) Handles BunifuTextbox1.OnTextChange

    End Sub

    Private Sub BunifuTextbox1_KeyUp(sender As Object, e As EventArgs) Handles BunifuTextbox1.KeyUp
        mycon.Open()
        'Dim adap1 As New SqlDataAdapter("Select * From Tron Where Fname='" & ComboBox1.Text & "'", con)
        ' Dim adap1 As New MySqlDataAdapter("Select *  from tblvehicleregi where Registration_No  like '%" & TextBox1.Text & "%'", mycon)
        Dim adap1 As New MySqlDataAdapter("Select *  from patientlogin where CONCAT(patient_id,"" "",patient_name,"" "",rooms,"" "",room_no,"" "",uid) like '%" & BunifuTextbox1.text & "%'", mycon)

        ' sql = "SELECT * from student where CONCAT(fname,"" "", mname) like '%" & TextBox1.Text & "%'"

        Dim ds1 As New DataSet
        adap1.Fill(ds1, "patientlogin")
        mycon.Close()

        Dim t As DataTable = ds1.Tables("patientlogin")
        DataGridView1.DataSource = t

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            txtid.Text = DataGridView1.Item(0, e.RowIndex).Value
            txtname.Text = DataGridView1.Item(1, e.RowIndex).Value
            txtage.Text = DataGridView1.Item(2, e.RowIndex).Value



            'TextBox2.Text =
            txtadd.Text = DataGridView1.Item(3, e.RowIndex).Value
            txtcity.Text = DataGridView1.Item(4, e.RowIndex).Value
            txtgender.Text = DataGridView1.Item(5, e.RowIndex).Value
            txtmobile.Text = DataGridView1.Item(6, e.RowIndex).Value
            txtmoble2.Text = DataGridView1.Item(7, e.RowIndex).Value

            txtweight.Text = DataGridView1.Item(8, e.RowIndex).Value
            txtheight.Text = DataGridView1.Item(9, e.RowIndex).Value
            txtbloodgroup.Text = DataGridView1.Item(10, e.RowIndex).Value
            txtselectward.Text = DataGridView1.Item(11, e.RowIndex).Value

            txtselectwardno.Text = DataGridView1.Item(12, e.RowIndex).Value

            txtuid.Text = DataGridView1.Item(13, e.RowIndex).Value
            txtfees.Text = DataGridView1.Item(14, e.RowIndex).Value

            txtemail.Text = DataGridView1.Item(15, e.RowIndex).Value
            ''sample.Show()

            TabControl2.SelectedTab = TabPage7

        Catch ex As Exception

        End Try
    End Sub

    Private Sub BunifuThinButton28_Click_1(sender As Object, e As EventArgs) Handles BunifuThinButton28.Click
        mycon.Open()
        adap.SelectCommand = New MySqlCommand

        adap.SelectCommand.Connection = mycon
        'adap.SelectCommand.CommandText = "delete from AccountMaster1 ('" & txtacno.Text & "','" & txtna.Text & "','" & txtdoj.Text & "','" & txtadd.Text & "','" & txtcno.Text & "')"
        adap.SelectCommand.CommandText = "delete from patientlogin where patient_id= ('" & cmbpid.Text & "')"
        adap.SelectCommand.CommandType = CommandType.Text

        mycon.Close()

        adap.Fill(ds, "patientlogin")

        'bindingfields()
        MsgBox("Record Deleted From Record Successfully......", MsgBoxStyle.Information)

        Display_patientdata()

        cmbpid.Items.Clear()

        ' access data 

        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            query = "select * from patientlogin"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("patient_id")
                Dim r As String

                cmbpid.Items.Add(disea1)

            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try



    End Sub

    Private Sub BunifuThinButton29_Click(sender As Object, e As EventArgs) Handles BunifuThinButton29.Click
        Panel28.Visible = False

    End Sub

    'ward name
    Public Sub wardname_select()
        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            query = "select * from ward"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("ward_name")
                Dim r As String

                nurward1.Items.Add(disea1)
                'nurward1.Items.Add(disea1)


            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try
    End Sub


    Public Sub wardtype_select()
        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            query = "select * from wardtype"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("ward_type")
                Dim r As String

                txtselectward.Items.Add(disea1)
                'nurward1.Items.Add(disea1)


            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try
    End Sub
    'nurse id select
    Public Sub nurse_id_select()
        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            query = "select * from nurse"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("n_id")
                Dim r As String

                nurid1.Items.Add(disea1)

            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try
    End Sub
    Private Sub txtselectward_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtselectward.SelectedIndexChanged



        'If txtselectward.Text = "Ward" Then
        '    txtselectwardno.Items.Add("Ward 1")
        '    txtselectwardno.Items.Add("Ward 2")
        '    txtselectwardno.Items.Add("Ward 3")
        '    txtselectwardno.Items.Add("Ward 4")
        '    txtselectwardno.Items.Add("Ward 5")

        'ElseIf txtselectward.Text = "Room"

        '    txtselectwardno.Items.Add("Room 1")
        '    txtselectwardno.Items.Add("Room 2")
        '    txtselectwardno.Items.Add("Room 3")
        '    txtselectwardno.Items.Add("Room 4")
        '    txtselectwardno.Items.Add("Room 5")

        'End If

        txtselectwardno.Items.Clear()

        '        master()





        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            ' query = "select * from studentaddmission where admission_year='" & getyear.Text & "'"
            query = "select * from ward where ward_type='" & txtselectward.Text & "'"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("Ward_Name")
                'Dim disea2 = reader.GetString("admission_date")


                Dim r As String
                txtselectwardno.Items.Add(disea1)


            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try




    End Sub
    'hardware data access code
    Private Sub SensorComm_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SensorComm.DataReceived

        Sensorcomdata = SensorComm.ReadExisting
        'Try
        '    TextBox1.Text = Sensorcomdata

        'Catch ex As Exception
        '    MessageBox.Show(ex.Message)


        'End Try

    End Sub
    Private Sub BunifuFlatButton7_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton7.Click

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        textboxcom.Text = Sensorcomdata

    End Sub

    Private Sub BunifuFlatButton32_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton32.Click

        Try
            SensorComm.Dispose()

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try


    End Sub

    Private Sub bunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton4.Click
        addward.ShowDialog()



    End Sub

    Private Sub BunifuTileButton2_Click(sender As Object, e As EventArgs) Handles BunifuTileButton2.Click
        addward.ShowDialog()

    End Sub

    Private Sub BunifuThinButton210_Click(sender As Object, e As EventArgs) Handles BunifuThinButton210.Click
        TabControl1.SelectedTab = TabPage27

    End Sub


    'id
    Public Sub id_data()

        Dim oResult As String
        txtid.Text = 101

        Try

            mycon.Open()

            cmd = New MySqlCommand(" SELECT MAX(patient_id) AS LastId FROM patientlogin", mycon)
            oResult = cmd.ExecuteScalar()

            If oResult IsNot Nothing Then
                '                MsgBox(oResult.ToString)

                txtid.Text = oResult.ToString + 1

            Else

                MsgBox("No Record Found")

            End If

        Catch ex As Exception

            'MsgBox(ex.Message)
            'MsgBox("help")

        Finally
            mycon.Close()
        End Try

    End Sub


    Public Sub docid_data()

        Dim oResult As String
        txtdocid1.Text = 101

        Try

            mycon.Open()

            cmd = New MySqlCommand(" SELECT MAX(Doctor_Id) AS LastId FROM tbldoctor", mycon)
            oResult = cmd.ExecuteScalar()

            If oResult IsNot Nothing Then
                '                MsgBox(oResult.ToString)

                txtdocid1.Text = oResult.ToString + 1

            Else

                MsgBox("No Record Found")

            End If

        Catch ex As Exception

            'MsgBox(ex.Message)
            'MsgBox("help")

        Finally
            mycon.Close()
        End Try

    End Sub

    ' nurse id
    Public Sub nurse_id_data()

        Dim oResult As String
        nurid.Text = 1001

        Try

            mycon.Open()

            cmd = New MySqlCommand(" SELECT MAX(n_id) AS LastId FROM nurse", mycon)
            oResult = cmd.ExecuteScalar()

            If oResult IsNot Nothing Then
                '                MsgBox(oResult.ToString)

                nurid.Text = oResult.ToString + 1

            Else

                MsgBox("No Record Found")

            End If

        Catch ex As Exception

            'MsgBox(ex.Message)
            'MsgBox("help")

        Finally
            mycon.Close()
        End Try

    End Sub

    'end




    Private Sub txtuid_OnValueChanged(sender As Object, e As EventArgs) Handles txtuid.OnValueChanged

    End Sub

    Private Sub txtuid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtuid.KeyPress
        ' new log
        If txtuid.Text.Length >= 12 Then



            MsgBox("please enter 12 digit only")
            Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-.*_1234567890#+mnbvcxzlkjhgfdsapoiuytrewqZXCVBNMASDFDGHJKLIEQWERTYUIOP "

            'Allowed letters numbers and ( _ $ *)

            If e.KeyChar <> ControlChars.Back = True Then
                If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                    e.Handled = True
                End If
            End If


        Else

            Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-.*_#+mnbvcxzlkjhgfdsapoiuytrewqZXCVBNMASDFDGHJKLIEQWERTYUIOP "

            'Allowed letters numbers and ( _ $ *)

            If e.KeyChar <> ControlChars.Back = True Then
                If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                    e.Handled = True
                End If
            End If

        End If


    End Sub

    Private Sub txtweight_OnValueChanged(sender As Object, e As EventArgs) Handles txtweight.OnValueChanged

    End Sub

    Private Sub txtweight_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtweight.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+mnbvcxzlkjhgfdsapoiuytrewqZXCVBNMASDFDGHJKLIEQWERTYUIOP "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtmobile_OnValueChanged(sender As Object, e As EventArgs) Handles txtmobile.OnValueChanged

    End Sub

    Private Sub txtmobile_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtmobile.KeyPress
        If txtmobile.Text.Length >= 10 Then



            MsgBox("please enter 10 digit mobile number only")
            Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-.*_#+mnbvcxzlkjhgfdsapoiuytrewqZXCVBNMASDFDGHJKLIEQWERTYUIOP1234567890 "

            'Allowed letters numbers and ( _ $ *)

            If e.KeyChar <> ControlChars.Back = True Then
                If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                    e.Handled = True
                End If
            End If


        Else

            Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-.*_#+mnbvcxzlkjhgfdsapoiuytrewqZXCVBNMASDFDGHJKLIEQWERTYUIOP "

            'Allowed letters numbers and ( _ $ *)

            If e.KeyChar <> ControlChars.Back = True Then
                If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                    e.Handled = True
                End If
            End If

        End If


    End Sub

    Private Sub txtfirstname_OnValueChanged(sender As Object, e As EventArgs) Handles txtfirstname.OnValueChanged

    End Sub

    Private Sub txtfirstname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtfirstname.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+1234567890"

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtlastname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtlastname.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+0123456789"

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtname_OnValueChanged(sender As Object, e As EventArgs) Handles txtname.OnValueChanged

    End Sub

    Private Sub txtname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtname.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+1234567890"

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtfees_OnValueChanged(sender As Object, e As EventArgs) Handles txtfees.OnValueChanged

    End Sub

    Private Sub txtfees_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtfees.KeyPress

        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+mnbvcxzlkjhgfdsapoiuytrewqZXCVBNMASDFDGHJKLIEQWERTYUIOP "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
                If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                    e.Handled = True
                End If
            End If


    End Sub

    Private Sub bunifuFlatButton5_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton5.Click
        wardtype.ShowDialog()

    End Sub

    Private Sub BunifuTileButton3_Click(sender As Object, e As EventArgs) Handles BunifuTileButton3.Click
        roomtype.ShowDialog()


    End Sub

    Private Sub BunifuFlatButton38_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton38.Click
        TabControl5.SelectedTab = TabPage22
        BunifuFlatButton40.Enabled = True

    End Sub
    'nurse data insert

    Public Sub nurse_add_Data()

        ' TRUE LOGIC



        Dim a As Integer
        Dim i As Integer
        mycon.Open()

        sql = "Select * from nurse where n_id='" & txtid.Text & "'"



        ' sql = "Select * from Tutorial_Micro where Student_Id='" & txtid.Text & "' and Email_Id='" & txtemail.Text & "'"
        cmd = New MySqlCommand(sql, mycon)
        reader2 = cmd.ExecuteReader()

        While reader2.Read()
            a = 1
        End While
        mycon.Close()
        If a = 1 Then
            MsgBox(" ID Already exist.", MsgBoxStyle.Critical)

        Else
            mycon.Open()
            '        Dim rs As New SqlClient.SqlCommand("insert into arrest1 values ('" + ComboBox1.Text + "','" + ComboBox2.Text + "','" + ComboBox3.Text + "','" + date1.Text + "','" + date2.Text + "','" + date3.Text + "','" + TextBox1.Text + "','" + ComboBox4.Text + "','" + ComboBox5.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + ComboBox27.Text + "' )", con)

            'Dim rs As New OleDb.OleDbCommand("insert into arrest1 values ('" + ComboBox1.Text + "','" + ComboBox2.Text + "','" + ComboBox3.Text + "','" + date1.Text + "','" + date2.Text + "','" + date3.Text + "','" + TextBox1.Text + "','" + ComboBox4.Text + "','" + ComboBox5.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + ComboBox27.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + ComboBox6.Text + "','" + ComboBox8.Text + "','" + ComboBox10.Text + "','" + TextBox10.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + date4.Text + "','" + ComboBox7.Text + "' ,'" + ComboBox9.Text + "' ,'" + TextBox11.Text + "','" + TextBox12.Text + "','" + TextBox13.Text + "','" + ComboBox11.Text + "','" + TextBox14.Text + "','" + TextBox15.Text + "','" + TextBox16.Text + "','" + TextBox17.Text + "','" + TextBox18.Text + "','" + TextBox19.Text + "','" + TextBox20.Text + "','" + TextBox21.Text + "','" + date5.Text + "','" + ComboBox12.Text + "','" + date6.Text + "','" + ComboBox13.Text + "','" + TextBox22.Text + "','" + TextBox23.Text + "','" + TextBox24.Text + "','" + TextBox25.Text + "','" + TextBox26.Text + "','" + TextBox27.Text + "','" + TextBox28.Text + "','" + TextBox29.Text + "','" + TextBox30.Text + "','" + TextBox31.Text + "','" + TextBox32.Text + "','" + TextBox33.Text + "','" + TextBox34.Text + "','" + TextBox35.Text + "','" + TextBox36.Text + "','" + TextBox37.Text + "','" + ComboBox14.Text + "','" + ComboBox15.Text + "','" + TextBox38.Text + "','" + ComboBox17.Text + "','" + ComboBox16.Text + "','" + ComboBox18.Text + "','" + ComboBox26.Text + "','" + ComboBox19.Text + "','" + ComboBox25.Text + "','" + ComboBox22.Text + "','" + ComboBox24.Text + "','" + ComboBox21.Text + "','" + ComboBox20.Text + "','" + ComboBox23.Text + "','" + TextBox39.Text + "','" + TextBox40.Text + "','" + TextBox42.Text + "','" + TextBox43.Text + "','" + TextBox44.Text + "','" + date9.Text + "','" + TextBox41.Text + "' )", con)
            '+ TextBox42.Text + "','" + TextBox43.Text + "','" + TextBox44.Text + "','" + date9.Text + "','" + TextBox41.Text + 
            'Dim rs As New MySqlCommand("insert into wardmember Values('" & txtid.Text & "','" & txtname.Text & " ','" & txtadd.Text & " ',' " & txtquali.Text & " ',' " & txtoccu.Text & "','" & txtcity.Text & "','" & txtcountry.Text & "','" & txtgender.Text & "','" & txtmob.Text & "','" & txtuid.Text & "')", mycon)
            Dim rs As New MySqlCommand("insert into  nurse Values('" & Trim(nurid.Text) & "','" &
                                       Trim(nurfname.Text) & "','" &
                                            Trim(nurlname.Text) & "','" &
                                             Trim(nurdoj.Text) & "','" &
                                             Trim(nurdob.Text) & "','" &
                                             Trim(nurdesig.Text) & "','" &
                                             Trim(nurgen.Text) & "','" &
                                             Trim(nurmob.Text) & "','" &
                                             Trim(nuremail.Text) & "','" &
                                             Trim(nuradd.Text) & "','" &
                                              Trim(nurcity.Text) & "','" &
                                               Trim(nurstate.Text) & "','" &
                                                Trim(nurcountry.Text) & "','" &
                                                 Trim(nurpin.Text) & "','" &
                                             Trim(nurdate.Text) & "')", mycon)

            'Dim rs As New OleDb.OleDbCommand("insert into Tutorial_Micro Values('" & txtid.Text & "','" & txtfna.Text & " ','" & txtlna.Text & " ',' " & txtadd.Text & " ',' " & txtemail.Text & "','" & txtcno.Text & "','" & txtclgna.Text & "','" & txtbranch.Text & "','" & txtsem.Text & "','" & txtgender.Text & "','" & comboCourse.Text & "','" & DateTimePicker1.Text & "','" & txttotalfee.Text & "','" & txtfirstinstall.Text & "','" & txtsecondinstall.Text & "','" & txtthirdinstall.Text & "','" & txtbalance.Text & "')", con1)


            i = rs.ExecuteNonQuery()
            If i > 0 Then
                MessageBox.Show("Patient Admission Record Successfully.", "Process Completed", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Failed to update record!", "Failed...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

            mycon.Close()
        End If




    End Sub

    '  sms otp
    'sendsms
    ' for sms otp
    Public Sub sendmsg(ByVal sms As String, ByVal num As String)
        Dim cl As New Net.WebClient
        Dim apikey As String = "tRVRtUgikiKkj4R"
        cl.OpenRead("http://apivm.valuemobo.com/SMS/SMS_ApiKey.asmx/SMS_APIKeyNUC?apiKey=scsfLN06PP7pIhN&senderId=MCRTRN&cellNoList=" & num & "&msgText=" & sms)


    End Sub

    'nurse allocation

    Public Sub nurse_allocation_Data()

        ' TRUE LOGIC



        Dim a As Integer
        Dim i As Integer
        mycon.Open()

        sql = "Select * from wardallocation where n_id='" & nurid1.Text & "'"



        ' sql = "Select * from Tutorial_Micro where Student_Id='" & txtid.Text & "' and Email_Id='" & txtemail.Text & "'"
        cmd = New MySqlCommand(sql, mycon)
        reader2 = cmd.ExecuteReader()

        While reader2.Read()
            a = 1
        End While
        mycon.Close()
        If a = 1 Then
            MsgBox(" ID Already exist.", MsgBoxStyle.Critical)

        Else
            mycon.Open()
            '        Dim rs As New SqlClient.SqlCommand("insert into arrest1 values ('" + ComboBox1.Text + "','" + ComboBox2.Text + "','" + ComboBox3.Text + "','" + date1.Text + "','" + date2.Text + "','" + date3.Text + "','" + TextBox1.Text + "','" + ComboBox4.Text + "','" + ComboBox5.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + ComboBox27.Text + "' )", con)

            'Dim rs As New OleDb.OleDbCommand("insert into arrest1 values ('" + ComboBox1.Text + "','" + ComboBox2.Text + "','" + ComboBox3.Text + "','" + date1.Text + "','" + date2.Text + "','" + date3.Text + "','" + TextBox1.Text + "','" + ComboBox4.Text + "','" + ComboBox5.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + ComboBox27.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + ComboBox6.Text + "','" + ComboBox8.Text + "','" + ComboBox10.Text + "','" + TextBox10.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + date4.Text + "','" + ComboBox7.Text + "' ,'" + ComboBox9.Text + "' ,'" + TextBox11.Text + "','" + TextBox12.Text + "','" + TextBox13.Text + "','" + ComboBox11.Text + "','" + TextBox14.Text + "','" + TextBox15.Text + "','" + TextBox16.Text + "','" + TextBox17.Text + "','" + TextBox18.Text + "','" + TextBox19.Text + "','" + TextBox20.Text + "','" + TextBox21.Text + "','" + date5.Text + "','" + ComboBox12.Text + "','" + date6.Text + "','" + ComboBox13.Text + "','" + TextBox22.Text + "','" + TextBox23.Text + "','" + TextBox24.Text + "','" + TextBox25.Text + "','" + TextBox26.Text + "','" + TextBox27.Text + "','" + TextBox28.Text + "','" + TextBox29.Text + "','" + TextBox30.Text + "','" + TextBox31.Text + "','" + TextBox32.Text + "','" + TextBox33.Text + "','" + TextBox34.Text + "','" + TextBox35.Text + "','" + TextBox36.Text + "','" + TextBox37.Text + "','" + ComboBox14.Text + "','" + ComboBox15.Text + "','" + TextBox38.Text + "','" + ComboBox17.Text + "','" + ComboBox16.Text + "','" + ComboBox18.Text + "','" + ComboBox26.Text + "','" + ComboBox19.Text + "','" + ComboBox25.Text + "','" + ComboBox22.Text + "','" + ComboBox24.Text + "','" + ComboBox21.Text + "','" + ComboBox20.Text + "','" + ComboBox23.Text + "','" + TextBox39.Text + "','" + TextBox40.Text + "','" + TextBox42.Text + "','" + TextBox43.Text + "','" + TextBox44.Text + "','" + date9.Text + "','" + TextBox41.Text + "' )", con)
            '+ TextBox42.Text + "','" + TextBox43.Text + "','" + TextBox44.Text + "','" + date9.Text + "','" + TextBox41.Text + 
            'Dim rs As New MySqlCommand("insert into wardmember Values('" & txtid.Text & "','" & txtname.Text & " ','" & txtadd.Text & " ',' " & txtquali.Text & " ',' " & txtoccu.Text & "','" & txtcity.Text & "','" & txtcountry.Text & "','" & txtgender.Text & "','" & txtmob.Text & "','" & txtuid.Text & "')", mycon)
            Dim rs As New MySqlCommand("insert into  wardallocation Values('" & Trim(txtsral.Text) & "','" &
                                        Trim(nurid1.Text) & "','" &
                                       Trim(nurfname1.Text) & "','" &
                                            Trim(nurlname1.Text) & "','" &
                                             Trim(nurdesig.Text) & "','" &
                                             Trim(nurmob.Text) & "','" &
                                                Trim(nurward1.Text) & "','" &
                                                 Trim(nurusername.Text) & "','" &
                                             Trim(nurpassword.Text) & "')", mycon)

            'Dim rs As New OleDb.OleDbCommand("insert into Tutorial_Micro Values('" & txtid.Text & "','" & txtfna.Text & " ','" & txtlna.Text & " ',' " & txtadd.Text & " ',' " & txtemail.Text & "','" & txtcno.Text & "','" & txtclgna.Text & "','" & txtbranch.Text & "','" & txtsem.Text & "','" & txtgender.Text & "','" & comboCourse.Text & "','" & DateTimePicker1.Text & "','" & txttotalfee.Text & "','" & txtfirstinstall.Text & "','" & txtsecondinstall.Text & "','" & txtthirdinstall.Text & "','" & txtbalance.Text & "')", con1)


            i = rs.ExecuteNonQuery()
            If i > 0 Then
                MessageBox.Show("Data Add Successfully.", "Process Completed", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Failed to update record!", "Failed...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

            mycon.Close()
        End If




    End Sub
    Private Sub BunifuFlatButton40_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton40.Click
        'nurse_id_select()
        nurid1.Items.Clear()
        nurse_id_select()
        nurse_add_Data()
        Display_nurse()
        nurfname.Text = ""
        nurlname.Text = ""
        nurmob.Text = ""
        nurpin.Text = ""
        nuremail.Text = ""
        nuradd.Text = ""
        nurfname.Focus()


    End Sub

    Private Sub nurid1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles nurid1.SelectedIndexChanged
        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            ' query = "select * from studentaddmission where admission_year='" & getyear.Text & "'"
            query = "select * from nurse where n_id='" & nurid1.Text & "'"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim fna = reader.GetString("first_name")
                Dim lna = reader.GetString("last_name")
                Dim desg = reader.GetString("designation")
                Dim mob = reader.GetString("mobile")


                Dim r As String
                'txtselectwardno.Items.Add(disea1)
                nurfname1.Text = fna
                nurlname1.Text = lna

                nurdesig1.Text = desg
                nurmob1.Text = mob
                nurusername.Text = fna + lna
                nurusername.Text = LCase(nurusername.Text)

            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try


    End Sub

    Private Sub BunifuTileButton4_Click(sender As Object, e As EventArgs) Handles BunifuTileButton4.Click
        wardtype.ShowDialog()

    End Sub

    Private Sub BunifuFlatButton12_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton12.Click
        Try
            If nurward1.Text <> "" Then
                nurse_allocation_Data()
                sendmsg(txtmsg.Text, nurmob1.Text)
            Else
                MsgBox("Please Select Ward")

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub BunifuFlatButton13_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton13.Click
        nurfname1.Text = ""
        nurlname1.Text = ""
        nurdesig1.Text = ""
        nurmob1.Text = ""
        nurusername.Text = ""
        nurpassword.Text = ""
        nurward1.Items.Clear()
        wardname_select()
        otpgrn()


    End Sub

    Private Sub BunifuFlatButton34_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton34.Click
        nurid1.Items.Clear()

        nurse_id_select()
        TabControl5.SelectedTab = TabPage23
        BunifuFlatButton40.Enabled = False

    End Sub

    Private Sub BunifuFlatButton39_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton39.Click
        nurfname.Text = ""
        nurlname.Text = ""
        nurmob.Text = ""
        nurpin.Text = ""
        nuremail.Text = ""
        nuradd.Text = ""


    End Sub

    Private Sub nurward1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles nurward1.SelectedIndexChanged
        txtmsg.Text = "dear Sister " + nurfname1.Text + " " + nurlname1.Text + vbCrLf + " your registration is successfully complete" + vbCrLf + "and Your ward allocated is- " + nurward1.Text + "username: " + nurusername.Text + " Password: " + nurpassword.Text

    End Sub

    Private Sub BunifuThinButton219_Click(sender As Object, e As EventArgs) Handles BunifuThinButton219.Click
        TabControl2.SelectedTab = TabPage7

    End Sub

    Private Sub BunifuFlatButton35_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton35.Click
        TabControl5.SelectedTab = TabPage24

    End Sub

    Private Sub txtid_OnValueChanged(sender As Object, e As EventArgs) Handles txtid.OnValueChanged

    End Sub

    Private Sub BunifuFlatButton36_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton36.Click
        TabControl5.SelectedTab = TabPage22

    End Sub

    Private Sub Panel21_Paint(sender As Object, e As PaintEventArgs) Handles Panel21.Paint

    End Sub

    Private Sub bunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton6.Click
        'MsgBox("Work Is Under Process", MsgBoxStyle.Information + MsgBoxStyle.OkOnly + MsgBoxStyle.SystemModal, "Patient Monitoring System")
        docid_data()
        TabControl1.SelectedTab = TabPage28


    End Sub

    Private Sub bunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton3.Click

    End Sub

    Private Sub BunifuFlatButton42_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton42.Click

    End Sub

    Private Sub BunifuThinButton271_Click(sender As Object, e As EventArgs) Handles BunifuThinButton271.Click
        doct_pass()

    End Sub
    'doctor add 

    Public Sub doctor_add()

        ' TRUE LOGIC



        Dim a As Integer
        Dim i As Integer
        mycon.Open()

        sql = "Select * from tbldoctor where Doctor_Id='" & txtdocid1.Text & "'"



        ' sql = "Select * from Tutorial_Micro where Student_Id='" & txtid.Text & "' and Email_Id='" & txtemail.Text & "'"
        cmd = New MySqlCommand(sql, mycon)
        reader2 = cmd.ExecuteReader()

        While reader2.Read()
            a = 1
        End While
        mycon.Close()
        If a = 1 Then
            MsgBox(" ID Already exist.", MsgBoxStyle.Critical)

        Else
            mycon.Open()

            Dim rs As New MySqlCommand("insert into  tbldoctor Values('" & Trim(txtdocid.Text) & "','" &
                                        Trim(txtdocid1.Text) & "','" &
                                        Trim(txtdocfullname.Text) & "','" &
                                        Trim(txtdocdob.Text) & "','" &
                                        Trim(txtdocquali.Text) & "','" &
                                        Trim(txtdocmobile.Text) & "','" &
                                        Trim(txtdocaddress.Text) & "','" &
                                            Trim(txtdoccat.Text) & "','" &
                                             Trim(txtdocusername.Text) & "','" &
                                             Trim(txtdocpass.Text) & "','" &
                                             Trim(txtdocdate.Text) & "')", mycon)


            i = rs.ExecuteNonQuery()
            If i > 0 Then
                MessageBox.Show("Data Add Successfully.", "Process Completed", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Failed to update record!", "Failed...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

            mycon.Close()
        End If




    End Sub
    Private Sub BunifuThinButton269_Click(sender As Object, e As EventArgs) Handles BunifuThinButton269.Click
        doctor_add()
        doct_pass()
        docid_data()

        sendmsg(msg2.Text, txtdocmobile.Text)


    End Sub

    Private Sub BunifuMetroTextbox11_OnValueChanged(sender As Object, e As EventArgs) Handles txtdocid1.OnValueChanged

    End Sub

    Private Sub BunifuMetroTextbox10_OnValueChanged(sender As Object, e As EventArgs) Handles txtdocfname.OnValueChanged

    End Sub

    Private Sub BunifuMetroTextbox8_OnValueChanged(sender As Object, e As EventArgs) Handles txtdocmobile.OnValueChanged
        msg2.Text = "Dear Dr." + txtdocfullname.Text + " your registration is successfully completed" + vbCrLf + " User Id: " + txtdocusername.Text + vbCrLf + "Password: " + txtdocpass.Text



    End Sub

    Private Sub txtdid_OnValueChanged(sender As Object, e As EventArgs) Handles txtdocid.OnValueChanged

    End Sub

    Private Sub BunifuTextbox5_OnTextChange(sender As Object, e As EventArgs) Handles BunifuTextbox5.OnTextChange

    End Sub

    Private Sub BunifuTextbox5_KeyUp(sender As Object, e As EventArgs) Handles BunifuTextbox5.KeyUp
        mycon.Open()
        'Dim adap1 As New SqlDataAdapter("Select * From Tron Where Fname='" & ComboBox1.Text & "'", con)
        ' Dim adap1 As New MySqlDataAdapter("Select *  from tblvehicleregi where Registration_No  like '%" & TextBox1.Text & "%'", mycon)
        Dim adap1 As New MySqlDataAdapter("select Doctor_Id,Name,Birth_Date,Qualification,Mobile,Address,Catagory from tbldoctor where CONCAT(Doctor_Id,"" "",Name,"" "",Mobile,"" "",Address,"" "",Catagory) like '%" & BunifuTextbox5.text & "%'", mycon)

        ' sql = "SELECT * from student where CONCAT(fname,"" "", mname) like '%" & TextBox1.Text & "%'"

        Dim ds1 As New DataSet
        adap1.Fill(ds1, "tbldoctor")
        mycon.Close()

        Dim t As DataTable = ds1.Tables("tbldoctor")
        BunifuCustomDataGrid1.DataSource = t

    End Sub

    Private Sub BunifuFlatButton41_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton41.Click
        TabControl6.SelectedTab = TabPage29

    End Sub

    Private Sub BunifuFlatButton33_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton33.Click
        TabControl6.SelectedTab = TabPage30


    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles BunifuCustomDataGrid1.CellContentClick
        Try



            'TextBox2.Text =
            txtdocdelete.Text = BunifuCustomDataGrid1.Item(0, e.RowIndex).Value
            'txtdocfullname.Text = BunifuCustomDataGrid1.Item(1, e.RowIndex).Value
            'txtdocdob.Text = BunifuCustomDataGrid1.Item(2, e.RowIndex).Value
            'txtdocquali.Text = BunifuCustomDataGrid1.Item(3, e.RowIndex).Value
            'txtdocmobile.Text = BunifuCustomDataGrid1.Item(4, e.RowIndex).Value

            'txtdocaddress.Text = BunifuCustomDataGrid1.Item(5, e.RowIndex).Value
            'txtdoccat.Text = BunifuCustomDataGrid1.Item(6, e.RowIndex).Value
            'txtdocusername.Text = BunifuCustomDataGrid1.Item(7, e.RowIndex).Value

            ''sample.Show()

            'TabControl6.SelectedTab = TabPage29

        Catch ex As Exception

        End Try
    End Sub

    Private Sub BunifuThinButton273_Click(sender As Object, e As EventArgs) Handles BunifuThinButton273.Click
        If txtdocdelete.Text <> "" Then
            mycon.Open()
            adap.SelectCommand = New MySqlCommand

            adap.SelectCommand.Connection = mycon
            'adap.SelectCommand.CommandText = "delete from AccountMaster1 ('" & txtacno.Text & "','" & txtna.Text & "','" & txtdoj.Text & "','" & txtadd.Text & "','" & txtcno.Text & "')"
            adap.SelectCommand.CommandText = "delete from tbldoctor where Doctor_Id= ('" & txtdocdelete.Text & "')"
            adap.SelectCommand.CommandType = CommandType.Text

            mycon.Close()

            adap.Fill(ds, "tbldoctor")

            'bindingfields()
            MsgBox("Record Deleted From Record Successfully......", MsgBoxStyle.Information)

            Display_doctor()


        Else
            MsgBox("Please select data for delete... ")

        End If


    End Sub

    Private Sub BunifuThinButton264_Click(sender As Object, e As EventArgs) Handles BunifuThinButton264.Click
        TabControl6.SelectedTab = TabPage29

    End Sub

    Private Sub BunifuThinButton266_Click(sender As Object, e As EventArgs) Handles BunifuThinButton266.Click
        TabControl6.SelectedTab = TabPage30

    End Sub

    Private Sub BunifuMetroTextbox1_OnValueChanged(sender As Object, e As EventArgs) Handles txtdoclname.OnValueChanged
        txtdocusername.Text = LCase(txtdocfname.Text) + LCase(txtdoclname.Text)

    End Sub

    Private Sub txtdoclname_Leave(sender As Object, e As EventArgs) Handles txtdoclname.Leave
        If txtdoclname.Text = "" Then
            txtdoclname.Focus()

        End If

        txtdocfullname.Text = txtdocfname.Text + " " + txtdoclname.Text

    End Sub

    Private Sub txtdocfname_Leave(sender As Object, e As EventArgs) Handles txtdocfname.Leave
        If txtdocfname.Text = "" Then
            txtdocfname.Focus()

        End If
    End Sub

    Private Sub txtdocquali_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtdocquali.SelectedIndexChanged

    End Sub

    Private Sub txtdocquali_Leave(sender As Object, e As EventArgs) Handles txtdocquali.Leave
        If txtdocquali.Text = "" Then
            txtdocquali.Focus()

        End If
    End Sub

    Private Sub txtdocmobile_Leave(sender As Object, e As EventArgs) Handles txtdocmobile.Leave
        If txtdocmobile.Text = "" Then
            txtdocmobile.Focus()

        End If
    End Sub

    Private Sub txtdocaddress_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtdocaddress.SelectedIndexChanged

    End Sub

    Private Sub txtdocaddress_Leave(sender As Object, e As EventArgs) Handles txtdocaddress.Leave
        If txtdocaddress.Text = "" Then
            txtdocaddress.Focus()

        End If
    End Sub

    Private Sub txtdoccat_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtdoccat.SelectedIndexChanged

    End Sub

    Private Sub txtdoccat_Leave(sender As Object, e As EventArgs) Handles txtdoccat.Leave
        If txtdoccat.Text = "" Then
            txtdoccat.Focus()

        End If
    End Sub

    Private Sub nurfname_OnValueChanged(sender As Object, e As EventArgs) Handles nurfname.OnValueChanged

    End Sub

    Private Sub nurfname_Leave(sender As Object, e As EventArgs) Handles nurfname.Leave
        If nurfname.Text = "" Then
            nurfname.Focus()

        End If
    End Sub

    Private Sub nurlname_OnValueChanged(sender As Object, e As EventArgs) Handles nurlname.OnValueChanged

    End Sub

    Private Sub txtdocfullname_OnValueChanged(sender As Object, e As EventArgs) Handles txtdocfullname.OnValueChanged

    End Sub

    Private Sub nurdesig_OnValueChanged(sender As Object, e As EventArgs) Handles nurdesig.OnValueChanged

    End Sub

    Private Sub nurdesig_Leave(sender As Object, e As EventArgs) Handles nurdesig.Leave
        If nurdesig.Text = "" Then
            nurdesig.Focus()

        End If
    End Sub

    Private Sub nurgen_SelectedIndexChanged(sender As Object, e As EventArgs) Handles nurgen.SelectedIndexChanged

    End Sub

    Private Sub nurgen_Leave(sender As Object, e As EventArgs) Handles nurgen.Leave
        If nurgen.Text = "" Then
            nurgen.Focus()

        End If
    End Sub

    Private Sub nurmob_Leave(sender As Object, e As EventArgs) Handles nurmob.Leave
        If nurmob.Text = "" Then
            nurmob.Focus()

        End If
    End Sub

    Private Sub nurpin_Leave(sender As Object, e As EventArgs) Handles nurpin.Leave
        If nurpin.Text = "" Then
            nurpin.Focus()

        End If
    End Sub

    Private Sub nurstate_Leave(sender As Object, e As EventArgs) Handles nurstate.Leave
        If nurstate.Text = "" Then
            nurstate.Focus()

        End If
    End Sub

    Private Sub nuremail_OnValueChanged(sender As Object, e As EventArgs) Handles nuremail.OnValueChanged

    End Sub

    Private Sub nuremail_Leave(sender As Object, e As EventArgs) Handles nuremail.Leave
        If nuremail.Text = "" Then
            nuremail.Focus()

        End If
    End Sub

    Private Sub nurfname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nurfname.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+1234567890 "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub nurlname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nurlname.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+1234567890 "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub nurmob_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nurmob.KeyPress
        Dim NotAllowed As String = "~`@%^&={[}]()!:,;'><?/|\-*_#+mnbvcxzlkjhgfdsapoiuytrewqZXCVBNMASDFDGHJKLIEQWERTYUIOP "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub nurstate_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nurstate.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+1234567890 "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub nurdesig_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nurdesig.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+1234567890 "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub nurgen_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nurgen.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+1234567890 "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub nurmob_OnValueChanged(sender As Object, e As EventArgs) Handles nurmob.OnValueChanged

    End Sub

    Private Sub nuradd_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nuradd.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\*_#+"

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub nurcity_Leave(sender As Object, e As EventArgs) Handles nurcity.Leave
        If nurcity.Text = "" Then
            nurcity.Focus()

        End If
    End Sub

    Private Sub nurcity_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nurcity.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+1234567890 "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub nurcountry_Leave(sender As Object, e As EventArgs) Handles nurcountry.Leave
        If nurcountry.Text = "" Then
            nurcountry.Focus()

        End If
    End Sub

    Private Sub nurcountry_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nurcountry.KeyPress
        Dim NotAllowed As String = "~`@%^&+={[}]()!:,;'><?/|\-*_#+1234567890 "

        'Allowed letters numbers and ( _ $ *)

        If e.KeyChar <> ControlChars.Back = True Then
            If NotAllowed.IndexOf(e.KeyChar) = -1 = False Then
                e.Handled = True
            End If
        End If
    End Sub
End Class
