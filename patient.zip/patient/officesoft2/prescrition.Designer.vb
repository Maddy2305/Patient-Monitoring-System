﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class prescrition
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtpatient = New System.Windows.Forms.Label()
        Me.txtpdisease = New System.Windows.Forms.Label()
        Me.txtpdate = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.docname1 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.med1 = New System.Windows.Forms.Label()
        Me.dose1 = New System.Windows.Forms.Label()
        Me.time1 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.med2 = New System.Windows.Forms.Label()
        Me.dose2 = New System.Windows.Forms.Label()
        Me.time2 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.med3 = New System.Windows.Forms.Label()
        Me.dose3 = New System.Windows.Forms.Label()
        Me.time3 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.bunifuFlatButton1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 3
        Me.BunifuElipse1.TargetControl = Me
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Panel1.Controls.Add(Me.bunifuFlatButton1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(662, 17)
        Me.Panel1.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.officesoft2.My.Resources.Resources.preimg
        Me.PictureBox1.Location = New System.Drawing.Point(20, 37)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(319, 113)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(1, 160)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(665, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "_________________________________________________________________________________" &
    "_____________"
        '
        'txtpatient
        '
        Me.txtpatient.AutoSize = True
        Me.txtpatient.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpatient.ForeColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.txtpatient.Location = New System.Drawing.Point(16, 192)
        Me.txtpatient.Name = "txtpatient"
        Me.txtpatient.Size = New System.Drawing.Size(155, 20)
        Me.txtpatient.TabIndex = 3
        Me.txtpatient.Text = "Ashwini Thakare"
        '
        'txtpdisease
        '
        Me.txtpdisease.AutoSize = True
        Me.txtpdisease.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpdisease.Location = New System.Drawing.Point(16, 216)
        Me.txtpdisease.Name = "txtpdisease"
        Me.txtpdisease.Size = New System.Drawing.Size(107, 18)
        Me.txtpdisease.TabIndex = 4
        Me.txtpdisease.Text = "28 Yrs, Female"
        '
        'txtpdate
        '
        Me.txtpdate.AutoSize = True
        Me.txtpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpdate.Location = New System.Drawing.Point(16, 236)
        Me.txtpdate.Name = "txtpdate"
        Me.txtpdate.Size = New System.Drawing.Size(159, 18)
        Me.txtpdate.TabIndex = 5
        Me.txtpdate.Text = "28 Jan 2019, 12:30 PM"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(-1, 289)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(665, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "_________________________________________________________________________________" &
    "_____________"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(16, 310)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(283, 51)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "1. drink Salt water twice a day" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "2. Avoide cold exposure for few days" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "3. apply a" &
    " hot pack to your throat and chest"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(16, 273)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(200, 20)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Recommended Action"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(-1, 394)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(665, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "_________________________________________________________________________________" &
    "_____________"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(16, 376)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(140, 20)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "RX. Medication"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(460, 79)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 18)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "MD Surgen"
        '
        'docname1
        '
        Me.docname1.AutoSize = True
        Me.docname1.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.docname1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.docname1.Location = New System.Drawing.Point(460, 54)
        Me.docname1.Name = "docname1"
        Me.docname1.Size = New System.Drawing.Size(185, 20)
        Me.docname1.TabIndex = 12
        Me.docname1.Text = "Dr. Gaurang Sabane"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.651898!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.03798!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.41139!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.21519!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label16, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label18, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.med1, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.dose1, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.time1, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.med2, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.dose2, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.time2, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label28, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.med3, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.dose3, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.time3, 3, 3)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(12, 417)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(633, 186)
        Me.TableLayoutPanel1.TabIndex = 15
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(4, 1)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(54, 35)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "SR."
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(65, 1)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(263, 35)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Medicine"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(335, 1)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(121, 35)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Dose"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(463, 1)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(166, 35)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "Instruction, If Any"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.White
        Me.Label18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(4, 37)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(54, 50)
        Me.Label18.TabIndex = 5
        Me.Label18.Text = "1."
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'med1
        '
        Me.med1.AutoSize = True
        Me.med1.BackColor = System.Drawing.Color.White
        Me.med1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.med1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.med1.Location = New System.Drawing.Point(65, 37)
        Me.med1.Name = "med1"
        Me.med1.Size = New System.Drawing.Size(263, 50)
        Me.med1.TabIndex = 6
        Me.med1.Text = "med1"
        Me.med1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dose1
        '
        Me.dose1.AutoSize = True
        Me.dose1.BackColor = System.Drawing.Color.White
        Me.dose1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dose1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dose1.Location = New System.Drawing.Point(335, 37)
        Me.dose1.Name = "dose1"
        Me.dose1.Size = New System.Drawing.Size(121, 50)
        Me.dose1.TabIndex = 7
        Me.dose1.Text = "dose1"
        Me.dose1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'time1
        '
        Me.time1.AutoSize = True
        Me.time1.BackColor = System.Drawing.Color.White
        Me.time1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.time1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.time1.Location = New System.Drawing.Point(463, 37)
        Me.time1.Name = "time1"
        Me.time1.Size = New System.Drawing.Size(166, 50)
        Me.time1.TabIndex = 8
        Me.time1.Text = "time1"
        Me.time1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.White
        Me.Label23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(4, 88)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(54, 50)
        Me.Label23.TabIndex = 10
        Me.Label23.Text = "2."
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'med2
        '
        Me.med2.AutoSize = True
        Me.med2.BackColor = System.Drawing.Color.White
        Me.med2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.med2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.med2.Location = New System.Drawing.Point(65, 88)
        Me.med2.Name = "med2"
        Me.med2.Size = New System.Drawing.Size(263, 50)
        Me.med2.TabIndex = 11
        Me.med2.Text = "med2"
        Me.med2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dose2
        '
        Me.dose2.AutoSize = True
        Me.dose2.BackColor = System.Drawing.Color.White
        Me.dose2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dose2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dose2.Location = New System.Drawing.Point(335, 88)
        Me.dose2.Name = "dose2"
        Me.dose2.Size = New System.Drawing.Size(121, 50)
        Me.dose2.TabIndex = 12
        Me.dose2.Text = "dose2"
        Me.dose2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'time2
        '
        Me.time2.AutoSize = True
        Me.time2.BackColor = System.Drawing.Color.White
        Me.time2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.time2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.time2.Location = New System.Drawing.Point(463, 88)
        Me.time2.Name = "time2"
        Me.time2.Size = New System.Drawing.Size(166, 50)
        Me.time2.TabIndex = 13
        Me.time2.Text = "time2"
        Me.time2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.White
        Me.Label28.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(4, 139)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(54, 50)
        Me.Label28.TabIndex = 15
        Me.Label28.Text = "3."
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'med3
        '
        Me.med3.AutoSize = True
        Me.med3.BackColor = System.Drawing.Color.White
        Me.med3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.med3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.med3.Location = New System.Drawing.Point(65, 139)
        Me.med3.Name = "med3"
        Me.med3.Size = New System.Drawing.Size(263, 50)
        Me.med3.TabIndex = 16
        Me.med3.Text = "med3"
        Me.med3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dose3
        '
        Me.dose3.AutoSize = True
        Me.dose3.BackColor = System.Drawing.Color.White
        Me.dose3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dose3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dose3.Location = New System.Drawing.Point(335, 139)
        Me.dose3.Name = "dose3"
        Me.dose3.Size = New System.Drawing.Size(121, 50)
        Me.dose3.TabIndex = 17
        Me.dose3.Text = "dose3"
        Me.dose3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'time3
        '
        Me.time3.AutoSize = True
        Me.time3.BackColor = System.Drawing.Color.White
        Me.time3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.time3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.time3.Location = New System.Drawing.Point(463, 139)
        Me.time3.Name = "time3"
        Me.time3.Size = New System.Drawing.Size(166, 50)
        Me.time3.TabIndex = 18
        Me.time3.Text = "time3"
        Me.time3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.Label17.Location = New System.Drawing.Point(7, 591)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(637, 13)
        Me.Label17.TabIndex = 16
        Me.Label17.Text = "_________________________________________________________________________________" &
    "_________"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'bunifuFlatButton1
        '
        Me.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton1.BorderRadius = 0
        Me.bunifuFlatButton1.ButtonText = "Close"
        Me.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton1.Iconimage = Nothing
        Me.bunifuFlatButton1.Iconimage_right = Nothing
        Me.bunifuFlatButton1.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton1.Iconimage_Selected = Nothing
        Me.bunifuFlatButton1.IconMarginLeft = 0
        Me.bunifuFlatButton1.IconMarginRight = 0
        Me.bunifuFlatButton1.IconRightVisible = True
        Me.bunifuFlatButton1.IconRightZoom = 0R
        Me.bunifuFlatButton1.IconVisible = True
        Me.bunifuFlatButton1.IconZoom = 60.0R
        Me.bunifuFlatButton1.IsTab = True
        Me.bunifuFlatButton1.Location = New System.Drawing.Point(605, 0)
        Me.bunifuFlatButton1.Name = "bunifuFlatButton1"
        Me.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(202, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton1.selected = False
        Me.bunifuFlatButton1.Size = New System.Drawing.Size(67, 17)
        Me.bunifuFlatButton1.TabIndex = 17
        Me.bunifuFlatButton1.Text = "Close"
        Me.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.bunifuFlatButton1.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'prescrition
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(662, 650)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.docname1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtpdate)
        Me.Controls.Add(Me.txtpdisease)
        Me.Controls.Add(Me.txtpatient)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label17)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "prescrition"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "prescrition"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label11 As Label
    Friend WithEvents docname1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtpdate As Label
    Friend WithEvents txtpdisease As Label
    Friend WithEvents txtpatient As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents med1 As Label
    Friend WithEvents dose1 As Label
    Friend WithEvents time1 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents med2 As Label
    Friend WithEvents dose2 As Label
    Friend WithEvents time2 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents med3 As Label
    Friend WithEvents dose3 As Label
    Friend WithEvents time3 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Timer1 As Timer
    Private WithEvents bunifuFlatButton1 As Bunifu.Framework.UI.BunifuFlatButton
End Class
