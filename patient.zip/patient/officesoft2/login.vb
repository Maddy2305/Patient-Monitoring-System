﻿Imports MySql.Data.MySqlClient
Imports MySql.Data


Public Class login
    'Public ward As String = ""
    Public Sub Login_Add()
        Try
            mycon.Open()
            'Dim dr As OleDb.OleDbDataReader
            Dim dr As MySqlDataReader

            'Dim cmd As New SqlClient.SqlCommand("select * from userid where userid=" + TextBox1.Text + "and password=" + TextBox2.Text + "", con)
            Dim cmd As New MySqlCommand("Select * from wardallocation where username = '" & txtusername.Text & "' and password = '" & txtpassword.Text & "'", mycon)
            dr = cmd.ExecuteReader
            If dr.Read Then
                Dim obj As New patientdata
                obj.Show()
                obj.MdiParent = mainform
                Me.Hide()

                MsgBox("Login Successfull", MsgBoxStyle.Exclamation)


            Else
                MsgBox("Invalid Login Name...", MsgBoxStyle.Critical)

            End If
            mycon.Close()

        Catch ex As Exception

            'MessageBox.Show(ex.Message)
        Finally
            mycon.Dispose()

        End Try

        mycon.Close()

    End Sub


    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        If txtusername.Text = "admin" And txtpassword.Text = "123" Then
            Dim obj As New Form1
            obj.Show()
            obj.MdiParent = mainform
            Me.Hide()


        ElseIf txtusername.Text <> "admin" And txtpassword.Text <> "123" Then






            Dim reader As MySqlDataReader
            Dim obj As String
            Dim obj1 As String


            'txtdoctor.Items.Clear()
            Try
                mycon.Open()
                Dim query As String
                query = "select * from wardallocation where username='" & txtusername.Text & "'"

                cmd = New MySqlCommand(query, mycon)
                reader = cmd.ExecuteReader
                While reader.Read
                    obj = reader.GetString("ward")
                    'obj1 = reader.GetString("Doctor_Id")
                    'txtdoctor.Items.Add(obj)
                    'txtdocid.Text = obj1
                    ward = obj

                End While
                mycon.Close()

            Catch ex As Exception
                MessageBox.Show(ex.Message)


            Finally
                mycon.Dispose()

            End Try

            Login_Add()
        End If
    End Sub
End Class