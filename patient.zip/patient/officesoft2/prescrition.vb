﻿Imports MySql.Data.MySqlClient

Public Class prescrition
    'Public med1, med2, med3 As String



    Private Sub prescrition_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'medicine

        med1.Text = medd1
        med2.Text = medd2
        med3.Text = medd3

        'dose
        dose1.Text = dosee1
        dose2.Text = dosee2
        dose3.Text = dosee3

        'time
        time1.Text = timee1
        time2.Text = timee2
        time3.Text = timee3

        'doctor
        docname1.Text = "Dr. " + docname
        'txtcontact.Text = "Contact: " + mobl

        txtpdisease.Text = "Disease: " + pdisease

        txtpdate.Text = "Prescription Date: " + pdate

        txtpatient.Text = patient





    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick



    End Sub

    Private Sub bunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton1.Click
        Close()


    End Sub
End Class