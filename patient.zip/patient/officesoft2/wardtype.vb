﻿Imports MySql.Data.MySqlClient
Public Class wardtype
    Dim adap As New MySqlDataAdapter("select * from wardtype", mycon)
    Dim z As String

    Dim ds As New DataSet
    Dim dv As New DataView
    Dim cm As CurrencyManager
    'add wardtype
    Public Sub Add_Data()

        Dim a As Integer
        Dim i As Integer

        mycon.Open()

        Dim rs As New MySqlCommand("insert into  wardtype Values('" & Trim(txtsr.Text) & "','" & Trim(txtwardtype.Text) & "')", mycon)

        i = rs.ExecuteNonQuery()
        If i > 0 Then
            MessageBox.Show("Data Submit Successfully.", "Process Completed", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("Failed to update record!", "Failed...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

        mycon.Close()

    End Sub

    Public Sub Display_Data1()

        mycon.Open()

        Dim dt As New DataTable("wardtype")
        Dim rs As New MySqlDataAdapter("select * from wardtype", mycon)
        rs.Fill(dt)
        BunifuCustomDataGrid1.DataSource = dt
        BunifuCustomDataGrid1.Refresh()
        'Label1.Text = dt.Rows.Count
        rs.Dispose()
        mycon.Close()

    End Sub

    Private Sub bunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton1.Click
        txtsr.Enabled = True

        txtwardtype.Enabled = True

        txtsr.Text = ""
        txtwardtype.Text = ""
        txtwardtype.Focus()
        sr_data()


    End Sub
    'id
    Public Sub sr_data()

        Dim oResult As String
        txtsr.Text = 1

        Try

            mycon.Open()

            cmd = New MySqlCommand(" SELECT MAX(sr) AS LastId FROM wardtype", mycon)
            oResult = cmd.ExecuteScalar()

            If oResult IsNot Nothing Then
                '                MsgBox(oResult.ToString)

                txtsr.Text = oResult.ToString + 1

            Else

                MsgBox("No Record Found")

            End If

        Catch ex As Exception

            'MsgBox(ex.Message)
            'MsgBox("help")

        Finally
            mycon.Close()
        End Try

    End Sub
    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        Add_Data()
        Display_Data1()
        txtwardtype.Text = ""
        txtwardtype.Focus()
        sr_data()
    End Sub

    Private Sub wardtype_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtsr.Enabled = False
        txtwardtype.Enabled = False

        Display_Data1()
        'sr_no()
        sr_data()

    End Sub

    Private Sub txtsearch_OnTextChange(sender As Object, e As EventArgs) Handles txtsearch.OnTextChange

    End Sub

    Private Sub txtsearch_KeyUp(sender As Object, e As EventArgs) Handles txtsearch.KeyUp
        mycon.Open()
        'Dim adap1 As New SqlDataAdapter("Select * From Tron Where Fname='" & ComboBox1.Text & "'", con)
        Dim adap1 As New MySqlDataAdapter("Select *  from wardtype where ward_type like '%" & txtsearch.text & "%'", mycon)

        ' sql = "SELECT * from student where CONCAT(fname,"" "", mname) like '%" & TextBox1.Text & "%'"

        Dim ds1 As New DataSet
        adap1.Fill(ds1, "wardtype")
        mycon.Close()

        Dim t As DataTable = ds1.Tables("wardtype")
        BunifuCustomDataGrid1.DataSource = t
    End Sub

    'serial number
    Public Sub sr_no()
        mycon.Open()

        Dim dt1 As New DataTable("wardtype")
        Dim rs1 As New MySqlDataAdapter("select * from wardtype", mycon)
        rs1.Fill(dt1)
        BunifuCustomDataGrid1.DataSource = dt1
        BunifuCustomDataGrid1.Refresh()
        txtsr.Text = dt1.Rows.Count + 1
        rs1.Dispose()
        mycon.Close()

    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click
        mycon.Open()
        adap.SelectCommand = New MySqlCommand

        adap.SelectCommand.Connection = mycon
        'adap.SelectCommand.CommandText = "delete from AccountMaster1 ('" & txtacno.Text & "','" & txtna.Text & "','" & txtdoj.Text & "','" & txtadd.Text & "','" & txtcno.Text & "')"
        adap.SelectCommand.CommandText = "delete from wardtype where sr= ('" & Trim(txtsr.Text) & "')"
        adap.SelectCommand.CommandType = CommandType.Text

        mycon.Close()

        adap.Fill(ds, "wardtype")

        'bindingfields()
        MsgBox("Record Deleted From Record Successfully......", MsgBoxStyle.Information)
        Display_Data1()
    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click
        Update_Data()
        Display_Data1()

    End Sub

    Public Sub Update_Data()

        'new
        Dim i As Integer
        Dim B As Integer
        B = MessageBox.Show("Do You want to update a record........!", "Modify Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If B = MsgBoxResult.Yes Then
            'Dim com As SqlCommand = New SqlCommand("Update empprofile Set First_Name=@First_Name1, Last_Name=@Last_Name1, Address=@Address1, DOB=@DOB1 , Sex=@Sex1, Age=@Age1 , Father_Name=@Father_Name1 , Contact=@Contact1 , Blood_Group=@Blood_Group1, Designation=@Designation1 , DOJ=@DOJ1 , DOR=@DOR1 , Basic_Salary=@Basic_Salary1 , Leave_Granted=@Leave_Granted1   where Username='" + txtusername1.Text + "'", con)
            Dim com As MySqlCommand = New MySqlCommand("update wardtype set  ward_type=@2    where sr='" + txtsr.Text + "'", mycon)
            com.Parameters.AddWithValue("@2", txtwardtype.Text)

            mycon.Open()
            com.ExecuteNonQuery()
            mycon.Close()

            MessageBox.Show("Record Modify In Database")

        End If
    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles BunifuCustomDataGrid1.CellContentClick
        Try


            txtsr.Text = BunifuCustomDataGrid1.Item(0, e.RowIndex).Value
            txtwardtype.Text = BunifuCustomDataGrid1.Item(1, e.RowIndex).Value



        Catch ex As Exception

        End Try
    End Sub

    Private Sub BunifuFlatButton5_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton5.Click
        Me.Close()

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Me.Close()

    End Sub
End Class