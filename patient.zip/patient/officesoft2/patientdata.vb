﻿Imports MySql.Data.MySqlClient
Public Class patientdata
    Dim WithEvents com As New IO.Ports.SerialPort
    Public btemp As String
    Public prate As String




    'for hardware obj data


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            With com
                .PortName = ComboBox2.Text
                .BaudRate = 9600
                .StopBits = IO.Ports.StopBits.One
                .DataBits = 8
            End With
            com.Open()
            com.Write("AT")
            Threading.Thread.Sleep(800)
            com.Write(Chr(13))
            Threading.Thread.Sleep(800)
            com.Write("AT+CMGF=1")
            Threading.Thread.Sleep(800)
            com.Write(Chr(13))
            Threading.Thread.Sleep(800)
            com.Write("AT+CMGF=1")
            Threading.Thread.Sleep(800)
            com.Write(Chr(13))
            Threading.Thread.Sleep(800)

            Timer2.Start()
            'Timer12.Start()
            'TabControl1.SelectedTab = TabPage7
            'Timer10.Start()

            'Label15.BackColor = Color.Green

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "err")
        End Try

    End Sub


    Dim SMS_Num As String = 1
    Dim newSMS As Boolean = False



    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        TextBox1.Text = commdata
        If commdata.Contains("CMTI") Then
            Dim s() As String = commdata.Split(" ")

            For i As Integer = 0 To s.Length - 1
                If s(i).Contains("SM") Then
                    Dim sm As String = s(i)
                    Dim smP() As String = sm.Split(",")
                    For j As Integer = 0 To smP.Length - 1
                        If smP(j).Contains("SM") Then
                            Try
                                SMS_Num = smP(j + 1)
                                newSMS = True
                                com.Write("AT+CMGR=" & SMS_Num)
                                Threading.Thread.Sleep(200)
                                com.Write(Chr(13))
                            Catch ex As Exception

                            End Try
                        End If
                    Next
                End If
            Next
        End If

        If commdata.Contains("CMGR") Then
            'smsEX(commdata)
        End If

    End Sub


    Dim commdata As String = ""

    Private Sub com_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles com.DataReceived



        If newSMS = False Then
            Threading.Thread.Sleep(300)
        Else
            Threading.Thread.Sleep(1500)
        End If
        commdata = com.ReadExisting
        'dataREAD()

        'TextBox2.Text = SMS_Num
        'txtreading.Text = SMS_Num

    End Sub

    Public Sub dataREAD()
        TextBox1.Invoke(New A1Delegate(AddressOf A1Text))

    End Sub
    Public Delegate Sub A1Delegate()

    Public Sub A1Text()
        TextBox1.Text = commdata


        'If ServerData.Contains("conn") Then
        '    'ClientList.Items.Add()
        'End If
        'If ServerData.Contains("lmd") Then
        '    LMD.BackColor = Color.Red

        'End If
        'If ServerData.Contains("lr") Then
        '    IR.BackColor = Color.Red
        'End If

    End Sub

    Dim SMSTextq As String = ""
    Public Sub sendSMS(ByVal sms As String, ByVal number As String)
        com.Write("AT")
        Threading.Thread.Sleep(800)
        com.Write(Chr(13))
        Threading.Thread.Sleep(800)

        com.Write("AT+CMGF=1")
        Threading.Thread.Sleep(800)
        com.Write(Chr(13))
        Threading.Thread.Sleep(800)

        com.Write("AT+CMGS=")
        Threading.Thread.Sleep(800)
        'com.Write(Chr(13))
        com.Write("""" & number & """")
        Threading.Thread.Sleep(800)
        com.Write(Chr(13))
        Threading.Thread.Sleep(800)

        com.Write(sms)
        Threading.Thread.Sleep(800)
        com.Write(Chr(13))
        Threading.Thread.Sleep(800)

        com.Write(Chr(26))
        Threading.Thread.Sleep(800)
    End Sub


    Private Sub patientdata_Load(sender As Object, e As EventArgs) Handles Me.Load



        clear_data()
        ComboBox1.Items.Add(ward)

        For i As Integer = 0 To My.Computer.Ports.SerialPortNames.Count - 1
            ComboBox2.Items.Add(My.Computer.Ports.SerialPortNames(i).ToString)
            'ComboBox5.Items.Add(My.Computer.Ports.SerialPortNames(i).ToString)

        Next

    End Sub

    'for specialisation
    Public Sub catagory()
        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            query = "select * from tblcatagory"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("Catagory")
                txtdisease.Items.Add(disea1)

            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            'mycon.Close()

            mycon.Dispose()

        End Try
    End Sub

    'for doctor

    Private Sub txtdisease_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtdisease.SelectedIndexChanged
        Dim reader As MySqlDataReader
        Dim obj As String
        Dim obj1 As String


        txtdoctor.Items.Clear()
        Try
            mycon.Open()
            Dim query As String
            query = "select * from tbldoctor where Catagory='" & txtdisease.Text & "'"

            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                obj = reader.GetString("Name")
                'obj1 = reader.GetString("Doctor_Id")
                txtdoctor.Items.Add(obj)
                'txtdocid.Text = obj1

            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try
    End Sub


    'for patient id

    Public Sub patient_id()
        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            query = "select * from patientlogin"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("patient_id")
                txtpatientid.Items.Add(disea1)
                ListBox1.Items.Add(disea1)
                ListView1.Items.Add(disea1)
            End While
            mycon.Close()

        Catch ex As Exception
            'MessageBox.Show(ex.Message)


        Finally
            'mycon.Close()

            mycon.Dispose()

        End Try
    End Sub

    Private Sub txtpatientid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtpatientid.SelectedIndexChanged
        Dim cmd As New MySqlCommand("select * from patientlogin where patient_id = @id", mycon)
        'Dim cmd As New MySqlCommand("select * from patientlogin where Email_Id = @id and Patient_Id=@uid1", mycon)
        cmd.Parameters.Add("@id", MySqlDbType.String).Value = txtpatientid.Text
        'cmd.Parameters.Add("@uid1", MySqlDbType.String).Value = txtpatientid.Text
        Dim adapter As New MySqlDataAdapter(cmd)
        Dim table As New DataTable

        adapter.Fill(table)
        Try
            txtpatientid.Text = table.Rows(0)(0).ToString()
            txtpatientname.Text = table.Rows(0)(1).ToString()
            txtage.Text = table.Rows(0)(2).ToString()
            txtaddress.Text = table.Rows(0)(3).ToString()
            txtgender.Text = table.Rows(0)(5).ToString()
            txtmobile.Text = table.Rows(0)(6).ToString()
            txtweight.Text = table.Rows(0)(8).ToString()
            txtheight.Text = table.Rows(0)(9).ToString()
            txtbloodgroup.Text = table.Rows(0)(10).ToString()
            txtwardtype.Text = table.Rows(0)(11).ToString()
            txtwardno.Text = table.Rows(0)(12).ToString()
            'txtfirstname.Text = table.Rows(0)(1).ToString()
            'txtlastname.Text = table.Rows(0)(2).ToString()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtdoctor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtdoctor.SelectedIndexChanged
        Dim reader As MySqlDataReader
        'Dim obj As String
        Dim obj1 As String


        'txtdoctor.Items.Clear()
        Try
            mycon.Open()
            Dim query As String
            query = "select * from tbldoctor where Name='" & txtdoctor.Text & "'"

            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                'obj = reader.GetString("Name")
                obj1 = reader.GetString("Doctor_Id")
                'txtdoctor.Items.Add(obj)
                txtdoctorid.Text = obj1



            End While
            mycon.Close()

        Catch ex As Exception
            'MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try

    End Sub

    Private Sub BunifuImageButton2_Click(sender As Object, e As EventArgs) Handles BunifuImageButton2.Click
        Me.Close()

        mainform.Panel1.Visible = True
    End Sub

    Private Sub BunifuThinButton26_Click(sender As Object, e As EventArgs) Handles BunifuThinButton26.Click
        If txtpatientid.Text <> "" Then
            Add_Data()
            Display_patientdata()

        End If


    End Sub

    Public Sub Add_Data()

        ' TRUE LOGIC



        Dim a As Integer
        Dim i As Integer
        mycon.Open()

        sql = "Select * from  dignosis where sr='" & txtsr.Text & "'"



        ' sql = "Select * from Tutorial_Micro where Student_Id='" & txtid.Text & "' and Email_Id='" & txtemail.Text & "'"
        cmd = New MySqlCommand(sql, mycon)
        reader2 = cmd.ExecuteReader()

        While reader2.Read()
            a = 1
        End While
        mycon.Close()
        If a = 1 Then
            MsgBox(" ID Already exist.", MsgBoxStyle.Critical)

        Else
            mycon.Open()
            '        Dim rs As New SqlClient.SqlCommand("insert into arrest1 values ('" + ComboBox1.Text + "','" + ComboBox2.Text + "','" + ComboBox3.Text + "','" + date1.Text + "','" + date2.Text + "','" + date3.Text + "','" + TextBox1.Text + "','" + ComboBox4.Text + "','" + ComboBox5.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + ComboBox27.Text + "' )", con)

            'Dim rs As New OleDb.OleDbCommand("insert into arrest1 values ('" + ComboBox1.Text + "','" + ComboBox2.Text + "','" + ComboBox3.Text + "','" + date1.Text + "','" + date2.Text + "','" + date3.Text + "','" + TextBox1.Text + "','" + ComboBox4.Text + "','" + ComboBox5.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + ComboBox27.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + ComboBox6.Text + "','" + ComboBox8.Text + "','" + ComboBox10.Text + "','" + TextBox10.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + date4.Text + "','" + ComboBox7.Text + "' ,'" + ComboBox9.Text + "' ,'" + TextBox11.Text + "','" + TextBox12.Text + "','" + TextBox13.Text + "','" + ComboBox11.Text + "','" + TextBox14.Text + "','" + TextBox15.Text + "','" + TextBox16.Text + "','" + TextBox17.Text + "','" + TextBox18.Text + "','" + TextBox19.Text + "','" + TextBox20.Text + "','" + TextBox21.Text + "','" + date5.Text + "','" + ComboBox12.Text + "','" + date6.Text + "','" + ComboBox13.Text + "','" + TextBox22.Text + "','" + TextBox23.Text + "','" + TextBox24.Text + "','" + TextBox25.Text + "','" + TextBox26.Text + "','" + TextBox27.Text + "','" + TextBox28.Text + "','" + TextBox29.Text + "','" + TextBox30.Text + "','" + TextBox31.Text + "','" + TextBox32.Text + "','" + TextBox33.Text + "','" + TextBox34.Text + "','" + TextBox35.Text + "','" + TextBox36.Text + "','" + TextBox37.Text + "','" + ComboBox14.Text + "','" + ComboBox15.Text + "','" + TextBox38.Text + "','" + ComboBox17.Text + "','" + ComboBox16.Text + "','" + ComboBox18.Text + "','" + ComboBox26.Text + "','" + ComboBox19.Text + "','" + ComboBox25.Text + "','" + ComboBox22.Text + "','" + ComboBox24.Text + "','" + ComboBox21.Text + "','" + ComboBox20.Text + "','" + ComboBox23.Text + "','" + TextBox39.Text + "','" + TextBox40.Text + "','" + TextBox42.Text + "','" + TextBox43.Text + "','" + TextBox44.Text + "','" + date9.Text + "','" + TextBox41.Text + "' )", con)
            '+ TextBox42.Text + "','" + TextBox43.Text + "','" + TextBox44.Text + "','" + date9.Text + "','" + TextBox41.Text + 
            'Dim rs As New MySqlCommand("insert into wardmember Values('" & txtid.Text & "','" & txtname.Text & " ','" & txtadd.Text & " ',' " & txtquali.Text & " ',' " & txtoccu.Text & "','" & txtcity.Text & "','" & txtcountry.Text & "','" & txtgender.Text & "','" & txtmob.Text & "','" & txtuid.Text & "')", mycon)
            Dim rs As New MySqlCommand("insert into   dignosis Values('" & Trim(txtsr.Text) & "','" &
                                       Trim(txtdoctorid.Text) & "','" &
                                            Trim(txtpatientid.Text) & "','" &
                                             Trim(txtpatientname.Text) & "','" &
                                             Trim(txtdob.Text) & "','" &
                                             Trim(txtage.Text) & "','" &
                                             Trim(txtmobile.Text) & "','" &
                                             Trim(txtgender.Text) & "','" &
                                             Trim(txtaddress.Text) & "','" &
                                             Trim(txtbloodgroup.Text) & "','" &
                                             Trim(txtbodytemp.Text) & "','" &
                                               Trim(txtdisease.Text) & "','" &
                                                Trim(txtdoctor.Text) & "','" &
                                                 Trim(txthbp.Text) & "','" &
                                                  Trim(txtlbp.Text) & "','" &
                                                   Trim(txtprate.Text) & "','" &
                                                    Trim(txtheight.Text) & "','" &
                                                     Trim(txtweight.Text) & "','" &
                                                      Trim(txtwardtype.Text) & "','" &
                                                       Trim(txtwardno.Text) & "','" &
                                             Trim(date1.Text) & "')", mycon)

            'Dim rs As New OleDb.OleDbCommand("insert into Tutorial_Micro Values('" & txtid.Text & "','" & txtfna.Text & " ','" & txtlna.Text & " ',' " & txtadd.Text & " ',' " & txtemail.Text & "','" & txtcno.Text & "','" & txtclgna.Text & "','" & txtbranch.Text & "','" & txtsem.Text & "','" & txtgender.Text & "','" & comboCourse.Text & "','" & DateTimePicker1.Text & "','" & txttotalfee.Text & "','" & txtfirstinstall.Text & "','" & txtsecondinstall.Text & "','" & txtthirdinstall.Text & "','" & txtbalance.Text & "')", con1)


            i = rs.ExecuteNonQuery()
            If i > 0 Then
                MessageBox.Show("Patient Admission Record Successfully.", "Process Completed", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Failed to update record!", "Failed...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

            mycon.Close()
        End If




    End Sub



    Private Sub textboxcom_OnValueChanged(sender As Object, e As EventArgs) Handles textboxcom.OnValueChanged
        txtbodytemp.Text = textboxcom.Text
        txtreading.Text = textboxcom.Text


    End Sub

    Private Sub BunifuThinButton212_Click(sender As Object, e As EventArgs) Handles BunifuThinButton212.Click
        TabControl1.SelectedTab = TabPage27

    End Sub

    Private Sub BunifuFlatButton9_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton9.Click
        TabControl1.SelectedTab = TabPage2

    End Sub


    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        txtpatientid.Items.Clear()

        Dim cmd As New MySqlCommand("select * from dignosis where room_no = @id", mycon)
        'Dim cmd As New MySqlCommand("select * from patientlogin where Email_Id = @id and Patient_Id=@uid1", mycon)
        cmd.Parameters.Add("@id", MySqlDbType.String).Value = ComboBox1.Text
        'cmd.Parameters.Add("@uid1", MySqlDbType.String).Value = txtpatientid.Text
        Dim adapter As New MySqlDataAdapter(cmd)
        Dim table As New DataTable

        adapter.Fill(table)
        Try
            'clear patient name
            lblp1.Text = ""
            lblp2.Text = ""
            lblp3.Text = ""
            lblp4.Text = ""
            lblp5.Text = ""
            lblp6.Text = ""
            lblp7.Text = ""
            lblp8.Text = ""
            lblp9.Text = ""
            lblp10.Text = ""

            'clear body temp
            bt1.Text = ""
            bt2.Text = ""
            bt3.Text = ""
            bt4.Text = ""
            bt5.Text = ""
            bt6.Text = ""
            bt7.Text = ""
            bt8.Text = ""
            bt9.Text = ""
            bt10.Text = ""

            'clear high bp
            hbp1.Text = ""
            hbp2.Text = ""
            hbp3.Text = ""
            hbp4.Text = ""
            hbp5.Text = ""
            hbp6.Text = ""
            hbp7.Text = ""
            hbp8.Text = ""
            hbp9.Text = ""
            hbp10.Text = ""


            'clear low bp
            lbp1.Text = ""
            lbp2.Text = ""
            lbp3.Text = ""
            lbp4.Text = ""
            lbp5.Text = ""
            lbp6.Text = ""
            lbp7.Text = ""
            lbp8.Text = ""
            lbp9.Text = ""
            lbp10.Text = ""

            'clear doctor

            dr1.Text = ""
            dr2.Text = ""
            dr3.Text = ""
            dr4.Text = ""
            dr5.Text = ""
            dr6.Text = ""
            dr7.Text = ""
            dr8.Text = ""
            dr9.Text = ""
            dr10.Text = ""

            ' clear pulse rate
            PL1.Text = ""
            PL2.Text = ""
            PL3.Text = ""
            PL4.Text = ""
            PL5.Text = ""
            PL6.Text = ""
            PL7.Text = ""
            PL8.Text = ""
            PL9.Text = ""
            PL10.Text = ""



            'patient1

            lblp1.Text = table.Rows(0)(3).ToString()
            bt1.Text = table.Rows(0)(10).ToString()
            hbp1.Text = table.Rows(0)(13).ToString()
            lbp1.Text = table.Rows(0)(14).ToString()
            dr1.Text = table.Rows(0)(12).ToString()
            PL1.Text = table.Rows(0)(15).ToString()


            'patient2
            lblp2.Text = table.Rows(1)(3).ToString()
            bt2.Text = table.Rows(1)(10).ToString()
            hbp2.Text = table.Rows(1)(13).ToString()
            lbp2.Text = table.Rows(1)(14).ToString()
            dr2.Text = table.Rows(1)(12).ToString()
            PL2.Text = table.Rows(1)(15).ToString()


            'patient3

            lblp3.Text = table.Rows(2)(3).ToString()
            bt3.Text = table.Rows(2)(10).ToString()
            hbp3.Text = table.Rows(2)(13).ToString()
            lbp3.Text = table.Rows(2)(14).ToString()
            dr3.Text = table.Rows(2)(12).ToString()
            PL3.Text = table.Rows(2)(15).ToString()


            'patient4

            lblp4.Text = table.Rows(3)(3).ToString()
            bt4.Text = table.Rows(3)(10).ToString()
            hbp4.Text = table.Rows(3)(13).ToString()
            lbp4.Text = table.Rows(3)(14).ToString()
            dr4.Text = table.Rows(3)(12).ToString()
            PL4.Text = table.Rows(3)(15).ToString()


            'patient5

            lblp5.Text = table.Rows(4)(3).ToString()
            bt5.Text = table.Rows(4)(10).ToString()
            hbp5.Text = table.Rows(4)(13).ToString()
            lbp5.Text = table.Rows(4)(14).ToString()
            dr5.Text = table.Rows(4)(12).ToString()
            PL5.Text = table.Rows(4)(15).ToString()

            'patient6
            lblp6.Text = table.Rows(5)(3).ToString()
            bt6.Text = table.Rows(5)(10).ToString()
            hbp6.Text = table.Rows(5)(13).ToString()
            lbp6.Text = table.Rows(5)(14).ToString()
            dr6.Text = table.Rows(5)(12).ToString()
            PL6.Text = table.Rows(5)(15).ToString()

            'patient7


            lblp7.Text = table.Rows(6)(3).ToString()
            bt7.Text = table.Rows(6)(10).ToString()
            hbp7.Text = table.Rows(6)(13).ToString()
            lbp7.Text = table.Rows(6)(14).ToString()
            dr7.Text = table.Rows(6)(12).ToString()
            PL7.Text = table.Rows(6)(15).ToString()

            'patient8


            lblp8.Text = table.Rows(7)(3).ToString()
            bt8.Text = table.Rows(7)(10).ToString()
            hbp8.Text = table.Rows(7)(13).ToString()
            lbp8.Text = table.Rows(7)(14).ToString()
            dr8.Text = table.Rows(7)(12).ToString()
            PL8.Text = table.Rows(7)(15).ToString()

            'patient9

            lblp9.Text = table.Rows(8)(3).ToString()
            bt9.Text = table.Rows(8)(10).ToString()
            hbp9.Text = table.Rows(8)(13).ToString()
            lbp9.Text = table.Rows(8)(14).ToString()
            dr9.Text = table.Rows(8)(12).ToString()
            PL9.Text = table.Rows(8)(15).ToString()


            'patient10


            lblp10.Text = table.Rows(9)(3).ToString()
            bt10.Text = table.Rows(9)(10).ToString()
            hbp10.Text = table.Rows(9)(13).ToString()
            lbp10.Text = table.Rows(9)(14).ToString()
            dr10.Text = table.Rows(9)(12).ToString()
            PL10.Text = table.Rows(9)(15).ToString()



            'lblp2.Text = table.Rows(10)(1).ToString()


            'txtpatientname.Text = table.Rows(0)(1).ToString()
            'txtage.Text = table.Rows(0)(2).ToString()
            'txtaddress.Text = table.Rows(0)(3).ToString()
            'txtgender.Text = table.Rows(0)(5).ToString()
            'txtmobile.Text = table.Rows(0)(6).ToString()
            'txtweight.Text = table.Rows(0)(8).ToString()
            'txtheight.Text = table.Rows(0)(9).ToString()
            'txtbloodgroup.Text = table.Rows(0)(10).ToString()
            'txtwardtype.Text = table.Rows(0)(11).ToString()
            'txtwardno.Text = table.Rows(0)(12).ToString()
            'txtfirstname.Text = table.Rows(0)(1).ToString()
            'txtlastname.Text = table.Rows(0)(2).ToString()
        Catch ex As Exception

        End Try


        'If CInt(bt1.Text) >= 90 Or CInt(bt2.Text) >= 90 Then
        '    bt1.ForeColor = Color.Red
        '    bt2.ForeColor = Color.Red
        '    bt3.ForeColor = Color.Red
        '    bt4.ForeColor = Color.Red

        'Else

        '    bt1.ForeColor = Color.DarkGreen
        '    bt2.ForeColor = Color.DarkGreen
        '    bt3.ForeColor = Color.DarkGreen
        '    bt4.ForeColor = Color.DarkGreen



        'End If







        'new patient data id

        ' gaurang sabane sai nagar wardha
        ';new code



        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            query = "select * from patientlogin  where room_no='" & ComboBox1.Text & "'"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("patient_id")
                txtpatientid.Items.Add(disea1)
                'ListBox1.Items.Add(disea1)
                'ListView1.Items.Add(disea1)
            End While
            mycon.Close()

        Catch ex As Exception
            'MessageBox.Show(ex.Message)


        Finally
            'mycon.Close()

            mycon.Dispose()

        End Try




        'priscription



        mycon.Open()

        Dim dt As New DataTable("prescription")
        ' Dim rs As New MySqlDataAdapter("Select Officer_Id,First_Name,Middle_Name,Last_Name,Gender,Birth_Date,Address1,Address2,City,State,Area,Email,Mobile ,Designation,Aadhar_No,Date1 from tblofficerregistration ", mycon)
        'Dim rs As New MySqlDataAdapter("Select * from prescription", mycon)
        Dim rs As New MySqlDataAdapter("Select * from prescription where ward='" & ComboBox1.Text & "'", mycon)
        'Dim rs As New MySqlDataAdapter("Select * from  where room_no='" & ComboBox1.Text & "'", mycon)
        rs.Fill(dt)
        gridprescription.DataSource = dt
        gridprescription.Refresh()
        'TextBox2.Text = dt.Rows.Count
        'BunifuCustomLabel1.Text = dt.Rows.Count
        rs.Dispose()
        mycon.Close()


    End Sub

    Private Sub BunifuCustomLabel99_Click(sender As Object, e As EventArgs) Handles lbp2.Click

    End Sub

    Private Sub txtreading_TextChanged(sender As Object, e As EventArgs) Handles txtreading.TextChanged
        ''new start code 31 jan
        ''

        Dim SMSTextq As String = ""
        'TextBox1.Text = SMSTextq
        SMSTextq = txtreading.Text
        Dim s() As String = SMSTextq.Split(",")

        For i As Integer = 0 To s.Length - 1
            'If s(i).Contains("ID ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtsolarid.Text = st(1)
            '    'Label23.Text = st(1)

            'End If



            If s(i).Contains("Temp") Then
                Dim st() As String = s(i).Split(" ")
                'T1.Text = st(2)
                btemp = st(2)

                'Label23.Text = st(1)


                txtbodytemp.Text = btemp
                BunifuCustomLabel64.Text = btemp




            End If

            If s(i).Contains("HB") Then
                Dim st() As String = s(i).Split(" ")
                'T2.Text = st(4)
                prate = st(4)
                'Label18.Text = st(3)

                txtprate.Text = prate
                BunifuCustomLabel68.Text = prate

            End If


            'If s(i).Contains("PH ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtph.Text = st(6)
            '    'Label19.Text = st(5)

            'End If

            'If s(i).Contains("SL ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtsali.Text = st(8)
            '    'Label19.Text = st(5)

            'End If

            'If s(i).Contains("UR ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txturea.Text = st(10)
            '    'Label19.Text = st(5)

            'End If

            'If s(i).Contains("PO ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtpho.Text = st(12)
            '    'Label19.Text = st(5)

            'End If


            'If s(i).Contains("MO ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtmoi.Text = st(14)
            '    'Label19.Text = st(5)

            'End If

            'If s(i).Contains("PSR ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtprssure.Text = st(7)
            'End If


            'If s(i).Contains("ENDL ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtendl.Text = st(9)
            'End If



            'If s(i).Contains("ATMP ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtamtp.Text = st(11)
            'End If



            'If s(i).Contains("SST ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtsst.Text = st(7)
            '    Label22.Text = st(7)

            'End If




            'If s(i).Contains("ITM2 ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtinlet2.Text = st(16)
            'End If



            'If s(i).Contains("OTM2 ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtoutlet2.Text = st(18)
            'End If


            'If s(i).Contains("FLW ") Then
            '    Dim st() As String = s(i).Split(" ")
            '    txtflow.Text = st(20)
            'End If



        Next






        ''
        ''new code end 
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        txtreading.Text = TextBox1.Text

    End Sub

    Private Sub T1_TextChanged(sender As Object, e As EventArgs) Handles T1.TextChanged

    End Sub

    Private Sub cmbpid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbpid.SelectedIndexChanged

    End Sub


    Public Sub clear_data()
        'clear patient name
        lblp1.Text = ""
        lblp2.Text = ""
        lblp3.Text = ""
        lblp4.Text = ""
        lblp5.Text = ""
        lblp6.Text = ""
        lblp7.Text = ""
        lblp8.Text = ""
        lblp9.Text = ""
        lblp10.Text = ""

        'clear body temp
        bt1.Text = ""
        bt2.Text = ""
        bt3.Text = ""
        bt4.Text = ""
        bt5.Text = ""
        bt6.Text = ""
        bt7.Text = ""
        bt8.Text = ""
        bt9.Text = ""
        bt10.Text = ""

        'clear high bp
        hbp1.Text = ""
        hbp2.Text = ""
        hbp3.Text = ""
        hbp4.Text = ""
        hbp5.Text = ""
        hbp6.Text = ""
        hbp7.Text = ""
        hbp8.Text = ""
        hbp9.Text = ""
        hbp10.Text = ""


        'clear low bp
        lbp1.Text = ""
        lbp2.Text = ""
        lbp3.Text = ""
        lbp4.Text = ""
        lbp5.Text = ""
        lbp6.Text = ""
        lbp7.Text = ""
        lbp8.Text = ""
        lbp9.Text = ""
        lbp10.Text = ""

        'clear doctor

        dr1.Text = ""
        dr2.Text = ""
        dr3.Text = ""
        dr4.Text = ""
        dr5.Text = ""
        dr6.Text = ""
        dr7.Text = ""
        dr8.Text = ""
        dr9.Text = ""
        dr10.Text = ""

        ' clear pulse rate
        PL1.Text = ""
        PL2.Text = ""
        PL3.Text = ""
        PL4.Text = ""
        PL5.Text = ""
        PL6.Text = ""
        PL7.Text = ""
        PL8.Text = ""
        PL9.Text = ""
        PL10.Text = ""

    End Sub

    Private Sub BunifuFlatButton31_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton31.Click
        mainform.Show()
        Me.Hide()
        mainform.Panel1.Visible = True



    End Sub

    'patient data

    Public Sub Display_patientdata()

        mycon.Open()

        Dim dt As New DataTable("dignosis")
        ' Dim rs As New MySqlDataAdapter("Select Officer_Id,First_Name,Middle_Name,Last_Name,Gender,Birth_Date,Address1,Address2,City,State,Area,Email,Mobile ,Designation,Aadhar_No,Date1 from tblofficerregistration ", mycon)
        Dim rs As New MySqlDataAdapter("Select * from dignosis", mycon)
        'Dim rs As New MySqlDataAdapter("Select * from  where room_no='" & ComboBox1.Text & "'", mycon)
        rs.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Refresh()
        'TextBox2.Text = dt.Rows.Count
        'BunifuCustomLabel1.Text = dt.Rows.Count
        rs.Dispose()
        mycon.Close()

    End Sub

    Private Sub bunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton1.Click
        TabControl1.SelectedTab = TabPage2
        TabControl2.SelectedTab = TabPage7

        txtdisease.Items.Clear()

        'txtpatientid.Items.Clear()

        Display_patientdata()



        'patient_id()
        catagory()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        com.Close()
        com.Dispose()

    End Sub

    Private Sub BunifuTextbox1_OnTextChange(sender As Object, e As EventArgs) Handles BunifuTextbox1.OnTextChange

    End Sub

    Private Sub BunifuTextbox1_KeyUp(sender As Object, e As EventArgs) Handles BunifuTextbox1.KeyUp
        mycon.Open()
        'Dim adap1 As New SqlDataAdapter("Select * From Tron Where Fname='" & ComboBox1.Text & "'", con)
        ' Dim adap1 As New MySqlDataAdapter("Select *  from tblvehicleregi where Registration_No  like '%" & TextBox1.Text & "%'", mycon)
        Dim adap1 As New MySqlDataAdapter("Select *  from dignosis where CONCAT(Name,"" "",Patient_Id,"" "",Doctor_Name,"" "",mobile,"" "",Disease) like '%" & BunifuTextbox1.text & "%'", mycon)

        ' sql = "SELECT * from student where CONCAT(fname,"" "", mname) like '%" & TextBox1.Text & "%'"

        Dim ds1 As New DataSet
        adap1.Fill(ds1, "dignosis")
        mycon.Close()

        Dim t As DataTable = ds1.Tables("dignosis")
        DataGridView1.DataSource = t

    End Sub

    Private Sub BunifuThinButton24_Click(sender As Object, e As EventArgs) Handles BunifuThinButton24.Click
        TabControl2.SelectedTab = TabPage11

    End Sub

    Private Sub BunifuThinButton22_Click(sender As Object, e As EventArgs) Handles BunifuThinButton22.Click
        TabControl2.SelectedTab = TabPage7

    End Sub

    Private Sub BunifuThinButton219_Click(sender As Object, e As EventArgs) Handles BunifuThinButton219.Click
        TabControl2.SelectedTab = TabPage7

    End Sub

    Private Sub bunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton2.Click
        TabControl2.SelectedTab = TabPage11

    End Sub

    Public Sub dispaly_prescription()
        mycon.Open()

        Dim dt As New DataTable("prescription")
        ' Dim rs As New MySqlDataAdapter("Select Officer_Id,First_Name,Middle_Name,Last_Name,Gender,Birth_Date,Address1,Address2,City,State,Area,Email,Mobile ,Designation,Aadhar_No,Date1 from tblofficerregistration ", mycon)
        'Dim rs As New MySqlDataAdapter("Select * from prescription", mycon)
        Dim rs As New MySqlDataAdapter("Select * from prescription where ward='" & ward & "'", mycon)
        'Dim rs As New MySqlDataAdapter("Select * from  where room_no='" & ComboBox1.Text & "'", mycon)
        rs.Fill(dt)
        gridprescription.DataSource = dt
        gridprescription.Refresh()
        'TextBox2.Text = dt.Rows.Count
        'BunifuCustomLabel1.Text = dt.Rows.Count
        rs.Dispose()
        mycon.Close()

    End Sub
    Private Sub bunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton3.Click
        TabControl1.SelectedTab = TabPage28

        dispaly_prescription()


    End Sub

    Private Sub BunifuThinButton211_Click(sender As Object, e As EventArgs) Handles BunifuThinButton211.Click
        TabControl2.SelectedTab = TabPage11

    End Sub

    Private Sub bunifuThinButton21_Click(sender As Object, e As EventArgs) Handles bunifuThinButton21.Click
        TabControl1.SelectedTab = TabPage1

    End Sub

    Private Sub bunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton4.Click
        MsgBox("Work Is Under Process", MsgBoxStyle.Information + MsgBoxStyle.OkOnly + MsgBoxStyle.SystemModal, "Patient Monitoring System")




    End Sub

    Private Sub BunifuFlatButton13_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton13.Click
        MsgBox("Work Is Under Process", MsgBoxStyle.Information + MsgBoxStyle.OkOnly + MsgBoxStyle.SystemModal, "Patient Monitoring System")

    End Sub

    Private Sub Panel37_Paint(sender As Object, e As PaintEventArgs) Handles Panel37.Paint

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
    'Dim med1, med2, med3 As New prescrition
    Private Sub gridprescription_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles gridprescription.CellContentClick

        Try
            'medicine

            medd1 = gridprescription.Item(7, e.RowIndex).Value
            medd2 = gridprescription.Item(10, e.RowIndex).Value
            medd3 = gridprescription.Item(13, e.RowIndex).Value

            'dose

            dosee1 = gridprescription.Item(8, e.RowIndex).Value
            dosee2 = gridprescription.Item(11, e.RowIndex).Value
            dosee3 = gridprescription.Item(14, e.RowIndex).Value



            'time 

            timee1 = gridprescription.Item(9, e.RowIndex).Value
            timee2 = gridprescription.Item(12, e.RowIndex).Value
            timee3 = gridprescription.Item(15, e.RowIndex).Value


            'doctor details 

            docname = gridprescription.Item(4, e.RowIndex).Value
            patient = gridprescription.Item(3, e.RowIndex).Value
            pdisease = gridprescription.Item(5, e.RowIndex).Value
            pdate = gridprescription.Item(16, e.RowIndex).Value






        Catch ex As Exception

        End Try


        prescrition.ShowDialog()






























    End Sub

    Private Sub BunifuTextbox2_OnTextChange(sender As Object, e As EventArgs)


    End Sub

    Private Sub BunifuTextbox2_KeyUp(sender As Object, e As EventArgs)

    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick





    End Sub
End Class