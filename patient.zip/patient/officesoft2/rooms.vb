﻿Imports MySql.Data.MySqlClient
Public Class rooms

    Public Sub room_select()
        txtroomtype.Items.Clear()


        Dim reader As MySqlDataReader
        Try
            mycon.Open()
            Dim query As String
            query = "select * from roomtype"
            cmd = New MySqlCommand(query, mycon)
            reader = cmd.ExecuteReader
            While reader.Read
                Dim disea1 = reader.GetString("room_type")
                Dim r As String

                txtroomtype.Items.Add(disea1)

            End While
            mycon.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)


        Finally
            mycon.Dispose()

        End Try
    End Sub

    Public Sub Add_Data()

        Dim a As Integer
        Dim i As Integer

        mycon.Open()

        Dim rs As New MySqlCommand("insert into  rooms Values('" & Trim(txtsr.Text) & "','" & Trim(txtroomtype.Text) & "','" & Trim(txtroomname.Text) & "','" & Trim(txtroomno.Text) & "')", mycon)

        i = rs.ExecuteNonQuery()
        If i > 0 Then
            MessageBox.Show("Data Submit Successfully.", "Process Completed", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("Failed to update record!", "Failed...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

        mycon.Close()

    End Sub
    Public Sub room_display()
        mycon.Open()

        Dim dt1 As New DataTable("rooms")
        Dim rs1 As New MySqlDataAdapter("select * from  rooms", mycon)
        rs1.Fill(dt1)
        BunifuCustomDataGrid1.DataSource = dt1
        BunifuCustomDataGrid1.Refresh()
        txtsr.Text = dt1.Rows.Count + 1
        rs1.Dispose()
        mycon.Close()

    End Sub

    Private Sub bunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles bunifuFlatButton1.Click
        txtroomno.Text = ""
        txtroomname.Text = ""

        txtroomtype.Items.Clear()
        txtroomtype.Text = "Select Room type"

        room_select()
        txtroomtype.Focus()




    End Sub

    Private Sub rooms_Load(sender As Object, e As EventArgs) Handles Me.Load
        room_select()
        room_display()

    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        Add_Data()
        room_display()
        txtroomtype.Items.Clear()
        txtroomtype.Text = "Select Room Type"
        room_select()
        txtroomno.Text = ""
        txtroomname.Text = ""




    End Sub

    Private Sub BunifuFlatButton5_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton5.Click
        Me.Close()

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Me.Close()

    End Sub

    Private Sub BunifuCustomDataGrid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles BunifuCustomDataGrid1.CellContentClick
        Try


            txtsr.Text = BunifuCustomDataGrid1.Item(0, e.RowIndex).Value
            txtroomtype.Text = BunifuCustomDataGrid1.Item(1, e.RowIndex).Value
            txtroomname.Text = BunifuCustomDataGrid1.Item(2, e.RowIndex).Value
            txtroomno.Text = BunifuCustomDataGrid1.Item(3, e.RowIndex).Value


        Catch ex As Exception

        End Try
    End Sub
End Class