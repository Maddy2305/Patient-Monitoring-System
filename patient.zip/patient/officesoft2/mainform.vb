﻿Public Class mainform
    Private Sub mainform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Dim obj As New Form1

        'obj.Show()
        'obj.MdiParent = Me

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        Panel1.Visible = False
        Dim obj As New login

        obj.Show()
        obj.MdiParent = Me

    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        Panel1.Visible = False
        Dim obj As New login

        obj.Show()
        obj.MdiParent = Me

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Application.Exit()

    End Sub
End Class