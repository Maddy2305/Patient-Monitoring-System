﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class patientdata
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Animation7 As BunifuAnimatorNS.Animation = New BunifuAnimatorNS.Animation()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(patientdata))
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim Animation8 As BunifuAnimatorNS.Animation = New BunifuAnimatorNS.Animation()
        Dim Animation9 As BunifuAnimatorNS.Animation = New BunifuAnimatorNS.Animation()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.BunifuTransition3 = New BunifuAnimatorNS.BunifuTransition(Me.components)
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.bunifuThinButton21 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton31 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton13 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton8 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuImageButton1 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuFlatButton1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton4 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton3 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.label1 = New System.Windows.Forms.Label()
        Me.header = New System.Windows.Forms.Panel()
        Me.BunifuImageButton2 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel8 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel4 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel78 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel77 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel76 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel54 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.BunifuGradientPanel5 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel28 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL10 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL9 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL8 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL7 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL6 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL5 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL4 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL3 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL2 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PL1 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel6 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr10 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr9 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr8 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr7 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr6 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr5 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr4 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr3 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr2 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.dr1 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel2 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.BunifuCustomLabel90 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp10 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp9 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp8 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp7 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp6 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp5 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp4 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp3 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp2 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lbp1 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel79 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp10 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp9 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp8 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp7 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp6 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp5 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp4 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp3 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp2 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.hbp1 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel51 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt10 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt9 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt8 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt7 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt6 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel11 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuSeparator11 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuCustomLabel12 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel9 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuSeparator10 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.lblp10 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel7 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuSeparator9 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.lblp9 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel5 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuSeparator8 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.lblp8 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel3 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuSeparator7 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.lblp7 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel1 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuSeparator6 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.lblp6 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt5 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt4 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt3 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt2 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.bt1 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel23 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel22 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel21 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel20 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel19 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel18 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuSeparator5 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator4 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator3 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator2 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator1 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.lblp5 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lblp4 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lblp3 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lblp2 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.lblp1 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.BunifuThinButton219 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton221 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton211 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton217 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton26 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton214 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton27 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton212 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton213 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton215 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.BunifuThinButton29 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton28 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.cmbpid = New System.Windows.Forms.ComboBox()
        Me.BunifuThinButton239 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton240 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton223 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton225 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton24 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton25 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton22 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton23 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.txtsr = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel64 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel75 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel74 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel73 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel72 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel71 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel68 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel67 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel66 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel63 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel70 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel62 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel69 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel61 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel36 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel38 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.txtdoctorid = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtpatientid = New System.Windows.Forms.ComboBox()
        Me.txtdoctor = New System.Windows.Forms.ComboBox()
        Me.txtdisease = New System.Windows.Forms.ComboBox()
        Me.BunifuCustomLabel60 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel59 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel58 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel53 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel52 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel50 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel48 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel46 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel44 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel43 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel42 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel41 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel40 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel35 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel34 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel33 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel32 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel31 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel30 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.date1 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtwardno = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtprate = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtwardtype = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtlbp = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtmobile = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txthbp = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtbodytemp = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtbloodgroup = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtheight = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtweight = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtage = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtgender = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtaddress = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtdob = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtpatientname = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.BunifuGradientPanel6 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuTextbox1 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.DataGridView1 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.TabPage17 = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.BunifuCustomLabel29 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.BunifuThinButton227 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton228 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton229 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton230 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton231 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton232 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton233 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton234 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton235 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton236 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton237 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton238 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel57 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabControl4 = New System.Windows.Forms.TabControl()
        Me.TabPage18 = New System.Windows.Forms.TabPage()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.BunifuFlatButton25 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton26 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton247 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton248 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton27 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton28 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton29 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton249 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton30 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton250 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton251 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton252 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.TabPage19 = New System.Windows.Forms.TabPage()
        Me.BunifuCustomDataGrid4 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BunifuGradientPanel14 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuTextbox3 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.TabPage20 = New System.Windows.Forms.TabPage()
        Me.TabPage21 = New System.Windows.Forms.TabPage()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.BunifuFlatButton19 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton20 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton241 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton242 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton21 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton22 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton23 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton243 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton24 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton244 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton245 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton246 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel159 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.BunifuTileButton1 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton17 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton2 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton18 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton3 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton19 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton4 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton20 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton5 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton13 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton6 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton14 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton7 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton15 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton8 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton16 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton12 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton9 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton11 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton10 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel172 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.BunifuFlatButton38 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton39 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton259 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton260 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton40 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton41 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton42 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton261 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton43 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton262 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton263 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton264 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.BunifuFlatButton34 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton35 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton36 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton255 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton37 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton256 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton257 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton258 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel173 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabControl5 = New System.Windows.Forms.TabControl()
        Me.TabPage22 = New System.Windows.Forms.TabPage()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.TabPage23 = New System.Windows.Forms.TabPage()
        Me.TabPage24 = New System.Windows.Forms.TabPage()
        Me.BunifuCustomDataGrid5 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BunifuGradientPanel15 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuTextbox4 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.TabPage25 = New System.Windows.Forms.TabPage()
        Me.TabPage26 = New System.Windows.Forms.TabPage()
        Me.TabPage27 = New System.Windows.Forms.TabPage()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.BunifuFlatButton9 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BunifuCustomLabel65 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel56 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel55 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.T4 = New System.Windows.Forms.TextBox()
        Me.Hcom = New System.Windows.Forms.ComboBox()
        Me.textboxcom = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.T3 = New System.Windows.Forms.TextBox()
        Me.T2 = New System.Windows.Forms.TextBox()
        Me.T1 = New System.Windows.Forms.TextBox()
        Me.txtreading = New System.Windows.Forms.TextBox()
        Me.BunifuFlatButton32 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton7 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Panel36 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel10 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel13 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel14 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel15 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel16 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel17 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage28 = New System.Windows.Forms.TabPage()
        Me.gridprescription = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.BunifuGradientPanel1 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel24 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel37 = New System.Windows.Forms.Panel()
        Me.BunifuElipse2 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.BunifuTransition2 = New BunifuAnimatorNS.BunifuTransition(Me.components)
        Me.BunifuTransition1 = New BunifuAnimatorNS.BunifuTransition(Me.components)
        Me.BunifuElipse3 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.bunifuDragControl1 = New Bunifu.Framework.UI.BunifuDragControl(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.panel1.SuspendLayout()
        CType(Me.bunifuImageButton1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.header.SuspendLayout()
        CType(Me.BunifuImageButton2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel35.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.BunifuGradientPanel5.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.Panel31.SuspendLayout()
        Me.Panel34.SuspendLayout()
        Me.Panel33.SuspendLayout()
        Me.Panel32.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.BunifuGradientPanel6.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage17.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabPage14.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.TabPage16.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.TabPage15.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabControl4.SuspendLayout()
        Me.TabPage18.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.TabPage19.SuspendLayout()
        CType(Me.BunifuCustomDataGrid4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel14.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.TabControl5.SuspendLayout()
        Me.TabPage22.SuspendLayout()
        Me.TabPage24.SuspendLayout()
        CType(Me.BunifuCustomDataGrid5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel15.SuspendLayout()
        Me.TabPage27.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.Panel30.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.Panel36.SuspendLayout()
        Me.TabPage28.SuspendLayout()
        CType(Me.gridprescription, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 5
        Me.BunifuElipse1.TargetControl = Me
        '
        'BunifuTransition3
        '
        Me.BunifuTransition3.AnimationType = BunifuAnimatorNS.AnimationType.HorizSlide
        Me.BunifuTransition3.Cursor = Nothing
        Animation7.AnimateOnlyDifferences = True
        Animation7.BlindCoeff = CType(resources.GetObject("Animation7.BlindCoeff"), System.Drawing.PointF)
        Animation7.LeafCoeff = 0!
        Animation7.MaxTime = 1.0!
        Animation7.MinTime = 0!
        Animation7.MosaicCoeff = CType(resources.GetObject("Animation7.MosaicCoeff"), System.Drawing.PointF)
        Animation7.MosaicShift = CType(resources.GetObject("Animation7.MosaicShift"), System.Drawing.PointF)
        Animation7.MosaicSize = 0
        Animation7.Padding = New System.Windows.Forms.Padding(0)
        Animation7.RotateCoeff = 0!
        Animation7.RotateLimit = 0!
        Animation7.ScaleCoeff = CType(resources.GetObject("Animation7.ScaleCoeff"), System.Drawing.PointF)
        Animation7.SlideCoeff = CType(resources.GetObject("Animation7.SlideCoeff"), System.Drawing.PointF)
        Animation7.TimeCoeff = 0!
        Animation7.TransparencyCoeff = 0!
        Me.BunifuTransition3.DefaultAnimation = Animation7
        Me.BunifuTransition3.Interval = 100
        Me.BunifuTransition3.MaxAnimationTime = 1000
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.bunifuThinButton21)
        Me.panel1.Controls.Add(Me.BunifuFlatButton31)
        Me.panel1.Controls.Add(Me.BunifuFlatButton13)
        Me.panel1.Controls.Add(Me.bunifuFlatButton8)
        Me.panel1.Controls.Add(Me.bunifuImageButton1)
        Me.panel1.Controls.Add(Me.bunifuFlatButton1)
        Me.panel1.Controls.Add(Me.bunifuFlatButton4)
        Me.panel1.Controls.Add(Me.bunifuFlatButton2)
        Me.panel1.Controls.Add(Me.bunifuFlatButton3)
        Me.BunifuTransition3.SetDecoration(Me.panel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.panel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.panel1, BunifuAnimatorNS.DecorationType.None)
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.panel1.Location = New System.Drawing.Point(0, 40)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(200, 580)
        Me.panel1.TabIndex = 15
        '
        'bunifuThinButton21
        '
        Me.bunifuThinButton21.ActiveBorderThickness = 1
        Me.bunifuThinButton21.ActiveCornerRadius = 30
        Me.bunifuThinButton21.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.White
        Me.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.White
        Me.bunifuThinButton21.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuThinButton21.BackgroundImage = CType(resources.GetObject("bunifuThinButton21.BackgroundImage"), System.Drawing.Image)
        Me.bunifuThinButton21.ButtonText = "Dashboard"
        Me.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.bunifuThinButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.bunifuThinButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuThinButton21, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuThinButton21.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bunifuThinButton21.ForeColor = System.Drawing.Color.Black
        Me.bunifuThinButton21.IdleBorderThickness = 1
        Me.bunifuThinButton21.IdleCornerRadius = 30
        Me.bunifuThinButton21.IdleFillColor = System.Drawing.Color.White
        Me.bunifuThinButton21.IdleForecolor = System.Drawing.Color.Black
        Me.bunifuThinButton21.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.bunifuThinButton21.Location = New System.Drawing.Point(12, 44)
        Me.bunifuThinButton21.Margin = New System.Windows.Forms.Padding(5)
        Me.bunifuThinButton21.Name = "bunifuThinButton21"
        Me.bunifuThinButton21.Size = New System.Drawing.Size(177, 51)
        Me.bunifuThinButton21.TabIndex = 14
        Me.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton31
        '
        Me.BunifuFlatButton31.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton31.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton31.BorderRadius = 0
        Me.BunifuFlatButton31.ButtonText = "Logout"
        Me.BunifuFlatButton31.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton31.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton31.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton31.Iconimage = Global.officesoft2.My.Resources.Resources.target_keyword
        Me.BunifuFlatButton31.Iconimage_right = Nothing
        Me.BunifuFlatButton31.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton31.Iconimage_Selected = Nothing
        Me.BunifuFlatButton31.IconMarginLeft = 0
        Me.BunifuFlatButton31.IconMarginRight = 0
        Me.BunifuFlatButton31.IconRightVisible = True
        Me.BunifuFlatButton31.IconRightZoom = 0R
        Me.BunifuFlatButton31.IconVisible = True
        Me.BunifuFlatButton31.IconZoom = 60.0R
        Me.BunifuFlatButton31.IsTab = True
        Me.BunifuFlatButton31.Location = New System.Drawing.Point(8, 92)
        Me.BunifuFlatButton31.Name = "BunifuFlatButton31"
        Me.BunifuFlatButton31.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton31.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton31.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton31.selected = False
        Me.BunifuFlatButton31.Size = New System.Drawing.Size(174, 36)
        Me.BunifuFlatButton31.TabIndex = 13
        Me.BunifuFlatButton31.Text = "Logout"
        Me.BunifuFlatButton31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton31.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton31.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton13
        '
        Me.BunifuFlatButton13.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton13.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton13.BorderRadius = 0
        Me.BunifuFlatButton13.ButtonText = "  SMS"
        Me.BunifuFlatButton13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton13.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton13.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton13.Iconimage = Global.officesoft2.My.Resources.Resources.speech_bubble__1_
        Me.BunifuFlatButton13.Iconimage_right = Nothing
        Me.BunifuFlatButton13.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton13.Iconimage_Selected = Nothing
        Me.BunifuFlatButton13.IconMarginLeft = 0
        Me.BunifuFlatButton13.IconMarginRight = 0
        Me.BunifuFlatButton13.IconRightVisible = True
        Me.BunifuFlatButton13.IconRightZoom = 0R
        Me.BunifuFlatButton13.IconVisible = True
        Me.BunifuFlatButton13.IconZoom = 60.0R
        Me.BunifuFlatButton13.IsTab = True
        Me.BunifuFlatButton13.Location = New System.Drawing.Point(8, 267)
        Me.BunifuFlatButton13.Name = "BunifuFlatButton13"
        Me.BunifuFlatButton13.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton13.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton13.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton13.selected = False
        Me.BunifuFlatButton13.Size = New System.Drawing.Size(174, 36)
        Me.BunifuFlatButton13.TabIndex = 12
        Me.BunifuFlatButton13.Text = "  SMS"
        Me.BunifuFlatButton13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton13.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton13.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'bunifuFlatButton8
        '
        Me.bunifuFlatButton8.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton8.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton8.BorderRadius = 0
        Me.bunifuFlatButton8.ButtonText = " Back"
        Me.bunifuFlatButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton8, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton8.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton8.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton8.Iconimage = Global.officesoft2.My.Resources.Resources.back
        Me.bunifuFlatButton8.Iconimage_right = Nothing
        Me.bunifuFlatButton8.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton8.Iconimage_Selected = Nothing
        Me.bunifuFlatButton8.IconMarginLeft = 0
        Me.bunifuFlatButton8.IconMarginRight = 0
        Me.bunifuFlatButton8.IconRightVisible = True
        Me.bunifuFlatButton8.IconRightZoom = 0R
        Me.bunifuFlatButton8.IconVisible = True
        Me.bunifuFlatButton8.IconZoom = 60.0R
        Me.bunifuFlatButton8.IsTab = True
        Me.bunifuFlatButton8.Location = New System.Drawing.Point(8, 306)
        Me.bunifuFlatButton8.Name = "bunifuFlatButton8"
        Me.bunifuFlatButton8.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton8.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton8.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton8.selected = False
        Me.bunifuFlatButton8.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton8.TabIndex = 8
        Me.bunifuFlatButton8.Text = " Back"
        Me.bunifuFlatButton8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton8.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton8.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'bunifuImageButton1
        '
        Me.bunifuImageButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuImageButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition3.SetDecoration(Me.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuImageButton1.Image = Global.officesoft2.My.Resources.Resources.menu1
        Me.bunifuImageButton1.ImageActive = Nothing
        Me.bunifuImageButton1.Location = New System.Drawing.Point(160, 5)
        Me.bunifuImageButton1.Name = "bunifuImageButton1"
        Me.bunifuImageButton1.Size = New System.Drawing.Size(35, 23)
        Me.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton1.TabIndex = 5
        Me.bunifuImageButton1.TabStop = False
        Me.bunifuImageButton1.Zoom = -10
        '
        'bunifuFlatButton1
        '
        Me.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton1.BorderRadius = 0
        Me.bunifuFlatButton1.ButtonText = "Patient Diagnosis"
        Me.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton1, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton1.Iconimage = Global.officesoft2.My.Resources.Resources.staff
        Me.bunifuFlatButton1.Iconimage_right = Nothing
        Me.bunifuFlatButton1.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton1.Iconimage_Selected = Nothing
        Me.bunifuFlatButton1.IconMarginLeft = 0
        Me.bunifuFlatButton1.IconMarginRight = 0
        Me.bunifuFlatButton1.IconRightVisible = True
        Me.bunifuFlatButton1.IconRightZoom = 0R
        Me.bunifuFlatButton1.IconVisible = True
        Me.bunifuFlatButton1.IconZoom = 60.0R
        Me.bunifuFlatButton1.IsTab = True
        Me.bunifuFlatButton1.Location = New System.Drawing.Point(8, 134)
        Me.bunifuFlatButton1.Name = "bunifuFlatButton1"
        Me.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton1.selected = False
        Me.bunifuFlatButton1.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton1.TabIndex = 1
        Me.bunifuFlatButton1.Text = "Patient Diagnosis"
        Me.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton1.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'bunifuFlatButton4
        '
        Me.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton4.BorderRadius = 0
        Me.bunifuFlatButton4.ButtonText = "Medicals"
        Me.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton4, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton4.Iconimage = Global.officesoft2.My.Resources.Resources.tuition_and_fees
        Me.bunifuFlatButton4.Iconimage_right = Nothing
        Me.bunifuFlatButton4.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton4.Iconimage_Selected = Nothing
        Me.bunifuFlatButton4.IconMarginLeft = 0
        Me.bunifuFlatButton4.IconMarginRight = 0
        Me.bunifuFlatButton4.IconRightVisible = True
        Me.bunifuFlatButton4.IconRightZoom = 0R
        Me.bunifuFlatButton4.IconVisible = True
        Me.bunifuFlatButton4.IconZoom = 60.0R
        Me.bunifuFlatButton4.IsTab = True
        Me.bunifuFlatButton4.Location = New System.Drawing.Point(1, 355)
        Me.bunifuFlatButton4.Name = "bunifuFlatButton4"
        Me.bunifuFlatButton4.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton4.selected = False
        Me.bunifuFlatButton4.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton4.TabIndex = 2
        Me.bunifuFlatButton4.Text = "Medicals"
        Me.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton4.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton4.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bunifuFlatButton4.Visible = False
        '
        'bunifuFlatButton2
        '
        Me.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton2.BorderRadius = 0
        Me.bunifuFlatButton2.ButtonText = "Diagnosis Data"
        Me.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton2, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton2.Iconimage = Global.officesoft2.My.Resources.Resources.business_people_meeting
        Me.bunifuFlatButton2.Iconimage_right = Nothing
        Me.bunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton2.Iconimage_Selected = Nothing
        Me.bunifuFlatButton2.IconMarginLeft = 0
        Me.bunifuFlatButton2.IconMarginRight = 0
        Me.bunifuFlatButton2.IconRightVisible = True
        Me.bunifuFlatButton2.IconRightZoom = 0R
        Me.bunifuFlatButton2.IconVisible = True
        Me.bunifuFlatButton2.IconZoom = 60.0R
        Me.bunifuFlatButton2.IsTab = True
        Me.bunifuFlatButton2.Location = New System.Drawing.Point(8, 177)
        Me.bunifuFlatButton2.Name = "bunifuFlatButton2"
        Me.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton2.selected = False
        Me.bunifuFlatButton2.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton2.TabIndex = 2
        Me.bunifuFlatButton2.Text = "Diagnosis Data"
        Me.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'bunifuFlatButton3
        '
        Me.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton3.BorderRadius = 0
        Me.bunifuFlatButton3.ButtonText = "Patient Prescription"
        Me.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton3, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton3.Iconimage = Global.officesoft2.My.Resources.Resources.group_of_males
        Me.bunifuFlatButton3.Iconimage_right = Nothing
        Me.bunifuFlatButton3.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton3.Iconimage_Selected = Nothing
        Me.bunifuFlatButton3.IconMarginLeft = 0
        Me.bunifuFlatButton3.IconMarginRight = 0
        Me.bunifuFlatButton3.IconRightVisible = True
        Me.bunifuFlatButton3.IconRightZoom = 0R
        Me.bunifuFlatButton3.IconVisible = True
        Me.bunifuFlatButton3.IconZoom = 60.0R
        Me.bunifuFlatButton3.IsTab = True
        Me.bunifuFlatButton3.Location = New System.Drawing.Point(8, 219)
        Me.bunifuFlatButton3.Name = "bunifuFlatButton3"
        Me.bunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton3.selected = False
        Me.bunifuFlatButton3.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton3.TabIndex = 3
        Me.bunifuFlatButton3.Text = "Patient Prescription"
        Me.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton3.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton3.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.BunifuTransition1.SetDecoration(Me.label1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.label1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.label1, BunifuAnimatorNS.DecorationType.None)
        Me.label1.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.ForeColor = System.Drawing.Color.White
        Me.label1.Location = New System.Drawing.Point(18, 6)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(302, 26)
        Me.label1.TabIndex = 5
        Me.label1.Text = "Patient Health Monitoring System"
        '
        'header
        '
        Me.header.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.header.Controls.Add(Me.BunifuImageButton2)
        Me.header.Controls.Add(Me.label1)
        Me.BunifuTransition3.SetDecoration(Me.header, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.header, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.header, BunifuAnimatorNS.DecorationType.None)
        Me.header.Dock = System.Windows.Forms.DockStyle.Top
        Me.header.Location = New System.Drawing.Point(0, 0)
        Me.header.Name = "header"
        Me.header.Size = New System.Drawing.Size(1186, 40)
        Me.header.TabIndex = 14
        '
        'BunifuImageButton2
        '
        Me.BunifuImageButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.BunifuTransition3.SetDecoration(Me.BunifuImageButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuImageButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuImageButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuImageButton2.Image = Global.officesoft2.My.Resources.Resources.close
        Me.BunifuImageButton2.ImageActive = Nothing
        Me.BunifuImageButton2.Location = New System.Drawing.Point(1118, 9)
        Me.BunifuImageButton2.Name = "BunifuImageButton2"
        Me.BunifuImageButton2.Size = New System.Drawing.Size(21, 30)
        Me.BunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuImageButton2.TabIndex = 12
        Me.BunifuImageButton2.TabStop = False
        Me.BunifuImageButton2.Zoom = 10
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage26)
        Me.TabControl1.Controls.Add(Me.TabPage27)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage28)
        Me.BunifuTransition3.SetDecoration(Me.TabControl1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabControl1, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl1.Location = New System.Drawing.Point(194, -1)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(991, 632)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.Panel35)
        Me.TabPage1.Controls.Add(Me.Panel21)
        Me.BunifuTransition1.SetDecoration(Me.TabPage1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage1, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(983, 606)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        '
        'Panel35
        '
        Me.Panel35.Controls.Add(Me.BunifuCustomLabel8)
        Me.Panel35.Controls.Add(Me.BunifuCustomLabel4)
        Me.Panel35.Controls.Add(Me.BunifuCustomLabel78)
        Me.Panel35.Controls.Add(Me.BunifuCustomLabel77)
        Me.Panel35.Controls.Add(Me.BunifuCustomLabel76)
        Me.Panel35.Controls.Add(Me.BunifuCustomLabel54)
        Me.BunifuTransition3.SetDecoration(Me.Panel35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel35, BunifuAnimatorNS.DecorationType.None)
        Me.Panel35.Location = New System.Drawing.Point(6, 65)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(923, 28)
        Me.Panel35.TabIndex = 51
        '
        'BunifuCustomLabel8
        '
        Me.BunifuCustomLabel8.AutoSize = True
        Me.BunifuCustomLabel8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel8.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel8.Location = New System.Drawing.Point(427, 5)
        Me.BunifuCustomLabel8.Name = "BunifuCustomLabel8"
        Me.BunifuCustomLabel8.Size = New System.Drawing.Size(86, 19)
        Me.BunifuCustomLabel8.TabIndex = 80
        Me.BunifuCustomLabel8.Text = "Pulse Rate"
        '
        'BunifuCustomLabel4
        '
        Me.BunifuCustomLabel4.AutoSize = True
        Me.BunifuCustomLabel4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel4.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel4.Location = New System.Drawing.Point(793, 3)
        Me.BunifuCustomLabel4.Name = "BunifuCustomLabel4"
        Me.BunifuCustomLabel4.Size = New System.Drawing.Size(59, 19)
        Me.BunifuCustomLabel4.TabIndex = 79
        Me.BunifuCustomLabel4.Text = "Doctor"
        '
        'BunifuCustomLabel78
        '
        Me.BunifuCustomLabel78.AutoSize = True
        Me.BunifuCustomLabel78.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel78, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel78, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel78, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel78.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel78.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel78.Location = New System.Drawing.Point(663, 4)
        Me.BunifuCustomLabel78.Name = "BunifuCustomLabel78"
        Me.BunifuCustomLabel78.Size = New System.Drawing.Size(61, 19)
        Me.BunifuCustomLabel78.TabIndex = 60
        Me.BunifuCustomLabel78.Text = "Low BP"
        '
        'BunifuCustomLabel77
        '
        Me.BunifuCustomLabel77.AutoSize = True
        Me.BunifuCustomLabel77.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel77, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel77, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel77, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel77.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel77.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel77.Location = New System.Drawing.Point(543, 4)
        Me.BunifuCustomLabel77.Name = "BunifuCustomLabel77"
        Me.BunifuCustomLabel77.Size = New System.Drawing.Size(67, 19)
        Me.BunifuCustomLabel77.TabIndex = 59
        Me.BunifuCustomLabel77.Text = "High BP"
        '
        'BunifuCustomLabel76
        '
        Me.BunifuCustomLabel76.AutoSize = True
        Me.BunifuCustomLabel76.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel76, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel76, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel76, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel76.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel76.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel76.Location = New System.Drawing.Point(287, 4)
        Me.BunifuCustomLabel76.Name = "BunifuCustomLabel76"
        Me.BunifuCustomLabel76.Size = New System.Drawing.Size(96, 19)
        Me.BunifuCustomLabel76.TabIndex = 58
        Me.BunifuCustomLabel76.Text = "Body Temp"
        '
        'BunifuCustomLabel54
        '
        Me.BunifuCustomLabel54.AutoSize = True
        Me.BunifuCustomLabel54.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel54, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel54, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel54, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel54.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel54.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel54.Location = New System.Drawing.Point(26, 4)
        Me.BunifuCustomLabel54.Name = "BunifuCustomLabel54"
        Me.BunifuCustomLabel54.Size = New System.Drawing.Size(114, 19)
        Me.BunifuCustomLabel54.TabIndex = 57
        Me.BunifuCustomLabel54.Text = "Patient Name"
        '
        'Panel21
        '
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel5)
        Me.BunifuTransition3.SetDecoration(Me.Panel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel21, BunifuAnimatorNS.DecorationType.None)
        Me.Panel21.Location = New System.Drawing.Point(6, 6)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(945, 590)
        Me.Panel21.TabIndex = 20
        '
        'BunifuGradientPanel5
        '
        Me.BunifuGradientPanel5.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel5.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel28)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL10)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL9)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL8)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL7)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL6)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL5)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL4)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL3)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL2)
        Me.BunifuGradientPanel5.Controls.Add(Me.PL1)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel6)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr10)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr9)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr8)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr7)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr6)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr5)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr4)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr3)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr2)
        Me.BunifuGradientPanel5.Controls.Add(Me.dr1)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel2)
        Me.BunifuGradientPanel5.Controls.Add(Me.ComboBox1)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel90)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp10)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp9)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp8)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp7)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp6)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp5)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp4)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp3)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp2)
        Me.BunifuGradientPanel5.Controls.Add(Me.lbp1)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel79)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp10)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp9)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp8)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp7)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp6)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp5)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp4)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp3)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp2)
        Me.BunifuGradientPanel5.Controls.Add(Me.hbp1)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel51)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt10)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt9)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt8)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt7)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt6)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel11)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator11)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel12)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel9)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator10)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp10)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel7)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator9)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp9)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel5)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator8)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp8)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel3)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator7)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp7)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel1)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator6)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp6)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt5)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt4)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt3)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt2)
        Me.BunifuGradientPanel5.Controls.Add(Me.bt1)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel23)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel22)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel21)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel20)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel19)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel18)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator5)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator4)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator3)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator2)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator1)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp5)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp4)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp3)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp2)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblp1)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel5.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel5.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel5.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel5.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel5.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel5.Name = "BunifuGradientPanel5"
        Me.BunifuGradientPanel5.Quality = 10
        Me.BunifuGradientPanel5.Size = New System.Drawing.Size(920, 537)
        Me.BunifuGradientPanel5.TabIndex = 0
        '
        'BunifuCustomLabel28
        '
        Me.BunifuCustomLabel28.AutoSize = True
        Me.BunifuCustomLabel28.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel28.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel28.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel28.Location = New System.Drawing.Point(442, 444)
        Me.BunifuCustomLabel28.Name = "BunifuCustomLabel28"
        Me.BunifuCustomLabel28.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel28.TabIndex = 101
        Me.BunifuCustomLabel28.Text = "24"
        Me.BunifuCustomLabel28.Visible = False
        '
        'PL10
        '
        Me.PL10.AutoSize = True
        Me.PL10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL10, BunifuAnimatorNS.DecorationType.None)
        Me.PL10.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL10.ForeColor = System.Drawing.Color.Gray
        Me.PL10.Location = New System.Drawing.Point(442, 409)
        Me.PL10.Name = "PL10"
        Me.PL10.Size = New System.Drawing.Size(27, 19)
        Me.PL10.TabIndex = 100
        Me.PL10.Text = "24"
        '
        'PL9
        '
        Me.PL9.AutoSize = True
        Me.PL9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL9, BunifuAnimatorNS.DecorationType.None)
        Me.PL9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL9.ForeColor = System.Drawing.Color.Gray
        Me.PL9.Location = New System.Drawing.Point(442, 377)
        Me.PL9.Name = "PL9"
        Me.PL9.Size = New System.Drawing.Size(27, 19)
        Me.PL9.TabIndex = 99
        Me.PL9.Text = "24"
        '
        'PL8
        '
        Me.PL8.AutoSize = True
        Me.PL8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL8, BunifuAnimatorNS.DecorationType.None)
        Me.PL8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL8.ForeColor = System.Drawing.Color.Gray
        Me.PL8.Location = New System.Drawing.Point(442, 339)
        Me.PL8.Name = "PL8"
        Me.PL8.Size = New System.Drawing.Size(27, 19)
        Me.PL8.TabIndex = 98
        Me.PL8.Text = "24"
        '
        'PL7
        '
        Me.PL7.AutoSize = True
        Me.PL7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL7, BunifuAnimatorNS.DecorationType.None)
        Me.PL7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL7.ForeColor = System.Drawing.Color.Gray
        Me.PL7.Location = New System.Drawing.Point(442, 304)
        Me.PL7.Name = "PL7"
        Me.PL7.Size = New System.Drawing.Size(27, 19)
        Me.PL7.TabIndex = 97
        Me.PL7.Text = "24"
        '
        'PL6
        '
        Me.PL6.AutoSize = True
        Me.PL6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL6, BunifuAnimatorNS.DecorationType.None)
        Me.PL6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL6.ForeColor = System.Drawing.Color.Gray
        Me.PL6.Location = New System.Drawing.Point(442, 269)
        Me.PL6.Name = "PL6"
        Me.PL6.Size = New System.Drawing.Size(27, 19)
        Me.PL6.TabIndex = 96
        Me.PL6.Text = "24"
        '
        'PL5
        '
        Me.PL5.AutoSize = True
        Me.PL5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL5, BunifuAnimatorNS.DecorationType.None)
        Me.PL5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL5.ForeColor = System.Drawing.Color.Gray
        Me.PL5.Location = New System.Drawing.Point(442, 234)
        Me.PL5.Name = "PL5"
        Me.PL5.Size = New System.Drawing.Size(27, 19)
        Me.PL5.TabIndex = 95
        Me.PL5.Text = "24"
        '
        'PL4
        '
        Me.PL4.AutoSize = True
        Me.PL4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL4, BunifuAnimatorNS.DecorationType.None)
        Me.PL4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL4.ForeColor = System.Drawing.Color.Gray
        Me.PL4.Location = New System.Drawing.Point(442, 199)
        Me.PL4.Name = "PL4"
        Me.PL4.Size = New System.Drawing.Size(27, 19)
        Me.PL4.TabIndex = 94
        Me.PL4.Text = "24"
        '
        'PL3
        '
        Me.PL3.AutoSize = True
        Me.PL3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL3, BunifuAnimatorNS.DecorationType.None)
        Me.PL3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL3.ForeColor = System.Drawing.Color.Gray
        Me.PL3.Location = New System.Drawing.Point(442, 164)
        Me.PL3.Name = "PL3"
        Me.PL3.Size = New System.Drawing.Size(27, 19)
        Me.PL3.TabIndex = 93
        Me.PL3.Text = "24"
        '
        'PL2
        '
        Me.PL2.AutoSize = True
        Me.PL2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL2, BunifuAnimatorNS.DecorationType.None)
        Me.PL2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL2.ForeColor = System.Drawing.Color.Gray
        Me.PL2.Location = New System.Drawing.Point(442, 129)
        Me.PL2.Name = "PL2"
        Me.PL2.Size = New System.Drawing.Size(27, 19)
        Me.PL2.TabIndex = 92
        Me.PL2.Text = "24"
        '
        'PL1
        '
        Me.PL1.AutoSize = True
        Me.PL1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.PL1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PL1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.PL1, BunifuAnimatorNS.DecorationType.None)
        Me.PL1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PL1.ForeColor = System.Drawing.Color.Gray
        Me.PL1.Location = New System.Drawing.Point(442, 90)
        Me.PL1.Name = "PL1"
        Me.PL1.Size = New System.Drawing.Size(27, 19)
        Me.PL1.TabIndex = 91
        Me.PL1.Text = "24"
        '
        'BunifuCustomLabel6
        '
        Me.BunifuCustomLabel6.AutoSize = True
        Me.BunifuCustomLabel6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel6.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel6.Location = New System.Drawing.Point(804, 444)
        Me.BunifuCustomLabel6.Name = "BunifuCustomLabel6"
        Me.BunifuCustomLabel6.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel6.TabIndex = 90
        Me.BunifuCustomLabel6.Text = "24"
        Me.BunifuCustomLabel6.Visible = False
        '
        'dr10
        '
        Me.dr10.AutoSize = True
        Me.dr10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr10, BunifuAnimatorNS.DecorationType.None)
        Me.dr10.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr10.ForeColor = System.Drawing.Color.Gray
        Me.dr10.Location = New System.Drawing.Point(804, 409)
        Me.dr10.Name = "dr10"
        Me.dr10.Size = New System.Drawing.Size(27, 19)
        Me.dr10.TabIndex = 89
        Me.dr10.Text = "24"
        '
        'dr9
        '
        Me.dr9.AutoSize = True
        Me.dr9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr9, BunifuAnimatorNS.DecorationType.None)
        Me.dr9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr9.ForeColor = System.Drawing.Color.Gray
        Me.dr9.Location = New System.Drawing.Point(804, 377)
        Me.dr9.Name = "dr9"
        Me.dr9.Size = New System.Drawing.Size(27, 19)
        Me.dr9.TabIndex = 88
        Me.dr9.Text = "24"
        '
        'dr8
        '
        Me.dr8.AutoSize = True
        Me.dr8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr8, BunifuAnimatorNS.DecorationType.None)
        Me.dr8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr8.ForeColor = System.Drawing.Color.Gray
        Me.dr8.Location = New System.Drawing.Point(804, 339)
        Me.dr8.Name = "dr8"
        Me.dr8.Size = New System.Drawing.Size(27, 19)
        Me.dr8.TabIndex = 87
        Me.dr8.Text = "24"
        '
        'dr7
        '
        Me.dr7.AutoSize = True
        Me.dr7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr7, BunifuAnimatorNS.DecorationType.None)
        Me.dr7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr7.ForeColor = System.Drawing.Color.Gray
        Me.dr7.Location = New System.Drawing.Point(804, 304)
        Me.dr7.Name = "dr7"
        Me.dr7.Size = New System.Drawing.Size(27, 19)
        Me.dr7.TabIndex = 86
        Me.dr7.Text = "24"
        '
        'dr6
        '
        Me.dr6.AutoSize = True
        Me.dr6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr6, BunifuAnimatorNS.DecorationType.None)
        Me.dr6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr6.ForeColor = System.Drawing.Color.Gray
        Me.dr6.Location = New System.Drawing.Point(804, 269)
        Me.dr6.Name = "dr6"
        Me.dr6.Size = New System.Drawing.Size(27, 19)
        Me.dr6.TabIndex = 85
        Me.dr6.Text = "24"
        '
        'dr5
        '
        Me.dr5.AutoSize = True
        Me.dr5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr5, BunifuAnimatorNS.DecorationType.None)
        Me.dr5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr5.ForeColor = System.Drawing.Color.Gray
        Me.dr5.Location = New System.Drawing.Point(804, 234)
        Me.dr5.Name = "dr5"
        Me.dr5.Size = New System.Drawing.Size(27, 19)
        Me.dr5.TabIndex = 84
        Me.dr5.Text = "24"
        '
        'dr4
        '
        Me.dr4.AutoSize = True
        Me.dr4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr4, BunifuAnimatorNS.DecorationType.None)
        Me.dr4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr4.ForeColor = System.Drawing.Color.Gray
        Me.dr4.Location = New System.Drawing.Point(804, 199)
        Me.dr4.Name = "dr4"
        Me.dr4.Size = New System.Drawing.Size(27, 19)
        Me.dr4.TabIndex = 83
        Me.dr4.Text = "24"
        '
        'dr3
        '
        Me.dr3.AutoSize = True
        Me.dr3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr3, BunifuAnimatorNS.DecorationType.None)
        Me.dr3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr3.ForeColor = System.Drawing.Color.Gray
        Me.dr3.Location = New System.Drawing.Point(804, 164)
        Me.dr3.Name = "dr3"
        Me.dr3.Size = New System.Drawing.Size(27, 19)
        Me.dr3.TabIndex = 82
        Me.dr3.Text = "24"
        '
        'dr2
        '
        Me.dr2.AutoSize = True
        Me.dr2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr2, BunifuAnimatorNS.DecorationType.None)
        Me.dr2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr2.ForeColor = System.Drawing.Color.Gray
        Me.dr2.Location = New System.Drawing.Point(804, 129)
        Me.dr2.Name = "dr2"
        Me.dr2.Size = New System.Drawing.Size(27, 19)
        Me.dr2.TabIndex = 81
        Me.dr2.Text = "24"
        '
        'dr1
        '
        Me.dr1.AutoSize = True
        Me.dr1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.dr1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.dr1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.dr1, BunifuAnimatorNS.DecorationType.None)
        Me.dr1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dr1.ForeColor = System.Drawing.Color.Gray
        Me.dr1.Location = New System.Drawing.Point(804, 90)
        Me.dr1.Name = "dr1"
        Me.dr1.Size = New System.Drawing.Size(27, 19)
        Me.dr1.TabIndex = 80
        Me.dr1.Text = "24"
        '
        'BunifuCustomLabel2
        '
        Me.BunifuCustomLabel2.AutoSize = True
        Me.BunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel2.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel2.Location = New System.Drawing.Point(557, 17)
        Me.BunifuCustomLabel2.Name = "BunifuCustomLabel2"
        Me.BunifuCustomLabel2.Size = New System.Drawing.Size(100, 19)
        Me.BunifuCustomLabel2.TabIndex = 80
        Me.BunifuCustomLabel2.Text = "Select Ward"
        '
        'ComboBox1
        '
        Me.BunifuTransition2.SetDecoration(Me.ComboBox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.ComboBox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.ComboBox1, BunifuAnimatorNS.DecorationType.None)
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(667, 16)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(209, 21)
        Me.ComboBox1.TabIndex = 79
        '
        'BunifuCustomLabel90
        '
        Me.BunifuCustomLabel90.AutoSize = True
        Me.BunifuCustomLabel90.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel90, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel90, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel90, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel90.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel90.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel90.Location = New System.Drawing.Point(673, 444)
        Me.BunifuCustomLabel90.Name = "BunifuCustomLabel90"
        Me.BunifuCustomLabel90.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel90.TabIndex = 78
        Me.BunifuCustomLabel90.Text = "24"
        Me.BunifuCustomLabel90.Visible = False
        '
        'lbp10
        '
        Me.lbp10.AutoSize = True
        Me.lbp10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp10, BunifuAnimatorNS.DecorationType.None)
        Me.lbp10.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp10.ForeColor = System.Drawing.Color.Gray
        Me.lbp10.Location = New System.Drawing.Point(673, 409)
        Me.lbp10.Name = "lbp10"
        Me.lbp10.Size = New System.Drawing.Size(27, 19)
        Me.lbp10.TabIndex = 77
        Me.lbp10.Text = "24"
        '
        'lbp9
        '
        Me.lbp9.AutoSize = True
        Me.lbp9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp9, BunifuAnimatorNS.DecorationType.None)
        Me.lbp9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp9.ForeColor = System.Drawing.Color.Gray
        Me.lbp9.Location = New System.Drawing.Point(673, 377)
        Me.lbp9.Name = "lbp9"
        Me.lbp9.Size = New System.Drawing.Size(27, 19)
        Me.lbp9.TabIndex = 76
        Me.lbp9.Text = "24"
        '
        'lbp8
        '
        Me.lbp8.AutoSize = True
        Me.lbp8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp8, BunifuAnimatorNS.DecorationType.None)
        Me.lbp8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp8.ForeColor = System.Drawing.Color.Gray
        Me.lbp8.Location = New System.Drawing.Point(673, 339)
        Me.lbp8.Name = "lbp8"
        Me.lbp8.Size = New System.Drawing.Size(27, 19)
        Me.lbp8.TabIndex = 75
        Me.lbp8.Text = "24"
        '
        'lbp7
        '
        Me.lbp7.AutoSize = True
        Me.lbp7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp7, BunifuAnimatorNS.DecorationType.None)
        Me.lbp7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp7.ForeColor = System.Drawing.Color.Gray
        Me.lbp7.Location = New System.Drawing.Point(673, 304)
        Me.lbp7.Name = "lbp7"
        Me.lbp7.Size = New System.Drawing.Size(27, 19)
        Me.lbp7.TabIndex = 74
        Me.lbp7.Text = "24"
        '
        'lbp6
        '
        Me.lbp6.AutoSize = True
        Me.lbp6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp6, BunifuAnimatorNS.DecorationType.None)
        Me.lbp6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp6.ForeColor = System.Drawing.Color.Gray
        Me.lbp6.Location = New System.Drawing.Point(673, 269)
        Me.lbp6.Name = "lbp6"
        Me.lbp6.Size = New System.Drawing.Size(27, 19)
        Me.lbp6.TabIndex = 73
        Me.lbp6.Text = "24"
        '
        'lbp5
        '
        Me.lbp5.AutoSize = True
        Me.lbp5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp5, BunifuAnimatorNS.DecorationType.None)
        Me.lbp5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp5.ForeColor = System.Drawing.Color.Gray
        Me.lbp5.Location = New System.Drawing.Point(673, 234)
        Me.lbp5.Name = "lbp5"
        Me.lbp5.Size = New System.Drawing.Size(27, 19)
        Me.lbp5.TabIndex = 72
        Me.lbp5.Text = "24"
        '
        'lbp4
        '
        Me.lbp4.AutoSize = True
        Me.lbp4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp4, BunifuAnimatorNS.DecorationType.None)
        Me.lbp4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp4.ForeColor = System.Drawing.Color.Gray
        Me.lbp4.Location = New System.Drawing.Point(673, 199)
        Me.lbp4.Name = "lbp4"
        Me.lbp4.Size = New System.Drawing.Size(27, 19)
        Me.lbp4.TabIndex = 71
        Me.lbp4.Text = "24"
        '
        'lbp3
        '
        Me.lbp3.AutoSize = True
        Me.lbp3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp3, BunifuAnimatorNS.DecorationType.None)
        Me.lbp3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp3.ForeColor = System.Drawing.Color.Gray
        Me.lbp3.Location = New System.Drawing.Point(673, 164)
        Me.lbp3.Name = "lbp3"
        Me.lbp3.Size = New System.Drawing.Size(27, 19)
        Me.lbp3.TabIndex = 70
        Me.lbp3.Text = "24"
        '
        'lbp2
        '
        Me.lbp2.AutoSize = True
        Me.lbp2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp2, BunifuAnimatorNS.DecorationType.None)
        Me.lbp2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp2.ForeColor = System.Drawing.Color.Gray
        Me.lbp2.Location = New System.Drawing.Point(673, 129)
        Me.lbp2.Name = "lbp2"
        Me.lbp2.Size = New System.Drawing.Size(27, 19)
        Me.lbp2.TabIndex = 69
        Me.lbp2.Text = "24"
        '
        'lbp1
        '
        Me.lbp1.AutoSize = True
        Me.lbp1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lbp1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lbp1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lbp1, BunifuAnimatorNS.DecorationType.None)
        Me.lbp1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbp1.ForeColor = System.Drawing.Color.Gray
        Me.lbp1.Location = New System.Drawing.Point(673, 90)
        Me.lbp1.Name = "lbp1"
        Me.lbp1.Size = New System.Drawing.Size(27, 19)
        Me.lbp1.TabIndex = 68
        Me.lbp1.Text = "24"
        '
        'BunifuCustomLabel79
        '
        Me.BunifuCustomLabel79.AutoSize = True
        Me.BunifuCustomLabel79.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel79, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel79, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel79, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel79.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel79.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel79.Location = New System.Drawing.Point(562, 444)
        Me.BunifuCustomLabel79.Name = "BunifuCustomLabel79"
        Me.BunifuCustomLabel79.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel79.TabIndex = 67
        Me.BunifuCustomLabel79.Text = "24"
        Me.BunifuCustomLabel79.Visible = False
        '
        'hbp10
        '
        Me.hbp10.AutoSize = True
        Me.hbp10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp10, BunifuAnimatorNS.DecorationType.None)
        Me.hbp10.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp10.ForeColor = System.Drawing.Color.Gray
        Me.hbp10.Location = New System.Drawing.Point(562, 409)
        Me.hbp10.Name = "hbp10"
        Me.hbp10.Size = New System.Drawing.Size(27, 19)
        Me.hbp10.TabIndex = 66
        Me.hbp10.Text = "24"
        '
        'hbp9
        '
        Me.hbp9.AutoSize = True
        Me.hbp9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp9, BunifuAnimatorNS.DecorationType.None)
        Me.hbp9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp9.ForeColor = System.Drawing.Color.Gray
        Me.hbp9.Location = New System.Drawing.Point(562, 377)
        Me.hbp9.Name = "hbp9"
        Me.hbp9.Size = New System.Drawing.Size(27, 19)
        Me.hbp9.TabIndex = 65
        Me.hbp9.Text = "24"
        '
        'hbp8
        '
        Me.hbp8.AutoSize = True
        Me.hbp8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp8, BunifuAnimatorNS.DecorationType.None)
        Me.hbp8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp8.ForeColor = System.Drawing.Color.Gray
        Me.hbp8.Location = New System.Drawing.Point(562, 339)
        Me.hbp8.Name = "hbp8"
        Me.hbp8.Size = New System.Drawing.Size(27, 19)
        Me.hbp8.TabIndex = 64
        Me.hbp8.Text = "24"
        '
        'hbp7
        '
        Me.hbp7.AutoSize = True
        Me.hbp7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp7, BunifuAnimatorNS.DecorationType.None)
        Me.hbp7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp7.ForeColor = System.Drawing.Color.Gray
        Me.hbp7.Location = New System.Drawing.Point(562, 304)
        Me.hbp7.Name = "hbp7"
        Me.hbp7.Size = New System.Drawing.Size(27, 19)
        Me.hbp7.TabIndex = 63
        Me.hbp7.Text = "24"
        '
        'hbp6
        '
        Me.hbp6.AutoSize = True
        Me.hbp6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp6, BunifuAnimatorNS.DecorationType.None)
        Me.hbp6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp6.ForeColor = System.Drawing.Color.Gray
        Me.hbp6.Location = New System.Drawing.Point(562, 269)
        Me.hbp6.Name = "hbp6"
        Me.hbp6.Size = New System.Drawing.Size(27, 19)
        Me.hbp6.TabIndex = 62
        Me.hbp6.Text = "24"
        '
        'hbp5
        '
        Me.hbp5.AutoSize = True
        Me.hbp5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp5, BunifuAnimatorNS.DecorationType.None)
        Me.hbp5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp5.ForeColor = System.Drawing.Color.Gray
        Me.hbp5.Location = New System.Drawing.Point(562, 234)
        Me.hbp5.Name = "hbp5"
        Me.hbp5.Size = New System.Drawing.Size(27, 19)
        Me.hbp5.TabIndex = 61
        Me.hbp5.Text = "24"
        '
        'hbp4
        '
        Me.hbp4.AutoSize = True
        Me.hbp4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp4, BunifuAnimatorNS.DecorationType.None)
        Me.hbp4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp4.ForeColor = System.Drawing.Color.Gray
        Me.hbp4.Location = New System.Drawing.Point(562, 199)
        Me.hbp4.Name = "hbp4"
        Me.hbp4.Size = New System.Drawing.Size(27, 19)
        Me.hbp4.TabIndex = 60
        Me.hbp4.Text = "24"
        '
        'hbp3
        '
        Me.hbp3.AutoSize = True
        Me.hbp3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp3, BunifuAnimatorNS.DecorationType.None)
        Me.hbp3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp3.ForeColor = System.Drawing.Color.Gray
        Me.hbp3.Location = New System.Drawing.Point(562, 164)
        Me.hbp3.Name = "hbp3"
        Me.hbp3.Size = New System.Drawing.Size(27, 19)
        Me.hbp3.TabIndex = 59
        Me.hbp3.Text = "24"
        '
        'hbp2
        '
        Me.hbp2.AutoSize = True
        Me.hbp2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp2, BunifuAnimatorNS.DecorationType.None)
        Me.hbp2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp2.ForeColor = System.Drawing.Color.Gray
        Me.hbp2.Location = New System.Drawing.Point(562, 129)
        Me.hbp2.Name = "hbp2"
        Me.hbp2.Size = New System.Drawing.Size(27, 19)
        Me.hbp2.TabIndex = 58
        Me.hbp2.Text = "24"
        '
        'hbp1
        '
        Me.hbp1.AutoSize = True
        Me.hbp1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.hbp1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.hbp1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.hbp1, BunifuAnimatorNS.DecorationType.None)
        Me.hbp1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hbp1.ForeColor = System.Drawing.Color.Gray
        Me.hbp1.Location = New System.Drawing.Point(562, 90)
        Me.hbp1.Name = "hbp1"
        Me.hbp1.Size = New System.Drawing.Size(27, 19)
        Me.hbp1.TabIndex = 57
        Me.hbp1.Text = "24"
        '
        'BunifuCustomLabel51
        '
        Me.BunifuCustomLabel51.AutoSize = True
        Me.BunifuCustomLabel51.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel51, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel51, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel51, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel51.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel51.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel51.Location = New System.Drawing.Point(318, 444)
        Me.BunifuCustomLabel51.Name = "BunifuCustomLabel51"
        Me.BunifuCustomLabel51.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel51.TabIndex = 56
        Me.BunifuCustomLabel51.Text = "24"
        Me.BunifuCustomLabel51.Visible = False
        '
        'bt10
        '
        Me.bt10.AutoSize = True
        Me.bt10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt10, BunifuAnimatorNS.DecorationType.None)
        Me.bt10.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt10.ForeColor = System.Drawing.Color.Gray
        Me.bt10.Location = New System.Drawing.Point(318, 409)
        Me.bt10.Name = "bt10"
        Me.bt10.Size = New System.Drawing.Size(27, 19)
        Me.bt10.TabIndex = 55
        Me.bt10.Text = "24"
        '
        'bt9
        '
        Me.bt9.AutoSize = True
        Me.bt9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt9, BunifuAnimatorNS.DecorationType.None)
        Me.bt9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt9.ForeColor = System.Drawing.Color.Gray
        Me.bt9.Location = New System.Drawing.Point(318, 377)
        Me.bt9.Name = "bt9"
        Me.bt9.Size = New System.Drawing.Size(27, 19)
        Me.bt9.TabIndex = 54
        Me.bt9.Text = "24"
        '
        'bt8
        '
        Me.bt8.AutoSize = True
        Me.bt8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt8, BunifuAnimatorNS.DecorationType.None)
        Me.bt8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt8.ForeColor = System.Drawing.Color.Gray
        Me.bt8.Location = New System.Drawing.Point(318, 339)
        Me.bt8.Name = "bt8"
        Me.bt8.Size = New System.Drawing.Size(27, 19)
        Me.bt8.TabIndex = 53
        Me.bt8.Text = "24"
        '
        'bt7
        '
        Me.bt7.AutoSize = True
        Me.bt7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt7, BunifuAnimatorNS.DecorationType.None)
        Me.bt7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt7.ForeColor = System.Drawing.Color.Gray
        Me.bt7.Location = New System.Drawing.Point(318, 304)
        Me.bt7.Name = "bt7"
        Me.bt7.Size = New System.Drawing.Size(27, 19)
        Me.bt7.TabIndex = 52
        Me.bt7.Text = "24"
        '
        'bt6
        '
        Me.bt6.AutoSize = True
        Me.bt6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt6, BunifuAnimatorNS.DecorationType.None)
        Me.bt6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt6.ForeColor = System.Drawing.Color.Gray
        Me.bt6.Location = New System.Drawing.Point(318, 269)
        Me.bt6.Name = "bt6"
        Me.bt6.Size = New System.Drawing.Size(27, 19)
        Me.bt6.TabIndex = 51
        Me.bt6.Text = "24"
        '
        'BunifuCustomLabel11
        '
        Me.BunifuCustomLabel11.AutoSize = True
        Me.BunifuCustomLabel11.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel11.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel11.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel11.Location = New System.Drawing.Point(5, 444)
        Me.BunifuCustomLabel11.Name = "BunifuCustomLabel11"
        Me.BunifuCustomLabel11.Size = New System.Drawing.Size(37, 19)
        Me.BunifuCustomLabel11.TabIndex = 50
        Me.BunifuCustomLabel11.Text = "10.)"
        Me.BunifuCustomLabel11.Visible = False
        '
        'BunifuSeparator11
        '
        Me.BunifuSeparator11.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator11.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator11.LineThickness = 1
        Me.BunifuSeparator11.Location = New System.Drawing.Point(40, 466)
        Me.BunifuSeparator11.Name = "BunifuSeparator11"
        Me.BunifuSeparator11.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator11.TabIndex = 49
        Me.BunifuSeparator11.Transparency = 255
        Me.BunifuSeparator11.Vertical = False
        '
        'BunifuCustomLabel12
        '
        Me.BunifuCustomLabel12.AutoSize = True
        Me.BunifuCustomLabel12.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel12.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel12.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel12.Location = New System.Drawing.Point(42, 444)
        Me.BunifuCustomLabel12.Name = "BunifuCustomLabel12"
        Me.BunifuCustomLabel12.Size = New System.Drawing.Size(123, 19)
        Me.BunifuCustomLabel12.TabIndex = 48
        Me.BunifuCustomLabel12.Text = "Total Expences"
        Me.BunifuCustomLabel12.Visible = False
        '
        'BunifuCustomLabel9
        '
        Me.BunifuCustomLabel9.AutoSize = True
        Me.BunifuCustomLabel9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel9.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel9.Location = New System.Drawing.Point(5, 409)
        Me.BunifuCustomLabel9.Name = "BunifuCustomLabel9"
        Me.BunifuCustomLabel9.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel9.TabIndex = 47
        Me.BunifuCustomLabel9.Text = "9.)"
        '
        'BunifuSeparator10
        '
        Me.BunifuSeparator10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator10.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator10.LineThickness = 1
        Me.BunifuSeparator10.Location = New System.Drawing.Point(40, 431)
        Me.BunifuSeparator10.Name = "BunifuSeparator10"
        Me.BunifuSeparator10.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator10.TabIndex = 46
        Me.BunifuSeparator10.Transparency = 255
        Me.BunifuSeparator10.Vertical = False
        '
        'lblp10
        '
        Me.lblp10.AutoSize = True
        Me.lblp10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp10, BunifuAnimatorNS.DecorationType.None)
        Me.lblp10.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp10.ForeColor = System.Drawing.Color.Gray
        Me.lblp10.Location = New System.Drawing.Point(42, 409)
        Me.lblp10.Name = "lblp10"
        Me.lblp10.Size = New System.Drawing.Size(83, 19)
        Me.lblp10.TabIndex = 45
        Me.lblp10.Text = "Patient 10"
        '
        'BunifuCustomLabel7
        '
        Me.BunifuCustomLabel7.AutoSize = True
        Me.BunifuCustomLabel7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel7.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel7.Location = New System.Drawing.Point(5, 374)
        Me.BunifuCustomLabel7.Name = "BunifuCustomLabel7"
        Me.BunifuCustomLabel7.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel7.TabIndex = 44
        Me.BunifuCustomLabel7.Text = "8.)"
        '
        'BunifuSeparator9
        '
        Me.BunifuSeparator9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator9.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator9.LineThickness = 1
        Me.BunifuSeparator9.Location = New System.Drawing.Point(40, 396)
        Me.BunifuSeparator9.Name = "BunifuSeparator9"
        Me.BunifuSeparator9.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator9.TabIndex = 43
        Me.BunifuSeparator9.Transparency = 255
        Me.BunifuSeparator9.Vertical = False
        '
        'lblp9
        '
        Me.lblp9.AutoSize = True
        Me.lblp9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp9, BunifuAnimatorNS.DecorationType.None)
        Me.lblp9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp9.ForeColor = System.Drawing.Color.Gray
        Me.lblp9.Location = New System.Drawing.Point(42, 374)
        Me.lblp9.Name = "lblp9"
        Me.lblp9.Size = New System.Drawing.Size(74, 19)
        Me.lblp9.TabIndex = 42
        Me.lblp9.Text = "Patient 9"
        '
        'BunifuCustomLabel5
        '
        Me.BunifuCustomLabel5.AutoSize = True
        Me.BunifuCustomLabel5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel5.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel5.Location = New System.Drawing.Point(5, 339)
        Me.BunifuCustomLabel5.Name = "BunifuCustomLabel5"
        Me.BunifuCustomLabel5.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel5.TabIndex = 41
        Me.BunifuCustomLabel5.Text = "7.)"
        '
        'BunifuSeparator8
        '
        Me.BunifuSeparator8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator8.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator8.LineThickness = 1
        Me.BunifuSeparator8.Location = New System.Drawing.Point(40, 361)
        Me.BunifuSeparator8.Name = "BunifuSeparator8"
        Me.BunifuSeparator8.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator8.TabIndex = 40
        Me.BunifuSeparator8.Transparency = 255
        Me.BunifuSeparator8.Vertical = False
        '
        'lblp8
        '
        Me.lblp8.AutoSize = True
        Me.lblp8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp8, BunifuAnimatorNS.DecorationType.None)
        Me.lblp8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp8.ForeColor = System.Drawing.Color.Gray
        Me.lblp8.Location = New System.Drawing.Point(42, 339)
        Me.lblp8.Name = "lblp8"
        Me.lblp8.Size = New System.Drawing.Size(74, 19)
        Me.lblp8.TabIndex = 39
        Me.lblp8.Text = "Patient 8"
        '
        'BunifuCustomLabel3
        '
        Me.BunifuCustomLabel3.AutoSize = True
        Me.BunifuCustomLabel3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel3.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel3.Location = New System.Drawing.Point(5, 304)
        Me.BunifuCustomLabel3.Name = "BunifuCustomLabel3"
        Me.BunifuCustomLabel3.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel3.TabIndex = 38
        Me.BunifuCustomLabel3.Text = "6.)"
        '
        'BunifuSeparator7
        '
        Me.BunifuSeparator7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator7.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator7.LineThickness = 1
        Me.BunifuSeparator7.Location = New System.Drawing.Point(40, 326)
        Me.BunifuSeparator7.Name = "BunifuSeparator7"
        Me.BunifuSeparator7.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator7.TabIndex = 37
        Me.BunifuSeparator7.Transparency = 255
        Me.BunifuSeparator7.Vertical = False
        '
        'lblp7
        '
        Me.lblp7.AutoSize = True
        Me.lblp7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp7, BunifuAnimatorNS.DecorationType.None)
        Me.lblp7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp7.ForeColor = System.Drawing.Color.Gray
        Me.lblp7.Location = New System.Drawing.Point(42, 304)
        Me.lblp7.Name = "lblp7"
        Me.lblp7.Size = New System.Drawing.Size(74, 19)
        Me.lblp7.TabIndex = 36
        Me.lblp7.Text = "Patient 7"
        '
        'BunifuCustomLabel1
        '
        Me.BunifuCustomLabel1.AutoSize = True
        Me.BunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel1.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel1.Location = New System.Drawing.Point(5, 269)
        Me.BunifuCustomLabel1.Name = "BunifuCustomLabel1"
        Me.BunifuCustomLabel1.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel1.TabIndex = 35
        Me.BunifuCustomLabel1.Text = "5.)"
        '
        'BunifuSeparator6
        '
        Me.BunifuSeparator6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator6.LineThickness = 1
        Me.BunifuSeparator6.Location = New System.Drawing.Point(40, 291)
        Me.BunifuSeparator6.Name = "BunifuSeparator6"
        Me.BunifuSeparator6.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator6.TabIndex = 34
        Me.BunifuSeparator6.Transparency = 255
        Me.BunifuSeparator6.Vertical = False
        '
        'lblp6
        '
        Me.lblp6.AutoSize = True
        Me.lblp6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp6, BunifuAnimatorNS.DecorationType.None)
        Me.lblp6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp6.ForeColor = System.Drawing.Color.Gray
        Me.lblp6.Location = New System.Drawing.Point(42, 269)
        Me.lblp6.Name = "lblp6"
        Me.lblp6.Size = New System.Drawing.Size(74, 19)
        Me.lblp6.TabIndex = 33
        Me.lblp6.Text = "Patient 6"
        '
        'bt5
        '
        Me.bt5.AutoSize = True
        Me.bt5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt5, BunifuAnimatorNS.DecorationType.None)
        Me.bt5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt5.ForeColor = System.Drawing.Color.Gray
        Me.bt5.Location = New System.Drawing.Point(318, 234)
        Me.bt5.Name = "bt5"
        Me.bt5.Size = New System.Drawing.Size(27, 19)
        Me.bt5.TabIndex = 32
        Me.bt5.Text = "24"
        '
        'bt4
        '
        Me.bt4.AutoSize = True
        Me.bt4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt4, BunifuAnimatorNS.DecorationType.None)
        Me.bt4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt4.ForeColor = System.Drawing.Color.Gray
        Me.bt4.Location = New System.Drawing.Point(318, 199)
        Me.bt4.Name = "bt4"
        Me.bt4.Size = New System.Drawing.Size(27, 19)
        Me.bt4.TabIndex = 31
        Me.bt4.Text = "24"
        '
        'bt3
        '
        Me.bt3.AutoSize = True
        Me.bt3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt3, BunifuAnimatorNS.DecorationType.None)
        Me.bt3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt3.ForeColor = System.Drawing.Color.Gray
        Me.bt3.Location = New System.Drawing.Point(318, 164)
        Me.bt3.Name = "bt3"
        Me.bt3.Size = New System.Drawing.Size(27, 19)
        Me.bt3.TabIndex = 30
        Me.bt3.Text = "24"
        '
        'bt2
        '
        Me.bt2.AutoSize = True
        Me.bt2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt2, BunifuAnimatorNS.DecorationType.None)
        Me.bt2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt2.ForeColor = System.Drawing.Color.Gray
        Me.bt2.Location = New System.Drawing.Point(318, 129)
        Me.bt2.Name = "bt2"
        Me.bt2.Size = New System.Drawing.Size(27, 19)
        Me.bt2.TabIndex = 29
        Me.bt2.Text = "24"
        '
        'bt1
        '
        Me.bt1.AutoSize = True
        Me.bt1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.bt1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bt1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bt1, BunifuAnimatorNS.DecorationType.None)
        Me.bt1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt1.ForeColor = System.Drawing.Color.Gray
        Me.bt1.Location = New System.Drawing.Point(318, 90)
        Me.bt1.Name = "bt1"
        Me.bt1.Size = New System.Drawing.Size(27, 19)
        Me.bt1.TabIndex = 28
        Me.bt1.Text = "24"
        '
        'BunifuCustomLabel23
        '
        Me.BunifuCustomLabel23.AutoSize = True
        Me.BunifuCustomLabel23.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel23.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel23.ForeColor = System.Drawing.Color.Black
        Me.BunifuCustomLabel23.Location = New System.Drawing.Point(8, 14)
        Me.BunifuCustomLabel23.Name = "BunifuCustomLabel23"
        Me.BunifuCustomLabel23.Size = New System.Drawing.Size(142, 19)
        Me.BunifuCustomLabel23.TabIndex = 27
        Me.BunifuCustomLabel23.Text = "# Sub Dashboard"
        '
        'BunifuCustomLabel22
        '
        Me.BunifuCustomLabel22.AutoSize = True
        Me.BunifuCustomLabel22.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel22.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel22.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel22.Location = New System.Drawing.Point(5, 234)
        Me.BunifuCustomLabel22.Name = "BunifuCustomLabel22"
        Me.BunifuCustomLabel22.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel22.TabIndex = 26
        Me.BunifuCustomLabel22.Text = "5.)"
        '
        'BunifuCustomLabel21
        '
        Me.BunifuCustomLabel21.AutoSize = True
        Me.BunifuCustomLabel21.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel21.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel21.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel21.Location = New System.Drawing.Point(5, 199)
        Me.BunifuCustomLabel21.Name = "BunifuCustomLabel21"
        Me.BunifuCustomLabel21.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel21.TabIndex = 25
        Me.BunifuCustomLabel21.Text = "4.)"
        '
        'BunifuCustomLabel20
        '
        Me.BunifuCustomLabel20.AutoSize = True
        Me.BunifuCustomLabel20.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel20.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel20.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel20.Location = New System.Drawing.Point(5, 164)
        Me.BunifuCustomLabel20.Name = "BunifuCustomLabel20"
        Me.BunifuCustomLabel20.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel20.TabIndex = 24
        Me.BunifuCustomLabel20.Text = "3.)"
        '
        'BunifuCustomLabel19
        '
        Me.BunifuCustomLabel19.AutoSize = True
        Me.BunifuCustomLabel19.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel19.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel19.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel19.Location = New System.Drawing.Point(5, 129)
        Me.BunifuCustomLabel19.Name = "BunifuCustomLabel19"
        Me.BunifuCustomLabel19.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel19.TabIndex = 23
        Me.BunifuCustomLabel19.Text = "2.)"
        '
        'BunifuCustomLabel18
        '
        Me.BunifuCustomLabel18.AutoSize = True
        Me.BunifuCustomLabel18.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel18.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel18.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel18.Location = New System.Drawing.Point(5, 94)
        Me.BunifuCustomLabel18.Name = "BunifuCustomLabel18"
        Me.BunifuCustomLabel18.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel18.TabIndex = 22
        Me.BunifuCustomLabel18.Text = "1.)"
        '
        'BunifuSeparator5
        '
        Me.BunifuSeparator5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator5.LineThickness = 1
        Me.BunifuSeparator5.Location = New System.Drawing.Point(40, 256)
        Me.BunifuSeparator5.Name = "BunifuSeparator5"
        Me.BunifuSeparator5.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator5.TabIndex = 21
        Me.BunifuSeparator5.Transparency = 255
        Me.BunifuSeparator5.Vertical = False
        '
        'BunifuSeparator4
        '
        Me.BunifuSeparator4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator4.LineThickness = 1
        Me.BunifuSeparator4.Location = New System.Drawing.Point(40, 220)
        Me.BunifuSeparator4.Name = "BunifuSeparator4"
        Me.BunifuSeparator4.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator4.TabIndex = 20
        Me.BunifuSeparator4.Transparency = 255
        Me.BunifuSeparator4.Vertical = False
        '
        'BunifuSeparator3
        '
        Me.BunifuSeparator3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator3.LineThickness = 1
        Me.BunifuSeparator3.Location = New System.Drawing.Point(40, 184)
        Me.BunifuSeparator3.Name = "BunifuSeparator3"
        Me.BunifuSeparator3.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator3.TabIndex = 19
        Me.BunifuSeparator3.Transparency = 255
        Me.BunifuSeparator3.Vertical = False
        '
        'BunifuSeparator2
        '
        Me.BunifuSeparator2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator2.LineThickness = 1
        Me.BunifuSeparator2.Location = New System.Drawing.Point(40, 148)
        Me.BunifuSeparator2.Name = "BunifuSeparator2"
        Me.BunifuSeparator2.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator2.TabIndex = 18
        Me.BunifuSeparator2.Transparency = 255
        Me.BunifuSeparator2.Vertical = False
        '
        'BunifuSeparator1
        '
        Me.BunifuSeparator1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator1.LineThickness = 1
        Me.BunifuSeparator1.Location = New System.Drawing.Point(40, 112)
        Me.BunifuSeparator1.Name = "BunifuSeparator1"
        Me.BunifuSeparator1.Size = New System.Drawing.Size(830, 10)
        Me.BunifuSeparator1.TabIndex = 17
        Me.BunifuSeparator1.Transparency = 255
        Me.BunifuSeparator1.Vertical = False
        '
        'lblp5
        '
        Me.lblp5.AutoSize = True
        Me.lblp5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp5, BunifuAnimatorNS.DecorationType.None)
        Me.lblp5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp5.ForeColor = System.Drawing.Color.Gray
        Me.lblp5.Location = New System.Drawing.Point(42, 234)
        Me.lblp5.Name = "lblp5"
        Me.lblp5.Size = New System.Drawing.Size(74, 19)
        Me.lblp5.TabIndex = 16
        Me.lblp5.Text = "Patient 5"
        '
        'lblp4
        '
        Me.lblp4.AutoSize = True
        Me.lblp4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp4, BunifuAnimatorNS.DecorationType.None)
        Me.lblp4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp4.ForeColor = System.Drawing.Color.Gray
        Me.lblp4.Location = New System.Drawing.Point(42, 199)
        Me.lblp4.Name = "lblp4"
        Me.lblp4.Size = New System.Drawing.Size(74, 19)
        Me.lblp4.TabIndex = 15
        Me.lblp4.Text = "Patient 4"
        '
        'lblp3
        '
        Me.lblp3.AutoSize = True
        Me.lblp3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp3, BunifuAnimatorNS.DecorationType.None)
        Me.lblp3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp3.ForeColor = System.Drawing.Color.Gray
        Me.lblp3.Location = New System.Drawing.Point(42, 164)
        Me.lblp3.Name = "lblp3"
        Me.lblp3.Size = New System.Drawing.Size(74, 19)
        Me.lblp3.TabIndex = 14
        Me.lblp3.Text = "Patient 3"
        '
        'lblp2
        '
        Me.lblp2.AutoSize = True
        Me.lblp2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp2, BunifuAnimatorNS.DecorationType.None)
        Me.lblp2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp2.ForeColor = System.Drawing.Color.Gray
        Me.lblp2.Location = New System.Drawing.Point(42, 129)
        Me.lblp2.Name = "lblp2"
        Me.lblp2.Size = New System.Drawing.Size(74, 19)
        Me.lblp2.TabIndex = 13
        Me.lblp2.Text = "Patient 2"
        '
        'lblp1
        '
        Me.lblp1.AutoSize = True
        Me.lblp1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.lblp1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.lblp1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.lblp1, BunifuAnimatorNS.DecorationType.None)
        Me.lblp1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblp1.ForeColor = System.Drawing.Color.Gray
        Me.lblp1.Location = New System.Drawing.Point(42, 94)
        Me.lblp1.Name = "lblp1"
        Me.lblp1.Size = New System.Drawing.Size(74, 19)
        Me.lblp1.TabIndex = 12
        Me.lblp1.Text = "Patient 1"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.Panel15)
        Me.TabPage2.Controls.Add(Me.Panel4)
        Me.TabPage2.Controls.Add(Me.TabControl2)
        Me.TabPage2.Controls.Add(Me.BunifuCustomLabel29)
        Me.BunifuTransition1.SetDecoration(Me.TabPage2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage2, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(983, 606)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.BunifuThinButton219)
        Me.Panel15.Controls.Add(Me.BunifuThinButton221)
        Me.Panel15.Controls.Add(Me.BunifuThinButton211)
        Me.Panel15.Controls.Add(Me.BunifuThinButton217)
        Me.Panel15.Controls.Add(Me.BunifuThinButton26)
        Me.Panel15.Controls.Add(Me.BunifuThinButton214)
        Me.Panel15.Controls.Add(Me.BunifuThinButton27)
        Me.Panel15.Controls.Add(Me.BunifuThinButton212)
        Me.Panel15.Controls.Add(Me.BunifuThinButton213)
        Me.Panel15.Controls.Add(Me.BunifuThinButton215)
        Me.BunifuTransition3.SetDecoration(Me.Panel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel15, BunifuAnimatorNS.DecorationType.None)
        Me.Panel15.Location = New System.Drawing.Point(3, 510)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(947, 49)
        Me.Panel15.TabIndex = 35
        '
        'BunifuThinButton219
        '
        Me.BunifuThinButton219.ActiveBorderThickness = 1
        Me.BunifuThinButton219.ActiveCornerRadius = 3
        Me.BunifuThinButton219.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton219.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton219.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton219.AutoSize = True
        Me.BunifuThinButton219.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton219.BackgroundImage = CType(resources.GetObject("BunifuThinButton219.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton219.ButtonText = "Home"
        Me.BunifuThinButton219.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton219, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton219, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton219, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton219.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton219.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton219.IdleBorderThickness = 1
        Me.BunifuThinButton219.IdleCornerRadius = 1
        Me.BunifuThinButton219.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton219.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton219.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton219.Location = New System.Drawing.Point(595, 1)
        Me.BunifuThinButton219.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton219.Name = "BunifuThinButton219"
        Me.BunifuThinButton219.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton219.TabIndex = 38
        Me.BunifuThinButton219.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton221
        '
        Me.BunifuThinButton221.ActiveBorderThickness = 1
        Me.BunifuThinButton221.ActiveCornerRadius = 2
        Me.BunifuThinButton221.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton221.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton221.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton221.AutoSize = True
        Me.BunifuThinButton221.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton221.BackgroundImage = CType(resources.GetObject("BunifuThinButton221.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton221.ButtonText = "Sign Up"
        Me.BunifuThinButton221.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton221, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton221, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton221, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton221.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton221.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton221.IdleBorderThickness = 1
        Me.BunifuThinButton221.IdleCornerRadius = 1
        Me.BunifuThinButton221.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton221.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton221.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton221.Location = New System.Drawing.Point(595, 0)
        Me.BunifuThinButton221.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton221.Name = "BunifuThinButton221"
        Me.BunifuThinButton221.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton221.TabIndex = 37
        Me.BunifuThinButton221.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton211
        '
        Me.BunifuThinButton211.ActiveBorderThickness = 1
        Me.BunifuThinButton211.ActiveCornerRadius = 3
        Me.BunifuThinButton211.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton211.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton211.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton211.AutoSize = True
        Me.BunifuThinButton211.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton211.BackgroundImage = CType(resources.GetObject("BunifuThinButton211.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton211.ButtonText = "View Record"
        Me.BunifuThinButton211.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton211, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton211, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton211, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton211.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton211.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton211.IdleBorderThickness = 1
        Me.BunifuThinButton211.IdleCornerRadius = 1
        Me.BunifuThinButton211.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton211.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton211.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton211.Location = New System.Drawing.Point(445, 1)
        Me.BunifuThinButton211.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton211.Name = "BunifuThinButton211"
        Me.BunifuThinButton211.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton211.TabIndex = 36
        Me.BunifuThinButton211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton217
        '
        Me.BunifuThinButton217.ActiveBorderThickness = 1
        Me.BunifuThinButton217.ActiveCornerRadius = 2
        Me.BunifuThinButton217.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton217.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton217.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton217.AutoSize = True
        Me.BunifuThinButton217.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton217.BackgroundImage = CType(resources.GetObject("BunifuThinButton217.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton217.ButtonText = "Sign Up"
        Me.BunifuThinButton217.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton217, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton217, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton217, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton217.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton217.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton217.IdleBorderThickness = 1
        Me.BunifuThinButton217.IdleCornerRadius = 1
        Me.BunifuThinButton217.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton217.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton217.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton217.Location = New System.Drawing.Point(445, 0)
        Me.BunifuThinButton217.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton217.Name = "BunifuThinButton217"
        Me.BunifuThinButton217.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton217.TabIndex = 35
        Me.BunifuThinButton217.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton26
        '
        Me.BunifuThinButton26.ActiveBorderThickness = 1
        Me.BunifuThinButton26.ActiveCornerRadius = 3
        Me.BunifuThinButton26.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton26.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton26.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton26.AutoSize = True
        Me.BunifuThinButton26.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton26.BackgroundImage = CType(resources.GetObject("BunifuThinButton26.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton26.ButtonText = "Submit"
        Me.BunifuThinButton26.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton26.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton26.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton26.IdleBorderThickness = 1
        Me.BunifuThinButton26.IdleCornerRadius = 1
        Me.BunifuThinButton26.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton26.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton26.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton26.Location = New System.Drawing.Point(3, 1)
        Me.BunifuThinButton26.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton26.Name = "BunifuThinButton26"
        Me.BunifuThinButton26.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton26.TabIndex = 28
        Me.BunifuThinButton26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton214
        '
        Me.BunifuThinButton214.ActiveBorderThickness = 1
        Me.BunifuThinButton214.ActiveCornerRadius = 3
        Me.BunifuThinButton214.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton214.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton214.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton214.AutoSize = True
        Me.BunifuThinButton214.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton214.BackgroundImage = CType(resources.GetObject("BunifuThinButton214.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton214.ButtonText = "Clear"
        Me.BunifuThinButton214.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton214, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton214, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton214, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton214.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton214.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton214.IdleBorderThickness = 1
        Me.BunifuThinButton214.IdleCornerRadius = 1
        Me.BunifuThinButton214.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton214.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton214.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton214.Location = New System.Drawing.Point(297, 1)
        Me.BunifuThinButton214.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton214.Name = "BunifuThinButton214"
        Me.BunifuThinButton214.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton214.TabIndex = 34
        Me.BunifuThinButton214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton27
        '
        Me.BunifuThinButton27.ActiveBorderThickness = 1
        Me.BunifuThinButton27.ActiveCornerRadius = 2
        Me.BunifuThinButton27.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton27.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton27.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton27.AutoSize = True
        Me.BunifuThinButton27.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton27.BackgroundImage = CType(resources.GetObject("BunifuThinButton27.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton27.ButtonText = "Sign Up"
        Me.BunifuThinButton27.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton27.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton27.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton27.IdleBorderThickness = 1
        Me.BunifuThinButton27.IdleCornerRadius = 1
        Me.BunifuThinButton27.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton27.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton27.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton27.Location = New System.Drawing.Point(3, 0)
        Me.BunifuThinButton27.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton27.Name = "BunifuThinButton27"
        Me.BunifuThinButton27.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton27.TabIndex = 27
        Me.BunifuThinButton27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton212
        '
        Me.BunifuThinButton212.ActiveBorderThickness = 1
        Me.BunifuThinButton212.ActiveCornerRadius = 3
        Me.BunifuThinButton212.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton212.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton212.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton212.AutoSize = True
        Me.BunifuThinButton212.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton212.BackgroundImage = CType(resources.GetObject("BunifuThinButton212.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton212.ButtonText = "Sensor Connection"
        Me.BunifuThinButton212.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton212, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton212, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton212, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton212.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton212.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton212.IdleBorderThickness = 1
        Me.BunifuThinButton212.IdleCornerRadius = 1
        Me.BunifuThinButton212.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton212.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton212.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton212.Location = New System.Drawing.Point(149, 1)
        Me.BunifuThinButton212.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton212.Name = "BunifuThinButton212"
        Me.BunifuThinButton212.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton212.TabIndex = 32
        Me.BunifuThinButton212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton213
        '
        Me.BunifuThinButton213.ActiveBorderThickness = 1
        Me.BunifuThinButton213.ActiveCornerRadius = 2
        Me.BunifuThinButton213.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton213.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton213.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton213.AutoSize = True
        Me.BunifuThinButton213.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton213.BackgroundImage = CType(resources.GetObject("BunifuThinButton213.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton213.ButtonText = "Sign Up"
        Me.BunifuThinButton213.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton213, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton213, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton213, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton213.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton213.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton213.IdleBorderThickness = 1
        Me.BunifuThinButton213.IdleCornerRadius = 1
        Me.BunifuThinButton213.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton213.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton213.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton213.Location = New System.Drawing.Point(149, 0)
        Me.BunifuThinButton213.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton213.Name = "BunifuThinButton213"
        Me.BunifuThinButton213.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton213.TabIndex = 31
        Me.BunifuThinButton213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton215
        '
        Me.BunifuThinButton215.ActiveBorderThickness = 1
        Me.BunifuThinButton215.ActiveCornerRadius = 2
        Me.BunifuThinButton215.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton215.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton215.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton215.AutoSize = True
        Me.BunifuThinButton215.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton215.BackgroundImage = CType(resources.GetObject("BunifuThinButton215.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton215.ButtonText = "Sign Up"
        Me.BunifuThinButton215.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton215, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton215, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton215, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton215.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton215.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton215.IdleBorderThickness = 1
        Me.BunifuThinButton215.IdleCornerRadius = 1
        Me.BunifuThinButton215.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton215.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton215.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton215.Location = New System.Drawing.Point(297, 0)
        Me.BunifuThinButton215.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton215.Name = "BunifuThinButton215"
        Me.BunifuThinButton215.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton215.TabIndex = 33
        Me.BunifuThinButton215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Panel28)
        Me.Panel4.Controls.Add(Me.BunifuThinButton239)
        Me.Panel4.Controls.Add(Me.BunifuThinButton240)
        Me.Panel4.Controls.Add(Me.BunifuThinButton223)
        Me.Panel4.Controls.Add(Me.BunifuThinButton225)
        Me.Panel4.Controls.Add(Me.BunifuThinButton24)
        Me.Panel4.Controls.Add(Me.BunifuThinButton25)
        Me.Panel4.Controls.Add(Me.BunifuThinButton22)
        Me.Panel4.Controls.Add(Me.BunifuThinButton23)
        Me.BunifuTransition3.SetDecoration(Me.Panel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel4, BunifuAnimatorNS.DecorationType.None)
        Me.Panel4.Location = New System.Drawing.Point(-1, 30)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(962, 45)
        Me.Panel4.TabIndex = 13
        '
        'Panel28
        '
        Me.Panel28.Controls.Add(Me.BunifuThinButton29)
        Me.Panel28.Controls.Add(Me.BunifuThinButton28)
        Me.Panel28.Controls.Add(Me.cmbpid)
        Me.BunifuTransition3.SetDecoration(Me.Panel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel28, BunifuAnimatorNS.DecorationType.None)
        Me.Panel28.Location = New System.Drawing.Point(657, 4)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(283, 35)
        Me.Panel28.TabIndex = 31
        '
        'BunifuThinButton29
        '
        Me.BunifuThinButton29.ActiveBorderThickness = 1
        Me.BunifuThinButton29.ActiveCornerRadius = 3
        Me.BunifuThinButton29.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton29.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton29.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton29.AutoSize = True
        Me.BunifuThinButton29.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton29.BackgroundImage = CType(resources.GetObject("BunifuThinButton29.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton29.ButtonText = "Hide"
        Me.BunifuThinButton29.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton29.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton29.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton29.IdleBorderThickness = 1
        Me.BunifuThinButton29.IdleCornerRadius = 1
        Me.BunifuThinButton29.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton29.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton29.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton29.Location = New System.Drawing.Point(210, 1)
        Me.BunifuThinButton29.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton29.Name = "BunifuThinButton29"
        Me.BunifuThinButton29.Size = New System.Drawing.Size(63, 36)
        Me.BunifuThinButton29.TabIndex = 34
        Me.BunifuThinButton29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton28
        '
        Me.BunifuThinButton28.ActiveBorderThickness = 1
        Me.BunifuThinButton28.ActiveCornerRadius = 3
        Me.BunifuThinButton28.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton28.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton28.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton28.AutoSize = True
        Me.BunifuThinButton28.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton28.BackgroundImage = CType(resources.GetObject("BunifuThinButton28.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton28.ButtonText = "Delete"
        Me.BunifuThinButton28.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton28.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton28.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton28.IdleBorderThickness = 1
        Me.BunifuThinButton28.IdleCornerRadius = 1
        Me.BunifuThinButton28.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton28.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton28.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton28.Location = New System.Drawing.Point(139, 1)
        Me.BunifuThinButton28.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton28.Name = "BunifuThinButton28"
        Me.BunifuThinButton28.Size = New System.Drawing.Size(63, 36)
        Me.BunifuThinButton28.TabIndex = 33
        Me.BunifuThinButton28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbpid
        '
        Me.BunifuTransition2.SetDecoration(Me.cmbpid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.cmbpid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.cmbpid, BunifuAnimatorNS.DecorationType.None)
        Me.cmbpid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbpid.FormattingEnabled = True
        Me.cmbpid.Location = New System.Drawing.Point(5, 8)
        Me.cmbpid.Name = "cmbpid"
        Me.cmbpid.Size = New System.Drawing.Size(128, 23)
        Me.cmbpid.TabIndex = 31
        Me.cmbpid.Text = "Select Patient Id"
        '
        'BunifuThinButton239
        '
        Me.BunifuThinButton239.ActiveBorderThickness = 1
        Me.BunifuThinButton239.ActiveCornerRadius = 3
        Me.BunifuThinButton239.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton239.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton239.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton239.AutoSize = True
        Me.BunifuThinButton239.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton239.BackgroundImage = CType(resources.GetObject("BunifuThinButton239.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton239.ButtonText = "Print"
        Me.BunifuThinButton239.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton239, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton239, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton239, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton239.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton239.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton239.IdleBorderThickness = 1
        Me.BunifuThinButton239.IdleCornerRadius = 1
        Me.BunifuThinButton239.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton239.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton239.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton239.Location = New System.Drawing.Point(455, 3)
        Me.BunifuThinButton239.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton239.Name = "BunifuThinButton239"
        Me.BunifuThinButton239.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton239.TabIndex = 30
        Me.BunifuThinButton239.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuThinButton239.Visible = False
        '
        'BunifuThinButton240
        '
        Me.BunifuThinButton240.ActiveBorderThickness = 1
        Me.BunifuThinButton240.ActiveCornerRadius = 2
        Me.BunifuThinButton240.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton240.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton240.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton240.AutoSize = True
        Me.BunifuThinButton240.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton240.BackgroundImage = CType(resources.GetObject("BunifuThinButton240.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton240.ButtonText = "Sign Up"
        Me.BunifuThinButton240.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton240, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton240, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton240, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton240.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton240.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton240.IdleBorderThickness = 1
        Me.BunifuThinButton240.IdleCornerRadius = 1
        Me.BunifuThinButton240.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton240.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton240.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton240.Location = New System.Drawing.Point(455, 6)
        Me.BunifuThinButton240.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton240.Name = "BunifuThinButton240"
        Me.BunifuThinButton240.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton240.TabIndex = 29
        Me.BunifuThinButton240.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuThinButton240.Visible = False
        '
        'BunifuThinButton223
        '
        Me.BunifuThinButton223.ActiveBorderThickness = 1
        Me.BunifuThinButton223.ActiveCornerRadius = 3
        Me.BunifuThinButton223.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton223.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton223.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton223.AutoSize = True
        Me.BunifuThinButton223.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton223.BackgroundImage = CType(resources.GetObject("BunifuThinButton223.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton223.ButtonText = "Report"
        Me.BunifuThinButton223.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton223, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton223, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton223, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton223.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton223.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton223.IdleBorderThickness = 1
        Me.BunifuThinButton223.IdleCornerRadius = 1
        Me.BunifuThinButton223.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton223.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton223.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton223.Location = New System.Drawing.Point(307, 4)
        Me.BunifuThinButton223.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton223.Name = "BunifuThinButton223"
        Me.BunifuThinButton223.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton223.TabIndex = 28
        Me.BunifuThinButton223.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuThinButton223.Visible = False
        '
        'BunifuThinButton225
        '
        Me.BunifuThinButton225.ActiveBorderThickness = 1
        Me.BunifuThinButton225.ActiveCornerRadius = 2
        Me.BunifuThinButton225.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton225.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton225.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton225.AutoSize = True
        Me.BunifuThinButton225.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton225.BackgroundImage = CType(resources.GetObject("BunifuThinButton225.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton225.ButtonText = "Sign Up"
        Me.BunifuThinButton225.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton225, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton225, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton225, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton225.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton225.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton225.IdleBorderThickness = 1
        Me.BunifuThinButton225.IdleCornerRadius = 1
        Me.BunifuThinButton225.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton225.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton225.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton225.Location = New System.Drawing.Point(307, 3)
        Me.BunifuThinButton225.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton225.Name = "BunifuThinButton225"
        Me.BunifuThinButton225.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton225.TabIndex = 27
        Me.BunifuThinButton225.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuThinButton225.Visible = False
        '
        'BunifuThinButton24
        '
        Me.BunifuThinButton24.ActiveBorderThickness = 1
        Me.BunifuThinButton24.ActiveCornerRadius = 3
        Me.BunifuThinButton24.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton24.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton24.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton24.AutoSize = True
        Me.BunifuThinButton24.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton24.BackgroundImage = CType(resources.GetObject("BunifuThinButton24.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton24.ButtonText = "Patient Record"
        Me.BunifuThinButton24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton24.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton24.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton24.IdleBorderThickness = 1
        Me.BunifuThinButton24.IdleCornerRadius = 1
        Me.BunifuThinButton24.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton24.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton24.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton24.Location = New System.Drawing.Point(159, 4)
        Me.BunifuThinButton24.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton24.Name = "BunifuThinButton24"
        Me.BunifuThinButton24.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton24.TabIndex = 26
        Me.BunifuThinButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton25
        '
        Me.BunifuThinButton25.ActiveBorderThickness = 1
        Me.BunifuThinButton25.ActiveCornerRadius = 2
        Me.BunifuThinButton25.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton25.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton25.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton25.AutoSize = True
        Me.BunifuThinButton25.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton25.BackgroundImage = CType(resources.GetObject("BunifuThinButton25.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton25.ButtonText = "Sign Up"
        Me.BunifuThinButton25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton25.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton25.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton25.IdleBorderThickness = 1
        Me.BunifuThinButton25.IdleCornerRadius = 1
        Me.BunifuThinButton25.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton25.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton25.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton25.Location = New System.Drawing.Point(159, 3)
        Me.BunifuThinButton25.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton25.Name = "BunifuThinButton25"
        Me.BunifuThinButton25.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton25.TabIndex = 25
        Me.BunifuThinButton25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton22
        '
        Me.BunifuThinButton22.ActiveBorderThickness = 1
        Me.BunifuThinButton22.ActiveCornerRadius = 3
        Me.BunifuThinButton22.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton22.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton22.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton22.AutoSize = True
        Me.BunifuThinButton22.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton22.BackgroundImage = CType(resources.GetObject("BunifuThinButton22.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BunifuThinButton22.ButtonText = "Add Patient"
        Me.BunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton22.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton22.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton22.IdleBorderThickness = 1
        Me.BunifuThinButton22.IdleCornerRadius = 1
        Me.BunifuThinButton22.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton22.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton22.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton22.Location = New System.Drawing.Point(11, 4)
        Me.BunifuThinButton22.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton22.Name = "BunifuThinButton22"
        Me.BunifuThinButton22.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton22.TabIndex = 24
        Me.BunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton23
        '
        Me.BunifuThinButton23.ActiveBorderThickness = 1
        Me.BunifuThinButton23.ActiveCornerRadius = 2
        Me.BunifuThinButton23.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton23.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton23.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton23.AutoSize = True
        Me.BunifuThinButton23.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton23.BackgroundImage = CType(resources.GetObject("BunifuThinButton23.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton23.ButtonText = "Sign Up"
        Me.BunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton23.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton23.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton23.IdleBorderThickness = 1
        Me.BunifuThinButton23.IdleCornerRadius = 1
        Me.BunifuThinButton23.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton23.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton23.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton23.Location = New System.Drawing.Point(11, 2)
        Me.BunifuThinButton23.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton23.Name = "BunifuThinButton23"
        Me.BunifuThinButton23.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton23.TabIndex = 23
        Me.BunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Controls.Add(Me.TabPage11)
        Me.TabControl2.Controls.Add(Me.TabPage17)
        Me.BunifuTransition3.SetDecoration(Me.TabControl2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabControl2, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl2.Location = New System.Drawing.Point(-4, 55)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(981, 435)
        Me.TabControl2.TabIndex = 14
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage7.Controls.Add(Me.txtsr)
        Me.TabPage7.Controls.Add(Me.Panel31)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel38)
        Me.TabPage7.Controls.Add(Me.txtdoctorid)
        Me.TabPage7.Controls.Add(Me.txtpatientid)
        Me.TabPage7.Controls.Add(Me.txtdoctor)
        Me.TabPage7.Controls.Add(Me.txtdisease)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel60)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel59)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel58)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel53)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel52)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel50)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel48)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel46)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel44)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel43)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel42)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel41)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel40)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel35)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel34)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel33)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel32)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel31)
        Me.TabPage7.Controls.Add(Me.BunifuCustomLabel30)
        Me.TabPage7.Controls.Add(Me.date1)
        Me.TabPage7.Controls.Add(Me.txtwardno)
        Me.TabPage7.Controls.Add(Me.txtprate)
        Me.TabPage7.Controls.Add(Me.txtwardtype)
        Me.TabPage7.Controls.Add(Me.txtlbp)
        Me.TabPage7.Controls.Add(Me.txtmobile)
        Me.TabPage7.Controls.Add(Me.txthbp)
        Me.TabPage7.Controls.Add(Me.txtbodytemp)
        Me.TabPage7.Controls.Add(Me.txtbloodgroup)
        Me.TabPage7.Controls.Add(Me.txtheight)
        Me.TabPage7.Controls.Add(Me.txtweight)
        Me.TabPage7.Controls.Add(Me.txtage)
        Me.TabPage7.Controls.Add(Me.txtgender)
        Me.TabPage7.Controls.Add(Me.txtaddress)
        Me.TabPage7.Controls.Add(Me.txtdob)
        Me.TabPage7.Controls.Add(Me.txtpatientname)
        Me.BunifuTransition1.SetDecoration(Me.TabPage7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage7, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(973, 409)
        Me.TabPage7.TabIndex = 0
        Me.TabPage7.Text = "TabPage7"
        '
        'txtsr
        '
        Me.txtsr.BorderColorFocused = System.Drawing.Color.White
        Me.txtsr.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtsr.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtsr.BorderThickness = 1
        Me.txtsr.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtsr, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtsr, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtsr, BunifuAnimatorNS.DecorationType.None)
        Me.txtsr.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtsr.ForeColor = System.Drawing.Color.White
        Me.txtsr.isPassword = False
        Me.txtsr.Location = New System.Drawing.Point(130, 344)
        Me.txtsr.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsr.Name = "txtsr"
        Me.txtsr.Size = New System.Drawing.Size(96, 30)
        Me.txtsr.TabIndex = 168
        Me.txtsr.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Panel31
        '
        Me.Panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel64)
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel75)
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel74)
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel73)
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel72)
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel71)
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel68)
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel67)
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel66)
        Me.Panel31.Controls.Add(Me.Panel34)
        Me.Panel31.Controls.Add(Me.Panel33)
        Me.Panel31.Controls.Add(Me.Panel32)
        Me.Panel31.Controls.Add(Me.Panel3)
        Me.BunifuTransition3.SetDecoration(Me.Panel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel31, BunifuAnimatorNS.DecorationType.None)
        Me.Panel31.Location = New System.Drawing.Point(804, 21)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(157, 382)
        Me.Panel31.TabIndex = 167
        '
        'BunifuCustomLabel64
        '
        Me.BunifuCustomLabel64.AutoSize = True
        Me.BunifuCustomLabel64.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel64, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel64, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel64, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel64.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel64.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel64.Location = New System.Drawing.Point(47, 60)
        Me.BunifuCustomLabel64.Name = "BunifuCustomLabel64"
        Me.BunifuCustomLabel64.Size = New System.Drawing.Size(37, 23)
        Me.BunifuCustomLabel64.TabIndex = 14
        Me.BunifuCustomLabel64.Text = "90 "
        '
        'BunifuCustomLabel75
        '
        Me.BunifuCustomLabel75.AutoSize = True
        Me.BunifuCustomLabel75.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel75, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel75, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel75, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel75.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel75.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel75.Location = New System.Drawing.Point(115, 60)
        Me.BunifuCustomLabel75.Name = "BunifuCustomLabel75"
        Me.BunifuCustomLabel75.Size = New System.Drawing.Size(25, 23)
        Me.BunifuCustomLabel75.TabIndex = 176
        Me.BunifuCustomLabel75.Text = "C"
        '
        'BunifuCustomLabel74
        '
        Me.BunifuCustomLabel74.AutoSize = True
        Me.BunifuCustomLabel74.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel74, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel74, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel74, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel74.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel74.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel74.Location = New System.Drawing.Point(79, 62)
        Me.BunifuCustomLabel74.Name = "BunifuCustomLabel74"
        Me.BunifuCustomLabel74.Size = New System.Drawing.Size(17, 23)
        Me.BunifuCustomLabel74.TabIndex = 175
        Me.BunifuCustomLabel74.Text = "˚"
        '
        'BunifuCustomLabel73
        '
        Me.BunifuCustomLabel73.AutoSize = True
        Me.BunifuCustomLabel73.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel73, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel73, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel73, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel73.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel73.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel73.Location = New System.Drawing.Point(90, 321)
        Me.BunifuCustomLabel73.Name = "BunifuCustomLabel73"
        Me.BunifuCustomLabel73.Size = New System.Drawing.Size(57, 23)
        Me.BunifuCustomLabel73.TabIndex = 174
        Me.BunifuCustomLabel73.Text = "/ Min"
        '
        'BunifuCustomLabel72
        '
        Me.BunifuCustomLabel72.AutoSize = True
        Me.BunifuCustomLabel72.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel72, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel72, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel72, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel72.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel72.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel72.Location = New System.Drawing.Point(90, 235)
        Me.BunifuCustomLabel72.Name = "BunifuCustomLabel72"
        Me.BunifuCustomLabel72.Size = New System.Drawing.Size(59, 17)
        Me.BunifuCustomLabel72.TabIndex = 173
        Me.BunifuCustomLabel72.Text = "mm Hg"
        '
        'BunifuCustomLabel71
        '
        Me.BunifuCustomLabel71.AutoSize = True
        Me.BunifuCustomLabel71.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel71, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel71, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel71, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel71.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel71.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel71.Location = New System.Drawing.Point(90, 147)
        Me.BunifuCustomLabel71.Name = "BunifuCustomLabel71"
        Me.BunifuCustomLabel71.Size = New System.Drawing.Size(59, 17)
        Me.BunifuCustomLabel71.TabIndex = 172
        Me.BunifuCustomLabel71.Text = "mm Hg"
        '
        'BunifuCustomLabel68
        '
        Me.BunifuCustomLabel68.AutoSize = True
        Me.BunifuCustomLabel68.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel68, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel68, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel68, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel68.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel68.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel68.Location = New System.Drawing.Point(41, 322)
        Me.BunifuCustomLabel68.Name = "BunifuCustomLabel68"
        Me.BunifuCustomLabel68.Size = New System.Drawing.Size(32, 23)
        Me.BunifuCustomLabel68.TabIndex = 171
        Me.BunifuCustomLabel68.Text = "70"
        '
        'BunifuCustomLabel67
        '
        Me.BunifuCustomLabel67.AutoSize = True
        Me.BunifuCustomLabel67.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel67, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel67, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel67, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel67.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel67.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel67.Location = New System.Drawing.Point(41, 234)
        Me.BunifuCustomLabel67.Name = "BunifuCustomLabel67"
        Me.BunifuCustomLabel67.Size = New System.Drawing.Size(32, 23)
        Me.BunifuCustomLabel67.TabIndex = 170
        Me.BunifuCustomLabel67.Text = "80"
        '
        'BunifuCustomLabel66
        '
        Me.BunifuCustomLabel66.AutoSize = True
        Me.BunifuCustomLabel66.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel66, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel66, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel66, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel66.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel66.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel66.Location = New System.Drawing.Point(41, 146)
        Me.BunifuCustomLabel66.Name = "BunifuCustomLabel66"
        Me.BunifuCustomLabel66.Size = New System.Drawing.Size(43, 23)
        Me.BunifuCustomLabel66.TabIndex = 169
        Me.BunifuCustomLabel66.Text = "135"
        '
        'Panel34
        '
        Me.Panel34.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.Panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel63)
        Me.BunifuTransition3.SetDecoration(Me.Panel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel34, BunifuAnimatorNS.DecorationType.None)
        Me.Panel34.Location = New System.Drawing.Point(0, 267)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(155, 44)
        Me.Panel34.TabIndex = 168
        '
        'BunifuCustomLabel63
        '
        Me.BunifuCustomLabel63.AutoSize = True
        Me.BunifuCustomLabel63.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel63, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel63, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel63, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel63.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel63.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel63.Location = New System.Drawing.Point(33, 13)
        Me.BunifuCustomLabel63.Name = "BunifuCustomLabel63"
        Me.BunifuCustomLabel63.Size = New System.Drawing.Size(77, 17)
        Me.BunifuCustomLabel63.TabIndex = 16
        Me.BunifuCustomLabel63.Text = "Pulse Rate"
        '
        'Panel33
        '
        Me.Panel33.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.Panel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel33.Controls.Add(Me.BunifuCustomLabel70)
        Me.Panel33.Controls.Add(Me.BunifuCustomLabel62)
        Me.BunifuTransition3.SetDecoration(Me.Panel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel33, BunifuAnimatorNS.DecorationType.None)
        Me.Panel33.Location = New System.Drawing.Point(0, 174)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(155, 44)
        Me.Panel33.TabIndex = 168
        '
        'BunifuCustomLabel70
        '
        Me.BunifuCustomLabel70.AutoSize = True
        Me.BunifuCustomLabel70.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel70, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel70, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel70, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel70.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel70.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel70.Location = New System.Drawing.Point(42, 26)
        Me.BunifuCustomLabel70.Name = "BunifuCustomLabel70"
        Me.BunifuCustomLabel70.Size = New System.Drawing.Size(67, 17)
        Me.BunifuCustomLabel70.TabIndex = 16
        Me.BunifuCustomLabel70.Text = "Diastolic"
        '
        'BunifuCustomLabel62
        '
        Me.BunifuCustomLabel62.AutoSize = True
        Me.BunifuCustomLabel62.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel62, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel62, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel62, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel62.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel62.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel62.Location = New System.Drawing.Point(44, 5)
        Me.BunifuCustomLabel62.Name = "BunifuCustomLabel62"
        Me.BunifuCustomLabel62.Size = New System.Drawing.Size(54, 17)
        Me.BunifuCustomLabel62.TabIndex = 15
        Me.BunifuCustomLabel62.Text = "Low BP"
        '
        'Panel32
        '
        Me.Panel32.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.Panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel32.Controls.Add(Me.BunifuCustomLabel69)
        Me.Panel32.Controls.Add(Me.BunifuCustomLabel61)
        Me.BunifuTransition3.SetDecoration(Me.Panel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel32, BunifuAnimatorNS.DecorationType.None)
        Me.Panel32.Location = New System.Drawing.Point(0, 86)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(155, 44)
        Me.Panel32.TabIndex = 167
        '
        'BunifuCustomLabel69
        '
        Me.BunifuCustomLabel69.AutoSize = True
        Me.BunifuCustomLabel69.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel69, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel69, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel69, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel69.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel69.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel69.Location = New System.Drawing.Point(44, 23)
        Me.BunifuCustomLabel69.Name = "BunifuCustomLabel69"
        Me.BunifuCustomLabel69.Size = New System.Drawing.Size(58, 17)
        Me.BunifuCustomLabel69.TabIndex = 15
        Me.BunifuCustomLabel69.Text = "Systolic"
        '
        'BunifuCustomLabel61
        '
        Me.BunifuCustomLabel61.AutoSize = True
        Me.BunifuCustomLabel61.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel61, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel61, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel61, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel61.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel61.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel61.Location = New System.Drawing.Point(42, 1)
        Me.BunifuCustomLabel61.Name = "BunifuCustomLabel61"
        Me.BunifuCustomLabel61.Size = New System.Drawing.Size(59, 17)
        Me.BunifuCustomLabel61.TabIndex = 14
        Me.BunifuCustomLabel61.Text = "High BP"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel36)
        Me.BunifuTransition3.SetDecoration(Me.Panel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel3, BunifuAnimatorNS.DecorationType.None)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(155, 44)
        Me.Panel3.TabIndex = 166
        '
        'BunifuCustomLabel36
        '
        Me.BunifuCustomLabel36.AutoSize = True
        Me.BunifuCustomLabel36.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel36.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel36.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel36.Location = New System.Drawing.Point(6, 10)
        Me.BunifuCustomLabel36.Name = "BunifuCustomLabel36"
        Me.BunifuCustomLabel36.Size = New System.Drawing.Size(130, 17)
        Me.BunifuCustomLabel36.TabIndex = 13
        Me.BunifuCustomLabel36.Text = "Body Temperature"
        '
        'BunifuCustomLabel38
        '
        Me.BunifuCustomLabel38.AutoSize = True
        Me.BunifuCustomLabel38.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel38.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel38.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel38.Location = New System.Drawing.Point(404, 198)
        Me.BunifuCustomLabel38.Name = "BunifuCustomLabel38"
        Me.BunifuCustomLabel38.Size = New System.Drawing.Size(71, 17)
        Me.BunifuCustomLabel38.TabIndex = 164
        Me.BunifuCustomLabel38.Text = "Doctor ID"
        '
        'txtdoctorid
        '
        Me.txtdoctorid.BorderColorFocused = System.Drawing.Color.White
        Me.txtdoctorid.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdoctorid.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdoctorid.BorderThickness = 1
        Me.txtdoctorid.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtdoctorid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdoctorid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtdoctorid, BunifuAnimatorNS.DecorationType.None)
        Me.txtdoctorid.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdoctorid.ForeColor = System.Drawing.Color.White
        Me.txtdoctorid.isPassword = False
        Me.txtdoctorid.Location = New System.Drawing.Point(509, 191)
        Me.txtdoctorid.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdoctorid.Name = "txtdoctorid"
        Me.txtdoctorid.Size = New System.Drawing.Size(240, 30)
        Me.txtdoctorid.TabIndex = 163
        Me.txtdoctorid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtpatientid
        '
        Me.BunifuTransition2.SetDecoration(Me.txtpatientid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtpatientid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtpatientid, BunifuAnimatorNS.DecorationType.None)
        Me.txtpatientid.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpatientid.FormattingEnabled = True
        Me.txtpatientid.Location = New System.Drawing.Point(130, 30)
        Me.txtpatientid.Name = "txtpatientid"
        Me.txtpatientid.Size = New System.Drawing.Size(240, 28)
        Me.txtpatientid.TabIndex = 162
        '
        'txtdoctor
        '
        Me.BunifuTransition2.SetDecoration(Me.txtdoctor, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtdoctor, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdoctor, BunifuAnimatorNS.DecorationType.None)
        Me.txtdoctor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdoctor.FormattingEnabled = True
        Me.txtdoctor.Location = New System.Drawing.Point(509, 158)
        Me.txtdoctor.Name = "txtdoctor"
        Me.txtdoctor.Size = New System.Drawing.Size(240, 28)
        Me.txtdoctor.TabIndex = 161
        '
        'txtdisease
        '
        Me.BunifuTransition2.SetDecoration(Me.txtdisease, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtdisease, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdisease, BunifuAnimatorNS.DecorationType.None)
        Me.txtdisease.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdisease.FormattingEnabled = True
        Me.txtdisease.Location = New System.Drawing.Point(509, 126)
        Me.txtdisease.Name = "txtdisease"
        Me.txtdisease.Size = New System.Drawing.Size(240, 28)
        Me.txtdisease.TabIndex = 160
        '
        'BunifuCustomLabel60
        '
        Me.BunifuCustomLabel60.AutoSize = True
        Me.BunifuCustomLabel60.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel60, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel60, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel60, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel60.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel60.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel60.Location = New System.Drawing.Point(404, 378)
        Me.BunifuCustomLabel60.Name = "BunifuCustomLabel60"
        Me.BunifuCustomLabel60.Size = New System.Drawing.Size(40, 17)
        Me.BunifuCustomLabel60.TabIndex = 159
        Me.BunifuCustomLabel60.Text = "Date"
        '
        'BunifuCustomLabel59
        '
        Me.BunifuCustomLabel59.AutoSize = True
        Me.BunifuCustomLabel59.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel59, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel59, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel59, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel59.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel59.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel59.Location = New System.Drawing.Point(403, 340)
        Me.BunifuCustomLabel59.Name = "BunifuCustomLabel59"
        Me.BunifuCustomLabel59.Size = New System.Drawing.Size(77, 17)
        Me.BunifuCustomLabel59.TabIndex = 158
        Me.BunifuCustomLabel59.Text = "Pulse Rate"
        '
        'BunifuCustomLabel58
        '
        Me.BunifuCustomLabel58.AutoSize = True
        Me.BunifuCustomLabel58.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel58, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel58, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel58, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel58.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel58.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel58.Location = New System.Drawing.Point(404, 303)
        Me.BunifuCustomLabel58.Name = "BunifuCustomLabel58"
        Me.BunifuCustomLabel58.Size = New System.Drawing.Size(54, 17)
        Me.BunifuCustomLabel58.TabIndex = 157
        Me.BunifuCustomLabel58.Text = "Low BP"
        '
        'BunifuCustomLabel53
        '
        Me.BunifuCustomLabel53.AutoSize = True
        Me.BunifuCustomLabel53.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel53, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel53, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel53, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel53.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel53.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel53.Location = New System.Drawing.Point(404, 267)
        Me.BunifuCustomLabel53.Name = "BunifuCustomLabel53"
        Me.BunifuCustomLabel53.Size = New System.Drawing.Size(59, 17)
        Me.BunifuCustomLabel53.TabIndex = 156
        Me.BunifuCustomLabel53.Text = "High BP"
        '
        'BunifuCustomLabel52
        '
        Me.BunifuCustomLabel52.AutoSize = True
        Me.BunifuCustomLabel52.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel52, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel52, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel52, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel52.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel52.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel52.Location = New System.Drawing.Point(404, 233)
        Me.BunifuCustomLabel52.Name = "BunifuCustomLabel52"
        Me.BunifuCustomLabel52.Size = New System.Drawing.Size(83, 17)
        Me.BunifuCustomLabel52.TabIndex = 155
        Me.BunifuCustomLabel52.Text = "Body Temp"
        '
        'BunifuCustomLabel50
        '
        Me.BunifuCustomLabel50.AutoSize = True
        Me.BunifuCustomLabel50.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel50, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel50, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel50, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel50.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel50.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel50.Location = New System.Drawing.Point(404, 164)
        Me.BunifuCustomLabel50.Name = "BunifuCustomLabel50"
        Me.BunifuCustomLabel50.Size = New System.Drawing.Size(53, 17)
        Me.BunifuCustomLabel50.TabIndex = 154
        Me.BunifuCustomLabel50.Text = "Doctor"
        '
        'BunifuCustomLabel48
        '
        Me.BunifuCustomLabel48.AutoSize = True
        Me.BunifuCustomLabel48.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel48, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel48, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel48, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel48.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel48.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel48.Location = New System.Drawing.Point(404, 132)
        Me.BunifuCustomLabel48.Name = "BunifuCustomLabel48"
        Me.BunifuCustomLabel48.Size = New System.Drawing.Size(103, 17)
        Me.BunifuCustomLabel48.TabIndex = 153
        Me.BunifuCustomLabel48.Text = "Specialization"
        '
        'BunifuCustomLabel46
        '
        Me.BunifuCustomLabel46.AutoSize = True
        Me.BunifuCustomLabel46.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel46, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel46, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel46, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel46.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel46.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel46.Location = New System.Drawing.Point(403, 98)
        Me.BunifuCustomLabel46.Name = "BunifuCustomLabel46"
        Me.BunifuCustomLabel46.Size = New System.Drawing.Size(93, 17)
        Me.BunifuCustomLabel46.TabIndex = 152
        Me.BunifuCustomLabel46.Text = "Blood Group"
        '
        'BunifuCustomLabel44
        '
        Me.BunifuCustomLabel44.AutoSize = True
        Me.BunifuCustomLabel44.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel44, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel44, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel44, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel44.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel44.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel44.Location = New System.Drawing.Point(404, 64)
        Me.BunifuCustomLabel44.Name = "BunifuCustomLabel44"
        Me.BunifuCustomLabel44.Size = New System.Drawing.Size(52, 17)
        Me.BunifuCustomLabel44.TabIndex = 151
        Me.BunifuCustomLabel44.Text = "Height"
        '
        'BunifuCustomLabel43
        '
        Me.BunifuCustomLabel43.AutoSize = True
        Me.BunifuCustomLabel43.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel43.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel43.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel43.Location = New System.Drawing.Point(404, 33)
        Me.BunifuCustomLabel43.Name = "BunifuCustomLabel43"
        Me.BunifuCustomLabel43.Size = New System.Drawing.Size(55, 17)
        Me.BunifuCustomLabel43.TabIndex = 150
        Me.BunifuCustomLabel43.Text = "Weight"
        '
        'BunifuCustomLabel42
        '
        Me.BunifuCustomLabel42.AutoSize = True
        Me.BunifuCustomLabel42.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel42.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel42.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel42.Location = New System.Drawing.Point(15, 308)
        Me.BunifuCustomLabel42.Name = "BunifuCustomLabel42"
        Me.BunifuCustomLabel42.Size = New System.Drawing.Size(66, 17)
        Me.BunifuCustomLabel42.TabIndex = 149
        Me.BunifuCustomLabel42.Text = "Ward No"
        '
        'BunifuCustomLabel41
        '
        Me.BunifuCustomLabel41.AutoSize = True
        Me.BunifuCustomLabel41.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel41.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel41.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel41.Location = New System.Drawing.Point(15, 273)
        Me.BunifuCustomLabel41.Name = "BunifuCustomLabel41"
        Me.BunifuCustomLabel41.Size = New System.Drawing.Size(78, 17)
        Me.BunifuCustomLabel41.TabIndex = 148
        Me.BunifuCustomLabel41.Text = "Ward Type"
        '
        'BunifuCustomLabel40
        '
        Me.BunifuCustomLabel40.AutoSize = True
        Me.BunifuCustomLabel40.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel40.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel40.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel40.Location = New System.Drawing.Point(15, 239)
        Me.BunifuCustomLabel40.Name = "BunifuCustomLabel40"
        Me.BunifuCustomLabel40.Size = New System.Drawing.Size(79, 17)
        Me.BunifuCustomLabel40.TabIndex = 147
        Me.BunifuCustomLabel40.Text = "Mobile No"
        '
        'BunifuCustomLabel35
        '
        Me.BunifuCustomLabel35.AutoSize = True
        Me.BunifuCustomLabel35.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel35.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel35.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel35.Location = New System.Drawing.Point(15, 203)
        Me.BunifuCustomLabel35.Name = "BunifuCustomLabel35"
        Me.BunifuCustomLabel35.Size = New System.Drawing.Size(36, 17)
        Me.BunifuCustomLabel35.TabIndex = 145
        Me.BunifuCustomLabel35.Text = "Age"
        '
        'BunifuCustomLabel34
        '
        Me.BunifuCustomLabel34.AutoSize = True
        Me.BunifuCustomLabel34.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel34.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel34.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel34.Location = New System.Drawing.Point(15, 168)
        Me.BunifuCustomLabel34.Name = "BunifuCustomLabel34"
        Me.BunifuCustomLabel34.Size = New System.Drawing.Size(59, 17)
        Me.BunifuCustomLabel34.TabIndex = 144
        Me.BunifuCustomLabel34.Text = "Gender"
        '
        'BunifuCustomLabel33
        '
        Me.BunifuCustomLabel33.AutoSize = True
        Me.BunifuCustomLabel33.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel33.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel33.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel33.Location = New System.Drawing.Point(15, 134)
        Me.BunifuCustomLabel33.Name = "BunifuCustomLabel33"
        Me.BunifuCustomLabel33.Size = New System.Drawing.Size(61, 17)
        Me.BunifuCustomLabel33.TabIndex = 143
        Me.BunifuCustomLabel33.Text = "Address"
        '
        'BunifuCustomLabel32
        '
        Me.BunifuCustomLabel32.AutoSize = True
        Me.BunifuCustomLabel32.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel32.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel32.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel32.Location = New System.Drawing.Point(15, 100)
        Me.BunifuCustomLabel32.Name = "BunifuCustomLabel32"
        Me.BunifuCustomLabel32.Size = New System.Drawing.Size(92, 17)
        Me.BunifuCustomLabel32.TabIndex = 142
        Me.BunifuCustomLabel32.Text = "Date Of Birth"
        '
        'BunifuCustomLabel31
        '
        Me.BunifuCustomLabel31.AutoSize = True
        Me.BunifuCustomLabel31.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel31.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel31.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel31.Location = New System.Drawing.Point(15, 67)
        Me.BunifuCustomLabel31.Name = "BunifuCustomLabel31"
        Me.BunifuCustomLabel31.Size = New System.Drawing.Size(100, 17)
        Me.BunifuCustomLabel31.TabIndex = 141
        Me.BunifuCustomLabel31.Text = "Patient Name"
        '
        'BunifuCustomLabel30
        '
        Me.BunifuCustomLabel30.AutoSize = True
        Me.BunifuCustomLabel30.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel30.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel30.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel30.Location = New System.Drawing.Point(15, 33)
        Me.BunifuCustomLabel30.Name = "BunifuCustomLabel30"
        Me.BunifuCustomLabel30.Size = New System.Drawing.Size(71, 17)
        Me.BunifuCustomLabel30.TabIndex = 140
        Me.BunifuCustomLabel30.Text = "Patient Id"
        '
        'date1
        '
        Me.date1.BorderColorFocused = System.Drawing.Color.White
        Me.date1.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.date1.BorderColorMouseHover = System.Drawing.Color.White
        Me.date1.BorderThickness = 1
        Me.date1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.date1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.date1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.date1, BunifuAnimatorNS.DecorationType.None)
        Me.date1.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.date1.ForeColor = System.Drawing.Color.White
        Me.date1.isPassword = False
        Me.date1.Location = New System.Drawing.Point(509, 371)
        Me.date1.Margin = New System.Windows.Forms.Padding(4)
        Me.date1.Name = "date1"
        Me.date1.Size = New System.Drawing.Size(240, 30)
        Me.date1.TabIndex = 139
        Me.date1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtwardno
        '
        Me.txtwardno.BorderColorFocused = System.Drawing.Color.White
        Me.txtwardno.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtwardno.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtwardno.BorderThickness = 1
        Me.txtwardno.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtwardno, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtwardno, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtwardno, BunifuAnimatorNS.DecorationType.None)
        Me.txtwardno.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtwardno.ForeColor = System.Drawing.Color.White
        Me.txtwardno.isPassword = False
        Me.txtwardno.Location = New System.Drawing.Point(130, 300)
        Me.txtwardno.Margin = New System.Windows.Forms.Padding(4)
        Me.txtwardno.Name = "txtwardno"
        Me.txtwardno.Size = New System.Drawing.Size(240, 30)
        Me.txtwardno.TabIndex = 138
        Me.txtwardno.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtprate
        '
        Me.txtprate.BorderColorFocused = System.Drawing.Color.White
        Me.txtprate.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtprate.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtprate.BorderThickness = 1
        Me.txtprate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtprate, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtprate, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtprate, BunifuAnimatorNS.DecorationType.None)
        Me.txtprate.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtprate.ForeColor = System.Drawing.Color.White
        Me.txtprate.isPassword = False
        Me.txtprate.Location = New System.Drawing.Point(509, 333)
        Me.txtprate.Margin = New System.Windows.Forms.Padding(4)
        Me.txtprate.Name = "txtprate"
        Me.txtprate.Size = New System.Drawing.Size(240, 30)
        Me.txtprate.TabIndex = 137
        Me.txtprate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtwardtype
        '
        Me.txtwardtype.BorderColorFocused = System.Drawing.Color.White
        Me.txtwardtype.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtwardtype.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtwardtype.BorderThickness = 1
        Me.txtwardtype.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtwardtype, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtwardtype, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtwardtype, BunifuAnimatorNS.DecorationType.None)
        Me.txtwardtype.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtwardtype.ForeColor = System.Drawing.Color.White
        Me.txtwardtype.isPassword = False
        Me.txtwardtype.Location = New System.Drawing.Point(130, 266)
        Me.txtwardtype.Margin = New System.Windows.Forms.Padding(4)
        Me.txtwardtype.Name = "txtwardtype"
        Me.txtwardtype.Size = New System.Drawing.Size(240, 30)
        Me.txtwardtype.TabIndex = 136
        Me.txtwardtype.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtlbp
        '
        Me.txtlbp.BorderColorFocused = System.Drawing.Color.White
        Me.txtlbp.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtlbp.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtlbp.BorderThickness = 1
        Me.txtlbp.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtlbp, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtlbp, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtlbp, BunifuAnimatorNS.DecorationType.None)
        Me.txtlbp.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtlbp.ForeColor = System.Drawing.Color.White
        Me.txtlbp.isPassword = False
        Me.txtlbp.Location = New System.Drawing.Point(509, 296)
        Me.txtlbp.Margin = New System.Windows.Forms.Padding(4)
        Me.txtlbp.Name = "txtlbp"
        Me.txtlbp.Size = New System.Drawing.Size(240, 30)
        Me.txtlbp.TabIndex = 135
        Me.txtlbp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtmobile
        '
        Me.txtmobile.BorderColorFocused = System.Drawing.Color.White
        Me.txtmobile.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtmobile.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtmobile.BorderThickness = 1
        Me.txtmobile.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtmobile, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtmobile, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtmobile, BunifuAnimatorNS.DecorationType.None)
        Me.txtmobile.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtmobile.ForeColor = System.Drawing.Color.White
        Me.txtmobile.isPassword = False
        Me.txtmobile.Location = New System.Drawing.Point(130, 232)
        Me.txtmobile.Margin = New System.Windows.Forms.Padding(4)
        Me.txtmobile.Name = "txtmobile"
        Me.txtmobile.Size = New System.Drawing.Size(240, 30)
        Me.txtmobile.TabIndex = 134
        Me.txtmobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txthbp
        '
        Me.txthbp.BorderColorFocused = System.Drawing.Color.White
        Me.txthbp.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txthbp.BorderColorMouseHover = System.Drawing.Color.White
        Me.txthbp.BorderThickness = 1
        Me.txthbp.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txthbp, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txthbp, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txthbp, BunifuAnimatorNS.DecorationType.None)
        Me.txthbp.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txthbp.ForeColor = System.Drawing.Color.White
        Me.txthbp.isPassword = False
        Me.txthbp.Location = New System.Drawing.Point(509, 260)
        Me.txthbp.Margin = New System.Windows.Forms.Padding(4)
        Me.txthbp.Name = "txthbp"
        Me.txthbp.Size = New System.Drawing.Size(240, 30)
        Me.txthbp.TabIndex = 133
        Me.txthbp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtbodytemp
        '
        Me.txtbodytemp.BorderColorFocused = System.Drawing.Color.White
        Me.txtbodytemp.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtbodytemp.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtbodytemp.BorderThickness = 1
        Me.txtbodytemp.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtbodytemp, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtbodytemp, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtbodytemp, BunifuAnimatorNS.DecorationType.None)
        Me.txtbodytemp.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtbodytemp.ForeColor = System.Drawing.Color.White
        Me.txtbodytemp.isPassword = False
        Me.txtbodytemp.Location = New System.Drawing.Point(509, 226)
        Me.txtbodytemp.Margin = New System.Windows.Forms.Padding(4)
        Me.txtbodytemp.Name = "txtbodytemp"
        Me.txtbodytemp.Size = New System.Drawing.Size(240, 30)
        Me.txtbodytemp.TabIndex = 132
        Me.txtbodytemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtbloodgroup
        '
        Me.txtbloodgroup.BorderColorFocused = System.Drawing.Color.White
        Me.txtbloodgroup.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtbloodgroup.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtbloodgroup.BorderThickness = 1
        Me.txtbloodgroup.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtbloodgroup, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtbloodgroup, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtbloodgroup, BunifuAnimatorNS.DecorationType.None)
        Me.txtbloodgroup.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtbloodgroup.ForeColor = System.Drawing.Color.White
        Me.txtbloodgroup.isPassword = False
        Me.txtbloodgroup.Location = New System.Drawing.Point(509, 92)
        Me.txtbloodgroup.Margin = New System.Windows.Forms.Padding(4)
        Me.txtbloodgroup.Name = "txtbloodgroup"
        Me.txtbloodgroup.Size = New System.Drawing.Size(240, 30)
        Me.txtbloodgroup.TabIndex = 129
        Me.txtbloodgroup.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtheight
        '
        Me.txtheight.BorderColorFocused = System.Drawing.Color.White
        Me.txtheight.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtheight.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtheight.BorderThickness = 1
        Me.txtheight.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtheight, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtheight, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtheight, BunifuAnimatorNS.DecorationType.None)
        Me.txtheight.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtheight.ForeColor = System.Drawing.Color.White
        Me.txtheight.isPassword = False
        Me.txtheight.Location = New System.Drawing.Point(509, 59)
        Me.txtheight.Margin = New System.Windows.Forms.Padding(4)
        Me.txtheight.Name = "txtheight"
        Me.txtheight.Size = New System.Drawing.Size(240, 30)
        Me.txtheight.TabIndex = 128
        Me.txtheight.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtweight
        '
        Me.txtweight.BorderColorFocused = System.Drawing.Color.White
        Me.txtweight.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtweight.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtweight.BorderThickness = 1
        Me.txtweight.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtweight, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtweight, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtweight, BunifuAnimatorNS.DecorationType.None)
        Me.txtweight.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtweight.ForeColor = System.Drawing.Color.White
        Me.txtweight.isPassword = False
        Me.txtweight.Location = New System.Drawing.Point(509, 27)
        Me.txtweight.Margin = New System.Windows.Forms.Padding(4)
        Me.txtweight.Name = "txtweight"
        Me.txtweight.Size = New System.Drawing.Size(240, 30)
        Me.txtweight.TabIndex = 127
        Me.txtweight.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtage
        '
        Me.txtage.BorderColorFocused = System.Drawing.Color.White
        Me.txtage.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtage.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtage.BorderThickness = 1
        Me.txtage.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtage, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtage, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtage, BunifuAnimatorNS.DecorationType.None)
        Me.txtage.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtage.ForeColor = System.Drawing.Color.White
        Me.txtage.isPassword = False
        Me.txtage.Location = New System.Drawing.Point(130, 198)
        Me.txtage.Margin = New System.Windows.Forms.Padding(4)
        Me.txtage.Name = "txtage"
        Me.txtage.Size = New System.Drawing.Size(240, 30)
        Me.txtage.TabIndex = 125
        Me.txtage.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtgender
        '
        Me.txtgender.BorderColorFocused = System.Drawing.Color.White
        Me.txtgender.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtgender.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtgender.BorderThickness = 1
        Me.txtgender.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtgender, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtgender, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtgender, BunifuAnimatorNS.DecorationType.None)
        Me.txtgender.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtgender.ForeColor = System.Drawing.Color.White
        Me.txtgender.isPassword = False
        Me.txtgender.Location = New System.Drawing.Point(130, 164)
        Me.txtgender.Margin = New System.Windows.Forms.Padding(4)
        Me.txtgender.Name = "txtgender"
        Me.txtgender.Size = New System.Drawing.Size(240, 30)
        Me.txtgender.TabIndex = 124
        Me.txtgender.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtaddress
        '
        Me.txtaddress.BorderColorFocused = System.Drawing.Color.White
        Me.txtaddress.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtaddress.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtaddress.BorderThickness = 1
        Me.txtaddress.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtaddress, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtaddress, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtaddress, BunifuAnimatorNS.DecorationType.None)
        Me.txtaddress.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtaddress.ForeColor = System.Drawing.Color.White
        Me.txtaddress.isPassword = False
        Me.txtaddress.Location = New System.Drawing.Point(130, 130)
        Me.txtaddress.Margin = New System.Windows.Forms.Padding(4)
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(240, 30)
        Me.txtaddress.TabIndex = 123
        Me.txtaddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtdob
        '
        Me.txtdob.BorderColorFocused = System.Drawing.Color.White
        Me.txtdob.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdob.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdob.BorderThickness = 1
        Me.txtdob.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtdob, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdob, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtdob, BunifuAnimatorNS.DecorationType.None)
        Me.txtdob.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdob.ForeColor = System.Drawing.Color.White
        Me.txtdob.isPassword = False
        Me.txtdob.Location = New System.Drawing.Point(130, 96)
        Me.txtdob.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdob.Name = "txtdob"
        Me.txtdob.Size = New System.Drawing.Size(240, 30)
        Me.txtdob.TabIndex = 122
        Me.txtdob.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtpatientname
        '
        Me.txtpatientname.BorderColorFocused = System.Drawing.Color.White
        Me.txtpatientname.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtpatientname.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtpatientname.BorderThickness = 1
        Me.txtpatientname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.txtpatientname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtpatientname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtpatientname, BunifuAnimatorNS.DecorationType.None)
        Me.txtpatientname.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtpatientname.ForeColor = System.Drawing.Color.White
        Me.txtpatientname.isPassword = False
        Me.txtpatientname.Location = New System.Drawing.Point(130, 62)
        Me.txtpatientname.Margin = New System.Windows.Forms.Padding(4)
        Me.txtpatientname.Name = "txtpatientname"
        Me.txtpatientname.Size = New System.Drawing.Size(240, 30)
        Me.txtpatientname.TabIndex = 121
        Me.txtpatientname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage8.Controls.Add(Me.Panel5)
        Me.BunifuTransition1.SetDecoration(Me.TabPage8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage8, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(973, 409)
        Me.TabPage8.TabIndex = 1
        Me.TabPage8.Text = "TabPage8"
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.Panel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel5, BunifuAnimatorNS.DecorationType.None)
        Me.Panel5.Location = New System.Drawing.Point(6, 6)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(824, 387)
        Me.Panel5.TabIndex = 0
        '
        'TabPage11
        '
        Me.TabPage11.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage11.Controls.Add(Me.BunifuGradientPanel6)
        Me.TabPage11.Controls.Add(Me.DataGridView1)
        Me.BunifuTransition1.SetDecoration(Me.TabPage11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage11, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage11.Location = New System.Drawing.Point(4, 22)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(973, 409)
        Me.TabPage11.TabIndex = 4
        Me.TabPage11.Text = "TabPage11"
        '
        'BunifuGradientPanel6
        '
        Me.BunifuGradientPanel6.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel6.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel6.Controls.Add(Me.BunifuTextbox1)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel6.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel6.Name = "BunifuGradientPanel6"
        Me.BunifuGradientPanel6.Quality = 10
        Me.BunifuGradientPanel6.Size = New System.Drawing.Size(967, 37)
        Me.BunifuGradientPanel6.TabIndex = 1
        '
        'BunifuTextbox1
        '
        Me.BunifuTextbox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTextbox1.BackgroundImage = CType(resources.GetObject("BunifuTextbox1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition3.SetDecoration(Me.BunifuTextbox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuTextbox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTextbox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTextbox1.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox1.Icon = CType(resources.GetObject("BunifuTextbox1.Icon"), System.Drawing.Image)
        Me.BunifuTextbox1.Location = New System.Drawing.Point(12, 1)
        Me.BunifuTextbox1.Name = "BunifuTextbox1"
        Me.BunifuTextbox1.Size = New System.Drawing.Size(239, 31)
        Me.BunifuTextbox1.TabIndex = 0
        Me.BunifuTextbox1.text = "Search Id, ward,room"
        '
        'DataGridView1
        '
        DataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle17
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle18
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuTransition1.SetDecoration(Me.DataGridView1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.DataGridView1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.DataGridView1, BunifuAnimatorNS.DecorationType.None)
        Me.DataGridView1.DoubleBuffered = True
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.DataGridView1.HeaderForeColor = System.Drawing.Color.White
        Me.DataGridView1.Location = New System.Drawing.Point(6, 42)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DataGridView1.Size = New System.Drawing.Size(944, 401)
        Me.DataGridView1.TabIndex = 0
        '
        'TabPage17
        '
        Me.TabPage17.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage17.Controls.Add(Me.GroupBox7)
        Me.BunifuTransition1.SetDecoration(Me.TabPage17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage17, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage17.Location = New System.Drawing.Point(4, 22)
        Me.TabPage17.Name = "TabPage17"
        Me.TabPage17.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage17.Size = New System.Drawing.Size(973, 409)
        Me.TabPage17.TabIndex = 5
        Me.TabPage17.Text = "TabPage17"
        '
        'GroupBox7
        '
        Me.BunifuTransition3.SetDecoration(Me.GroupBox7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.GroupBox7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.GroupBox7, BunifuAnimatorNS.DecorationType.None)
        Me.GroupBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.ForeColor = System.Drawing.Color.White
        Me.GroupBox7.Location = New System.Drawing.Point(9, 6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(933, 417)
        Me.GroupBox7.TabIndex = 97
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Report"
        '
        'BunifuCustomLabel29
        '
        Me.BunifuCustomLabel29.AutoSize = True
        Me.BunifuCustomLabel29.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel29.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel29.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel29.Location = New System.Drawing.Point(12, 7)
        Me.BunifuCustomLabel29.Name = "BunifuCustomLabel29"
        Me.BunifuCustomLabel29.Size = New System.Drawing.Size(156, 23)
        Me.BunifuCustomLabel29.TabIndex = 11
        Me.BunifuCustomLabel29.Text = "Patient Diagosis"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.Panel16)
        Me.TabPage3.Controls.Add(Me.Panel6)
        Me.TabPage3.Controls.Add(Me.TabControl3)
        Me.BunifuTransition1.SetDecoration(Me.TabPage3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage3, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(983, 606)
        Me.TabPage3.TabIndex = 6
        Me.TabPage3.Text = "TabPage3"
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.BunifuThinButton227)
        Me.Panel16.Controls.Add(Me.BunifuThinButton228)
        Me.Panel16.Controls.Add(Me.BunifuThinButton229)
        Me.Panel16.Controls.Add(Me.BunifuThinButton230)
        Me.Panel16.Controls.Add(Me.BunifuThinButton231)
        Me.Panel16.Controls.Add(Me.BunifuThinButton232)
        Me.Panel16.Controls.Add(Me.BunifuThinButton233)
        Me.Panel16.Controls.Add(Me.BunifuThinButton234)
        Me.Panel16.Controls.Add(Me.BunifuThinButton235)
        Me.Panel16.Controls.Add(Me.BunifuThinButton236)
        Me.Panel16.Controls.Add(Me.BunifuThinButton237)
        Me.Panel16.Controls.Add(Me.BunifuThinButton238)
        Me.BunifuTransition3.SetDecoration(Me.Panel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel16, BunifuAnimatorNS.DecorationType.None)
        Me.Panel16.Location = New System.Drawing.Point(6, 545)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(947, 49)
        Me.Panel16.TabIndex = 37
        '
        'BunifuThinButton227
        '
        Me.BunifuThinButton227.ActiveBorderThickness = 1
        Me.BunifuThinButton227.ActiveCornerRadius = 3
        Me.BunifuThinButton227.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton227.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton227.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton227.AutoSize = True
        Me.BunifuThinButton227.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton227.BackgroundImage = CType(resources.GetObject("BunifuThinButton227.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton227.ButtonText = "Home"
        Me.BunifuThinButton227.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton227, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton227, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton227, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton227.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton227.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton227.IdleBorderThickness = 1
        Me.BunifuThinButton227.IdleCornerRadius = 1
        Me.BunifuThinButton227.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton227.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton227.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton227.Location = New System.Drawing.Point(743, 4)
        Me.BunifuThinButton227.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton227.Name = "BunifuThinButton227"
        Me.BunifuThinButton227.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton227.TabIndex = 38
        Me.BunifuThinButton227.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton228
        '
        Me.BunifuThinButton228.ActiveBorderThickness = 1
        Me.BunifuThinButton228.ActiveCornerRadius = 2
        Me.BunifuThinButton228.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton228.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton228.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton228.AutoSize = True
        Me.BunifuThinButton228.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton228.BackgroundImage = CType(resources.GetObject("BunifuThinButton228.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton228.ButtonText = "Sign Up"
        Me.BunifuThinButton228.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton228, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton228, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton228, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton228.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton228.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton228.IdleBorderThickness = 1
        Me.BunifuThinButton228.IdleCornerRadius = 1
        Me.BunifuThinButton228.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton228.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton228.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton228.Location = New System.Drawing.Point(743, 3)
        Me.BunifuThinButton228.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton228.Name = "BunifuThinButton228"
        Me.BunifuThinButton228.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton228.TabIndex = 37
        Me.BunifuThinButton228.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton229
        '
        Me.BunifuThinButton229.ActiveBorderThickness = 1
        Me.BunifuThinButton229.ActiveCornerRadius = 3
        Me.BunifuThinButton229.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton229.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton229.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton229.AutoSize = True
        Me.BunifuThinButton229.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton229.BackgroundImage = CType(resources.GetObject("BunifuThinButton229.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton229.ButtonText = "View Record"
        Me.BunifuThinButton229.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton229, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton229, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton229, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton229.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton229.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton229.IdleBorderThickness = 1
        Me.BunifuThinButton229.IdleCornerRadius = 1
        Me.BunifuThinButton229.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton229.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton229.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton229.Location = New System.Drawing.Point(595, 4)
        Me.BunifuThinButton229.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton229.Name = "BunifuThinButton229"
        Me.BunifuThinButton229.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton229.TabIndex = 36
        Me.BunifuThinButton229.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton230
        '
        Me.BunifuThinButton230.ActiveBorderThickness = 1
        Me.BunifuThinButton230.ActiveCornerRadius = 2
        Me.BunifuThinButton230.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton230.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton230.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton230.AutoSize = True
        Me.BunifuThinButton230.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton230.BackgroundImage = CType(resources.GetObject("BunifuThinButton230.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton230.ButtonText = "Sign Up"
        Me.BunifuThinButton230.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton230, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton230, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton230, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton230.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton230.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton230.IdleBorderThickness = 1
        Me.BunifuThinButton230.IdleCornerRadius = 1
        Me.BunifuThinButton230.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton230.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton230.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton230.Location = New System.Drawing.Point(595, 3)
        Me.BunifuThinButton230.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton230.Name = "BunifuThinButton230"
        Me.BunifuThinButton230.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton230.TabIndex = 35
        Me.BunifuThinButton230.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton231
        '
        Me.BunifuThinButton231.ActiveBorderThickness = 1
        Me.BunifuThinButton231.ActiveCornerRadius = 3
        Me.BunifuThinButton231.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton231.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton231.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton231.AutoSize = True
        Me.BunifuThinButton231.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton231.BackgroundImage = CType(resources.GetObject("BunifuThinButton231.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton231.ButtonText = "Update"
        Me.BunifuThinButton231.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton231, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton231, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton231, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton231.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton231.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton231.IdleBorderThickness = 1
        Me.BunifuThinButton231.IdleCornerRadius = 1
        Me.BunifuThinButton231.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton231.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton231.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton231.Location = New System.Drawing.Point(151, 4)
        Me.BunifuThinButton231.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton231.Name = "BunifuThinButton231"
        Me.BunifuThinButton231.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton231.TabIndex = 30
        Me.BunifuThinButton231.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton232
        '
        Me.BunifuThinButton232.ActiveBorderThickness = 1
        Me.BunifuThinButton232.ActiveCornerRadius = 3
        Me.BunifuThinButton232.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton232.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton232.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton232.AutoSize = True
        Me.BunifuThinButton232.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton232.BackgroundImage = CType(resources.GetObject("BunifuThinButton232.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton232.ButtonText = "Submit"
        Me.BunifuThinButton232.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton232, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton232, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton232, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton232.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton232.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton232.IdleBorderThickness = 1
        Me.BunifuThinButton232.IdleCornerRadius = 1
        Me.BunifuThinButton232.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton232.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton232.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton232.Location = New System.Drawing.Point(3, 4)
        Me.BunifuThinButton232.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton232.Name = "BunifuThinButton232"
        Me.BunifuThinButton232.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton232.TabIndex = 28
        Me.BunifuThinButton232.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton233
        '
        Me.BunifuThinButton233.ActiveBorderThickness = 1
        Me.BunifuThinButton233.ActiveCornerRadius = 2
        Me.BunifuThinButton233.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton233.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton233.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton233.AutoSize = True
        Me.BunifuThinButton233.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton233.BackgroundImage = CType(resources.GetObject("BunifuThinButton233.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton233.ButtonText = "Sign Up"
        Me.BunifuThinButton233.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton233, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton233, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton233, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton233.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton233.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton233.IdleBorderThickness = 1
        Me.BunifuThinButton233.IdleCornerRadius = 1
        Me.BunifuThinButton233.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton233.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton233.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton233.Location = New System.Drawing.Point(151, 3)
        Me.BunifuThinButton233.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton233.Name = "BunifuThinButton233"
        Me.BunifuThinButton233.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton233.TabIndex = 29
        Me.BunifuThinButton233.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton234
        '
        Me.BunifuThinButton234.ActiveBorderThickness = 1
        Me.BunifuThinButton234.ActiveCornerRadius = 3
        Me.BunifuThinButton234.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton234.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton234.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton234.AutoSize = True
        Me.BunifuThinButton234.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton234.BackgroundImage = CType(resources.GetObject("BunifuThinButton234.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton234.ButtonText = "Clear"
        Me.BunifuThinButton234.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton234, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton234, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton234, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton234.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton234.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton234.IdleBorderThickness = 1
        Me.BunifuThinButton234.IdleCornerRadius = 1
        Me.BunifuThinButton234.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton234.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton234.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton234.Location = New System.Drawing.Point(447, 4)
        Me.BunifuThinButton234.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton234.Name = "BunifuThinButton234"
        Me.BunifuThinButton234.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton234.TabIndex = 34
        Me.BunifuThinButton234.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton235
        '
        Me.BunifuThinButton235.ActiveBorderThickness = 1
        Me.BunifuThinButton235.ActiveCornerRadius = 2
        Me.BunifuThinButton235.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton235.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton235.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton235.AutoSize = True
        Me.BunifuThinButton235.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton235.BackgroundImage = CType(resources.GetObject("BunifuThinButton235.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton235.ButtonText = "Sign Up"
        Me.BunifuThinButton235.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton235, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton235, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton235, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton235.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton235.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton235.IdleBorderThickness = 1
        Me.BunifuThinButton235.IdleCornerRadius = 1
        Me.BunifuThinButton235.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton235.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton235.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton235.Location = New System.Drawing.Point(3, 3)
        Me.BunifuThinButton235.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton235.Name = "BunifuThinButton235"
        Me.BunifuThinButton235.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton235.TabIndex = 27
        Me.BunifuThinButton235.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton236
        '
        Me.BunifuThinButton236.ActiveBorderThickness = 1
        Me.BunifuThinButton236.ActiveCornerRadius = 3
        Me.BunifuThinButton236.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton236.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton236.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton236.AutoSize = True
        Me.BunifuThinButton236.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton236.BackgroundImage = CType(resources.GetObject("BunifuThinButton236.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton236.ButtonText = "Delete"
        Me.BunifuThinButton236.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton236, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton236, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton236, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton236.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton236.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton236.IdleBorderThickness = 1
        Me.BunifuThinButton236.IdleCornerRadius = 1
        Me.BunifuThinButton236.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton236.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton236.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton236.Location = New System.Drawing.Point(299, 4)
        Me.BunifuThinButton236.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton236.Name = "BunifuThinButton236"
        Me.BunifuThinButton236.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton236.TabIndex = 32
        Me.BunifuThinButton236.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton237
        '
        Me.BunifuThinButton237.ActiveBorderThickness = 1
        Me.BunifuThinButton237.ActiveCornerRadius = 2
        Me.BunifuThinButton237.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton237.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton237.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton237.AutoSize = True
        Me.BunifuThinButton237.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton237.BackgroundImage = CType(resources.GetObject("BunifuThinButton237.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton237.ButtonText = "Sign Up"
        Me.BunifuThinButton237.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton237, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton237, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton237, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton237.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton237.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton237.IdleBorderThickness = 1
        Me.BunifuThinButton237.IdleCornerRadius = 1
        Me.BunifuThinButton237.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton237.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton237.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton237.Location = New System.Drawing.Point(299, 3)
        Me.BunifuThinButton237.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton237.Name = "BunifuThinButton237"
        Me.BunifuThinButton237.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton237.TabIndex = 31
        Me.BunifuThinButton237.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton238
        '
        Me.BunifuThinButton238.ActiveBorderThickness = 1
        Me.BunifuThinButton238.ActiveCornerRadius = 2
        Me.BunifuThinButton238.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton238.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton238.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton238.AutoSize = True
        Me.BunifuThinButton238.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton238.BackgroundImage = CType(resources.GetObject("BunifuThinButton238.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton238.ButtonText = "Sign Up"
        Me.BunifuThinButton238.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton238, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton238, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton238, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton238.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton238.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton238.IdleBorderThickness = 1
        Me.BunifuThinButton238.IdleCornerRadius = 1
        Me.BunifuThinButton238.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton238.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton238.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton238.Location = New System.Drawing.Point(447, 3)
        Me.BunifuThinButton238.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton238.Name = "BunifuThinButton238"
        Me.BunifuThinButton238.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton238.TabIndex = 33
        Me.BunifuThinButton238.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.BunifuCustomLabel57)
        Me.BunifuTransition3.SetDecoration(Me.Panel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel6, BunifuAnimatorNS.DecorationType.None)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel6.Location = New System.Drawing.Point(3, 3)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(977, 45)
        Me.Panel6.TabIndex = 0
        '
        'BunifuCustomLabel57
        '
        Me.BunifuCustomLabel57.AutoSize = True
        Me.BunifuCustomLabel57.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel57, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel57, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel57, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel57.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel57.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel57.Location = New System.Drawing.Point(15, 12)
        Me.BunifuCustomLabel57.Name = "BunifuCustomLabel57"
        Me.BunifuCustomLabel57.Size = New System.Drawing.Size(190, 23)
        Me.BunifuCustomLabel57.TabIndex = 12
        Me.BunifuCustomLabel57.Text = "Faculty Registration"
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage10)
        Me.TabControl3.Controls.Add(Me.TabPage12)
        Me.TabControl3.Controls.Add(Me.TabPage13)
        Me.TabControl3.Controls.Add(Me.TabPage14)
        Me.TabControl3.Controls.Add(Me.TabPage16)
        Me.TabControl3.Controls.Add(Me.TabPage15)
        Me.BunifuTransition3.SetDecoration(Me.TabControl3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabControl3, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl3.Location = New System.Drawing.Point(-4, 95)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(958, 460)
        Me.TabControl3.TabIndex = 15
        '
        'TabPage10
        '
        Me.TabPage10.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage10.Controls.Add(Me.Panel7)
        Me.BunifuTransition1.SetDecoration(Me.TabPage10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage10, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(950, 434)
        Me.TabPage10.TabIndex = 1
        Me.TabPage10.Text = "TabPage10"
        '
        'Panel7
        '
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.Panel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel7, BunifuAnimatorNS.DecorationType.None)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(3, 3)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(944, 428)
        Me.Panel7.TabIndex = 2
        '
        'TabPage12
        '
        Me.TabPage12.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage12.Controls.Add(Me.Panel10)
        Me.BunifuTransition1.SetDecoration(Me.TabPage12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage12, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage12.Location = New System.Drawing.Point(4, 22)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage12.Size = New System.Drawing.Size(950, 434)
        Me.TabPage12.TabIndex = 2
        Me.TabPage12.Text = "TabPage12"
        '
        'Panel10
        '
        Me.Panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.Panel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel10, BunifuAnimatorNS.DecorationType.None)
        Me.Panel10.Location = New System.Drawing.Point(6, 9)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(903, 466)
        Me.Panel10.TabIndex = 1
        '
        'TabPage13
        '
        Me.TabPage13.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage13.Controls.Add(Me.Panel8)
        Me.BunifuTransition1.SetDecoration(Me.TabPage13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage13, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage13.Location = New System.Drawing.Point(4, 22)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage13.Size = New System.Drawing.Size(950, 434)
        Me.TabPage13.TabIndex = 3
        Me.TabPage13.Text = "TabPage13"
        '
        'Panel8
        '
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.Panel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel8, BunifuAnimatorNS.DecorationType.None)
        Me.Panel8.Location = New System.Drawing.Point(24, -16)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(903, 466)
        Me.Panel8.TabIndex = 2
        '
        'TabPage14
        '
        Me.TabPage14.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage14.Controls.Add(Me.Panel12)
        Me.BunifuTransition1.SetDecoration(Me.TabPage14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage14, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage14.Location = New System.Drawing.Point(4, 22)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage14.Size = New System.Drawing.Size(950, 434)
        Me.TabPage14.TabIndex = 4
        Me.TabPage14.Text = "TabPage14"
        '
        'Panel12
        '
        Me.Panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel12.Controls.Add(Me.Panel9)
        Me.BunifuTransition3.SetDecoration(Me.Panel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel12, BunifuAnimatorNS.DecorationType.None)
        Me.Panel12.Location = New System.Drawing.Point(6, 9)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(903, 451)
        Me.Panel12.TabIndex = 1
        '
        'Panel9
        '
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.Panel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel9, BunifuAnimatorNS.DecorationType.None)
        Me.Panel9.Location = New System.Drawing.Point(-1, -9)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(903, 466)
        Me.Panel9.TabIndex = 2
        '
        'TabPage16
        '
        Me.TabPage16.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage16.Controls.Add(Me.Panel14)
        Me.BunifuTransition1.SetDecoration(Me.TabPage16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage16, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage16.Location = New System.Drawing.Point(4, 22)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage16.Size = New System.Drawing.Size(950, 434)
        Me.TabPage16.TabIndex = 6
        Me.TabPage16.Text = "TabPage16"
        '
        'Panel14
        '
        Me.Panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel14.Controls.Add(Me.Panel11)
        Me.BunifuTransition3.SetDecoration(Me.Panel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel14, BunifuAnimatorNS.DecorationType.None)
        Me.Panel14.Location = New System.Drawing.Point(6, 9)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(935, 427)
        Me.Panel14.TabIndex = 2
        '
        'Panel11
        '
        Me.Panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.Panel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel11, BunifuAnimatorNS.DecorationType.None)
        Me.Panel11.Location = New System.Drawing.Point(15, -21)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(903, 466)
        Me.Panel11.TabIndex = 2
        '
        'TabPage15
        '
        Me.TabPage15.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage15.Controls.Add(Me.Panel13)
        Me.BunifuTransition1.SetDecoration(Me.TabPage15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage15, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage15.Location = New System.Drawing.Point(4, 22)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage15.Size = New System.Drawing.Size(950, 434)
        Me.TabPage15.TabIndex = 5
        Me.TabPage15.Text = "TabPage15"
        '
        'Panel13
        '
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.Panel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel13, BunifuAnimatorNS.DecorationType.None)
        Me.Panel13.Location = New System.Drawing.Point(6, 9)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(903, 427)
        Me.Panel13.TabIndex = 2
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.TabControl4)
        Me.TabPage4.Controls.Add(Me.Panel18)
        Me.TabPage4.Controls.Add(Me.Panel17)
        Me.BunifuTransition1.SetDecoration(Me.TabPage4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage4, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(983, 606)
        Me.TabPage4.TabIndex = 7
        Me.TabPage4.Text = "TabPage4"
        '
        'TabControl4
        '
        Me.TabControl4.Controls.Add(Me.TabPage18)
        Me.TabControl4.Controls.Add(Me.TabPage19)
        Me.TabControl4.Controls.Add(Me.TabPage20)
        Me.TabControl4.Controls.Add(Me.TabPage21)
        Me.BunifuTransition3.SetDecoration(Me.TabControl4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabControl4, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl4.Location = New System.Drawing.Point(-4, 94)
        Me.TabControl4.Name = "TabControl4"
        Me.TabControl4.SelectedIndex = 0
        Me.TabControl4.Size = New System.Drawing.Size(943, 502)
        Me.TabControl4.TabIndex = 16
        '
        'TabPage18
        '
        Me.TabPage18.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage18.Controls.Add(Me.Panel19)
        Me.BunifuTransition1.SetDecoration(Me.TabPage18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage18, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage18.Location = New System.Drawing.Point(4, 22)
        Me.TabPage18.Name = "TabPage18"
        Me.TabPage18.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage18.Size = New System.Drawing.Size(935, 476)
        Me.TabPage18.TabIndex = 0
        Me.TabPage18.Text = "TabPage18"
        '
        'Panel19
        '
        Me.Panel19.Controls.Add(Me.BunifuFlatButton25)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton26)
        Me.Panel19.Controls.Add(Me.BunifuThinButton247)
        Me.Panel19.Controls.Add(Me.BunifuThinButton248)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton27)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton28)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton29)
        Me.Panel19.Controls.Add(Me.BunifuThinButton249)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton30)
        Me.Panel19.Controls.Add(Me.BunifuThinButton250)
        Me.Panel19.Controls.Add(Me.BunifuThinButton251)
        Me.Panel19.Controls.Add(Me.BunifuThinButton252)
        Me.BunifuTransition3.SetDecoration(Me.Panel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel19, BunifuAnimatorNS.DecorationType.None)
        Me.Panel19.Location = New System.Drawing.Point(7, 418)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(948, 52)
        Me.Panel19.TabIndex = 100
        '
        'BunifuFlatButton25
        '
        Me.BunifuFlatButton25.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton25.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton25.BorderRadius = 0
        Me.BunifuFlatButton25.ButtonText = "Home"
        Me.BunifuFlatButton25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton25.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton25.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton25.Iconimage = Global.officesoft2.My.Resources.Resources.hand_touching_tablet_screen
        Me.BunifuFlatButton25.Iconimage_right = Nothing
        Me.BunifuFlatButton25.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton25.Iconimage_Selected = Nothing
        Me.BunifuFlatButton25.IconMarginLeft = 0
        Me.BunifuFlatButton25.IconMarginRight = 0
        Me.BunifuFlatButton25.IconRightVisible = False
        Me.BunifuFlatButton25.IconRightZoom = 0R
        Me.BunifuFlatButton25.IconVisible = False
        Me.BunifuFlatButton25.IconZoom = 60.0R
        Me.BunifuFlatButton25.IsTab = False
        Me.BunifuFlatButton25.Location = New System.Drawing.Point(762, 6)
        Me.BunifuFlatButton25.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton25.Name = "BunifuFlatButton25"
        Me.BunifuFlatButton25.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton25.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton25.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton25.selected = False
        Me.BunifuFlatButton25.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton25.TabIndex = 17
        Me.BunifuFlatButton25.Text = "Home"
        Me.BunifuFlatButton25.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton25.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton25.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton26
        '
        Me.BunifuFlatButton26.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton26.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton26.BorderRadius = 0
        Me.BunifuFlatButton26.ButtonText = "Print"
        Me.BunifuFlatButton26.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton26.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton26.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton26.Iconimage = Global.officesoft2.My.Resources.Resources.employee
        Me.BunifuFlatButton26.Iconimage_right = Nothing
        Me.BunifuFlatButton26.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton26.Iconimage_Selected = Nothing
        Me.BunifuFlatButton26.IconMarginLeft = 0
        Me.BunifuFlatButton26.IconMarginRight = 0
        Me.BunifuFlatButton26.IconRightVisible = False
        Me.BunifuFlatButton26.IconRightZoom = 0R
        Me.BunifuFlatButton26.IconVisible = False
        Me.BunifuFlatButton26.IconZoom = 60.0R
        Me.BunifuFlatButton26.IsTab = False
        Me.BunifuFlatButton26.Location = New System.Drawing.Point(613, 6)
        Me.BunifuFlatButton26.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton26.Name = "BunifuFlatButton26"
        Me.BunifuFlatButton26.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton26.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton26.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton26.selected = False
        Me.BunifuFlatButton26.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton26.TabIndex = 17
        Me.BunifuFlatButton26.Text = "Print"
        Me.BunifuFlatButton26.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton26.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton26.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton247
        '
        Me.BunifuThinButton247.ActiveBorderThickness = 1
        Me.BunifuThinButton247.ActiveCornerRadius = 2
        Me.BunifuThinButton247.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton247.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton247.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton247.AutoSize = True
        Me.BunifuThinButton247.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton247.BackgroundImage = CType(resources.GetObject("BunifuThinButton247.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton247.ButtonText = "Sign Up"
        Me.BunifuThinButton247.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton247, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton247, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton247, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton247.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton247.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton247.IdleBorderThickness = 1
        Me.BunifuThinButton247.IdleCornerRadius = 1
        Me.BunifuThinButton247.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton247.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton247.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton247.Location = New System.Drawing.Point(762, 14)
        Me.BunifuThinButton247.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton247.Name = "BunifuThinButton247"
        Me.BunifuThinButton247.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton247.TabIndex = 25
        Me.BunifuThinButton247.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton248
        '
        Me.BunifuThinButton248.ActiveBorderThickness = 1
        Me.BunifuThinButton248.ActiveCornerRadius = 2
        Me.BunifuThinButton248.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton248.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton248.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton248.AutoSize = True
        Me.BunifuThinButton248.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton248.BackgroundImage = CType(resources.GetObject("BunifuThinButton248.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton248.ButtonText = "Sign Up"
        Me.BunifuThinButton248.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton248, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton248, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton248, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton248.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton248.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton248.IdleBorderThickness = 1
        Me.BunifuThinButton248.IdleCornerRadius = 1
        Me.BunifuThinButton248.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton248.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton248.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton248.Location = New System.Drawing.Point(613, 14)
        Me.BunifuThinButton248.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton248.Name = "BunifuThinButton248"
        Me.BunifuThinButton248.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton248.TabIndex = 33
        Me.BunifuThinButton248.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton27
        '
        Me.BunifuFlatButton27.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton27.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton27.BorderRadius = 0
        Me.BunifuFlatButton27.ButtonText = "Save"
        Me.BunifuFlatButton27.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton27.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton27.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton27.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton27.Iconimage_right = Nothing
        Me.BunifuFlatButton27.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton27.Iconimage_Selected = Nothing
        Me.BunifuFlatButton27.IconMarginLeft = 0
        Me.BunifuFlatButton27.IconMarginRight = 0
        Me.BunifuFlatButton27.IconRightVisible = False
        Me.BunifuFlatButton27.IconRightZoom = 0R
        Me.BunifuFlatButton27.IconVisible = False
        Me.BunifuFlatButton27.IconZoom = 60.0R
        Me.BunifuFlatButton27.IsTab = False
        Me.BunifuFlatButton27.Location = New System.Drawing.Point(163, 6)
        Me.BunifuFlatButton27.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton27.Name = "BunifuFlatButton27"
        Me.BunifuFlatButton27.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton27.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton27.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton27.selected = False
        Me.BunifuFlatButton27.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton27.TabIndex = 34
        Me.BunifuFlatButton27.Text = "Save"
        Me.BunifuFlatButton27.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton27.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton27.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton28
        '
        Me.BunifuFlatButton28.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton28.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton28.BorderRadius = 0
        Me.BunifuFlatButton28.ButtonText = "Update"
        Me.BunifuFlatButton28.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton28.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton28.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton28.Iconimage = Global.officesoft2.My.Resources.Resources.diploma
        Me.BunifuFlatButton28.Iconimage_right = Nothing
        Me.BunifuFlatButton28.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton28.Iconimage_Selected = Nothing
        Me.BunifuFlatButton28.IconMarginLeft = 0
        Me.BunifuFlatButton28.IconMarginRight = 0
        Me.BunifuFlatButton28.IconRightVisible = False
        Me.BunifuFlatButton28.IconRightZoom = 0R
        Me.BunifuFlatButton28.IconVisible = False
        Me.BunifuFlatButton28.IconZoom = 60.0R
        Me.BunifuFlatButton28.IsTab = False
        Me.BunifuFlatButton28.Location = New System.Drawing.Point(462, 6)
        Me.BunifuFlatButton28.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton28.Name = "BunifuFlatButton28"
        Me.BunifuFlatButton28.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton28.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton28.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton28.selected = False
        Me.BunifuFlatButton28.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton28.TabIndex = 35
        Me.BunifuFlatButton28.Text = "Update"
        Me.BunifuFlatButton28.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton28.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton28.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton29
        '
        Me.BunifuFlatButton29.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton29.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton29.BorderRadius = 0
        Me.BunifuFlatButton29.ButtonText = "New"
        Me.BunifuFlatButton29.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton29.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton29.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton29.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton29.Iconimage_right = Nothing
        Me.BunifuFlatButton29.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton29.Iconimage_Selected = Nothing
        Me.BunifuFlatButton29.IconMarginLeft = 0
        Me.BunifuFlatButton29.IconMarginRight = 0
        Me.BunifuFlatButton29.IconRightVisible = False
        Me.BunifuFlatButton29.IconRightZoom = 0R
        Me.BunifuFlatButton29.IconVisible = False
        Me.BunifuFlatButton29.IconZoom = 60.0R
        Me.BunifuFlatButton29.IsTab = False
        Me.BunifuFlatButton29.Location = New System.Drawing.Point(14, 6)
        Me.BunifuFlatButton29.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton29.Name = "BunifuFlatButton29"
        Me.BunifuFlatButton29.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton29.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton29.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton29.selected = False
        Me.BunifuFlatButton29.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton29.TabIndex = 15
        Me.BunifuFlatButton29.Text = "New"
        Me.BunifuFlatButton29.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton29.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton29.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton249
        '
        Me.BunifuThinButton249.ActiveBorderThickness = 1
        Me.BunifuThinButton249.ActiveCornerRadius = 2
        Me.BunifuThinButton249.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton249.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton249.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton249.AutoSize = True
        Me.BunifuThinButton249.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton249.BackgroundImage = CType(resources.GetObject("BunifuThinButton249.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton249.ButtonText = "Sign Up"
        Me.BunifuThinButton249.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton249, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton249, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton249, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton249.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton249.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton249.IdleBorderThickness = 1
        Me.BunifuThinButton249.IdleCornerRadius = 1
        Me.BunifuThinButton249.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton249.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton249.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton249.Location = New System.Drawing.Point(163, 14)
        Me.BunifuThinButton249.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton249.Name = "BunifuThinButton249"
        Me.BunifuThinButton249.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton249.TabIndex = 27
        Me.BunifuThinButton249.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton30
        '
        Me.BunifuFlatButton30.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton30.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton30.BorderRadius = 0
        Me.BunifuFlatButton30.ButtonText = "Delete"
        Me.BunifuFlatButton30.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton30.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton30.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton30.Iconimage = Global.officesoft2.My.Resources.Resources.education
        Me.BunifuFlatButton30.Iconimage_right = Nothing
        Me.BunifuFlatButton30.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton30.Iconimage_Selected = Nothing
        Me.BunifuFlatButton30.IconMarginLeft = 0
        Me.BunifuFlatButton30.IconMarginRight = 0
        Me.BunifuFlatButton30.IconRightVisible = False
        Me.BunifuFlatButton30.IconRightZoom = 0R
        Me.BunifuFlatButton30.IconVisible = False
        Me.BunifuFlatButton30.IconZoom = 60.0R
        Me.BunifuFlatButton30.IsTab = False
        Me.BunifuFlatButton30.Location = New System.Drawing.Point(312, 6)
        Me.BunifuFlatButton30.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton30.Name = "BunifuFlatButton30"
        Me.BunifuFlatButton30.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton30.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton30.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton30.selected = False
        Me.BunifuFlatButton30.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton30.TabIndex = 16
        Me.BunifuFlatButton30.Text = "Delete"
        Me.BunifuFlatButton30.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton30.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton30.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton250
        '
        Me.BunifuThinButton250.ActiveBorderThickness = 1
        Me.BunifuThinButton250.ActiveCornerRadius = 2
        Me.BunifuThinButton250.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton250.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton250.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton250.AutoSize = True
        Me.BunifuThinButton250.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton250.BackgroundImage = CType(resources.GetObject("BunifuThinButton250.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton250.ButtonText = "Sign Up"
        Me.BunifuThinButton250.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton250, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton250, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton250, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton250.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton250.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton250.IdleBorderThickness = 1
        Me.BunifuThinButton250.IdleCornerRadius = 1
        Me.BunifuThinButton250.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton250.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton250.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton250.Location = New System.Drawing.Point(14, 14)
        Me.BunifuThinButton250.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton250.Name = "BunifuThinButton250"
        Me.BunifuThinButton250.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton250.TabIndex = 23
        Me.BunifuThinButton250.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton251
        '
        Me.BunifuThinButton251.ActiveBorderThickness = 1
        Me.BunifuThinButton251.ActiveCornerRadius = 2
        Me.BunifuThinButton251.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton251.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton251.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton251.AutoSize = True
        Me.BunifuThinButton251.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton251.BackgroundImage = CType(resources.GetObject("BunifuThinButton251.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton251.ButtonText = "Sign Up"
        Me.BunifuThinButton251.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton251, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton251, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton251, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton251.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton251.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton251.IdleBorderThickness = 1
        Me.BunifuThinButton251.IdleCornerRadius = 1
        Me.BunifuThinButton251.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton251.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton251.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton251.Location = New System.Drawing.Point(312, 14)
        Me.BunifuThinButton251.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton251.Name = "BunifuThinButton251"
        Me.BunifuThinButton251.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton251.TabIndex = 29
        Me.BunifuThinButton251.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton252
        '
        Me.BunifuThinButton252.ActiveBorderThickness = 1
        Me.BunifuThinButton252.ActiveCornerRadius = 2
        Me.BunifuThinButton252.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton252.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton252.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton252.AutoSize = True
        Me.BunifuThinButton252.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton252.BackgroundImage = CType(resources.GetObject("BunifuThinButton252.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton252.ButtonText = "Sign Up"
        Me.BunifuThinButton252.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton252, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton252, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton252, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton252.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton252.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton252.IdleBorderThickness = 1
        Me.BunifuThinButton252.IdleCornerRadius = 1
        Me.BunifuThinButton252.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton252.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton252.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton252.Location = New System.Drawing.Point(462, 14)
        Me.BunifuThinButton252.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton252.Name = "BunifuThinButton252"
        Me.BunifuThinButton252.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton252.TabIndex = 31
        Me.BunifuThinButton252.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage19
        '
        Me.TabPage19.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage19.Controls.Add(Me.BunifuCustomDataGrid4)
        Me.TabPage19.Controls.Add(Me.BunifuGradientPanel14)
        Me.BunifuTransition1.SetDecoration(Me.TabPage19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage19, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage19.Location = New System.Drawing.Point(4, 22)
        Me.TabPage19.Name = "TabPage19"
        Me.TabPage19.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage19.Size = New System.Drawing.Size(935, 476)
        Me.TabPage19.TabIndex = 1
        Me.TabPage19.Text = "TabPage19"
        '
        'BunifuCustomDataGrid4
        '
        DataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuCustomDataGrid4.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle19
        Me.BunifuCustomDataGrid4.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.BunifuCustomDataGrid4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BunifuCustomDataGrid4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle20.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle20.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BunifuCustomDataGrid4.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle20
        Me.BunifuCustomDataGrid4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuCustomDataGrid4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18})
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomDataGrid4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomDataGrid4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomDataGrid4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomDataGrid4.DoubleBuffered = True
        Me.BunifuCustomDataGrid4.EnableHeadersVisualStyles = False
        Me.BunifuCustomDataGrid4.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuCustomDataGrid4.HeaderForeColor = System.Drawing.Color.White
        Me.BunifuCustomDataGrid4.Location = New System.Drawing.Point(10, 46)
        Me.BunifuCustomDataGrid4.Name = "BunifuCustomDataGrid4"
        Me.BunifuCustomDataGrid4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.BunifuCustomDataGrid4.Size = New System.Drawing.Size(907, 426)
        Me.BunifuCustomDataGrid4.TabIndex = 20
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.HeaderText = "Name 1"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "Name 2"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "Name 3"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "Name 4"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Name 5"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        '
        'BunifuGradientPanel14
        '
        Me.BunifuGradientPanel14.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel14.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel14.Controls.Add(Me.BunifuTextbox3)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel14.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel14.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel14.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel14.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel14.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel14.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel14.Name = "BunifuGradientPanel14"
        Me.BunifuGradientPanel14.Quality = 10
        Me.BunifuGradientPanel14.Size = New System.Drawing.Size(929, 37)
        Me.BunifuGradientPanel14.TabIndex = 2
        '
        'BunifuTextbox3
        '
        Me.BunifuTextbox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTextbox3.BackgroundImage = CType(resources.GetObject("BunifuTextbox3.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition3.SetDecoration(Me.BunifuTextbox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuTextbox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTextbox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTextbox3.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox3.Icon = CType(resources.GetObject("BunifuTextbox3.Icon"), System.Drawing.Image)
        Me.BunifuTextbox3.Location = New System.Drawing.Point(8, 1)
        Me.BunifuTextbox3.Name = "BunifuTextbox3"
        Me.BunifuTextbox3.Size = New System.Drawing.Size(316, 31)
        Me.BunifuTextbox3.TabIndex = 0
        Me.BunifuTextbox3.text = "Search Section, Fees No"
        '
        'TabPage20
        '
        Me.TabPage20.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition1.SetDecoration(Me.TabPage20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage20, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage20.Location = New System.Drawing.Point(4, 22)
        Me.TabPage20.Name = "TabPage20"
        Me.TabPage20.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage20.Size = New System.Drawing.Size(935, 476)
        Me.TabPage20.TabIndex = 2
        Me.TabPage20.Text = "TabPage20"
        '
        'TabPage21
        '
        Me.TabPage21.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition1.SetDecoration(Me.TabPage21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage21, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage21.Location = New System.Drawing.Point(4, 22)
        Me.TabPage21.Name = "TabPage21"
        Me.TabPage21.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage21.Size = New System.Drawing.Size(935, 476)
        Me.TabPage21.TabIndex = 3
        Me.TabPage21.Text = "TabPage21"
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.BunifuFlatButton19)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton20)
        Me.Panel18.Controls.Add(Me.BunifuThinButton241)
        Me.Panel18.Controls.Add(Me.BunifuThinButton242)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton21)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton22)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton23)
        Me.Panel18.Controls.Add(Me.BunifuThinButton243)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton24)
        Me.Panel18.Controls.Add(Me.BunifuThinButton244)
        Me.Panel18.Controls.Add(Me.BunifuThinButton245)
        Me.Panel18.Controls.Add(Me.BunifuThinButton246)
        Me.BunifuTransition3.SetDecoration(Me.Panel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel18, BunifuAnimatorNS.DecorationType.None)
        Me.Panel18.Location = New System.Drawing.Point(-1, 45)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(948, 52)
        Me.Panel18.TabIndex = 15
        '
        'BunifuFlatButton19
        '
        Me.BunifuFlatButton19.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton19.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton19.BorderRadius = 0
        Me.BunifuFlatButton19.ButtonText = "References"
        Me.BunifuFlatButton19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton19.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton19.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton19.Iconimage = Global.officesoft2.My.Resources.Resources.hand_touching_tablet_screen
        Me.BunifuFlatButton19.Iconimage_right = Nothing
        Me.BunifuFlatButton19.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton19.Iconimage_Selected = Nothing
        Me.BunifuFlatButton19.IconMarginLeft = 0
        Me.BunifuFlatButton19.IconMarginRight = 0
        Me.BunifuFlatButton19.IconRightVisible = False
        Me.BunifuFlatButton19.IconRightZoom = 0R
        Me.BunifuFlatButton19.IconVisible = False
        Me.BunifuFlatButton19.IconZoom = 60.0R
        Me.BunifuFlatButton19.IsTab = False
        Me.BunifuFlatButton19.Location = New System.Drawing.Point(787, 6)
        Me.BunifuFlatButton19.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton19.Name = "BunifuFlatButton19"
        Me.BunifuFlatButton19.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton19.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton19.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton19.selected = False
        Me.BunifuFlatButton19.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton19.TabIndex = 17
        Me.BunifuFlatButton19.Text = "References"
        Me.BunifuFlatButton19.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton19.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton19.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton20
        '
        Me.BunifuFlatButton20.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton20.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton20.BorderRadius = 0
        Me.BunifuFlatButton20.ButtonText = "Employment"
        Me.BunifuFlatButton20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton20.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton20.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton20.Iconimage = Global.officesoft2.My.Resources.Resources.employee
        Me.BunifuFlatButton20.Iconimage_right = Nothing
        Me.BunifuFlatButton20.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton20.Iconimage_Selected = Nothing
        Me.BunifuFlatButton20.IconMarginLeft = 0
        Me.BunifuFlatButton20.IconMarginRight = 0
        Me.BunifuFlatButton20.IconRightVisible = False
        Me.BunifuFlatButton20.IconRightZoom = 0R
        Me.BunifuFlatButton20.IconVisible = False
        Me.BunifuFlatButton20.IconZoom = 60.0R
        Me.BunifuFlatButton20.IsTab = False
        Me.BunifuFlatButton20.Location = New System.Drawing.Point(631, 6)
        Me.BunifuFlatButton20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton20.Name = "BunifuFlatButton20"
        Me.BunifuFlatButton20.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton20.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton20.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton20.selected = False
        Me.BunifuFlatButton20.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton20.TabIndex = 17
        Me.BunifuFlatButton20.Text = "Employment"
        Me.BunifuFlatButton20.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton20.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton20.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton241
        '
        Me.BunifuThinButton241.ActiveBorderThickness = 1
        Me.BunifuThinButton241.ActiveCornerRadius = 2
        Me.BunifuThinButton241.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton241.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton241.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton241.AutoSize = True
        Me.BunifuThinButton241.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton241.BackgroundImage = CType(resources.GetObject("BunifuThinButton241.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton241.ButtonText = "Sign Up"
        Me.BunifuThinButton241.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton241, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton241, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton241, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton241.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton241.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton241.IdleBorderThickness = 1
        Me.BunifuThinButton241.IdleCornerRadius = 1
        Me.BunifuThinButton241.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton241.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton241.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton241.Location = New System.Drawing.Point(787, 14)
        Me.BunifuThinButton241.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton241.Name = "BunifuThinButton241"
        Me.BunifuThinButton241.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton241.TabIndex = 25
        Me.BunifuThinButton241.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton242
        '
        Me.BunifuThinButton242.ActiveBorderThickness = 1
        Me.BunifuThinButton242.ActiveCornerRadius = 2
        Me.BunifuThinButton242.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton242.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton242.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton242.AutoSize = True
        Me.BunifuThinButton242.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton242.BackgroundImage = CType(resources.GetObject("BunifuThinButton242.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton242.ButtonText = "Sign Up"
        Me.BunifuThinButton242.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton242, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton242, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton242, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton242.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton242.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton242.IdleBorderThickness = 1
        Me.BunifuThinButton242.IdleCornerRadius = 1
        Me.BunifuThinButton242.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton242.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton242.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton242.Location = New System.Drawing.Point(631, 14)
        Me.BunifuThinButton242.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton242.Name = "BunifuThinButton242"
        Me.BunifuThinButton242.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton242.TabIndex = 33
        Me.BunifuThinButton242.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton21
        '
        Me.BunifuFlatButton21.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton21.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton21.BorderRadius = 0
        Me.BunifuFlatButton21.ButtonText = "Receipt details"
        Me.BunifuFlatButton21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton21.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton21.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton21.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton21.Iconimage_right = Nothing
        Me.BunifuFlatButton21.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton21.Iconimage_Selected = Nothing
        Me.BunifuFlatButton21.IconMarginLeft = 0
        Me.BunifuFlatButton21.IconMarginRight = 0
        Me.BunifuFlatButton21.IconRightVisible = False
        Me.BunifuFlatButton21.IconRightZoom = 0R
        Me.BunifuFlatButton21.IconVisible = False
        Me.BunifuFlatButton21.IconZoom = 60.0R
        Me.BunifuFlatButton21.IsTab = False
        Me.BunifuFlatButton21.Location = New System.Drawing.Point(166, 6)
        Me.BunifuFlatButton21.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton21.Name = "BunifuFlatButton21"
        Me.BunifuFlatButton21.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton21.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton21.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton21.selected = False
        Me.BunifuFlatButton21.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton21.TabIndex = 34
        Me.BunifuFlatButton21.Text = "Receipt details"
        Me.BunifuFlatButton21.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton21.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton21.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton22
        '
        Me.BunifuFlatButton22.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton22.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton22.BorderRadius = 0
        Me.BunifuFlatButton22.ButtonText = "Qualification"
        Me.BunifuFlatButton22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton22.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton22.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton22.Iconimage = Global.officesoft2.My.Resources.Resources.diploma
        Me.BunifuFlatButton22.Iconimage_right = Nothing
        Me.BunifuFlatButton22.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton22.Iconimage_Selected = Nothing
        Me.BunifuFlatButton22.IconMarginLeft = 0
        Me.BunifuFlatButton22.IconMarginRight = 0
        Me.BunifuFlatButton22.IconRightVisible = False
        Me.BunifuFlatButton22.IconRightZoom = 0R
        Me.BunifuFlatButton22.IconVisible = False
        Me.BunifuFlatButton22.IconZoom = 60.0R
        Me.BunifuFlatButton22.IsTab = False
        Me.BunifuFlatButton22.Location = New System.Drawing.Point(476, 6)
        Me.BunifuFlatButton22.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton22.Name = "BunifuFlatButton22"
        Me.BunifuFlatButton22.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton22.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton22.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton22.selected = False
        Me.BunifuFlatButton22.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton22.TabIndex = 35
        Me.BunifuFlatButton22.Text = "Qualification"
        Me.BunifuFlatButton22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton22.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton22.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton23
        '
        Me.BunifuFlatButton23.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton23.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton23.BorderRadius = 0
        Me.BunifuFlatButton23.ButtonText = "Fee Details"
        Me.BunifuFlatButton23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton23.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton23.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton23.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton23.Iconimage_right = Nothing
        Me.BunifuFlatButton23.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton23.Iconimage_Selected = Nothing
        Me.BunifuFlatButton23.IconMarginLeft = 0
        Me.BunifuFlatButton23.IconMarginRight = 0
        Me.BunifuFlatButton23.IconRightVisible = False
        Me.BunifuFlatButton23.IconRightZoom = 0R
        Me.BunifuFlatButton23.IconVisible = False
        Me.BunifuFlatButton23.IconZoom = 60.0R
        Me.BunifuFlatButton23.IsTab = False
        Me.BunifuFlatButton23.Location = New System.Drawing.Point(11, 6)
        Me.BunifuFlatButton23.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton23.Name = "BunifuFlatButton23"
        Me.BunifuFlatButton23.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton23.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton23.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton23.selected = False
        Me.BunifuFlatButton23.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton23.TabIndex = 15
        Me.BunifuFlatButton23.Text = "Fee Details"
        Me.BunifuFlatButton23.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton23.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton23.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton243
        '
        Me.BunifuThinButton243.ActiveBorderThickness = 1
        Me.BunifuThinButton243.ActiveCornerRadius = 2
        Me.BunifuThinButton243.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton243.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton243.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton243.AutoSize = True
        Me.BunifuThinButton243.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton243.BackgroundImage = CType(resources.GetObject("BunifuThinButton243.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton243.ButtonText = "Sign Up"
        Me.BunifuThinButton243.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton243, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton243, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton243, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton243.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton243.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton243.IdleBorderThickness = 1
        Me.BunifuThinButton243.IdleCornerRadius = 1
        Me.BunifuThinButton243.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton243.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton243.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton243.Location = New System.Drawing.Point(166, 14)
        Me.BunifuThinButton243.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton243.Name = "BunifuThinButton243"
        Me.BunifuThinButton243.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton243.TabIndex = 27
        Me.BunifuThinButton243.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton24
        '
        Me.BunifuFlatButton24.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton24.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton24.BorderRadius = 0
        Me.BunifuFlatButton24.ButtonText = "View Record"
        Me.BunifuFlatButton24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton24.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton24.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton24.Iconimage = Global.officesoft2.My.Resources.Resources.education
        Me.BunifuFlatButton24.Iconimage_right = Nothing
        Me.BunifuFlatButton24.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton24.Iconimage_Selected = Nothing
        Me.BunifuFlatButton24.IconMarginLeft = 0
        Me.BunifuFlatButton24.IconMarginRight = 0
        Me.BunifuFlatButton24.IconRightVisible = False
        Me.BunifuFlatButton24.IconRightZoom = 0R
        Me.BunifuFlatButton24.IconVisible = False
        Me.BunifuFlatButton24.IconZoom = 60.0R
        Me.BunifuFlatButton24.IsTab = False
        Me.BunifuFlatButton24.Location = New System.Drawing.Point(321, 6)
        Me.BunifuFlatButton24.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton24.Name = "BunifuFlatButton24"
        Me.BunifuFlatButton24.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton24.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton24.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton24.selected = False
        Me.BunifuFlatButton24.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton24.TabIndex = 16
        Me.BunifuFlatButton24.Text = "View Record"
        Me.BunifuFlatButton24.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton24.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton24.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton244
        '
        Me.BunifuThinButton244.ActiveBorderThickness = 1
        Me.BunifuThinButton244.ActiveCornerRadius = 2
        Me.BunifuThinButton244.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton244.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton244.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton244.AutoSize = True
        Me.BunifuThinButton244.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton244.BackgroundImage = CType(resources.GetObject("BunifuThinButton244.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton244.ButtonText = "Sign Up"
        Me.BunifuThinButton244.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton244, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton244, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton244, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton244.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton244.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton244.IdleBorderThickness = 1
        Me.BunifuThinButton244.IdleCornerRadius = 1
        Me.BunifuThinButton244.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton244.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton244.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton244.Location = New System.Drawing.Point(11, 14)
        Me.BunifuThinButton244.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton244.Name = "BunifuThinButton244"
        Me.BunifuThinButton244.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton244.TabIndex = 23
        Me.BunifuThinButton244.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton245
        '
        Me.BunifuThinButton245.ActiveBorderThickness = 1
        Me.BunifuThinButton245.ActiveCornerRadius = 2
        Me.BunifuThinButton245.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton245.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton245.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton245.AutoSize = True
        Me.BunifuThinButton245.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton245.BackgroundImage = CType(resources.GetObject("BunifuThinButton245.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton245.ButtonText = "Sign Up"
        Me.BunifuThinButton245.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton245, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton245, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton245, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton245.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton245.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton245.IdleBorderThickness = 1
        Me.BunifuThinButton245.IdleCornerRadius = 1
        Me.BunifuThinButton245.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton245.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton245.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton245.Location = New System.Drawing.Point(321, 14)
        Me.BunifuThinButton245.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton245.Name = "BunifuThinButton245"
        Me.BunifuThinButton245.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton245.TabIndex = 29
        Me.BunifuThinButton245.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton246
        '
        Me.BunifuThinButton246.ActiveBorderThickness = 1
        Me.BunifuThinButton246.ActiveCornerRadius = 2
        Me.BunifuThinButton246.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton246.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton246.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton246.AutoSize = True
        Me.BunifuThinButton246.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton246.BackgroundImage = CType(resources.GetObject("BunifuThinButton246.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton246.ButtonText = "Sign Up"
        Me.BunifuThinButton246.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton246, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton246, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton246, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton246.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton246.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton246.IdleBorderThickness = 1
        Me.BunifuThinButton246.IdleCornerRadius = 1
        Me.BunifuThinButton246.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton246.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton246.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton246.Location = New System.Drawing.Point(476, 6)
        Me.BunifuThinButton246.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton246.Name = "BunifuThinButton246"
        Me.BunifuThinButton246.Size = New System.Drawing.Size(149, 44)
        Me.BunifuThinButton246.TabIndex = 31
        Me.BunifuThinButton246.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.BunifuCustomLabel159)
        Me.BunifuTransition3.SetDecoration(Me.Panel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel17, BunifuAnimatorNS.DecorationType.None)
        Me.Panel17.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel17.Location = New System.Drawing.Point(3, 3)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(977, 45)
        Me.Panel17.TabIndex = 1
        '
        'BunifuCustomLabel159
        '
        Me.BunifuCustomLabel159.AutoSize = True
        Me.BunifuCustomLabel159.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel159, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel159, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel159, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel159.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel159.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel159.Location = New System.Drawing.Point(15, 12)
        Me.BunifuCustomLabel159.Name = "BunifuCustomLabel159"
        Me.BunifuCustomLabel159.Size = New System.Drawing.Size(125, 23)
        Me.BunifuCustomLabel159.TabIndex = 12
        Me.BunifuCustomLabel159.Text = "Student Fees"
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage5.Controls.Add(Me.Panel22)
        Me.TabPage5.Controls.Add(Me.Panel20)
        Me.BunifuTransition1.SetDecoration(Me.TabPage5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage5, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(983, 606)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "TabPage5"
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.BunifuTileButton1)
        Me.Panel22.Controls.Add(Me.BunifuTileButton17)
        Me.Panel22.Controls.Add(Me.BunifuTileButton2)
        Me.Panel22.Controls.Add(Me.BunifuTileButton18)
        Me.Panel22.Controls.Add(Me.BunifuTileButton3)
        Me.Panel22.Controls.Add(Me.BunifuTileButton19)
        Me.Panel22.Controls.Add(Me.BunifuTileButton4)
        Me.Panel22.Controls.Add(Me.BunifuTileButton20)
        Me.Panel22.Controls.Add(Me.BunifuTileButton5)
        Me.Panel22.Controls.Add(Me.BunifuTileButton13)
        Me.Panel22.Controls.Add(Me.BunifuTileButton6)
        Me.Panel22.Controls.Add(Me.BunifuTileButton14)
        Me.Panel22.Controls.Add(Me.BunifuTileButton7)
        Me.Panel22.Controls.Add(Me.BunifuTileButton15)
        Me.Panel22.Controls.Add(Me.BunifuTileButton8)
        Me.Panel22.Controls.Add(Me.BunifuTileButton16)
        Me.Panel22.Controls.Add(Me.BunifuTileButton12)
        Me.Panel22.Controls.Add(Me.BunifuTileButton9)
        Me.Panel22.Controls.Add(Me.BunifuTileButton11)
        Me.Panel22.Controls.Add(Me.BunifuTileButton10)
        Me.BunifuTransition3.SetDecoration(Me.Panel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel22, BunifuAnimatorNS.DecorationType.None)
        Me.Panel22.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel22.Location = New System.Drawing.Point(3, 48)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(977, 555)
        Me.Panel22.TabIndex = 22
        '
        'BunifuTileButton1
        '
        Me.BunifuTileButton1.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton1.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton1.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton1.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton1.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton1.Image = Global.officesoft2.My.Resources.Resources.calendar_with_a_clock_time_tools
        Me.BunifuTileButton1.ImagePosition = 5
        Me.BunifuTileButton1.ImageZoom = 25
        Me.BunifuTileButton1.LabelPosition = 26
        Me.BunifuTileButton1.LabelText = "Blood Group"
        Me.BunifuTileButton1.Location = New System.Drawing.Point(58, 17)
        Me.BunifuTileButton1.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuTileButton1.Name = "BunifuTileButton1"
        Me.BunifuTileButton1.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton1.TabIndex = 2
        '
        'BunifuTileButton17
        '
        Me.BunifuTileButton17.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton17.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton17.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton17.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton17.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton17.Image = CType(resources.GetObject("BunifuTileButton17.Image"), System.Drawing.Image)
        Me.BunifuTileButton17.ImagePosition = 5
        Me.BunifuTileButton17.ImageZoom = 25
        Me.BunifuTileButton17.LabelPosition = 26
        Me.BunifuTileButton17.LabelText = "Student Master"
        Me.BunifuTileButton17.Location = New System.Drawing.Point(689, 363)
        Me.BunifuTileButton17.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton17.Name = "BunifuTileButton17"
        Me.BunifuTileButton17.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton17.TabIndex = 21
        '
        'BunifuTileButton2
        '
        Me.BunifuTileButton2.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton2.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton2.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton2.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton2.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton2.Image = Global.officesoft2.My.Resources.Resources.month
        Me.BunifuTileButton2.ImagePosition = 5
        Me.BunifuTileButton2.ImageZoom = 25
        Me.BunifuTileButton2.LabelPosition = 26
        Me.BunifuTileButton2.LabelText = "Ward"
        Me.BunifuTileButton2.Location = New System.Drawing.Point(269, 17)
        Me.BunifuTileButton2.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BunifuTileButton2.Name = "BunifuTileButton2"
        Me.BunifuTileButton2.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton2.TabIndex = 3
        '
        'BunifuTileButton18
        '
        Me.BunifuTileButton18.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton18.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton18.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton18.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton18.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton18.Image = CType(resources.GetObject("BunifuTileButton18.Image"), System.Drawing.Image)
        Me.BunifuTileButton18.ImagePosition = 5
        Me.BunifuTileButton18.ImageZoom = 25
        Me.BunifuTileButton18.LabelPosition = 26
        Me.BunifuTileButton18.LabelText = "Payment Mode"
        Me.BunifuTileButton18.Location = New System.Drawing.Point(479, 363)
        Me.BunifuTileButton18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton18.Name = "BunifuTileButton18"
        Me.BunifuTileButton18.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton18.TabIndex = 20
        '
        'BunifuTileButton3
        '
        Me.BunifuTileButton3.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton3.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton3.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton3.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton3.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton3.Image = Global.officesoft2.My.Resources.Resources._class
        Me.BunifuTileButton3.ImagePosition = 5
        Me.BunifuTileButton3.ImageZoom = 25
        Me.BunifuTileButton3.LabelPosition = 26
        Me.BunifuTileButton3.LabelText = "Rooms"
        Me.BunifuTileButton3.Location = New System.Drawing.Point(479, 17)
        Me.BunifuTileButton3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton3.Name = "BunifuTileButton3"
        Me.BunifuTileButton3.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton3.TabIndex = 4
        '
        'BunifuTileButton19
        '
        Me.BunifuTileButton19.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton19.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton19.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton19.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton19.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton19.Image = CType(resources.GetObject("BunifuTileButton19.Image"), System.Drawing.Image)
        Me.BunifuTileButton19.ImagePosition = 5
        Me.BunifuTileButton19.ImageZoom = 25
        Me.BunifuTileButton19.LabelPosition = 26
        Me.BunifuTileButton19.LabelText = "Holiday Master"
        Me.BunifuTileButton19.Location = New System.Drawing.Point(269, 363)
        Me.BunifuTileButton19.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton19.Name = "BunifuTileButton19"
        Me.BunifuTileButton19.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton19.TabIndex = 19
        '
        'BunifuTileButton4
        '
        Me.BunifuTileButton4.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton4.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton4.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton4.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton4.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton4.Image = Global.officesoft2.My.Resources.Resources.subject
        Me.BunifuTileButton4.ImagePosition = 5
        Me.BunifuTileButton4.ImageZoom = 25
        Me.BunifuTileButton4.LabelPosition = 26
        Me.BunifuTileButton4.LabelText = "Specialist"
        Me.BunifuTileButton4.Location = New System.Drawing.Point(689, 17)
        Me.BunifuTileButton4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton4.Name = "BunifuTileButton4"
        Me.BunifuTileButton4.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton4.TabIndex = 5
        '
        'BunifuTileButton20
        '
        Me.BunifuTileButton20.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton20.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton20.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton20.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton20.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton20.Image = CType(resources.GetObject("BunifuTileButton20.Image"), System.Drawing.Image)
        Me.BunifuTileButton20.ImagePosition = 5
        Me.BunifuTileButton20.ImageZoom = 25
        Me.BunifuTileButton20.LabelPosition = 26
        Me.BunifuTileButton20.LabelText = "Account Head"
        Me.BunifuTileButton20.Location = New System.Drawing.Point(58, 363)
        Me.BunifuTileButton20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton20.Name = "BunifuTileButton20"
        Me.BunifuTileButton20.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton20.TabIndex = 18
        '
        'BunifuTileButton5
        '
        Me.BunifuTileButton5.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton5.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton5.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton5.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton5.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton5.Image = CType(resources.GetObject("BunifuTileButton5.Image"), System.Drawing.Image)
        Me.BunifuTileButton5.ImagePosition = 5
        Me.BunifuTileButton5.ImageZoom = 25
        Me.BunifuTileButton5.LabelPosition = 26
        Me.BunifuTileButton5.LabelText = "State"
        Me.BunifuTileButton5.Location = New System.Drawing.Point(58, 103)
        Me.BunifuTileButton5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton5.Name = "BunifuTileButton5"
        Me.BunifuTileButton5.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton5.TabIndex = 6
        '
        'BunifuTileButton13
        '
        Me.BunifuTileButton13.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton13.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton13.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton13.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton13.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton13.Image = CType(resources.GetObject("BunifuTileButton13.Image"), System.Drawing.Image)
        Me.BunifuTileButton13.ImagePosition = 5
        Me.BunifuTileButton13.ImageZoom = 25
        Me.BunifuTileButton13.LabelPosition = 26
        Me.BunifuTileButton13.LabelText = "Blood Group"
        Me.BunifuTileButton13.Location = New System.Drawing.Point(689, 276)
        Me.BunifuTileButton13.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton13.Name = "BunifuTileButton13"
        Me.BunifuTileButton13.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton13.TabIndex = 17
        '
        'BunifuTileButton6
        '
        Me.BunifuTileButton6.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton6.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton6.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton6.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton6.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton6.Image = CType(resources.GetObject("BunifuTileButton6.Image"), System.Drawing.Image)
        Me.BunifuTileButton6.ImagePosition = 5
        Me.BunifuTileButton6.ImageZoom = 25
        Me.BunifuTileButton6.LabelPosition = 26
        Me.BunifuTileButton6.LabelText = "City"
        Me.BunifuTileButton6.Location = New System.Drawing.Point(269, 103)
        Me.BunifuTileButton6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton6.Name = "BunifuTileButton6"
        Me.BunifuTileButton6.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton6.TabIndex = 7
        '
        'BunifuTileButton14
        '
        Me.BunifuTileButton14.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton14.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton14.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton14.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton14.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton14.Image = CType(resources.GetObject("BunifuTileButton14.Image"), System.Drawing.Image)
        Me.BunifuTileButton14.ImagePosition = 5
        Me.BunifuTileButton14.ImageZoom = 25
        Me.BunifuTileButton14.LabelPosition = 26
        Me.BunifuTileButton14.LabelText = "Blood Group"
        Me.BunifuTileButton14.Location = New System.Drawing.Point(479, 276)
        Me.BunifuTileButton14.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton14.Name = "BunifuTileButton14"
        Me.BunifuTileButton14.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton14.TabIndex = 16
        '
        'BunifuTileButton7
        '
        Me.BunifuTileButton7.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton7.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton7.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton7.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton7.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton7.Image = CType(resources.GetObject("BunifuTileButton7.Image"), System.Drawing.Image)
        Me.BunifuTileButton7.ImagePosition = 5
        Me.BunifuTileButton7.ImageZoom = 25
        Me.BunifuTileButton7.LabelPosition = 26
        Me.BunifuTileButton7.LabelText = "Blood Group"
        Me.BunifuTileButton7.Location = New System.Drawing.Point(479, 103)
        Me.BunifuTileButton7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton7.Name = "BunifuTileButton7"
        Me.BunifuTileButton7.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton7.TabIndex = 8
        '
        'BunifuTileButton15
        '
        Me.BunifuTileButton15.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton15.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton15.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton15.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton15.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton15.Image = CType(resources.GetObject("BunifuTileButton15.Image"), System.Drawing.Image)
        Me.BunifuTileButton15.ImagePosition = 5
        Me.BunifuTileButton15.ImageZoom = 25
        Me.BunifuTileButton15.LabelPosition = 26
        Me.BunifuTileButton15.LabelText = "Blood Group"
        Me.BunifuTileButton15.Location = New System.Drawing.Point(269, 276)
        Me.BunifuTileButton15.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton15.Name = "BunifuTileButton15"
        Me.BunifuTileButton15.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton15.TabIndex = 15
        '
        'BunifuTileButton8
        '
        Me.BunifuTileButton8.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton8.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton8.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton8.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton8.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton8.Image = CType(resources.GetObject("BunifuTileButton8.Image"), System.Drawing.Image)
        Me.BunifuTileButton8.ImagePosition = 5
        Me.BunifuTileButton8.ImageZoom = 25
        Me.BunifuTileButton8.LabelPosition = 26
        Me.BunifuTileButton8.LabelText = "Blood Group"
        Me.BunifuTileButton8.Location = New System.Drawing.Point(689, 103)
        Me.BunifuTileButton8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton8.Name = "BunifuTileButton8"
        Me.BunifuTileButton8.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton8.TabIndex = 9
        '
        'BunifuTileButton16
        '
        Me.BunifuTileButton16.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton16.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton16.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton16.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton16.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton16.Image = CType(resources.GetObject("BunifuTileButton16.Image"), System.Drawing.Image)
        Me.BunifuTileButton16.ImagePosition = 5
        Me.BunifuTileButton16.ImageZoom = 25
        Me.BunifuTileButton16.LabelPosition = 26
        Me.BunifuTileButton16.LabelText = "Blood Group"
        Me.BunifuTileButton16.Location = New System.Drawing.Point(58, 276)
        Me.BunifuTileButton16.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton16.Name = "BunifuTileButton16"
        Me.BunifuTileButton16.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton16.TabIndex = 14
        '
        'BunifuTileButton12
        '
        Me.BunifuTileButton12.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton12.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton12.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton12.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton12.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton12.Image = CType(resources.GetObject("BunifuTileButton12.Image"), System.Drawing.Image)
        Me.BunifuTileButton12.ImagePosition = 5
        Me.BunifuTileButton12.ImageZoom = 25
        Me.BunifuTileButton12.LabelPosition = 26
        Me.BunifuTileButton12.LabelText = "Blood Group"
        Me.BunifuTileButton12.Location = New System.Drawing.Point(58, 189)
        Me.BunifuTileButton12.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton12.Name = "BunifuTileButton12"
        Me.BunifuTileButton12.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton12.TabIndex = 10
        '
        'BunifuTileButton9
        '
        Me.BunifuTileButton9.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton9.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton9.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton9.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton9.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton9.Image = CType(resources.GetObject("BunifuTileButton9.Image"), System.Drawing.Image)
        Me.BunifuTileButton9.ImagePosition = 5
        Me.BunifuTileButton9.ImageZoom = 25
        Me.BunifuTileButton9.LabelPosition = 26
        Me.BunifuTileButton9.LabelText = "Blood Group"
        Me.BunifuTileButton9.Location = New System.Drawing.Point(689, 189)
        Me.BunifuTileButton9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton9.Name = "BunifuTileButton9"
        Me.BunifuTileButton9.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton9.TabIndex = 13
        '
        'BunifuTileButton11
        '
        Me.BunifuTileButton11.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton11.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton11.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton11.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton11.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton11.Image = CType(resources.GetObject("BunifuTileButton11.Image"), System.Drawing.Image)
        Me.BunifuTileButton11.ImagePosition = 5
        Me.BunifuTileButton11.ImageZoom = 25
        Me.BunifuTileButton11.LabelPosition = 26
        Me.BunifuTileButton11.LabelText = "Blood Group"
        Me.BunifuTileButton11.Location = New System.Drawing.Point(269, 189)
        Me.BunifuTileButton11.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton11.Name = "BunifuTileButton11"
        Me.BunifuTileButton11.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton11.TabIndex = 11
        '
        'BunifuTileButton10
        '
        Me.BunifuTileButton10.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton10.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton10.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton10.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton10.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton10.Image = CType(resources.GetObject("BunifuTileButton10.Image"), System.Drawing.Image)
        Me.BunifuTileButton10.ImagePosition = 5
        Me.BunifuTileButton10.ImageZoom = 25
        Me.BunifuTileButton10.LabelPosition = 26
        Me.BunifuTileButton10.LabelText = "Blood Group"
        Me.BunifuTileButton10.Location = New System.Drawing.Point(479, 189)
        Me.BunifuTileButton10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton10.Name = "BunifuTileButton10"
        Me.BunifuTileButton10.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton10.TabIndex = 12
        '
        'Panel20
        '
        Me.Panel20.Controls.Add(Me.BunifuCustomLabel172)
        Me.BunifuTransition3.SetDecoration(Me.Panel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel20, BunifuAnimatorNS.DecorationType.None)
        Me.Panel20.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel20.Location = New System.Drawing.Point(3, 3)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(977, 45)
        Me.Panel20.TabIndex = 1
        '
        'BunifuCustomLabel172
        '
        Me.BunifuCustomLabel172.AutoSize = True
        Me.BunifuCustomLabel172.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel172, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel172, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel172, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel172.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel172.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel172.Location = New System.Drawing.Point(15, 12)
        Me.BunifuCustomLabel172.Name = "BunifuCustomLabel172"
        Me.BunifuCustomLabel172.Size = New System.Drawing.Size(80, 23)
        Me.BunifuCustomLabel172.TabIndex = 12
        Me.BunifuCustomLabel172.Text = "Masters"
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage6.Controls.Add(Me.Panel23)
        Me.BunifuTransition1.SetDecoration(Me.TabPage6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage6, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(983, 606)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "TabPage6"
        '
        'Panel23
        '
        Me.Panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel23.Controls.Add(Me.Panel27)
        Me.Panel23.Controls.Add(Me.Panel25)
        Me.Panel23.Controls.Add(Me.Panel24)
        Me.Panel23.Controls.Add(Me.TabControl5)
        Me.BunifuTransition3.SetDecoration(Me.Panel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel23, BunifuAnimatorNS.DecorationType.None)
        Me.Panel23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel23.Location = New System.Drawing.Point(3, 3)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(977, 600)
        Me.Panel23.TabIndex = 0
        '
        'Panel27
        '
        Me.Panel27.Controls.Add(Me.BunifuFlatButton38)
        Me.Panel27.Controls.Add(Me.BunifuFlatButton39)
        Me.Panel27.Controls.Add(Me.BunifuThinButton259)
        Me.Panel27.Controls.Add(Me.BunifuThinButton260)
        Me.Panel27.Controls.Add(Me.BunifuFlatButton40)
        Me.Panel27.Controls.Add(Me.BunifuFlatButton41)
        Me.Panel27.Controls.Add(Me.BunifuFlatButton42)
        Me.Panel27.Controls.Add(Me.BunifuThinButton261)
        Me.Panel27.Controls.Add(Me.BunifuFlatButton43)
        Me.Panel27.Controls.Add(Me.BunifuThinButton262)
        Me.Panel27.Controls.Add(Me.BunifuThinButton263)
        Me.Panel27.Controls.Add(Me.BunifuThinButton264)
        Me.BunifuTransition3.SetDecoration(Me.Panel27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel27, BunifuAnimatorNS.DecorationType.None)
        Me.Panel27.Location = New System.Drawing.Point(0, 544)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(949, 52)
        Me.Panel27.TabIndex = 18
        '
        'BunifuFlatButton38
        '
        Me.BunifuFlatButton38.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton38.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton38.BorderRadius = 0
        Me.BunifuFlatButton38.ButtonText = "Home"
        Me.BunifuFlatButton38.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton38.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton38.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton38.Iconimage = Global.officesoft2.My.Resources.Resources.hand_touching_tablet_screen
        Me.BunifuFlatButton38.Iconimage_right = Nothing
        Me.BunifuFlatButton38.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton38.Iconimage_Selected = Nothing
        Me.BunifuFlatButton38.IconMarginLeft = 0
        Me.BunifuFlatButton38.IconMarginRight = 0
        Me.BunifuFlatButton38.IconRightVisible = False
        Me.BunifuFlatButton38.IconRightZoom = 0R
        Me.BunifuFlatButton38.IconVisible = False
        Me.BunifuFlatButton38.IconZoom = 60.0R
        Me.BunifuFlatButton38.IsTab = False
        Me.BunifuFlatButton38.Location = New System.Drawing.Point(787, 6)
        Me.BunifuFlatButton38.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton38.Name = "BunifuFlatButton38"
        Me.BunifuFlatButton38.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton38.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton38.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton38.selected = False
        Me.BunifuFlatButton38.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton38.TabIndex = 17
        Me.BunifuFlatButton38.Text = "Home"
        Me.BunifuFlatButton38.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton38.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton38.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton39
        '
        Me.BunifuFlatButton39.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton39.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton39.BorderRadius = 0
        Me.BunifuFlatButton39.ButtonText = "Clear"
        Me.BunifuFlatButton39.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton39.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton39.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton39.Iconimage = Global.officesoft2.My.Resources.Resources.employee
        Me.BunifuFlatButton39.Iconimage_right = Nothing
        Me.BunifuFlatButton39.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton39.Iconimage_Selected = Nothing
        Me.BunifuFlatButton39.IconMarginLeft = 0
        Me.BunifuFlatButton39.IconMarginRight = 0
        Me.BunifuFlatButton39.IconRightVisible = False
        Me.BunifuFlatButton39.IconRightZoom = 0R
        Me.BunifuFlatButton39.IconVisible = False
        Me.BunifuFlatButton39.IconZoom = 60.0R
        Me.BunifuFlatButton39.IsTab = False
        Me.BunifuFlatButton39.Location = New System.Drawing.Point(631, 6)
        Me.BunifuFlatButton39.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton39.Name = "BunifuFlatButton39"
        Me.BunifuFlatButton39.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton39.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton39.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton39.selected = False
        Me.BunifuFlatButton39.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton39.TabIndex = 17
        Me.BunifuFlatButton39.Text = "Clear"
        Me.BunifuFlatButton39.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton39.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton39.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton259
        '
        Me.BunifuThinButton259.ActiveBorderThickness = 1
        Me.BunifuThinButton259.ActiveCornerRadius = 2
        Me.BunifuThinButton259.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton259.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton259.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton259.AutoSize = True
        Me.BunifuThinButton259.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton259.BackgroundImage = CType(resources.GetObject("BunifuThinButton259.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton259.ButtonText = "Sign Up"
        Me.BunifuThinButton259.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton259, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton259, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton259, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton259.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton259.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton259.IdleBorderThickness = 1
        Me.BunifuThinButton259.IdleCornerRadius = 1
        Me.BunifuThinButton259.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton259.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton259.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton259.Location = New System.Drawing.Point(787, 14)
        Me.BunifuThinButton259.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton259.Name = "BunifuThinButton259"
        Me.BunifuThinButton259.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton259.TabIndex = 25
        Me.BunifuThinButton259.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton260
        '
        Me.BunifuThinButton260.ActiveBorderThickness = 1
        Me.BunifuThinButton260.ActiveCornerRadius = 2
        Me.BunifuThinButton260.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton260.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton260.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton260.AutoSize = True
        Me.BunifuThinButton260.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton260.BackgroundImage = CType(resources.GetObject("BunifuThinButton260.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton260.ButtonText = "Sign Up"
        Me.BunifuThinButton260.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton260, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton260, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton260, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton260.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton260.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton260.IdleBorderThickness = 1
        Me.BunifuThinButton260.IdleCornerRadius = 1
        Me.BunifuThinButton260.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton260.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton260.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton260.Location = New System.Drawing.Point(631, 14)
        Me.BunifuThinButton260.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton260.Name = "BunifuThinButton260"
        Me.BunifuThinButton260.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton260.TabIndex = 33
        Me.BunifuThinButton260.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton40
        '
        Me.BunifuFlatButton40.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton40.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton40.BorderRadius = 0
        Me.BunifuFlatButton40.ButtonText = "Save"
        Me.BunifuFlatButton40.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton40.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton40.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton40.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton40.Iconimage_right = Nothing
        Me.BunifuFlatButton40.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton40.Iconimage_Selected = Nothing
        Me.BunifuFlatButton40.IconMarginLeft = 0
        Me.BunifuFlatButton40.IconMarginRight = 0
        Me.BunifuFlatButton40.IconRightVisible = False
        Me.BunifuFlatButton40.IconRightZoom = 0R
        Me.BunifuFlatButton40.IconVisible = False
        Me.BunifuFlatButton40.IconZoom = 60.0R
        Me.BunifuFlatButton40.IsTab = False
        Me.BunifuFlatButton40.Location = New System.Drawing.Point(166, 6)
        Me.BunifuFlatButton40.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton40.Name = "BunifuFlatButton40"
        Me.BunifuFlatButton40.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton40.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton40.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton40.selected = False
        Me.BunifuFlatButton40.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton40.TabIndex = 34
        Me.BunifuFlatButton40.Text = "Save"
        Me.BunifuFlatButton40.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton40.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton40.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton41
        '
        Me.BunifuFlatButton41.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton41.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton41.BorderRadius = 0
        Me.BunifuFlatButton41.ButtonText = "Update"
        Me.BunifuFlatButton41.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton41.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton41.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton41.Iconimage = Global.officesoft2.My.Resources.Resources.diploma
        Me.BunifuFlatButton41.Iconimage_right = Nothing
        Me.BunifuFlatButton41.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton41.Iconimage_Selected = Nothing
        Me.BunifuFlatButton41.IconMarginLeft = 0
        Me.BunifuFlatButton41.IconMarginRight = 0
        Me.BunifuFlatButton41.IconRightVisible = False
        Me.BunifuFlatButton41.IconRightZoom = 0R
        Me.BunifuFlatButton41.IconVisible = False
        Me.BunifuFlatButton41.IconZoom = 60.0R
        Me.BunifuFlatButton41.IsTab = False
        Me.BunifuFlatButton41.Location = New System.Drawing.Point(476, 6)
        Me.BunifuFlatButton41.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton41.Name = "BunifuFlatButton41"
        Me.BunifuFlatButton41.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton41.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton41.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton41.selected = False
        Me.BunifuFlatButton41.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton41.TabIndex = 35
        Me.BunifuFlatButton41.Text = "Update"
        Me.BunifuFlatButton41.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton41.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton41.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton42
        '
        Me.BunifuFlatButton42.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton42.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton42.BorderRadius = 0
        Me.BunifuFlatButton42.ButtonText = "New"
        Me.BunifuFlatButton42.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton42.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton42.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton42.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton42.Iconimage_right = Nothing
        Me.BunifuFlatButton42.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton42.Iconimage_Selected = Nothing
        Me.BunifuFlatButton42.IconMarginLeft = 0
        Me.BunifuFlatButton42.IconMarginRight = 0
        Me.BunifuFlatButton42.IconRightVisible = False
        Me.BunifuFlatButton42.IconRightZoom = 0R
        Me.BunifuFlatButton42.IconVisible = False
        Me.BunifuFlatButton42.IconZoom = 60.0R
        Me.BunifuFlatButton42.IsTab = False
        Me.BunifuFlatButton42.Location = New System.Drawing.Point(11, 6)
        Me.BunifuFlatButton42.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton42.Name = "BunifuFlatButton42"
        Me.BunifuFlatButton42.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton42.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton42.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton42.selected = False
        Me.BunifuFlatButton42.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton42.TabIndex = 15
        Me.BunifuFlatButton42.Text = "New"
        Me.BunifuFlatButton42.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton42.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton42.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton261
        '
        Me.BunifuThinButton261.ActiveBorderThickness = 1
        Me.BunifuThinButton261.ActiveCornerRadius = 2
        Me.BunifuThinButton261.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton261.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton261.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton261.AutoSize = True
        Me.BunifuThinButton261.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton261.BackgroundImage = CType(resources.GetObject("BunifuThinButton261.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton261.ButtonText = "Sign Up"
        Me.BunifuThinButton261.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton261, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton261, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton261, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton261.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton261.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton261.IdleBorderThickness = 1
        Me.BunifuThinButton261.IdleCornerRadius = 1
        Me.BunifuThinButton261.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton261.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton261.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton261.Location = New System.Drawing.Point(166, 14)
        Me.BunifuThinButton261.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton261.Name = "BunifuThinButton261"
        Me.BunifuThinButton261.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton261.TabIndex = 27
        Me.BunifuThinButton261.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton43
        '
        Me.BunifuFlatButton43.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton43.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton43.BorderRadius = 0
        Me.BunifuFlatButton43.ButtonText = "Delete"
        Me.BunifuFlatButton43.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton43.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton43.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton43.Iconimage = Global.officesoft2.My.Resources.Resources.education
        Me.BunifuFlatButton43.Iconimage_right = Nothing
        Me.BunifuFlatButton43.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton43.Iconimage_Selected = Nothing
        Me.BunifuFlatButton43.IconMarginLeft = 0
        Me.BunifuFlatButton43.IconMarginRight = 0
        Me.BunifuFlatButton43.IconRightVisible = False
        Me.BunifuFlatButton43.IconRightZoom = 0R
        Me.BunifuFlatButton43.IconVisible = False
        Me.BunifuFlatButton43.IconZoom = 60.0R
        Me.BunifuFlatButton43.IsTab = False
        Me.BunifuFlatButton43.Location = New System.Drawing.Point(321, 6)
        Me.BunifuFlatButton43.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton43.Name = "BunifuFlatButton43"
        Me.BunifuFlatButton43.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton43.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton43.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton43.selected = False
        Me.BunifuFlatButton43.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton43.TabIndex = 16
        Me.BunifuFlatButton43.Text = "Delete"
        Me.BunifuFlatButton43.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton43.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton43.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton262
        '
        Me.BunifuThinButton262.ActiveBorderThickness = 1
        Me.BunifuThinButton262.ActiveCornerRadius = 2
        Me.BunifuThinButton262.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton262.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton262.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton262.AutoSize = True
        Me.BunifuThinButton262.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton262.BackgroundImage = CType(resources.GetObject("BunifuThinButton262.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton262.ButtonText = "Sign Up"
        Me.BunifuThinButton262.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton262, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton262, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton262, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton262.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton262.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton262.IdleBorderThickness = 1
        Me.BunifuThinButton262.IdleCornerRadius = 1
        Me.BunifuThinButton262.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton262.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton262.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton262.Location = New System.Drawing.Point(11, 14)
        Me.BunifuThinButton262.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton262.Name = "BunifuThinButton262"
        Me.BunifuThinButton262.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton262.TabIndex = 23
        Me.BunifuThinButton262.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton263
        '
        Me.BunifuThinButton263.ActiveBorderThickness = 1
        Me.BunifuThinButton263.ActiveCornerRadius = 2
        Me.BunifuThinButton263.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton263.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton263.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton263.AutoSize = True
        Me.BunifuThinButton263.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton263.BackgroundImage = CType(resources.GetObject("BunifuThinButton263.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton263.ButtonText = "Sign Up"
        Me.BunifuThinButton263.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton263, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton263, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton263, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton263.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton263.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton263.IdleBorderThickness = 1
        Me.BunifuThinButton263.IdleCornerRadius = 1
        Me.BunifuThinButton263.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton263.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton263.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton263.Location = New System.Drawing.Point(321, 14)
        Me.BunifuThinButton263.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton263.Name = "BunifuThinButton263"
        Me.BunifuThinButton263.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton263.TabIndex = 29
        Me.BunifuThinButton263.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton264
        '
        Me.BunifuThinButton264.ActiveBorderThickness = 1
        Me.BunifuThinButton264.ActiveCornerRadius = 2
        Me.BunifuThinButton264.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton264.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton264.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton264.AutoSize = True
        Me.BunifuThinButton264.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton264.BackgroundImage = CType(resources.GetObject("BunifuThinButton264.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton264.ButtonText = "Sign Up"
        Me.BunifuThinButton264.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton264, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton264, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton264, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton264.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton264.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton264.IdleBorderThickness = 1
        Me.BunifuThinButton264.IdleCornerRadius = 1
        Me.BunifuThinButton264.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton264.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton264.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton264.Location = New System.Drawing.Point(476, 6)
        Me.BunifuThinButton264.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton264.Name = "BunifuThinButton264"
        Me.BunifuThinButton264.Size = New System.Drawing.Size(149, 44)
        Me.BunifuThinButton264.TabIndex = 31
        Me.BunifuThinButton264.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel25
        '
        Me.Panel25.Controls.Add(Me.BunifuFlatButton34)
        Me.Panel25.Controls.Add(Me.BunifuFlatButton35)
        Me.Panel25.Controls.Add(Me.BunifuFlatButton36)
        Me.Panel25.Controls.Add(Me.BunifuThinButton255)
        Me.Panel25.Controls.Add(Me.BunifuFlatButton37)
        Me.Panel25.Controls.Add(Me.BunifuThinButton256)
        Me.Panel25.Controls.Add(Me.BunifuThinButton257)
        Me.Panel25.Controls.Add(Me.BunifuThinButton258)
        Me.BunifuTransition3.SetDecoration(Me.Panel25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel25, BunifuAnimatorNS.DecorationType.None)
        Me.Panel25.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel25.Location = New System.Drawing.Point(0, 45)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(975, 52)
        Me.Panel25.TabIndex = 16
        Me.Panel25.Visible = False
        '
        'BunifuFlatButton34
        '
        Me.BunifuFlatButton34.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton34.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton34.BorderRadius = 0
        Me.BunifuFlatButton34.ButtonText = "patient"
        Me.BunifuFlatButton34.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton34.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton34.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton34.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton34.Iconimage_right = Nothing
        Me.BunifuFlatButton34.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton34.Iconimage_Selected = Nothing
        Me.BunifuFlatButton34.IconMarginLeft = 0
        Me.BunifuFlatButton34.IconMarginRight = 0
        Me.BunifuFlatButton34.IconRightVisible = False
        Me.BunifuFlatButton34.IconRightZoom = 0R
        Me.BunifuFlatButton34.IconVisible = False
        Me.BunifuFlatButton34.IconZoom = 60.0R
        Me.BunifuFlatButton34.IsTab = False
        Me.BunifuFlatButton34.Location = New System.Drawing.Point(166, 6)
        Me.BunifuFlatButton34.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton34.Name = "BunifuFlatButton34"
        Me.BunifuFlatButton34.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton34.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton34.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton34.selected = False
        Me.BunifuFlatButton34.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton34.TabIndex = 34
        Me.BunifuFlatButton34.Text = "patient"
        Me.BunifuFlatButton34.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton34.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton34.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton35
        '
        Me.BunifuFlatButton35.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton35.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton35.BorderRadius = 0
        Me.BunifuFlatButton35.ButtonText = "patient"
        Me.BunifuFlatButton35.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton35.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton35.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton35.Iconimage = Global.officesoft2.My.Resources.Resources.diploma
        Me.BunifuFlatButton35.Iconimage_right = Nothing
        Me.BunifuFlatButton35.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton35.Iconimage_Selected = Nothing
        Me.BunifuFlatButton35.IconMarginLeft = 0
        Me.BunifuFlatButton35.IconMarginRight = 0
        Me.BunifuFlatButton35.IconRightVisible = False
        Me.BunifuFlatButton35.IconRightZoom = 0R
        Me.BunifuFlatButton35.IconVisible = False
        Me.BunifuFlatButton35.IconZoom = 60.0R
        Me.BunifuFlatButton35.IsTab = False
        Me.BunifuFlatButton35.Location = New System.Drawing.Point(476, 6)
        Me.BunifuFlatButton35.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton35.Name = "BunifuFlatButton35"
        Me.BunifuFlatButton35.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton35.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton35.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton35.selected = False
        Me.BunifuFlatButton35.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton35.TabIndex = 35
        Me.BunifuFlatButton35.Text = "patient"
        Me.BunifuFlatButton35.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton35.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton35.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton36
        '
        Me.BunifuFlatButton36.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton36.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton36.BorderRadius = 0
        Me.BunifuFlatButton36.ButtonText = "patient"
        Me.BunifuFlatButton36.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton36.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton36.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton36.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton36.Iconimage_right = Nothing
        Me.BunifuFlatButton36.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton36.Iconimage_Selected = Nothing
        Me.BunifuFlatButton36.IconMarginLeft = 0
        Me.BunifuFlatButton36.IconMarginRight = 0
        Me.BunifuFlatButton36.IconRightVisible = False
        Me.BunifuFlatButton36.IconRightZoom = 0R
        Me.BunifuFlatButton36.IconVisible = False
        Me.BunifuFlatButton36.IconZoom = 60.0R
        Me.BunifuFlatButton36.IsTab = False
        Me.BunifuFlatButton36.Location = New System.Drawing.Point(11, 6)
        Me.BunifuFlatButton36.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton36.Name = "BunifuFlatButton36"
        Me.BunifuFlatButton36.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton36.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton36.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton36.selected = False
        Me.BunifuFlatButton36.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton36.TabIndex = 15
        Me.BunifuFlatButton36.Text = "patient"
        Me.BunifuFlatButton36.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton36.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton36.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton255
        '
        Me.BunifuThinButton255.ActiveBorderThickness = 1
        Me.BunifuThinButton255.ActiveCornerRadius = 2
        Me.BunifuThinButton255.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton255.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton255.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton255.AutoSize = True
        Me.BunifuThinButton255.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton255.BackgroundImage = CType(resources.GetObject("BunifuThinButton255.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton255.ButtonText = "Sign Up"
        Me.BunifuThinButton255.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton255, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton255, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton255, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton255.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton255.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton255.IdleBorderThickness = 1
        Me.BunifuThinButton255.IdleCornerRadius = 1
        Me.BunifuThinButton255.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton255.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton255.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton255.Location = New System.Drawing.Point(166, 14)
        Me.BunifuThinButton255.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton255.Name = "BunifuThinButton255"
        Me.BunifuThinButton255.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton255.TabIndex = 27
        Me.BunifuThinButton255.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton37
        '
        Me.BunifuFlatButton37.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton37.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton37.BorderRadius = 0
        Me.BunifuFlatButton37.ButtonText = "patient"
        Me.BunifuFlatButton37.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton37.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton37.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton37.Iconimage = Global.officesoft2.My.Resources.Resources.education
        Me.BunifuFlatButton37.Iconimage_right = Nothing
        Me.BunifuFlatButton37.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton37.Iconimage_Selected = Nothing
        Me.BunifuFlatButton37.IconMarginLeft = 0
        Me.BunifuFlatButton37.IconMarginRight = 0
        Me.BunifuFlatButton37.IconRightVisible = False
        Me.BunifuFlatButton37.IconRightZoom = 0R
        Me.BunifuFlatButton37.IconVisible = False
        Me.BunifuFlatButton37.IconZoom = 60.0R
        Me.BunifuFlatButton37.IsTab = False
        Me.BunifuFlatButton37.Location = New System.Drawing.Point(321, 6)
        Me.BunifuFlatButton37.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton37.Name = "BunifuFlatButton37"
        Me.BunifuFlatButton37.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton37.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton37.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton37.selected = False
        Me.BunifuFlatButton37.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton37.TabIndex = 16
        Me.BunifuFlatButton37.Text = "patient"
        Me.BunifuFlatButton37.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton37.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton37.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton256
        '
        Me.BunifuThinButton256.ActiveBorderThickness = 1
        Me.BunifuThinButton256.ActiveCornerRadius = 2
        Me.BunifuThinButton256.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton256.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton256.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton256.AutoSize = True
        Me.BunifuThinButton256.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton256.BackgroundImage = CType(resources.GetObject("BunifuThinButton256.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton256.ButtonText = "Sign Up"
        Me.BunifuThinButton256.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton256, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton256, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton256, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton256.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton256.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton256.IdleBorderThickness = 1
        Me.BunifuThinButton256.IdleCornerRadius = 1
        Me.BunifuThinButton256.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton256.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton256.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton256.Location = New System.Drawing.Point(11, 14)
        Me.BunifuThinButton256.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton256.Name = "BunifuThinButton256"
        Me.BunifuThinButton256.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton256.TabIndex = 23
        Me.BunifuThinButton256.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton257
        '
        Me.BunifuThinButton257.ActiveBorderThickness = 1
        Me.BunifuThinButton257.ActiveCornerRadius = 2
        Me.BunifuThinButton257.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton257.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton257.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton257.AutoSize = True
        Me.BunifuThinButton257.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton257.BackgroundImage = CType(resources.GetObject("BunifuThinButton257.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton257.ButtonText = "Sign Up"
        Me.BunifuThinButton257.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton257, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton257, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton257, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton257.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton257.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton257.IdleBorderThickness = 1
        Me.BunifuThinButton257.IdleCornerRadius = 1
        Me.BunifuThinButton257.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton257.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton257.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton257.Location = New System.Drawing.Point(321, 14)
        Me.BunifuThinButton257.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton257.Name = "BunifuThinButton257"
        Me.BunifuThinButton257.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton257.TabIndex = 29
        Me.BunifuThinButton257.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton258
        '
        Me.BunifuThinButton258.ActiveBorderThickness = 1
        Me.BunifuThinButton258.ActiveCornerRadius = 2
        Me.BunifuThinButton258.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton258.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton258.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton258.AutoSize = True
        Me.BunifuThinButton258.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton258.BackgroundImage = CType(resources.GetObject("BunifuThinButton258.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton258.ButtonText = "Sign Up"
        Me.BunifuThinButton258.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton258, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton258, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton258, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton258.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton258.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton258.IdleBorderThickness = 1
        Me.BunifuThinButton258.IdleCornerRadius = 1
        Me.BunifuThinButton258.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton258.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton258.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton258.Location = New System.Drawing.Point(476, 6)
        Me.BunifuThinButton258.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton258.Name = "BunifuThinButton258"
        Me.BunifuThinButton258.Size = New System.Drawing.Size(149, 44)
        Me.BunifuThinButton258.TabIndex = 31
        Me.BunifuThinButton258.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel24
        '
        Me.Panel24.Controls.Add(Me.BunifuCustomLabel173)
        Me.BunifuTransition3.SetDecoration(Me.Panel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel24, BunifuAnimatorNS.DecorationType.None)
        Me.Panel24.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel24.Location = New System.Drawing.Point(0, 0)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(975, 45)
        Me.Panel24.TabIndex = 1
        Me.Panel24.Visible = False
        '
        'BunifuCustomLabel173
        '
        Me.BunifuCustomLabel173.AutoSize = True
        Me.BunifuCustomLabel173.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel173, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel173, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel173, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel173.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel173.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel173.Location = New System.Drawing.Point(15, 12)
        Me.BunifuCustomLabel173.Name = "BunifuCustomLabel173"
        Me.BunifuCustomLabel173.Size = New System.Drawing.Size(76, 23)
        Me.BunifuCustomLabel173.TabIndex = 12
        Me.BunifuCustomLabel173.Text = "patient"
        '
        'TabControl5
        '
        Me.TabControl5.Controls.Add(Me.TabPage22)
        Me.TabControl5.Controls.Add(Me.TabPage23)
        Me.TabControl5.Controls.Add(Me.TabPage24)
        Me.TabControl5.Controls.Add(Me.TabPage25)
        Me.BunifuTransition3.SetDecoration(Me.TabControl5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabControl5, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl5.Location = New System.Drawing.Point(-8, 113)
        Me.TabControl5.Name = "TabControl5"
        Me.TabControl5.SelectedIndex = 0
        Me.TabControl5.Size = New System.Drawing.Size(957, 437)
        Me.TabControl5.TabIndex = 17
        Me.TabControl5.Visible = False
        '
        'TabPage22
        '
        Me.TabPage22.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage22.Controls.Add(Me.Panel26)
        Me.BunifuTransition1.SetDecoration(Me.TabPage22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage22, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage22.Location = New System.Drawing.Point(4, 22)
        Me.TabPage22.Name = "TabPage22"
        Me.TabPage22.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage22.Size = New System.Drawing.Size(949, 411)
        Me.TabPage22.TabIndex = 0
        Me.TabPage22.Text = "TabPage22"
        '
        'Panel26
        '
        Me.Panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.Panel26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel26, BunifuAnimatorNS.DecorationType.None)
        Me.Panel26.Location = New System.Drawing.Point(7, 6)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(932, 466)
        Me.Panel26.TabIndex = 74
        '
        'TabPage23
        '
        Me.TabPage23.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition1.SetDecoration(Me.TabPage23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage23, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage23.Location = New System.Drawing.Point(4, 22)
        Me.TabPage23.Name = "TabPage23"
        Me.TabPage23.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage23.Size = New System.Drawing.Size(949, 411)
        Me.TabPage23.TabIndex = 1
        Me.TabPage23.Text = "TabPage23"
        '
        'TabPage24
        '
        Me.TabPage24.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage24.Controls.Add(Me.BunifuCustomDataGrid5)
        Me.TabPage24.Controls.Add(Me.BunifuGradientPanel15)
        Me.BunifuTransition1.SetDecoration(Me.TabPage24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage24, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage24.Location = New System.Drawing.Point(4, 22)
        Me.TabPage24.Name = "TabPage24"
        Me.TabPage24.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage24.Size = New System.Drawing.Size(949, 411)
        Me.TabPage24.TabIndex = 2
        Me.TabPage24.Text = "TabPage24"
        '
        'BunifuCustomDataGrid5
        '
        DataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuCustomDataGrid5.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle21
        Me.BunifuCustomDataGrid5.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.BunifuCustomDataGrid5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BunifuCustomDataGrid5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle22.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle22.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BunifuCustomDataGrid5.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle22
        Me.BunifuCustomDataGrid5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuCustomDataGrid5.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23, Me.DataGridViewTextBoxColumn24})
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomDataGrid5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomDataGrid5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomDataGrid5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomDataGrid5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BunifuCustomDataGrid5.DoubleBuffered = True
        Me.BunifuCustomDataGrid5.EnableHeadersVisualStyles = False
        Me.BunifuCustomDataGrid5.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuCustomDataGrid5.HeaderForeColor = System.Drawing.Color.White
        Me.BunifuCustomDataGrid5.Location = New System.Drawing.Point(3, 40)
        Me.BunifuCustomDataGrid5.Name = "BunifuCustomDataGrid5"
        Me.BunifuCustomDataGrid5.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.BunifuCustomDataGrid5.Size = New System.Drawing.Size(943, 368)
        Me.BunifuCustomDataGrid5.TabIndex = 19
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "Name 1"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.HeaderText = "Name 2"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.HeaderText = "Name 3"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.HeaderText = "Name 4"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.HeaderText = "Name 5"
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        '
        'BunifuGradientPanel15
        '
        Me.BunifuGradientPanel15.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel15.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel15.Controls.Add(Me.BunifuTextbox4)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel15.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel15.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel15.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel15.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel15.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel15.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel15.Name = "BunifuGradientPanel15"
        Me.BunifuGradientPanel15.Quality = 10
        Me.BunifuGradientPanel15.Size = New System.Drawing.Size(943, 37)
        Me.BunifuGradientPanel15.TabIndex = 18
        '
        'BunifuTextbox4
        '
        Me.BunifuTextbox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTextbox4.BackgroundImage = CType(resources.GetObject("BunifuTextbox4.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition3.SetDecoration(Me.BunifuTextbox4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuTextbox4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTextbox4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTextbox4.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox4.Icon = CType(resources.GetObject("BunifuTextbox4.Icon"), System.Drawing.Image)
        Me.BunifuTextbox4.Location = New System.Drawing.Point(12, 1)
        Me.BunifuTextbox4.Name = "BunifuTextbox4"
        Me.BunifuTextbox4.Size = New System.Drawing.Size(239, 31)
        Me.BunifuTextbox4.TabIndex = 0
        Me.BunifuTextbox4.text = "Search Id, Name, Regi No"
        '
        'TabPage25
        '
        Me.TabPage25.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition1.SetDecoration(Me.TabPage25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage25, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage25.Location = New System.Drawing.Point(4, 22)
        Me.TabPage25.Name = "TabPage25"
        Me.TabPage25.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage25.Size = New System.Drawing.Size(949, 411)
        Me.TabPage25.TabIndex = 3
        Me.TabPage25.Text = "TabPage25"
        '
        'TabPage26
        '
        Me.TabPage26.BackgroundImage = Global.officesoft2.My.Resources.Resources.doctor_5
        Me.TabPage26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition1.SetDecoration(Me.TabPage26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage26, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage26.Location = New System.Drawing.Point(4, 22)
        Me.TabPage26.Name = "TabPage26"
        Me.TabPage26.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage26.Size = New System.Drawing.Size(983, 606)
        Me.TabPage26.TabIndex = 8
        Me.TabPage26.Text = "TabPage26"
        Me.TabPage26.UseVisualStyleBackColor = True
        '
        'TabPage27
        '
        Me.TabPage27.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage27.Controls.Add(Me.Panel29)
        Me.TabPage27.Controls.Add(Me.Label10)
        Me.TabPage27.Controls.Add(Me.T4)
        Me.TabPage27.Controls.Add(Me.Hcom)
        Me.TabPage27.Controls.Add(Me.textboxcom)
        Me.TabPage27.Controls.Add(Me.T3)
        Me.TabPage27.Controls.Add(Me.T2)
        Me.TabPage27.Controls.Add(Me.T1)
        Me.TabPage27.Controls.Add(Me.txtreading)
        Me.TabPage27.Controls.Add(Me.BunifuFlatButton32)
        Me.TabPage27.Controls.Add(Me.BunifuFlatButton7)
        Me.BunifuTransition1.SetDecoration(Me.TabPage27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage27, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage27.Location = New System.Drawing.Point(4, 22)
        Me.TabPage27.Name = "TabPage27"
        Me.TabPage27.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage27.Size = New System.Drawing.Size(983, 606)
        Me.TabPage27.TabIndex = 9
        Me.TabPage27.Text = "TabPage27"
        '
        'Panel29
        '
        Me.Panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel29.Controls.Add(Me.BunifuFlatButton9)
        Me.Panel29.Controls.Add(Me.Button2)
        Me.Panel29.Controls.Add(Me.Button1)
        Me.Panel29.Controls.Add(Me.BunifuCustomLabel65)
        Me.Panel29.Controls.Add(Me.BunifuCustomLabel56)
        Me.Panel29.Controls.Add(Me.TextBox1)
        Me.Panel29.Controls.Add(Me.ComboBox2)
        Me.Panel29.Controls.Add(Me.Panel30)
        Me.BunifuTransition3.SetDecoration(Me.Panel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel29, BunifuAnimatorNS.DecorationType.None)
        Me.Panel29.Location = New System.Drawing.Point(264, 112)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(480, 294)
        Me.Panel29.TabIndex = 0
        '
        'BunifuFlatButton9
        '
        Me.BunifuFlatButton9.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton9.BorderRadius = 0
        Me.BunifuFlatButton9.ButtonText = "Go Back"
        Me.BunifuFlatButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton9.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton9.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton9.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton9.Iconimage_right = Nothing
        Me.BunifuFlatButton9.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton9.Iconimage_Selected = Nothing
        Me.BunifuFlatButton9.IconMarginLeft = 0
        Me.BunifuFlatButton9.IconMarginRight = 0
        Me.BunifuFlatButton9.IconRightVisible = False
        Me.BunifuFlatButton9.IconRightZoom = 0R
        Me.BunifuFlatButton9.IconVisible = False
        Me.BunifuFlatButton9.IconZoom = 60.0R
        Me.BunifuFlatButton9.IsTab = False
        Me.BunifuFlatButton9.Location = New System.Drawing.Point(133, 129)
        Me.BunifuFlatButton9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton9.Name = "BunifuFlatButton9"
        Me.BunifuFlatButton9.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton9.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton9.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton9.selected = False
        Me.BunifuFlatButton9.Size = New System.Drawing.Size(327, 36)
        Me.BunifuFlatButton9.TabIndex = 128
        Me.BunifuFlatButton9.Text = "Go Back"
        Me.BunifuFlatButton9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton9.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton9.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTransition1.SetDecoration(Me.Button2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Button2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Button2, BunifuAnimatorNS.DecorationType.None)
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(272, 92)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(188, 30)
        Me.Button2.TabIndex = 16
        Me.Button2.Text = "Disconnect"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BunifuTransition1.SetDecoration(Me.Button1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Button1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Button1, BunifuAnimatorNS.DecorationType.None)
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(135, 92)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(132, 30)
        Me.Button1.TabIndex = 15
        Me.Button1.Text = "Connect"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'BunifuCustomLabel65
        '
        Me.BunifuCustomLabel65.AutoSize = True
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel65, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel65, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel65, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel65.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel65.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel65.Location = New System.Drawing.Point(15, 94)
        Me.BunifuCustomLabel65.Name = "BunifuCustomLabel65"
        Me.BunifuCustomLabel65.Size = New System.Drawing.Size(90, 17)
        Me.BunifuCustomLabel65.TabIndex = 123
        Me.BunifuCustomLabel65.Text = "Temperature"
        '
        'BunifuCustomLabel56
        '
        Me.BunifuCustomLabel56.AutoSize = True
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel56, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel56, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel56, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel56.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel56.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel56.Location = New System.Drawing.Point(15, 55)
        Me.BunifuCustomLabel56.Name = "BunifuCustomLabel56"
        Me.BunifuCustomLabel56.Size = New System.Drawing.Size(113, 17)
        Me.BunifuCustomLabel56.TabIndex = 120
        Me.BunifuCustomLabel56.Text = "Select Com Port."
        '
        'TextBox1
        '
        Me.BunifuTransition1.SetDecoration(Me.TextBox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TextBox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TextBox1, BunifuAnimatorNS.DecorationType.None)
        Me.TextBox1.Location = New System.Drawing.Point(8, 172)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(452, 98)
        Me.TextBox1.TabIndex = 13
        '
        'ComboBox2
        '
        Me.BunifuTransition2.SetDecoration(Me.ComboBox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.ComboBox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.ComboBox2, BunifuAnimatorNS.DecorationType.None)
        Me.ComboBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(135, 52)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(325, 24)
        Me.ComboBox2.TabIndex = 14
        '
        'Panel30
        '
        Me.Panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel30.Controls.Add(Me.BunifuCustomLabel55)
        Me.BunifuTransition3.SetDecoration(Me.Panel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel30, BunifuAnimatorNS.DecorationType.None)
        Me.Panel30.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel30.Location = New System.Drawing.Point(0, 0)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(478, 33)
        Me.Panel30.TabIndex = 122
        '
        'BunifuCustomLabel55
        '
        Me.BunifuCustomLabel55.AutoSize = True
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel55, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel55, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel55, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel55.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel55.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel55.Location = New System.Drawing.Point(5, 7)
        Me.BunifuCustomLabel55.Name = "BunifuCustomLabel55"
        Me.BunifuCustomLabel55.Size = New System.Drawing.Size(173, 17)
        Me.BunifuCustomLabel55.TabIndex = 119
        Me.BunifuCustomLabel55.Text = "Hardware Communication "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.BunifuTransition1.SetDecoration(Me.Label10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Label10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Label10, BunifuAnimatorNS.DecorationType.None)
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(454, 112)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(231, 17)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = "Select Port For Communication"
        '
        'T4
        '
        Me.BunifuTransition1.SetDecoration(Me.T4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.T4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.T4, BunifuAnimatorNS.DecorationType.None)
        Me.T4.Location = New System.Drawing.Point(268, 168)
        Me.T4.Name = "T4"
        Me.T4.Size = New System.Drawing.Size(118, 20)
        Me.T4.TabIndex = 5
        Me.T4.Visible = False
        '
        'Hcom
        '
        Me.BunifuTransition2.SetDecoration(Me.Hcom, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Hcom, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Hcom, BunifuAnimatorNS.DecorationType.None)
        Me.Hcom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Hcom.FormattingEnabled = True
        Me.Hcom.Location = New System.Drawing.Point(513, 221)
        Me.Hcom.Name = "Hcom"
        Me.Hcom.Size = New System.Drawing.Size(189, 28)
        Me.Hcom.TabIndex = 121
        '
        'textboxcom
        '
        Me.textboxcom.BorderColorFocused = System.Drawing.Color.White
        Me.textboxcom.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.textboxcom.BorderColorMouseHover = System.Drawing.Color.White
        Me.textboxcom.BorderThickness = 1
        Me.textboxcom.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition1.SetDecoration(Me.textboxcom, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.textboxcom, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.textboxcom, BunifuAnimatorNS.DecorationType.None)
        Me.textboxcom.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.textboxcom.ForeColor = System.Drawing.Color.White
        Me.textboxcom.isPassword = False
        Me.textboxcom.Location = New System.Drawing.Point(513, 253)
        Me.textboxcom.Margin = New System.Windows.Forms.Padding(4)
        Me.textboxcom.Name = "textboxcom"
        Me.textboxcom.Size = New System.Drawing.Size(189, 30)
        Me.textboxcom.TabIndex = 120
        Me.textboxcom.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'T3
        '
        Me.BunifuTransition1.SetDecoration(Me.T3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.T3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.T3, BunifuAnimatorNS.DecorationType.None)
        Me.T3.Location = New System.Drawing.Point(268, 133)
        Me.T3.Name = "T3"
        Me.T3.Size = New System.Drawing.Size(118, 20)
        Me.T3.TabIndex = 4
        Me.T3.Visible = False
        '
        'T2
        '
        Me.BunifuTransition1.SetDecoration(Me.T2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.T2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.T2, BunifuAnimatorNS.DecorationType.None)
        Me.T2.Location = New System.Drawing.Point(269, 169)
        Me.T2.Name = "T2"
        Me.T2.Size = New System.Drawing.Size(118, 20)
        Me.T2.TabIndex = 3
        Me.T2.WordWrap = False
        '
        'T1
        '
        Me.BunifuTransition1.SetDecoration(Me.T1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.T1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.T1, BunifuAnimatorNS.DecorationType.None)
        Me.T1.Location = New System.Drawing.Point(269, 133)
        Me.T1.Name = "T1"
        Me.T1.Size = New System.Drawing.Size(118, 20)
        Me.T1.TabIndex = 2
        Me.T1.WordWrap = False
        '
        'txtreading
        '
        Me.BunifuTransition1.SetDecoration(Me.txtreading, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtreading, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtreading, BunifuAnimatorNS.DecorationType.None)
        Me.txtreading.Location = New System.Drawing.Point(432, 187)
        Me.txtreading.Multiline = True
        Me.txtreading.Name = "txtreading"
        Me.txtreading.Size = New System.Drawing.Size(215, 94)
        Me.txtreading.TabIndex = 1
        '
        'BunifuFlatButton32
        '
        Me.BunifuFlatButton32.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton32.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton32.BorderRadius = 0
        Me.BunifuFlatButton32.ButtonText = "Disconnect"
        Me.BunifuFlatButton32.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton32.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton32.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton32.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton32.Iconimage_right = Nothing
        Me.BunifuFlatButton32.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton32.Iconimage_Selected = Nothing
        Me.BunifuFlatButton32.IconMarginLeft = 0
        Me.BunifuFlatButton32.IconMarginRight = 0
        Me.BunifuFlatButton32.IconRightVisible = False
        Me.BunifuFlatButton32.IconRightZoom = 0R
        Me.BunifuFlatButton32.IconVisible = False
        Me.BunifuFlatButton32.IconZoom = 60.0R
        Me.BunifuFlatButton32.IsTab = False
        Me.BunifuFlatButton32.Location = New System.Drawing.Point(313, 288)
        Me.BunifuFlatButton32.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton32.Name = "BunifuFlatButton32"
        Me.BunifuFlatButton32.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton32.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton32.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton32.selected = False
        Me.BunifuFlatButton32.Size = New System.Drawing.Size(275, 36)
        Me.BunifuFlatButton32.TabIndex = 127
        Me.BunifuFlatButton32.Text = "Disconnect"
        Me.BunifuFlatButton32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton32.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton32.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton7
        '
        Me.BunifuFlatButton7.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton7.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton7.BorderRadius = 0
        Me.BunifuFlatButton7.ButtonText = "Connect"
        Me.BunifuFlatButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton7.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton7.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton7.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton7.Iconimage_right = Nothing
        Me.BunifuFlatButton7.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton7.Iconimage_Selected = Nothing
        Me.BunifuFlatButton7.IconMarginLeft = 0
        Me.BunifuFlatButton7.IconMarginRight = 0
        Me.BunifuFlatButton7.IconRightVisible = False
        Me.BunifuFlatButton7.IconRightZoom = 0R
        Me.BunifuFlatButton7.IconVisible = False
        Me.BunifuFlatButton7.IconZoom = 60.0R
        Me.BunifuFlatButton7.IsTab = False
        Me.BunifuFlatButton7.Location = New System.Drawing.Point(666, 269)
        Me.BunifuFlatButton7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton7.Name = "BunifuFlatButton7"
        Me.BunifuFlatButton7.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton7.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton7.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton7.selected = False
        Me.BunifuFlatButton7.Size = New System.Drawing.Size(40, 36)
        Me.BunifuFlatButton7.TabIndex = 126
        Me.BunifuFlatButton7.Text = "Connect"
        Me.BunifuFlatButton7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton7.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton7.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.ListView1)
        Me.TabPage9.Controls.Add(Me.ListBox1)
        Me.TabPage9.Controls.Add(Me.Panel36)
        Me.BunifuTransition1.SetDecoration(Me.TabPage9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage9, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(983, 606)
        Me.TabPage9.TabIndex = 10
        Me.TabPage9.Text = "TabPage9"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'ListView1
        '
        Me.BunifuTransition3.SetDecoration(Me.ListView1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.ListView1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.ListView1, BunifuAnimatorNS.DecorationType.None)
        Me.ListView1.Location = New System.Drawing.Point(283, 91)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(121, 222)
        Me.ListView1.TabIndex = 54
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.List
        '
        'ListBox1
        '
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BunifuTransition2.SetDecoration(Me.ListBox1, BunifuAnimatorNS.DecorationType.BottomMirror)
        Me.BunifuTransition3.SetDecoration(Me.ListBox1, BunifuAnimatorNS.DecorationType.BottomMirror)
        Me.BunifuTransition1.SetDecoration(Me.ListBox1, BunifuAnimatorNS.DecorationType.None)
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(19, 80)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(220, 442)
        Me.ListBox1.TabIndex = 53
        '
        'Panel36
        '
        Me.Panel36.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Panel36.Controls.Add(Me.BunifuCustomLabel10)
        Me.Panel36.Controls.Add(Me.BunifuCustomLabel13)
        Me.Panel36.Controls.Add(Me.BunifuCustomLabel14)
        Me.Panel36.Controls.Add(Me.BunifuCustomLabel15)
        Me.Panel36.Controls.Add(Me.BunifuCustomLabel16)
        Me.Panel36.Controls.Add(Me.BunifuCustomLabel17)
        Me.BunifuTransition3.SetDecoration(Me.Panel36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel36, BunifuAnimatorNS.DecorationType.None)
        Me.Panel36.Location = New System.Drawing.Point(3, 46)
        Me.Panel36.Name = "Panel36"
        Me.Panel36.Size = New System.Drawing.Size(923, 28)
        Me.Panel36.TabIndex = 52
        '
        'BunifuCustomLabel10
        '
        Me.BunifuCustomLabel10.AutoSize = True
        Me.BunifuCustomLabel10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel10.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel10.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel10.Location = New System.Drawing.Point(427, 5)
        Me.BunifuCustomLabel10.Name = "BunifuCustomLabel10"
        Me.BunifuCustomLabel10.Size = New System.Drawing.Size(86, 19)
        Me.BunifuCustomLabel10.TabIndex = 80
        Me.BunifuCustomLabel10.Text = "Pulse Rate"
        '
        'BunifuCustomLabel13
        '
        Me.BunifuCustomLabel13.AutoSize = True
        Me.BunifuCustomLabel13.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel13.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel13.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel13.Location = New System.Drawing.Point(793, 3)
        Me.BunifuCustomLabel13.Name = "BunifuCustomLabel13"
        Me.BunifuCustomLabel13.Size = New System.Drawing.Size(59, 19)
        Me.BunifuCustomLabel13.TabIndex = 79
        Me.BunifuCustomLabel13.Text = "Doctor"
        '
        'BunifuCustomLabel14
        '
        Me.BunifuCustomLabel14.AutoSize = True
        Me.BunifuCustomLabel14.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel14.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel14.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel14.Location = New System.Drawing.Point(663, 4)
        Me.BunifuCustomLabel14.Name = "BunifuCustomLabel14"
        Me.BunifuCustomLabel14.Size = New System.Drawing.Size(61, 19)
        Me.BunifuCustomLabel14.TabIndex = 60
        Me.BunifuCustomLabel14.Text = "Low BP"
        '
        'BunifuCustomLabel15
        '
        Me.BunifuCustomLabel15.AutoSize = True
        Me.BunifuCustomLabel15.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel15.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel15.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel15.Location = New System.Drawing.Point(543, 4)
        Me.BunifuCustomLabel15.Name = "BunifuCustomLabel15"
        Me.BunifuCustomLabel15.Size = New System.Drawing.Size(67, 19)
        Me.BunifuCustomLabel15.TabIndex = 59
        Me.BunifuCustomLabel15.Text = "High BP"
        '
        'BunifuCustomLabel16
        '
        Me.BunifuCustomLabel16.AutoSize = True
        Me.BunifuCustomLabel16.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel16.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel16.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel16.Location = New System.Drawing.Point(287, 4)
        Me.BunifuCustomLabel16.Name = "BunifuCustomLabel16"
        Me.BunifuCustomLabel16.Size = New System.Drawing.Size(96, 19)
        Me.BunifuCustomLabel16.TabIndex = 58
        Me.BunifuCustomLabel16.Text = "Body Temp"
        '
        'BunifuCustomLabel17
        '
        Me.BunifuCustomLabel17.AutoSize = True
        Me.BunifuCustomLabel17.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel17.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel17.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel17.Location = New System.Drawing.Point(26, 4)
        Me.BunifuCustomLabel17.Name = "BunifuCustomLabel17"
        Me.BunifuCustomLabel17.Size = New System.Drawing.Size(114, 19)
        Me.BunifuCustomLabel17.TabIndex = 57
        Me.BunifuCustomLabel17.Text = "Patient Name"
        '
        'TabPage28
        '
        Me.TabPage28.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage28.Controls.Add(Me.gridprescription)
        Me.TabPage28.Controls.Add(Me.BunifuGradientPanel1)
        Me.BunifuTransition1.SetDecoration(Me.TabPage28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabPage28, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage28.Location = New System.Drawing.Point(4, 22)
        Me.TabPage28.Name = "TabPage28"
        Me.TabPage28.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage28.Size = New System.Drawing.Size(983, 606)
        Me.TabPage28.TabIndex = 11
        Me.TabPage28.Text = "TabPage28"
        '
        'gridprescription
        '
        DataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.gridprescription.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle23
        Me.gridprescription.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.gridprescription.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.gridprescription.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle24.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle24.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.gridprescription.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle24
        Me.gridprescription.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuTransition1.SetDecoration(Me.gridprescription, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.gridprescription, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.gridprescription, BunifuAnimatorNS.DecorationType.None)
        Me.gridprescription.DoubleBuffered = True
        Me.gridprescription.EnableHeadersVisualStyles = False
        Me.gridprescription.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.gridprescription.HeaderForeColor = System.Drawing.Color.White
        Me.gridprescription.Location = New System.Drawing.Point(7, 99)
        Me.gridprescription.Name = "gridprescription"
        Me.gridprescription.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.gridprescription.Size = New System.Drawing.Size(944, 373)
        Me.gridprescription.TabIndex = 3
        '
        'BunifuGradientPanel1
        '
        Me.BunifuGradientPanel1.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel1.Controls.Add(Me.BunifuCustomLabel24)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel1.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel1.Name = "BunifuGradientPanel1"
        Me.BunifuGradientPanel1.Quality = 10
        Me.BunifuGradientPanel1.Size = New System.Drawing.Size(977, 47)
        Me.BunifuGradientPanel1.TabIndex = 2
        '
        'BunifuCustomLabel24
        '
        Me.BunifuCustomLabel24.AutoSize = True
        Me.BunifuCustomLabel24.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel24.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel24.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel24.Location = New System.Drawing.Point(25, 10)
        Me.BunifuCustomLabel24.Name = "BunifuCustomLabel24"
        Me.BunifuCustomLabel24.Size = New System.Drawing.Size(186, 23)
        Me.BunifuCustomLabel24.TabIndex = 13
        Me.BunifuCustomLabel24.Text = "Patient Prescription"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.TabControl1)
        Me.BunifuTransition3.SetDecoration(Me.Panel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel2, BunifuAnimatorNS.DecorationType.None)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 40)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1186, 580)
        Me.Panel2.TabIndex = 16
        '
        'Panel37
        '
        Me.Panel37.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition3.SetDecoration(Me.Panel37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Panel37, BunifuAnimatorNS.DecorationType.None)
        Me.Panel37.Location = New System.Drawing.Point(199, 41)
        Me.Panel37.Name = "Panel37"
        Me.Panel37.Size = New System.Drawing.Size(984, 21)
        Me.Panel37.TabIndex = 17
        '
        'BunifuElipse2
        '
        Me.BunifuElipse2.ElipseRadius = 25
        Me.BunifuElipse2.TargetControl = Me.BunifuGradientPanel5
        '
        'BunifuTransition2
        '
        Me.BunifuTransition2.AnimationType = BunifuAnimatorNS.AnimationType.Leaf
        Me.BunifuTransition2.Cursor = Nothing
        Animation8.AnimateOnlyDifferences = True
        Animation8.BlindCoeff = CType(resources.GetObject("Animation8.BlindCoeff"), System.Drawing.PointF)
        Animation8.LeafCoeff = 1.0!
        Animation8.MaxTime = 1.0!
        Animation8.MinTime = 0!
        Animation8.MosaicCoeff = CType(resources.GetObject("Animation8.MosaicCoeff"), System.Drawing.PointF)
        Animation8.MosaicShift = CType(resources.GetObject("Animation8.MosaicShift"), System.Drawing.PointF)
        Animation8.MosaicSize = 0
        Animation8.Padding = New System.Windows.Forms.Padding(0)
        Animation8.RotateCoeff = 0!
        Animation8.RotateLimit = 0!
        Animation8.ScaleCoeff = CType(resources.GetObject("Animation8.ScaleCoeff"), System.Drawing.PointF)
        Animation8.SlideCoeff = CType(resources.GetObject("Animation8.SlideCoeff"), System.Drawing.PointF)
        Animation8.TimeCoeff = 0!
        Animation8.TransparencyCoeff = 0!
        Me.BunifuTransition2.DefaultAnimation = Animation8
        Me.BunifuTransition2.Interval = 100
        Me.BunifuTransition2.MaxAnimationTime = 3000
        '
        'BunifuTransition1
        '
        Me.BunifuTransition1.AnimationType = BunifuAnimatorNS.AnimationType.Leaf
        Me.BunifuTransition1.Cursor = Nothing
        Animation9.AnimateOnlyDifferences = True
        Animation9.BlindCoeff = CType(resources.GetObject("Animation9.BlindCoeff"), System.Drawing.PointF)
        Animation9.LeafCoeff = 1.0!
        Animation9.MaxTime = 1.0!
        Animation9.MinTime = 0!
        Animation9.MosaicCoeff = CType(resources.GetObject("Animation9.MosaicCoeff"), System.Drawing.PointF)
        Animation9.MosaicShift = CType(resources.GetObject("Animation9.MosaicShift"), System.Drawing.PointF)
        Animation9.MosaicSize = 0
        Animation9.Padding = New System.Windows.Forms.Padding(0)
        Animation9.RotateCoeff = 0!
        Animation9.RotateLimit = 0!
        Animation9.ScaleCoeff = CType(resources.GetObject("Animation9.ScaleCoeff"), System.Drawing.PointF)
        Animation9.SlideCoeff = CType(resources.GetObject("Animation9.SlideCoeff"), System.Drawing.PointF)
        Animation9.TimeCoeff = 0!
        Animation9.TransparencyCoeff = 0!
        Me.BunifuTransition1.DefaultAnimation = Animation9
        Me.BunifuTransition1.Interval = 100
        Me.BunifuTransition1.MaxAnimationTime = 3000
        '
        'BunifuElipse3
        '
        Me.BunifuElipse3.ElipseRadius = 20
        Me.BunifuElipse3.TargetControl = Me
        '
        'bunifuDragControl1
        '
        Me.bunifuDragControl1.Fixed = True
        Me.bunifuDragControl1.Horizontal = True
        Me.bunifuDragControl1.TargetControl = Me.header
        Me.bunifuDragControl1.Vertical = True
        '
        'Timer2
        '
        '
        'Timer3
        '
        Me.Timer3.Interval = 1000
        '
        'patientdata
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1186, 620)
        Me.Controls.Add(Me.Panel37)
        Me.Controls.Add(Me.panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.header)
        Me.BunifuTransition2.SetDecoration(Me, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me, BunifuAnimatorNS.DecorationType.None)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "patientdata"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "patientdata"
        Me.panel1.ResumeLayout(False)
        CType(Me.bunifuImageButton1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.header.ResumeLayout(False)
        Me.header.PerformLayout()
        CType(Me.BunifuImageButton2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel35.ResumeLayout(False)
        Me.Panel35.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.BunifuGradientPanel5.ResumeLayout(False)
        Me.BunifuGradientPanel5.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout()
        Me.Panel34.ResumeLayout(False)
        Me.Panel34.PerformLayout()
        Me.Panel33.ResumeLayout(False)
        Me.Panel33.PerformLayout()
        Me.Panel32.ResumeLayout(False)
        Me.Panel32.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage11.ResumeLayout(False)
        Me.BunifuGradientPanel6.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage17.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage14.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.TabPage16.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.TabPage15.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabControl4.ResumeLayout(False)
        Me.TabPage18.ResumeLayout(False)
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.TabPage19.ResumeLayout(False)
        CType(Me.BunifuCustomDataGrid4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel14.ResumeLayout(False)
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.Panel22.ResumeLayout(False)
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.Panel23.ResumeLayout(False)
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.TabControl5.ResumeLayout(False)
        Me.TabPage22.ResumeLayout(False)
        Me.TabPage24.ResumeLayout(False)
        CType(Me.BunifuCustomDataGrid5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel15.ResumeLayout(False)
        Me.TabPage27.ResumeLayout(False)
        Me.TabPage27.PerformLayout()
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.Panel30.ResumeLayout(False)
        Me.Panel30.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.Panel36.ResumeLayout(False)
        Me.Panel36.PerformLayout()
        Me.TabPage28.ResumeLayout(False)
        CType(Me.gridprescription, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel1.ResumeLayout(False)
        Me.BunifuGradientPanel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Private WithEvents panel1 As Panel
    Private WithEvents BunifuFlatButton31 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuTransition1 As BunifuAnimatorNS.BunifuTransition
    Friend WithEvents BunifuTransition2 As BunifuAnimatorNS.BunifuTransition
    Friend WithEvents BunifuTransition3 As BunifuAnimatorNS.BunifuTransition
    Private WithEvents BunifuFlatButton13 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuFlatButton8 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuImageButton1 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuFlatButton1 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuFlatButton4 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuFlatButton2 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuFlatButton3 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents header As Panel
    Friend WithEvents BunifuImageButton2 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents label1 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents BunifuElipse2 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents BunifuElipse3 As Bunifu.Framework.UI.BunifuElipse
    Private WithEvents bunifuDragControl1 As Bunifu.Framework.UI.BunifuDragControl
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents Panel21 As Panel
    Friend WithEvents BunifuGradientPanel5 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents bt5 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents bt4 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents bt3 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents bt2 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents bt1 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel23 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel22 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel21 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel20 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel19 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel18 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuSeparator5 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator4 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator3 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator2 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator1 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents lblp5 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lblp4 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lblp3 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lblp2 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lblp1 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Panel15 As Panel
    Friend WithEvents BunifuThinButton219 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton221 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton211 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton217 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton26 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton214 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton27 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton212 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton213 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton215 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel28 As Panel
    Friend WithEvents BunifuThinButton29 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton28 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents cmbpid As ComboBox
    Friend WithEvents BunifuThinButton239 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton240 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton223 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton225 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton24 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton25 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton22 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton23 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents BunifuGradientPanel6 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuTextbox1 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents DataGridView1 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents TabPage17 As TabPage
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents BunifuCustomLabel29 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents Panel16 As Panel
    Friend WithEvents BunifuThinButton227 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton228 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton229 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton230 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton231 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton232 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton233 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton234 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton235 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton236 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton237 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton238 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Panel6 As Panel
    Friend WithEvents BunifuCustomLabel57 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabControl3 As TabControl
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents TabPage12 As TabPage
    Friend WithEvents Panel10 As Panel
    Friend WithEvents TabPage13 As TabPage
    Friend WithEvents TabPage14 As TabPage
    Friend WithEvents Panel12 As Panel
    Friend WithEvents TabPage16 As TabPage
    Friend WithEvents Panel14 As Panel
    Friend WithEvents TabPage15 As TabPage
    Friend WithEvents Panel13 As Panel
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabControl4 As TabControl
    Friend WithEvents TabPage18 As TabPage
    Friend WithEvents Panel19 As Panel
    Friend WithEvents BunifuFlatButton25 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton26 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton247 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton248 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton27 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton28 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton29 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton249 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton30 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton250 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton251 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton252 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents TabPage19 As TabPage
    Friend WithEvents BunifuCustomDataGrid4 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents BunifuGradientPanel14 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuTextbox3 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents TabPage20 As TabPage
    Friend WithEvents TabPage21 As TabPage
    Friend WithEvents Panel18 As Panel
    Friend WithEvents BunifuFlatButton19 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton20 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton241 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton242 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton21 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton22 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton23 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton243 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton24 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton244 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton245 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton246 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Panel17 As Panel
    Friend WithEvents BunifuCustomLabel159 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents Panel22 As Panel
    Friend WithEvents BunifuTileButton1 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton17 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton2 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton18 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton3 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton19 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton4 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton20 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton5 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton13 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton6 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton14 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton7 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton15 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton8 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton16 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton12 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton9 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton11 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton10 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents Panel20 As Panel
    Friend WithEvents BunifuCustomLabel172 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Panel27 As Panel
    Friend WithEvents BunifuFlatButton38 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton39 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton259 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton260 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton40 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton41 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton42 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton261 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton43 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton262 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton263 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton264 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Panel25 As Panel
    Friend WithEvents BunifuFlatButton34 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton35 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton36 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton255 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton37 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton256 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton257 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton258 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Panel24 As Panel
    Friend WithEvents BunifuCustomLabel173 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabControl5 As TabControl
    Friend WithEvents TabPage22 As TabPage
    Friend WithEvents Panel26 As Panel
    Friend WithEvents TabPage23 As TabPage
    Friend WithEvents TabPage24 As TabPage
    Friend WithEvents BunifuCustomDataGrid5 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As DataGridViewTextBoxColumn
    Friend WithEvents BunifuGradientPanel15 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuTextbox4 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents TabPage25 As TabPage
    Friend WithEvents TabPage26 As TabPage
    Friend WithEvents TabPage27 As TabPage
    Friend WithEvents Panel29 As Panel
    Friend WithEvents BunifuFlatButton32 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton7 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuCustomLabel65 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel56 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel30 As Panel
    Friend WithEvents BunifuCustomLabel55 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Hcom As ComboBox
    Friend WithEvents textboxcom As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel35 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel34 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel33 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel32 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel31 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel30 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents date1 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtwardno As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtprate As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtwardtype As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtlbp As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtmobile As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txthbp As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtbodytemp As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtbloodgroup As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtheight As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtweight As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtage As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtaddress As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtpatientname As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents BunifuCustomLabel60 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel59 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel58 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel53 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel52 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel50 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel48 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel46 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel44 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel43 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel42 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel41 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel40 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtgender As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtdob As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtpatientid As ComboBox
    Friend WithEvents txtdoctor As ComboBox
    Friend WithEvents txtdisease As ComboBox
    Private WithEvents bunifuThinButton21 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuCustomLabel38 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtdoctorid As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents Panel31 As Panel
    Friend WithEvents BunifuCustomLabel75 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel74 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel73 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel72 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel71 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel68 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel67 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel66 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel64 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel34 As Panel
    Friend WithEvents BunifuCustomLabel63 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel33 As Panel
    Friend WithEvents BunifuCustomLabel70 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel62 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel32 As Panel
    Friend WithEvents BunifuCustomLabel69 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel61 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents BunifuCustomLabel36 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtsr As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents Panel35 As Panel
    Friend WithEvents BunifuCustomLabel11 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuSeparator11 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuCustomLabel12 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel9 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuSeparator10 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents lblp10 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel7 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuSeparator9 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents lblp9 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel5 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuSeparator8 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents lblp8 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel3 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuSeparator7 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents lblp7 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel1 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuSeparator6 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents lblp6 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel78 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel77 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel76 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel54 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel90 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp10 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp9 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp8 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp7 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp6 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp5 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp4 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp3 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp2 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents lbp1 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel79 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp10 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp9 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp8 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp7 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp6 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp5 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp4 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp3 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp2 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents hbp1 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel51 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents bt10 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents bt9 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents bt8 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents bt7 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents bt6 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuFlatButton9 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents BunifuCustomLabel2 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel4 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel6 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr10 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr9 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr8 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr7 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr6 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr5 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr4 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr3 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr2 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents dr1 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtreading As TextBox
    Friend WithEvents T4 As TextBox
    Friend WithEvents T3 As TextBox
    Friend WithEvents T2 As TextBox
    Friend WithEvents T1 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents BunifuCustomLabel8 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel28 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL10 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL9 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL8 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL7 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL6 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL5 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL4 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL3 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL2 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PL1 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Panel36 As Panel
    Friend WithEvents BunifuCustomLabel10 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel13 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel14 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel15 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel16 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel17 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents ListView1 As ListView
    Friend WithEvents Panel37 As Panel
    Friend WithEvents TabPage28 As TabPage
    Friend WithEvents gridprescription As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents BunifuGradientPanel1 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuCustomLabel24 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Timer3 As Timer
End Class
