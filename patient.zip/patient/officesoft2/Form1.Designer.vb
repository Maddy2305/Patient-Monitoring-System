﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim Animation1 As BunifuAnimatorNS.Animation = New BunifuAnimatorNS.Animation()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim Animation2 As BunifuAnimatorNS.Animation = New BunifuAnimatorNS.Animation()
        Dim Animation3 As BunifuAnimatorNS.Animation = New BunifuAnimatorNS.Animation()
        Me.header = New System.Windows.Forms.Panel()
        Me.label1 = New System.Windows.Forms.Label()
        Me.bunifuDragControl1 = New Bunifu.Framework.UI.BunifuDragControl(Me.components)
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel54 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel51 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel49 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel47 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel45 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel39 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel37 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.cmbpid = New System.Windows.Forms.ComboBox()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel66 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel58 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel57 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.txtfees = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel154 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.txtselectwardno = New System.Windows.Forms.ComboBox()
        Me.BunifuCustomLabel151 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.txtmoble2 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel149 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.txtemail = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel77 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.txtdate1 = New System.Windows.Forms.DateTimePicker()
        Me.txtheight = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtweight = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtselectward = New System.Windows.Forms.ComboBox()
        Me.txtbloodgroup = New System.Windows.Forms.ComboBox()
        Me.BunifuCustomLabel70 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.txtuid = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtmobile = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtgender = New System.Windows.Forms.ComboBox()
        Me.txtcity = New System.Windows.Forms.ComboBox()
        Me.txtadd = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtage = New System.Windows.Forms.ComboBox()
        Me.txtname = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtlastname = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtfirstname = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtid = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel69 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel68 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel64 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel63 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel43 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel42 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel41 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel40 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel36 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel35 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel34 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel33 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel32 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel30 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel31 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel38 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.DataGridView1 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.TabPage17 = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.BunifuCustomLabel29 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.BunifuDropdown22 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel99 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown21 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel98 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel97 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox21 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel93 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel94 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel95 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown18 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuDropdown19 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuDropdown20 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel96 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown17 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel92 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel59 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.BunifuMetroTextbox33 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel110 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel105 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox31 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel108 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox32 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel109 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown25 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BunifuDropdown24 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuMetroTextbox30 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel100 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel107 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox24 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel104 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox29 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel106 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BunifuCustomLabel102 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox22 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel101 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox23 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel103 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown23 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel60 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.BunifuDropdown28 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuDropdown27 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuDropdown26 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel121 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel122 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel123 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel120 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox37 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel119 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox36 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel118 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel117 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox35 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel116 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox34 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel115 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel114 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel113 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomTextbox3 = New WindowsFormsControlLibrary1.BunifuCustomTextbox()
        Me.BunifuCustomLabel112 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel111 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomTextbox2 = New WindowsFormsControlLibrary1.BunifuCustomTextbox()
        Me.BunifuCustomLabel61 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.BunifuMetroTextbox45 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel141 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox44 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel140 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown35 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel139 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox43 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel138 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox42 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel137 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.BunifuDropdown32 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuDropdown33 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuDropdown34 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuDropdown29 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuDropdown30 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuDropdown31 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel133 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel134 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel135 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel136 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel124 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel125 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel126 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel127 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox38 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel128 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox39 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel129 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel130 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox40 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel131 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox41 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel132 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel62 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.BunifuCustomDataGrid2 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BunifuCustomLabel78 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabControl4 = New System.Windows.Forms.TabControl()
        Me.TabPage18 = New System.Windows.Forms.TabPage()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.TabPage19 = New System.Windows.Forms.TabPage()
        Me.BunifuCustomDataGrid4 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage20 = New System.Windows.Forms.TabPage()
        Me.TabPage21 = New System.Windows.Forms.TabPage()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel172 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel148 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabControl5 = New System.Windows.Forms.TabControl()
        Me.TabPage22 = New System.Windows.Forms.TabPage()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.txtsral = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel88 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel87 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel86 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel85 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel84 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel83 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel82 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel81 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurdate = New System.Windows.Forms.DateTimePicker()
        Me.nurpin = New System.Windows.Forms.MaskedTextBox()
        Me.nurcountry = New System.Windows.Forms.ComboBox()
        Me.nurstate = New System.Windows.Forms.ComboBox()
        Me.nurcity = New System.Windows.Forms.ComboBox()
        Me.nuradd = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel80 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nuremail = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel79 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurmob = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel76 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurgen = New System.Windows.Forms.ComboBox()
        Me.nurdesig = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel75 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurdob = New System.Windows.Forms.DateTimePicker()
        Me.nurdoj = New System.Windows.Forms.DateTimePicker()
        Me.nurlname = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel74 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurfname = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel73 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurid = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel72 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage23 = New System.Windows.Forms.TabPage()
        Me.txtmsg = New System.Windows.Forms.TextBox()
        Me.BunifuCustomLabel144 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurward1 = New System.Windows.Forms.ComboBox()
        Me.nurpassword = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel147 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurmob1 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel146 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurusername = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel145 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurdesig1 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel143 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurlname1 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel142 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurfname1 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel91 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel90 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.nurid1 = New System.Windows.Forms.ComboBox()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel89 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.txtCharacters = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.TabPage24 = New System.Windows.Forms.TabPage()
        Me.BunifuCustomDataGrid5 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.TabPage25 = New System.Windows.Forms.TabPage()
        Me.TabPage27 = New System.Windows.Forms.TabPage()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel65 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel56 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel55 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.Hcom = New System.Windows.Forms.ComboBox()
        Me.textboxcom = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.TabPage28 = New System.Windows.Forms.TabPage()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.txtdocdelete = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.BunifuCustomLabel150 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabControl6 = New System.Windows.Forms.TabControl()
        Me.TabPage29 = New System.Windows.Forms.TabPage()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.txtdocdob = New System.Windows.Forms.DateTimePicker()
        Me.txtdocfullname = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel153 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.txtdoclname = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel152 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.msg2 = New System.Windows.Forms.TextBox()
        Me.txtcharacter2 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtdocdate = New System.Windows.Forms.DateTimePicker()
        Me.txtdocpass = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtdocusername = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtdoccat = New System.Windows.Forms.ComboBox()
        Me.txtdocaddress = New System.Windows.Forms.ComboBox()
        Me.txtdocmobile = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtdocquali = New System.Windows.Forms.ComboBox()
        Me.txtdocfname = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtdocid1 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.txtdocid = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel162 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel163 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel164 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel167 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel168 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel169 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel170 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel171 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel173 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel174 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel175 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel176 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage30 = New System.Windows.Forms.TabPage()
        Me.BunifuCustomDataGrid1 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.BunifuTransition1 = New BunifuAnimatorNS.BunifuTransition(Me.components)
        Me.BunifuTransition2 = New BunifuAnimatorNS.BunifuTransition(Me.components)
        Me.BunifuElipse2 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.BunifuTransition3 = New BunifuAnimatorNS.BunifuTransition(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.BunifuFlatButton31 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton11 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton10 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton8 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton6 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuImageButton1 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.bunifuThinButton21 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.bunifuFlatButton5 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton4 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.bunifuFlatButton3 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuImageButton2 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.BunifuGradientPanel8 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel71 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel44 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.BunifuGradientPanel7 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel67 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel52 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.BunifuGradientPanel12 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel53 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.BunifuGradientPanel9 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel46 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.BunifuGradientPanel10 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel48 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.BunifuGradientPanel11 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel50 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.BunifuCircleProgressbar6 = New Bunifu.Framework.UI.BunifuCircleProgressbar()
        Me.BunifuCircleProgressbar5 = New Bunifu.Framework.UI.BunifuCircleProgressbar()
        Me.BunifuCircleProgressbar4 = New Bunifu.Framework.UI.BunifuCircleProgressbar()
        Me.BunifuCircleProgressbar3 = New Bunifu.Framework.UI.BunifuCircleProgressbar()
        Me.BunifuCircleProgressbar2 = New Bunifu.Framework.UI.BunifuCircleProgressbar()
        Me.BunifuCircleProgressbar1 = New Bunifu.Framework.UI.BunifuCircleProgressbar()
        Me.BunifuGradientPanel1 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel3 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel2 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BunifuCustomLabel1 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuGradientPanel5 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel28 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel27 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel26 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel25 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel24 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel23 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel22 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel21 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel20 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel19 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel18 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuSeparator5 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator4 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator3 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator2 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuSeparator1 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.BunifuCustomLabel17 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel16 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel15 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel14 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel13 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuGradientPanel2 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuCustomLabel4 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.BunifuCustomLabel5 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel6 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuGradientPanel3 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.BunifuCustomLabel7 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel8 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel9 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuThinButton210 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton253 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton219 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton221 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton211 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton217 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton26 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton214 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton27 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton212 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton213 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton215 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton29 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton28 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton239 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton240 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton223 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton225 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton24 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton25 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton22 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton23 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuGradientPanel6 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuTextbox1 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.BunifuThinButton227 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton228 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton229 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton230 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton231 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton232 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton233 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton234 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton235 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton236 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton237 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton238 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton18 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton17 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton224 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton216 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton14 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton16 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton9 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton222 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton15 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton226 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton220 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton218 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuGradientPanel13 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuTextbox2 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.BunifuFlatButton25 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton26 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton247 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton248 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton27 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton28 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton29 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton249 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton30 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton250 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton251 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton252 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuGradientPanel14 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuTextbox3 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.BunifuFlatButton19 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton20 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton241 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton242 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton21 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton22 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton23 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton243 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton24 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton244 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton245 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton246 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuTileButton1 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton17 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton2 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton18 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton3 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton19 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton4 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton20 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton5 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton13 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton6 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton14 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton7 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton15 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton8 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton16 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton12 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton9 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton11 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuTileButton10 = New Bunifu.Framework.UI.BunifuTileButton()
        Me.BunifuFlatButton38 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton39 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton259 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton260 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton40 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton42 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton261 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton262 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton34 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton35 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton36 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton255 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton256 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton258 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton13 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton12 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuGradientPanel15 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuTextbox4 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.TabPage26 = New System.Windows.Forms.TabPage()
        Me.BunifuFlatButton32 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton7 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton264 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton265 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton266 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton267 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton269 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton271 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton272 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton273 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton274 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton275 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuFlatButton33 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton41 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuThinButton254 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton257 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuGradientPanel16 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuTextbox5 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.header.SuspendLayout()
        Me.panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage17.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage14.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.TabPage16.SuspendLayout()
        Me.Panel14.SuspendLayout()
        CType(Me.BunifuCustomDataGrid2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage15.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabControl4.SuspendLayout()
        Me.TabPage18.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.TabPage19.SuspendLayout()
        CType(Me.BunifuCustomDataGrid4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel18.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.TabControl5.SuspendLayout()
        Me.TabPage22.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.TabPage23.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.TabPage24.SuspendLayout()
        CType(Me.BunifuCustomDataGrid5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage27.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.Panel30.SuspendLayout()
        Me.TabPage28.SuspendLayout()
        Me.Panel33.SuspendLayout()
        Me.Panel32.SuspendLayout()
        Me.Panel31.SuspendLayout()
        Me.TabControl6.SuspendLayout()
        Me.TabPage29.SuspendLayout()
        Me.Panel34.SuspendLayout()
        Me.TabPage30.SuspendLayout()
        CType(Me.BunifuCustomDataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bunifuImageButton1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BunifuImageButton2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel8.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel7.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel12.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel9.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel10.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel11.SuspendLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel5.SuspendLayout()
        Me.BunifuGradientPanel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuGradientPanel6.SuspendLayout()
        Me.BunifuGradientPanel13.SuspendLayout()
        Me.BunifuGradientPanel14.SuspendLayout()
        Me.BunifuGradientPanel15.SuspendLayout()
        Me.BunifuGradientPanel16.SuspendLayout()
        Me.SuspendLayout()
        '
        'header
        '
        Me.header.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.header.Controls.Add(Me.BunifuImageButton2)
        Me.header.Controls.Add(Me.label1)
        Me.BunifuTransition1.SetDecoration(Me.header, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.header, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.header, BunifuAnimatorNS.DecorationType.None)
        Me.header.Dock = System.Windows.Forms.DockStyle.Top
        Me.header.Location = New System.Drawing.Point(0, 0)
        Me.header.Name = "header"
        Me.header.Size = New System.Drawing.Size(1150, 37)
        Me.header.TabIndex = 5
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.label1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.label1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.label1, BunifuAnimatorNS.DecorationType.None)
        Me.label1.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.ForeColor = System.Drawing.Color.White
        Me.label1.Location = New System.Drawing.Point(15, 9)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(302, 26)
        Me.label1.TabIndex = 5
        Me.label1.Text = "Patient Health Monitoring System"
        '
        'bunifuDragControl1
        '
        Me.bunifuDragControl1.Fixed = True
        Me.bunifuDragControl1.Horizontal = True
        Me.bunifuDragControl1.TargetControl = Me.header
        Me.bunifuDragControl1.Vertical = True
        '
        'panel1
        '
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.BunifuFlatButton31)
        Me.panel1.Controls.Add(Me.BunifuFlatButton11)
        Me.panel1.Controls.Add(Me.BunifuFlatButton10)
        Me.panel1.Controls.Add(Me.bunifuFlatButton8)
        Me.panel1.Controls.Add(Me.bunifuFlatButton6)
        Me.panel1.Controls.Add(Me.bunifuImageButton1)
        Me.panel1.Controls.Add(Me.bunifuThinButton21)
        Me.panel1.Controls.Add(Me.bunifuFlatButton5)
        Me.panel1.Controls.Add(Me.bunifuFlatButton1)
        Me.panel1.Controls.Add(Me.bunifuFlatButton4)
        Me.panel1.Controls.Add(Me.bunifuFlatButton2)
        Me.panel1.Controls.Add(Me.bunifuFlatButton3)
        Me.BunifuTransition1.SetDecoration(Me.panel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.panel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.panel1, BunifuAnimatorNS.DecorationType.None)
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.panel1.Location = New System.Drawing.Point(0, 37)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(200, 621)
        Me.panel1.TabIndex = 7
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.TabControl1)
        Me.BunifuTransition1.SetDecoration(Me.Panel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel2, BunifuAnimatorNS.DecorationType.None)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1150, 658)
        Me.Panel2.TabIndex = 13
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage26)
        Me.TabControl1.Controls.Add(Me.TabPage27)
        Me.TabControl1.Controls.Add(Me.TabPage28)
        Me.BunifuTransition1.SetDecoration(Me.TabControl1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabControl1, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl1.Location = New System.Drawing.Point(194, 18)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(965, 632)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.Panel21)
        Me.BunifuTransition3.SetDecoration(Me.TabPage1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage1, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(957, 606)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        '
        'Panel21
        '
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel8)
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel7)
        Me.Panel21.Controls.Add(Me.BunifuCustomLabel54)
        Me.Panel21.Controls.Add(Me.BunifuCustomLabel51)
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel12)
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel9)
        Me.Panel21.Controls.Add(Me.BunifuCustomLabel49)
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel10)
        Me.Panel21.Controls.Add(Me.BunifuCustomLabel47)
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel11)
        Me.Panel21.Controls.Add(Me.BunifuCustomLabel45)
        Me.Panel21.Controls.Add(Me.BunifuCustomLabel39)
        Me.Panel21.Controls.Add(Me.BunifuCustomLabel37)
        Me.Panel21.Controls.Add(Me.BunifuCircleProgressbar6)
        Me.Panel21.Controls.Add(Me.BunifuCircleProgressbar5)
        Me.Panel21.Controls.Add(Me.BunifuCircleProgressbar4)
        Me.Panel21.Controls.Add(Me.BunifuCircleProgressbar3)
        Me.Panel21.Controls.Add(Me.BunifuCircleProgressbar2)
        Me.Panel21.Controls.Add(Me.BunifuCircleProgressbar1)
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel1)
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel5)
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel2)
        Me.Panel21.Controls.Add(Me.BunifuGradientPanel3)
        Me.BunifuTransition1.SetDecoration(Me.Panel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel21, BunifuAnimatorNS.DecorationType.None)
        Me.Panel21.Location = New System.Drawing.Point(6, 6)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(945, 590)
        Me.Panel21.TabIndex = 20
        '
        'BunifuCustomLabel54
        '
        Me.BunifuCustomLabel54.AutoSize = True
        Me.BunifuCustomLabel54.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel54, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel54, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel54, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel54.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel54.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel54.Location = New System.Drawing.Point(856, 455)
        Me.BunifuCustomLabel54.Name = "BunifuCustomLabel54"
        Me.BunifuCustomLabel54.Size = New System.Drawing.Size(30, 17)
        Me.BunifuCustomLabel54.TabIndex = 32
        Me.BunifuCustomLabel54.Text = "( 6)"
        Me.BunifuCustomLabel54.Visible = False
        '
        'BunifuCustomLabel51
        '
        Me.BunifuCustomLabel51.AutoSize = True
        Me.BunifuCustomLabel51.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel51, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel51, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel51, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel51.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel51.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel51.Location = New System.Drawing.Point(732, 455)
        Me.BunifuCustomLabel51.Name = "BunifuCustomLabel51"
        Me.BunifuCustomLabel51.Size = New System.Drawing.Size(30, 17)
        Me.BunifuCustomLabel51.TabIndex = 31
        Me.BunifuCustomLabel51.Text = "( 5)"
        Me.BunifuCustomLabel51.Visible = False
        '
        'BunifuCustomLabel49
        '
        Me.BunifuCustomLabel49.AutoSize = True
        Me.BunifuCustomLabel49.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel49, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel49, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel49, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel49.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel49.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel49.Location = New System.Drawing.Point(618, 455)
        Me.BunifuCustomLabel49.Name = "BunifuCustomLabel49"
        Me.BunifuCustomLabel49.Size = New System.Drawing.Size(34, 17)
        Me.BunifuCustomLabel49.TabIndex = 30
        Me.BunifuCustomLabel49.Text = "( 4 )"
        Me.BunifuCustomLabel49.Visible = False
        '
        'BunifuCustomLabel47
        '
        Me.BunifuCustomLabel47.AutoSize = True
        Me.BunifuCustomLabel47.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel47, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel47, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel47, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel47.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel47.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel47.Location = New System.Drawing.Point(856, 318)
        Me.BunifuCustomLabel47.Name = "BunifuCustomLabel47"
        Me.BunifuCustomLabel47.Size = New System.Drawing.Size(34, 17)
        Me.BunifuCustomLabel47.TabIndex = 29
        Me.BunifuCustomLabel47.Text = "( 3 )"
        Me.BunifuCustomLabel47.Visible = False
        '
        'BunifuCustomLabel45
        '
        Me.BunifuCustomLabel45.AutoSize = True
        Me.BunifuCustomLabel45.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel45, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel45, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel45, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel45.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel45.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel45.Location = New System.Drawing.Point(732, 318)
        Me.BunifuCustomLabel45.Name = "BunifuCustomLabel45"
        Me.BunifuCustomLabel45.Size = New System.Drawing.Size(30, 17)
        Me.BunifuCustomLabel45.TabIndex = 28
        Me.BunifuCustomLabel45.Text = "( 2)"
        Me.BunifuCustomLabel45.Visible = False
        '
        'BunifuCustomLabel39
        '
        Me.BunifuCustomLabel39.AutoSize = True
        Me.BunifuCustomLabel39.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel39.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel39.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel39.Location = New System.Drawing.Point(618, 318)
        Me.BunifuCustomLabel39.Name = "BunifuCustomLabel39"
        Me.BunifuCustomLabel39.Size = New System.Drawing.Size(34, 17)
        Me.BunifuCustomLabel39.TabIndex = 27
        Me.BunifuCustomLabel39.Text = "( 1 )"
        Me.BunifuCustomLabel39.Visible = False
        '
        'BunifuCustomLabel37
        '
        Me.BunifuCustomLabel37.AutoSize = True
        Me.BunifuCustomLabel37.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel37.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel37.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel37.Location = New System.Drawing.Point(551, 345)
        Me.BunifuCustomLabel37.Name = "BunifuCustomLabel37"
        Me.BunifuCustomLabel37.Size = New System.Drawing.Size(27, 242)
        Me.BunifuCustomLabel37.TabIndex = 26
        Me.BunifuCustomLabel37.Text = "W" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "A" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "R" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "S" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "T" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "A" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "T" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "U" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "S"
        Me.BunifuCustomLabel37.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BunifuCustomLabel37.Visible = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.Panel15)
        Me.TabPage2.Controls.Add(Me.Panel4)
        Me.TabPage2.Controls.Add(Me.TabControl2)
        Me.TabPage2.Controls.Add(Me.BunifuCustomLabel29)
        Me.BunifuTransition3.SetDecoration(Me.TabPage2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage2, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(957, 606)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.BunifuThinButton210)
        Me.Panel15.Controls.Add(Me.BunifuThinButton253)
        Me.Panel15.Controls.Add(Me.BunifuThinButton219)
        Me.Panel15.Controls.Add(Me.BunifuThinButton221)
        Me.Panel15.Controls.Add(Me.BunifuThinButton211)
        Me.Panel15.Controls.Add(Me.BunifuThinButton217)
        Me.Panel15.Controls.Add(Me.BunifuThinButton26)
        Me.Panel15.Controls.Add(Me.BunifuThinButton214)
        Me.Panel15.Controls.Add(Me.BunifuThinButton27)
        Me.Panel15.Controls.Add(Me.BunifuThinButton212)
        Me.Panel15.Controls.Add(Me.BunifuThinButton213)
        Me.Panel15.Controls.Add(Me.BunifuThinButton215)
        Me.BunifuTransition1.SetDecoration(Me.Panel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel15, BunifuAnimatorNS.DecorationType.None)
        Me.Panel15.Location = New System.Drawing.Point(6, 545)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(947, 49)
        Me.Panel15.TabIndex = 35
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Panel28)
        Me.Panel4.Controls.Add(Me.BunifuThinButton239)
        Me.Panel4.Controls.Add(Me.BunifuThinButton240)
        Me.Panel4.Controls.Add(Me.BunifuThinButton223)
        Me.Panel4.Controls.Add(Me.BunifuThinButton225)
        Me.Panel4.Controls.Add(Me.BunifuThinButton24)
        Me.Panel4.Controls.Add(Me.BunifuThinButton25)
        Me.Panel4.Controls.Add(Me.BunifuThinButton22)
        Me.Panel4.Controls.Add(Me.BunifuThinButton23)
        Me.BunifuTransition1.SetDecoration(Me.Panel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel4, BunifuAnimatorNS.DecorationType.None)
        Me.Panel4.Location = New System.Drawing.Point(-1, 32)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(962, 44)
        Me.Panel4.TabIndex = 13
        '
        'Panel28
        '
        Me.Panel28.Controls.Add(Me.BunifuThinButton29)
        Me.Panel28.Controls.Add(Me.BunifuThinButton28)
        Me.Panel28.Controls.Add(Me.cmbpid)
        Me.BunifuTransition1.SetDecoration(Me.Panel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel28, BunifuAnimatorNS.DecorationType.None)
        Me.Panel28.Location = New System.Drawing.Point(657, 4)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(283, 35)
        Me.Panel28.TabIndex = 31
        '
        'cmbpid
        '
        Me.BunifuTransition2.SetDecoration(Me.cmbpid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.cmbpid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.cmbpid, BunifuAnimatorNS.DecorationType.None)
        Me.cmbpid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbpid.FormattingEnabled = True
        Me.cmbpid.Location = New System.Drawing.Point(5, 8)
        Me.cmbpid.Name = "cmbpid"
        Me.cmbpid.Size = New System.Drawing.Size(128, 23)
        Me.cmbpid.TabIndex = 31
        Me.cmbpid.Text = "Select Patient Id"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Controls.Add(Me.TabPage11)
        Me.TabControl2.Controls.Add(Me.TabPage17)
        Me.BunifuTransition1.SetDecoration(Me.TabControl2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabControl2, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl2.Location = New System.Drawing.Point(-4, 69)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(961, 455)
        Me.TabControl2.TabIndex = 14
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage7.Controls.Add(Me.Panel3)
        Me.BunifuTransition3.SetDecoration(Me.TabPage7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage7, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(953, 429)
        Me.TabPage7.TabIndex = 0
        Me.TabPage7.Text = "TabPage7"
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel66)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel58)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel57)
        Me.Panel3.Controls.Add(Me.txtfees)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel154)
        Me.Panel3.Controls.Add(Me.txtselectwardno)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel151)
        Me.Panel3.Controls.Add(Me.txtmoble2)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel149)
        Me.Panel3.Controls.Add(Me.txtemail)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel77)
        Me.Panel3.Controls.Add(Me.txtdate1)
        Me.Panel3.Controls.Add(Me.txtheight)
        Me.Panel3.Controls.Add(Me.txtweight)
        Me.Panel3.Controls.Add(Me.txtselectward)
        Me.Panel3.Controls.Add(Me.txtbloodgroup)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel70)
        Me.Panel3.Controls.Add(Me.txtuid)
        Me.Panel3.Controls.Add(Me.txtmobile)
        Me.Panel3.Controls.Add(Me.txtgender)
        Me.Panel3.Controls.Add(Me.txtcity)
        Me.Panel3.Controls.Add(Me.txtadd)
        Me.Panel3.Controls.Add(Me.txtage)
        Me.Panel3.Controls.Add(Me.txtname)
        Me.Panel3.Controls.Add(Me.txtlastname)
        Me.Panel3.Controls.Add(Me.txtfirstname)
        Me.Panel3.Controls.Add(Me.txtid)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel69)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel68)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel64)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel63)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel43)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel42)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel41)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel40)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel36)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel35)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel34)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel33)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel32)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel30)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel31)
        Me.BunifuTransition1.SetDecoration(Me.Panel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel3, BunifuAnimatorNS.DecorationType.None)
        Me.Panel3.Location = New System.Drawing.Point(6, 9)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(933, 420)
        Me.Panel3.TabIndex = 12
        '
        'BunifuCustomLabel66
        '
        Me.BunifuCustomLabel66.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel66, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel66, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel66, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel66.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel66.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel66.Location = New System.Drawing.Point(523, 305)
        Me.BunifuCustomLabel66.Name = "BunifuCustomLabel66"
        Me.BunifuCustomLabel66.Size = New System.Drawing.Size(56, 17)
        Me.BunifuCustomLabel66.TabIndex = 144
        Me.BunifuCustomLabel66.Text = "(In INR)"
        '
        'BunifuCustomLabel58
        '
        Me.BunifuCustomLabel58.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel58, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel58, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel58, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel58.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel58.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel58.Location = New System.Drawing.Point(469, 91)
        Me.BunifuCustomLabel58.Name = "BunifuCustomLabel58"
        Me.BunifuCustomLabel58.Size = New System.Drawing.Size(61, 17)
        Me.BunifuCustomLabel58.TabIndex = 143
        Me.BunifuCustomLabel58.Text = "(In Feet)"
        '
        'BunifuCustomLabel57
        '
        Me.BunifuCustomLabel57.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel57, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel57, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel57, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel57.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel57.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel57.Location = New System.Drawing.Point(469, 53)
        Me.BunifuCustomLabel57.Name = "BunifuCustomLabel57"
        Me.BunifuCustomLabel57.Size = New System.Drawing.Size(54, 17)
        Me.BunifuCustomLabel57.TabIndex = 142
        Me.BunifuCustomLabel57.Text = "(In Kg.)"
        '
        'txtfees
        '
        Me.txtfees.BorderColorFocused = System.Drawing.Color.White
        Me.txtfees.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtfees.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtfees.BorderThickness = 1
        Me.txtfees.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtfees, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtfees, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtfees, BunifuAnimatorNS.DecorationType.None)
        Me.txtfees.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtfees.ForeColor = System.Drawing.Color.White
        Me.txtfees.isPassword = False
        Me.txtfees.Location = New System.Drawing.Point(602, 297)
        Me.txtfees.Margin = New System.Windows.Forms.Padding(4)
        Me.txtfees.Name = "txtfees"
        Me.txtfees.Size = New System.Drawing.Size(256, 30)
        Me.txtfees.TabIndex = 141
        Me.txtfees.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel154
        '
        Me.BunifuCustomLabel154.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel154, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel154, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel154, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel154.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel154.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel154.Location = New System.Drawing.Point(410, 305)
        Me.BunifuCustomLabel154.Name = "BunifuCustomLabel154"
        Me.BunifuCustomLabel154.Size = New System.Drawing.Size(107, 17)
        Me.BunifuCustomLabel154.TabIndex = 140
        Me.BunifuCustomLabel154.Text = "Admission Fees"
        '
        'txtselectwardno
        '
        Me.txtselectwardno.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition2.SetDecoration(Me.txtselectwardno, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtselectwardno, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtselectwardno, BunifuAnimatorNS.DecorationType.None)
        Me.txtselectwardno.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtselectwardno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtselectwardno.ForeColor = System.Drawing.Color.White
        Me.txtselectwardno.FormattingEnabled = True
        Me.txtselectwardno.Location = New System.Drawing.Point(602, 197)
        Me.txtselectwardno.Name = "txtselectwardno"
        Me.txtselectwardno.Size = New System.Drawing.Size(256, 24)
        Me.txtselectwardno.TabIndex = 139
        '
        'BunifuCustomLabel151
        '
        Me.BunifuCustomLabel151.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel151, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel151, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel151, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel151.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel151.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel151.Location = New System.Drawing.Point(410, 200)
        Me.BunifuCustomLabel151.Name = "BunifuCustomLabel151"
        Me.BunifuCustomLabel151.Size = New System.Drawing.Size(113, 17)
        Me.BunifuCustomLabel151.TabIndex = 138
        Me.BunifuCustomLabel151.Text = "Room / Ward No"
        '
        'txtmoble2
        '
        Me.txtmoble2.BorderColorFocused = System.Drawing.Color.White
        Me.txtmoble2.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtmoble2.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtmoble2.BorderThickness = 1
        Me.txtmoble2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtmoble2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtmoble2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtmoble2, BunifuAnimatorNS.DecorationType.None)
        Me.txtmoble2.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtmoble2.ForeColor = System.Drawing.Color.White
        Me.txtmoble2.isPassword = False
        Me.txtmoble2.Location = New System.Drawing.Point(151, 362)
        Me.txtmoble2.Margin = New System.Windows.Forms.Padding(4)
        Me.txtmoble2.Name = "txtmoble2"
        Me.txtmoble2.Size = New System.Drawing.Size(189, 30)
        Me.txtmoble2.TabIndex = 137
        Me.txtmoble2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel149
        '
        Me.BunifuCustomLabel149.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel149, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel149, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel149, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel149.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel149.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel149.Location = New System.Drawing.Point(23, 369)
        Me.BunifuCustomLabel149.Name = "BunifuCustomLabel149"
        Me.BunifuCustomLabel149.Size = New System.Drawing.Size(83, 17)
        Me.BunifuCustomLabel149.TabIndex = 136
        Me.BunifuCustomLabel149.Text = "Mobile No 2"
        '
        'txtemail
        '
        Me.txtemail.BorderColorFocused = System.Drawing.Color.White
        Me.txtemail.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtemail.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtemail.BorderThickness = 1
        Me.txtemail.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtemail, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtemail, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtemail, BunifuAnimatorNS.DecorationType.None)
        Me.txtemail.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtemail.ForeColor = System.Drawing.Color.White
        Me.txtemail.isPassword = False
        Me.txtemail.Location = New System.Drawing.Point(602, 226)
        Me.txtemail.Margin = New System.Windows.Forms.Padding(4)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(256, 30)
        Me.txtemail.TabIndex = 135
        Me.txtemail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel77
        '
        Me.BunifuCustomLabel77.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel77, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel77, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel77, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel77.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel77.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel77.Location = New System.Drawing.Point(410, 234)
        Me.BunifuCustomLabel77.Name = "BunifuCustomLabel77"
        Me.BunifuCustomLabel77.Size = New System.Drawing.Size(57, 17)
        Me.BunifuCustomLabel77.TabIndex = 134
        Me.BunifuCustomLabel77.Text = "Email Id"
        '
        'txtdate1
        '
        Me.txtdate1.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition3.SetDecoration(Me.txtdate1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdate1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdate1, BunifuAnimatorNS.DecorationType.None)
        Me.txtdate1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdate1.Location = New System.Drawing.Point(601, 341)
        Me.txtdate1.Name = "txtdate1"
        Me.txtdate1.Size = New System.Drawing.Size(256, 23)
        Me.txtdate1.TabIndex = 133
        '
        'txtheight
        '
        Me.txtheight.BorderColorFocused = System.Drawing.Color.White
        Me.txtheight.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtheight.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtheight.BorderThickness = 1
        Me.txtheight.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtheight, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtheight, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtheight, BunifuAnimatorNS.DecorationType.None)
        Me.txtheight.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtheight.ForeColor = System.Drawing.Color.White
        Me.txtheight.isPassword = False
        Me.txtheight.Location = New System.Drawing.Point(602, 84)
        Me.txtheight.Margin = New System.Windows.Forms.Padding(4)
        Me.txtheight.Name = "txtheight"
        Me.txtheight.Size = New System.Drawing.Size(256, 30)
        Me.txtheight.TabIndex = 132
        Me.txtheight.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtweight
        '
        Me.txtweight.BorderColorFocused = System.Drawing.Color.White
        Me.txtweight.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtweight.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtweight.BorderThickness = 1
        Me.txtweight.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtweight, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtweight, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtweight, BunifuAnimatorNS.DecorationType.None)
        Me.txtweight.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtweight.ForeColor = System.Drawing.Color.White
        Me.txtweight.isPassword = False
        Me.txtweight.Location = New System.Drawing.Point(602, 46)
        Me.txtweight.Margin = New System.Windows.Forms.Padding(4)
        Me.txtweight.Name = "txtweight"
        Me.txtweight.Size = New System.Drawing.Size(256, 30)
        Me.txtweight.TabIndex = 131
        Me.txtweight.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtselectward
        '
        Me.txtselectward.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition2.SetDecoration(Me.txtselectward, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtselectward, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtselectward, BunifuAnimatorNS.DecorationType.None)
        Me.txtselectward.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtselectward.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtselectward.ForeColor = System.Drawing.Color.White
        Me.txtselectward.FormattingEnabled = True
        Me.txtselectward.Location = New System.Drawing.Point(602, 161)
        Me.txtselectward.Name = "txtselectward"
        Me.txtselectward.Size = New System.Drawing.Size(256, 24)
        Me.txtselectward.TabIndex = 130
        '
        'txtbloodgroup
        '
        Me.txtbloodgroup.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition2.SetDecoration(Me.txtbloodgroup, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtbloodgroup, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtbloodgroup, BunifuAnimatorNS.DecorationType.None)
        Me.txtbloodgroup.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtbloodgroup.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbloodgroup.ForeColor = System.Drawing.Color.White
        Me.txtbloodgroup.FormattingEnabled = True
        Me.txtbloodgroup.Items.AddRange(New Object() {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"})
        Me.txtbloodgroup.Location = New System.Drawing.Point(602, 125)
        Me.txtbloodgroup.Name = "txtbloodgroup"
        Me.txtbloodgroup.Size = New System.Drawing.Size(256, 24)
        Me.txtbloodgroup.TabIndex = 129
        '
        'BunifuCustomLabel70
        '
        Me.BunifuCustomLabel70.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel70, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel70, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel70, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel70.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel70.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel70.Location = New System.Drawing.Point(410, 164)
        Me.BunifuCustomLabel70.Name = "BunifuCustomLabel70"
        Me.BunifuCustomLabel70.Size = New System.Drawing.Size(127, 17)
        Me.BunifuCustomLabel70.TabIndex = 128
        Me.BunifuCustomLabel70.Text = "Room / Ward Type"
        '
        'txtuid
        '
        Me.txtuid.BorderColorFocused = System.Drawing.Color.White
        Me.txtuid.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtuid.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtuid.BorderThickness = 1
        Me.txtuid.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtuid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtuid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtuid, BunifuAnimatorNS.DecorationType.None)
        Me.txtuid.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtuid.ForeColor = System.Drawing.Color.White
        Me.txtuid.isPassword = False
        Me.txtuid.Location = New System.Drawing.Point(602, 259)
        Me.txtuid.Margin = New System.Windows.Forms.Padding(4)
        Me.txtuid.Name = "txtuid"
        Me.txtuid.Size = New System.Drawing.Size(256, 30)
        Me.txtuid.TabIndex = 127
        Me.txtuid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtmobile
        '
        Me.txtmobile.BorderColorFocused = System.Drawing.Color.White
        Me.txtmobile.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtmobile.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtmobile.BorderThickness = 1
        Me.txtmobile.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtmobile, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtmobile, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtmobile, BunifuAnimatorNS.DecorationType.None)
        Me.txtmobile.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtmobile.ForeColor = System.Drawing.Color.White
        Me.txtmobile.isPassword = False
        Me.txtmobile.Location = New System.Drawing.Point(151, 324)
        Me.txtmobile.Margin = New System.Windows.Forms.Padding(4)
        Me.txtmobile.Name = "txtmobile"
        Me.txtmobile.Size = New System.Drawing.Size(189, 30)
        Me.txtmobile.TabIndex = 126
        Me.txtmobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtgender
        '
        Me.txtgender.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition2.SetDecoration(Me.txtgender, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtgender, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtgender, BunifuAnimatorNS.DecorationType.None)
        Me.txtgender.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtgender.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgender.ForeColor = System.Drawing.Color.White
        Me.txtgender.FormattingEnabled = True
        Me.txtgender.Items.AddRange(New Object() {"Male", "Female"})
        Me.txtgender.Location = New System.Drawing.Point(151, 293)
        Me.txtgender.Name = "txtgender"
        Me.txtgender.Size = New System.Drawing.Size(189, 24)
        Me.txtgender.TabIndex = 125
        '
        'txtcity
        '
        Me.txtcity.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition2.SetDecoration(Me.txtcity, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtcity, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtcity, BunifuAnimatorNS.DecorationType.None)
        Me.txtcity.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtcity.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcity.ForeColor = System.Drawing.Color.White
        Me.txtcity.FormattingEnabled = True
        Me.txtcity.Items.AddRange(New Object() {"Nagpur", "Wardha", "Chandrapur", "Amaravti", "Yavatmal"})
        Me.txtcity.Location = New System.Drawing.Point(151, 262)
        Me.txtcity.Name = "txtcity"
        Me.txtcity.Size = New System.Drawing.Size(189, 24)
        Me.txtcity.TabIndex = 124
        '
        'txtadd
        '
        Me.txtadd.BorderColorFocused = System.Drawing.Color.White
        Me.txtadd.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtadd.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtadd.BorderThickness = 1
        Me.txtadd.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtadd, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtadd, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtadd, BunifuAnimatorNS.DecorationType.None)
        Me.txtadd.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtadd.ForeColor = System.Drawing.Color.White
        Me.txtadd.isPassword = False
        Me.txtadd.Location = New System.Drawing.Point(151, 225)
        Me.txtadd.Margin = New System.Windows.Forms.Padding(4)
        Me.txtadd.Name = "txtadd"
        Me.txtadd.Size = New System.Drawing.Size(189, 30)
        Me.txtadd.TabIndex = 123
        Me.txtadd.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtage
        '
        Me.txtage.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition2.SetDecoration(Me.txtage, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtage, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtage, BunifuAnimatorNS.DecorationType.None)
        Me.txtage.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtage.ForeColor = System.Drawing.Color.White
        Me.txtage.FormattingEnabled = True
        Me.txtage.Location = New System.Drawing.Point(151, 194)
        Me.txtage.Name = "txtage"
        Me.txtage.Size = New System.Drawing.Size(189, 24)
        Me.txtage.TabIndex = 122
        '
        'txtname
        '
        Me.txtname.BorderColorFocused = System.Drawing.Color.White
        Me.txtname.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtname.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtname.BorderThickness = 1
        Me.txtname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtname, BunifuAnimatorNS.DecorationType.None)
        Me.txtname.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtname.ForeColor = System.Drawing.Color.White
        Me.txtname.isPassword = False
        Me.txtname.Location = New System.Drawing.Point(151, 157)
        Me.txtname.Margin = New System.Windows.Forms.Padding(4)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(189, 30)
        Me.txtname.TabIndex = 121
        Me.txtname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtlastname
        '
        Me.txtlastname.BorderColorFocused = System.Drawing.Color.White
        Me.txtlastname.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtlastname.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtlastname.BorderThickness = 1
        Me.txtlastname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtlastname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtlastname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtlastname, BunifuAnimatorNS.DecorationType.None)
        Me.txtlastname.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtlastname.ForeColor = System.Drawing.Color.White
        Me.txtlastname.isPassword = False
        Me.txtlastname.Location = New System.Drawing.Point(151, 120)
        Me.txtlastname.Margin = New System.Windows.Forms.Padding(4)
        Me.txtlastname.Name = "txtlastname"
        Me.txtlastname.Size = New System.Drawing.Size(189, 30)
        Me.txtlastname.TabIndex = 120
        Me.txtlastname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtfirstname
        '
        Me.txtfirstname.BorderColorFocused = System.Drawing.Color.White
        Me.txtfirstname.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtfirstname.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtfirstname.BorderThickness = 1
        Me.txtfirstname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtfirstname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtfirstname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtfirstname, BunifuAnimatorNS.DecorationType.None)
        Me.txtfirstname.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtfirstname.ForeColor = System.Drawing.Color.White
        Me.txtfirstname.isPassword = False
        Me.txtfirstname.Location = New System.Drawing.Point(151, 83)
        Me.txtfirstname.Margin = New System.Windows.Forms.Padding(4)
        Me.txtfirstname.Name = "txtfirstname"
        Me.txtfirstname.Size = New System.Drawing.Size(189, 30)
        Me.txtfirstname.TabIndex = 119
        Me.txtfirstname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtid
        '
        Me.txtid.BorderColorFocused = System.Drawing.Color.White
        Me.txtid.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtid.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtid.BorderThickness = 1
        Me.txtid.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtid, BunifuAnimatorNS.DecorationType.None)
        Me.txtid.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtid.ForeColor = System.Drawing.Color.White
        Me.txtid.isPassword = False
        Me.txtid.Location = New System.Drawing.Point(151, 46)
        Me.txtid.Margin = New System.Windows.Forms.Padding(4)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(189, 30)
        Me.txtid.TabIndex = 118
        Me.txtid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel69
        '
        Me.BunifuCustomLabel69.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel69, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel69, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel69, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel69.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel69.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel69.Location = New System.Drawing.Point(409, 344)
        Me.BunifuCustomLabel69.Name = "BunifuCustomLabel69"
        Me.BunifuCustomLabel69.Size = New System.Drawing.Size(106, 17)
        Me.BunifuCustomLabel69.TabIndex = 117
        Me.BunifuCustomLabel69.Text = "Admission Date"
        '
        'BunifuCustomLabel68
        '
        Me.BunifuCustomLabel68.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel68, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel68, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel68, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel68.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel68.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel68.Location = New System.Drawing.Point(410, 129)
        Me.BunifuCustomLabel68.Name = "BunifuCustomLabel68"
        Me.BunifuCustomLabel68.Size = New System.Drawing.Size(88, 17)
        Me.BunifuCustomLabel68.TabIndex = 116
        Me.BunifuCustomLabel68.Text = "Blood Group"
        '
        'BunifuCustomLabel64
        '
        Me.BunifuCustomLabel64.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel64, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel64, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel64, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel64.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel64.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel64.Location = New System.Drawing.Point(410, 91)
        Me.BunifuCustomLabel64.Name = "BunifuCustomLabel64"
        Me.BunifuCustomLabel64.Size = New System.Drawing.Size(49, 17)
        Me.BunifuCustomLabel64.TabIndex = 115
        Me.BunifuCustomLabel64.Text = "Height"
        '
        'BunifuCustomLabel63
        '
        Me.BunifuCustomLabel63.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel63, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel63, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel63, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel63.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel63.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel63.Location = New System.Drawing.Point(410, 53)
        Me.BunifuCustomLabel63.Name = "BunifuCustomLabel63"
        Me.BunifuCustomLabel63.Size = New System.Drawing.Size(52, 17)
        Me.BunifuCustomLabel63.TabIndex = 114
        Me.BunifuCustomLabel63.Text = "Weight"
        '
        'BunifuCustomLabel43
        '
        Me.BunifuCustomLabel43.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel43.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel43.Location = New System.Drawing.Point(410, 266)
        Me.BunifuCustomLabel43.Name = "BunifuCustomLabel43"
        Me.BunifuCustomLabel43.Size = New System.Drawing.Size(31, 17)
        Me.BunifuCustomLabel43.TabIndex = 113
        Me.BunifuCustomLabel43.Text = "UID"
        '
        'BunifuCustomLabel42
        '
        Me.BunifuCustomLabel42.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel42.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel42.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel42.Location = New System.Drawing.Point(23, 331)
        Me.BunifuCustomLabel42.Name = "BunifuCustomLabel42"
        Me.BunifuCustomLabel42.Size = New System.Drawing.Size(83, 17)
        Me.BunifuCustomLabel42.TabIndex = 112
        Me.BunifuCustomLabel42.Text = "Mobile No 1"
        '
        'BunifuCustomLabel41
        '
        Me.BunifuCustomLabel41.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel41.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel41.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel41.Location = New System.Drawing.Point(23, 297)
        Me.BunifuCustomLabel41.Name = "BunifuCustomLabel41"
        Me.BunifuCustomLabel41.Size = New System.Drawing.Size(56, 17)
        Me.BunifuCustomLabel41.TabIndex = 111
        Me.BunifuCustomLabel41.Text = "Gender"
        '
        'BunifuCustomLabel40
        '
        Me.BunifuCustomLabel40.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel40.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel40.Location = New System.Drawing.Point(23, 266)
        Me.BunifuCustomLabel40.Name = "BunifuCustomLabel40"
        Me.BunifuCustomLabel40.Size = New System.Drawing.Size(31, 17)
        Me.BunifuCustomLabel40.TabIndex = 110
        Me.BunifuCustomLabel40.Text = "City"
        '
        'BunifuCustomLabel36
        '
        Me.BunifuCustomLabel36.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel36.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel36.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel36.Location = New System.Drawing.Point(23, 232)
        Me.BunifuCustomLabel36.Name = "BunifuCustomLabel36"
        Me.BunifuCustomLabel36.Size = New System.Drawing.Size(60, 17)
        Me.BunifuCustomLabel36.TabIndex = 109
        Me.BunifuCustomLabel36.Text = "Address"
        '
        'BunifuCustomLabel35
        '
        Me.BunifuCustomLabel35.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel35.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel35.Location = New System.Drawing.Point(23, 198)
        Me.BunifuCustomLabel35.Name = "BunifuCustomLabel35"
        Me.BunifuCustomLabel35.Size = New System.Drawing.Size(33, 17)
        Me.BunifuCustomLabel35.TabIndex = 108
        Me.BunifuCustomLabel35.Text = "Age"
        '
        'BunifuCustomLabel34
        '
        Me.BunifuCustomLabel34.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel34.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel34.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel34.Location = New System.Drawing.Point(23, 167)
        Me.BunifuCustomLabel34.Name = "BunifuCustomLabel34"
        Me.BunifuCustomLabel34.Size = New System.Drawing.Size(71, 17)
        Me.BunifuCustomLabel34.TabIndex = 107
        Me.BunifuCustomLabel34.Text = "Full Name"
        '
        'BunifuCustomLabel33
        '
        Me.BunifuCustomLabel33.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel33.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel33.Location = New System.Drawing.Point(23, 129)
        Me.BunifuCustomLabel33.Name = "BunifuCustomLabel33"
        Me.BunifuCustomLabel33.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel33.TabIndex = 106
        Me.BunifuCustomLabel33.Text = "Last Name"
        '
        'BunifuCustomLabel32
        '
        Me.BunifuCustomLabel32.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel32.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel32.Location = New System.Drawing.Point(23, 91)
        Me.BunifuCustomLabel32.Name = "BunifuCustomLabel32"
        Me.BunifuCustomLabel32.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel32.TabIndex = 105
        Me.BunifuCustomLabel32.Text = "First Name"
        '
        'BunifuCustomLabel30
        '
        Me.BunifuCustomLabel30.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel30.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel30.Location = New System.Drawing.Point(23, 53)
        Me.BunifuCustomLabel30.Name = "BunifuCustomLabel30"
        Me.BunifuCustomLabel30.Size = New System.Drawing.Size(67, 17)
        Me.BunifuCustomLabel30.TabIndex = 104
        Me.BunifuCustomLabel30.Text = "Patient Id"
        '
        'BunifuCustomLabel31
        '
        Me.BunifuCustomLabel31.AutoSize = True
        Me.BunifuCustomLabel31.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel31.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel31.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel31.Location = New System.Drawing.Point(3, 4)
        Me.BunifuCustomLabel31.Name = "BunifuCustomLabel31"
        Me.BunifuCustomLabel31.Size = New System.Drawing.Size(123, 23)
        Me.BunifuCustomLabel31.TabIndex = 14
        Me.BunifuCustomLabel31.Text = "Patient Entry"
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage8.Controls.Add(Me.Panel5)
        Me.BunifuTransition3.SetDecoration(Me.TabPage8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage8, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(953, 429)
        Me.TabPage8.TabIndex = 1
        Me.TabPage8.Text = "TabPage8"
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel38)
        Me.BunifuTransition1.SetDecoration(Me.Panel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel5, BunifuAnimatorNS.DecorationType.None)
        Me.Panel5.Location = New System.Drawing.Point(6, 6)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(824, 387)
        Me.Panel5.TabIndex = 0
        '
        'BunifuCustomLabel38
        '
        Me.BunifuCustomLabel38.AutoSize = True
        Me.BunifuCustomLabel38.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel38.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel38.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel38.Location = New System.Drawing.Point(3, 17)
        Me.BunifuCustomLabel38.Name = "BunifuCustomLabel38"
        Me.BunifuCustomLabel38.Size = New System.Drawing.Size(89, 23)
        Me.BunifuCustomLabel38.TabIndex = 15
        Me.BunifuCustomLabel38.Text = "Fees Info"
        '
        'TabPage11
        '
        Me.TabPage11.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage11.Controls.Add(Me.BunifuGradientPanel6)
        Me.TabPage11.Controls.Add(Me.DataGridView1)
        Me.BunifuTransition3.SetDecoration(Me.TabPage11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage11, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage11.Location = New System.Drawing.Point(4, 22)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(953, 429)
        Me.TabPage11.TabIndex = 4
        Me.TabPage11.Text = "TabPage11"
        '
        'DataGridView1
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuTransition3.SetDecoration(Me.DataGridView1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.DataGridView1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.DataGridView1, BunifuAnimatorNS.DecorationType.None)
        Me.DataGridView1.DoubleBuffered = True
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.DataGridView1.HeaderForeColor = System.Drawing.Color.White
        Me.DataGridView1.Location = New System.Drawing.Point(6, 42)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DataGridView1.Size = New System.Drawing.Size(944, 401)
        Me.DataGridView1.TabIndex = 0
        '
        'TabPage17
        '
        Me.TabPage17.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage17.Controls.Add(Me.GroupBox7)
        Me.BunifuTransition3.SetDecoration(Me.TabPage17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage17, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage17.Location = New System.Drawing.Point(4, 22)
        Me.TabPage17.Name = "TabPage17"
        Me.TabPage17.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage17.Size = New System.Drawing.Size(953, 429)
        Me.TabPage17.TabIndex = 5
        Me.TabPage17.Text = "TabPage17"
        '
        'GroupBox7
        '
        Me.BunifuTransition1.SetDecoration(Me.GroupBox7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.GroupBox7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.GroupBox7, BunifuAnimatorNS.DecorationType.None)
        Me.GroupBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.ForeColor = System.Drawing.Color.White
        Me.GroupBox7.Location = New System.Drawing.Point(9, 6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(933, 417)
        Me.GroupBox7.TabIndex = 97
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Report"
        '
        'BunifuCustomLabel29
        '
        Me.BunifuCustomLabel29.AutoSize = True
        Me.BunifuCustomLabel29.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel29.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel29.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel29.Location = New System.Drawing.Point(15, 12)
        Me.BunifuCustomLabel29.Name = "BunifuCustomLabel29"
        Me.BunifuCustomLabel29.Size = New System.Drawing.Size(173, 23)
        Me.BunifuCustomLabel29.TabIndex = 11
        Me.BunifuCustomLabel29.Text = "Patient Admission"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.Panel16)
        Me.TabPage3.Controls.Add(Me.Panel7)
        Me.TabPage3.Controls.Add(Me.Panel6)
        Me.TabPage3.Controls.Add(Me.TabControl3)
        Me.BunifuTransition3.SetDecoration(Me.TabPage3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage3, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(957, 606)
        Me.TabPage3.TabIndex = 6
        Me.TabPage3.Text = "TabPage3"
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.BunifuThinButton227)
        Me.Panel16.Controls.Add(Me.BunifuThinButton228)
        Me.Panel16.Controls.Add(Me.BunifuThinButton229)
        Me.Panel16.Controls.Add(Me.BunifuThinButton230)
        Me.Panel16.Controls.Add(Me.BunifuThinButton231)
        Me.Panel16.Controls.Add(Me.BunifuThinButton232)
        Me.Panel16.Controls.Add(Me.BunifuThinButton233)
        Me.Panel16.Controls.Add(Me.BunifuThinButton234)
        Me.Panel16.Controls.Add(Me.BunifuThinButton235)
        Me.Panel16.Controls.Add(Me.BunifuThinButton236)
        Me.Panel16.Controls.Add(Me.BunifuThinButton237)
        Me.Panel16.Controls.Add(Me.BunifuThinButton238)
        Me.BunifuTransition1.SetDecoration(Me.Panel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel16, BunifuAnimatorNS.DecorationType.None)
        Me.Panel16.Location = New System.Drawing.Point(6, 545)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(947, 49)
        Me.Panel16.TabIndex = 37
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.BunifuFlatButton18)
        Me.Panel7.Controls.Add(Me.BunifuFlatButton17)
        Me.Panel7.Controls.Add(Me.BunifuThinButton224)
        Me.Panel7.Controls.Add(Me.BunifuThinButton216)
        Me.Panel7.Controls.Add(Me.BunifuFlatButton14)
        Me.Panel7.Controls.Add(Me.BunifuFlatButton16)
        Me.Panel7.Controls.Add(Me.BunifuFlatButton9)
        Me.Panel7.Controls.Add(Me.BunifuThinButton222)
        Me.Panel7.Controls.Add(Me.BunifuFlatButton15)
        Me.Panel7.Controls.Add(Me.BunifuThinButton226)
        Me.Panel7.Controls.Add(Me.BunifuThinButton220)
        Me.Panel7.Controls.Add(Me.BunifuThinButton218)
        Me.BunifuTransition1.SetDecoration(Me.Panel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel7, BunifuAnimatorNS.DecorationType.None)
        Me.Panel7.Location = New System.Drawing.Point(-1, 45)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(948, 52)
        Me.Panel7.TabIndex = 14
        Me.Panel7.Visible = False
        '
        'Panel6
        '
        Me.BunifuTransition1.SetDecoration(Me.Panel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel6, BunifuAnimatorNS.DecorationType.None)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel6.Location = New System.Drawing.Point(3, 3)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(951, 40)
        Me.Panel6.TabIndex = 0
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage9)
        Me.TabControl3.Controls.Add(Me.TabPage10)
        Me.TabControl3.Controls.Add(Me.TabPage12)
        Me.TabControl3.Controls.Add(Me.TabPage13)
        Me.TabControl3.Controls.Add(Me.TabPage14)
        Me.TabControl3.Controls.Add(Me.TabPage16)
        Me.TabControl3.Controls.Add(Me.TabPage15)
        Me.BunifuTransition1.SetDecoration(Me.TabControl3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabControl3, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl3.Location = New System.Drawing.Point(-4, 94)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(958, 460)
        Me.TabControl3.TabIndex = 15
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition3.SetDecoration(Me.TabPage9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage9, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(950, 434)
        Me.TabPage9.TabIndex = 0
        Me.TabPage9.Text = "TabPage9"
        '
        'TabPage10
        '
        Me.TabPage10.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage10.Controls.Add(Me.Panel9)
        Me.BunifuTransition3.SetDecoration(Me.TabPage10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage10, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(950, 434)
        Me.TabPage10.TabIndex = 1
        Me.TabPage10.Text = "TabPage10"
        '
        'Panel9
        '
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel9.Controls.Add(Me.BunifuDropdown22)
        Me.Panel9.Controls.Add(Me.BunifuCustomLabel99)
        Me.Panel9.Controls.Add(Me.BunifuDropdown21)
        Me.Panel9.Controls.Add(Me.BunifuCustomLabel98)
        Me.Panel9.Controls.Add(Me.BunifuCustomLabel97)
        Me.Panel9.Controls.Add(Me.BunifuMetroTextbox21)
        Me.Panel9.Controls.Add(Me.BunifuCustomLabel93)
        Me.Panel9.Controls.Add(Me.BunifuCustomLabel94)
        Me.Panel9.Controls.Add(Me.BunifuCustomLabel95)
        Me.Panel9.Controls.Add(Me.BunifuDropdown18)
        Me.Panel9.Controls.Add(Me.BunifuDropdown19)
        Me.Panel9.Controls.Add(Me.BunifuDropdown20)
        Me.Panel9.Controls.Add(Me.BunifuCustomLabel96)
        Me.Panel9.Controls.Add(Me.BunifuDropdown17)
        Me.Panel9.Controls.Add(Me.BunifuCustomLabel92)
        Me.Panel9.Controls.Add(Me.BunifuCustomLabel59)
        Me.BunifuTransition1.SetDecoration(Me.Panel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel9, BunifuAnimatorNS.DecorationType.None)
        Me.Panel9.Location = New System.Drawing.Point(6, 9)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(903, 427)
        Me.Panel9.TabIndex = 1
        '
        'BunifuDropdown22
        '
        Me.BunifuDropdown22.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown22.BorderRadius = 3
        Me.BunifuDropdown22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown22.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown22.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown22.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown22.Location = New System.Drawing.Point(150, 265)
        Me.BunifuDropdown22.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown22.Name = "BunifuDropdown22"
        Me.BunifuDropdown22.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown22.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown22.selectedIndex = -1
        Me.BunifuDropdown22.Size = New System.Drawing.Size(225, 30)
        Me.BunifuDropdown22.TabIndex = 91
        '
        'BunifuCustomLabel99
        '
        Me.BunifuCustomLabel99.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel99, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel99, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel99, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel99.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel99.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel99.Location = New System.Drawing.Point(17, 266)
        Me.BunifuCustomLabel99.Name = "BunifuCustomLabel99"
        Me.BunifuCustomLabel99.Size = New System.Drawing.Size(122, 34)
        Me.BunifuCustomLabel99.TabIndex = 90
        Me.BunifuCustomLabel99.Text = "Have you applied " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "here before ?"
        '
        'BunifuDropdown21
        '
        Me.BunifuDropdown21.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown21.BorderRadius = 3
        Me.BunifuDropdown21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown21.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown21.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown21.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown21.Location = New System.Drawing.Point(149, 210)
        Me.BunifuDropdown21.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown21.Name = "BunifuDropdown21"
        Me.BunifuDropdown21.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown21.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown21.selectedIndex = -1
        Me.BunifuDropdown21.Size = New System.Drawing.Size(226, 30)
        Me.BunifuDropdown21.TabIndex = 89
        '
        'BunifuCustomLabel98
        '
        Me.BunifuCustomLabel98.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel98, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel98, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel98, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel98.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel98.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel98.Location = New System.Drawing.Point(16, 209)
        Me.BunifuCustomLabel98.Name = "BunifuCustomLabel98"
        Me.BunifuCustomLabel98.Size = New System.Drawing.Size(123, 34)
        Me.BunifuCustomLabel98.TabIndex = 88
        Me.BunifuCustomLabel98.Text = "Have a work here " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "before ?"
        '
        'BunifuCustomLabel97
        '
        Me.BunifuCustomLabel97.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel97, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel97, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel97, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel97.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel97.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel97.Location = New System.Drawing.Point(13, 163)
        Me.BunifuCustomLabel97.Name = "BunifuCustomLabel97"
        Me.BunifuCustomLabel97.Size = New System.Drawing.Size(133, 17)
        Me.BunifuCustomLabel97.TabIndex = 86
        Me.BunifuCustomLabel97.Text = "Date Salary desired"
        '
        'BunifuMetroTextbox21
        '
        Me.BunifuMetroTextbox21.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox21.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox21.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox21.BorderThickness = 1
        Me.BunifuMetroTextbox21.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox21.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.BunifuMetroTextbox21.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox21.isPassword = False
        Me.BunifuMetroTextbox21.Location = New System.Drawing.Point(149, 157)
        Me.BunifuMetroTextbox21.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox21.Name = "BunifuMetroTextbox21"
        Me.BunifuMetroTextbox21.Size = New System.Drawing.Size(226, 28)
        Me.BunifuMetroTextbox21.TabIndex = 85
        Me.BunifuMetroTextbox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel93
        '
        Me.BunifuCustomLabel93.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel93, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel93, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel93, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel93.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel93.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel93.Location = New System.Drawing.Point(441, 85)
        Me.BunifuCustomLabel93.Name = "BunifuCustomLabel93"
        Me.BunifuCustomLabel93.Size = New System.Drawing.Size(38, 17)
        Me.BunifuCustomLabel93.TabIndex = 84
        Me.BunifuCustomLabel93.Text = "Year"
        '
        'BunifuCustomLabel94
        '
        Me.BunifuCustomLabel94.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel94, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel94, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel94, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel94.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel94.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel94.Location = New System.Drawing.Point(305, 85)
        Me.BunifuCustomLabel94.Name = "BunifuCustomLabel94"
        Me.BunifuCustomLabel94.Size = New System.Drawing.Size(47, 17)
        Me.BunifuCustomLabel94.TabIndex = 83
        Me.BunifuCustomLabel94.Text = "Month"
        '
        'BunifuCustomLabel95
        '
        Me.BunifuCustomLabel95.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel95, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel95, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel95, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel95.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel95.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel95.Location = New System.Drawing.Point(180, 85)
        Me.BunifuCustomLabel95.Name = "BunifuCustomLabel95"
        Me.BunifuCustomLabel95.Size = New System.Drawing.Size(33, 17)
        Me.BunifuCustomLabel95.TabIndex = 82
        Me.BunifuCustomLabel95.Text = "Day"
        '
        'BunifuDropdown18
        '
        Me.BunifuDropdown18.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown18.BorderRadius = 3
        Me.BunifuDropdown18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown18.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown18.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown18.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown18.Location = New System.Drawing.Point(413, 105)
        Me.BunifuDropdown18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown18.Name = "BunifuDropdown18"
        Me.BunifuDropdown18.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown18.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown18.selectedIndex = -1
        Me.BunifuDropdown18.Size = New System.Drawing.Size(94, 30)
        Me.BunifuDropdown18.TabIndex = 81
        '
        'BunifuDropdown19
        '
        Me.BunifuDropdown19.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown19.BorderRadius = 3
        Me.BunifuDropdown19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown19.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown19.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown19.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown19.Location = New System.Drawing.Point(281, 105)
        Me.BunifuDropdown19.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown19.Name = "BunifuDropdown19"
        Me.BunifuDropdown19.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown19.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown19.selectedIndex = -1
        Me.BunifuDropdown19.Size = New System.Drawing.Size(94, 30)
        Me.BunifuDropdown19.TabIndex = 80
        '
        'BunifuDropdown20
        '
        Me.BunifuDropdown20.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown20.BorderRadius = 3
        Me.BunifuDropdown20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown20.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown20.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown20.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown20.Location = New System.Drawing.Point(149, 105)
        Me.BunifuDropdown20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown20.Name = "BunifuDropdown20"
        Me.BunifuDropdown20.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown20.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown20.selectedIndex = -1
        Me.BunifuDropdown20.Size = New System.Drawing.Size(94, 30)
        Me.BunifuDropdown20.TabIndex = 79
        '
        'BunifuCustomLabel96
        '
        Me.BunifuCustomLabel96.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel96, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel96, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel96, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel96.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel96.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel96.Location = New System.Drawing.Point(12, 112)
        Me.BunifuCustomLabel96.Name = "BunifuCustomLabel96"
        Me.BunifuCustomLabel96.Size = New System.Drawing.Size(124, 17)
        Me.BunifuCustomLabel96.TabIndex = 78
        Me.BunifuCustomLabel96.Text = "Date you can start"
        '
        'BunifuDropdown17
        '
        Me.BunifuDropdown17.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown17.BorderRadius = 3
        Me.BunifuDropdown17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown17.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown17.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown17.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown17.Location = New System.Drawing.Point(150, 46)
        Me.BunifuDropdown17.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown17.Name = "BunifuDropdown17"
        Me.BunifuDropdown17.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown17.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown17.selectedIndex = -1
        Me.BunifuDropdown17.Size = New System.Drawing.Size(225, 30)
        Me.BunifuDropdown17.TabIndex = 74
        '
        'BunifuCustomLabel92
        '
        Me.BunifuCustomLabel92.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel92, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel92, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel92, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel92.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel92.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel92.Location = New System.Drawing.Point(13, 53)
        Me.BunifuCustomLabel92.Name = "BunifuCustomLabel92"
        Me.BunifuCustomLabel92.Size = New System.Drawing.Size(134, 17)
        Me.BunifuCustomLabel92.TabIndex = 73
        Me.BunifuCustomLabel92.Text = "Position Appling For"
        '
        'BunifuCustomLabel59
        '
        Me.BunifuCustomLabel59.AutoSize = True
        Me.BunifuCustomLabel59.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel59, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel59, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel59, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel59.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel59.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel59.Location = New System.Drawing.Point(3, 6)
        Me.BunifuCustomLabel59.Name = "BunifuCustomLabel59"
        Me.BunifuCustomLabel59.Size = New System.Drawing.Size(200, 23)
        Me.BunifuCustomLabel59.TabIndex = 16
        Me.BunifuCustomLabel59.Text = "Employment Desired"
        '
        'TabPage12
        '
        Me.TabPage12.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage12.Controls.Add(Me.Panel10)
        Me.BunifuTransition3.SetDecoration(Me.TabPage12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage12, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage12.Location = New System.Drawing.Point(4, 22)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage12.Size = New System.Drawing.Size(950, 434)
        Me.TabPage12.TabIndex = 2
        Me.TabPage12.Text = "TabPage12"
        '
        'Panel10
        '
        Me.Panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel10.Controls.Add(Me.GroupBox3)
        Me.Panel10.Controls.Add(Me.GroupBox2)
        Me.Panel10.Controls.Add(Me.GroupBox1)
        Me.Panel10.Controls.Add(Me.BunifuCustomLabel60)
        Me.BunifuTransition1.SetDecoration(Me.Panel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel10, BunifuAnimatorNS.DecorationType.None)
        Me.Panel10.Location = New System.Drawing.Point(6, 9)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(903, 466)
        Me.Panel10.TabIndex = 1
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.BunifuMetroTextbox33)
        Me.GroupBox3.Controls.Add(Me.BunifuCustomLabel110)
        Me.GroupBox3.Controls.Add(Me.BunifuCustomLabel105)
        Me.GroupBox3.Controls.Add(Me.BunifuMetroTextbox31)
        Me.GroupBox3.Controls.Add(Me.BunifuCustomLabel108)
        Me.GroupBox3.Controls.Add(Me.BunifuMetroTextbox32)
        Me.GroupBox3.Controls.Add(Me.BunifuCustomLabel109)
        Me.GroupBox3.Controls.Add(Me.BunifuDropdown25)
        Me.BunifuTransition1.SetDecoration(Me.GroupBox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.GroupBox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.GroupBox3, BunifuAnimatorNS.DecorationType.None)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.White
        Me.GroupBox3.Location = New System.Drawing.Point(15, 270)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(873, 146)
        Me.GroupBox3.TabIndex = 103
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Graduate school "
        '
        'BunifuMetroTextbox33
        '
        Me.BunifuMetroTextbox33.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox33.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox33.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox33.BorderThickness = 1
        Me.BunifuMetroTextbox33.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox33.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.BunifuMetroTextbox33.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox33.isPassword = False
        Me.BunifuMetroTextbox33.Location = New System.Drawing.Point(123, 91)
        Me.BunifuMetroTextbox33.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox33.Name = "BunifuMetroTextbox33"
        Me.BunifuMetroTextbox33.Size = New System.Drawing.Size(226, 28)
        Me.BunifuMetroTextbox33.TabIndex = 103
        Me.BunifuMetroTextbox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel110
        '
        Me.BunifuCustomLabel110.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel110, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel110, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel110, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel110.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel110.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel110.Location = New System.Drawing.Point(158, 70)
        Me.BunifuCustomLabel110.Name = "BunifuCustomLabel110"
        Me.BunifuCustomLabel110.Size = New System.Drawing.Size(157, 17)
        Me.BunifuCustomLabel110.TabIndex = 104
        Me.BunifuCustomLabel110.Text = "Area of Study / Degree "
        '
        'BunifuCustomLabel105
        '
        Me.BunifuCustomLabel105.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel105, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel105, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel105, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel105.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel105.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel105.Location = New System.Drawing.Point(441, 12)
        Me.BunifuCustomLabel105.Name = "BunifuCustomLabel105"
        Me.BunifuCustomLabel105.Size = New System.Drawing.Size(169, 17)
        Me.BunifuCustomLabel105.TabIndex = 91
        Me.BunifuCustomLabel105.Text = "Number of Year Attended"
        '
        'BunifuMetroTextbox31
        '
        Me.BunifuMetroTextbox31.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox31.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox31.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox31.BorderThickness = 1
        Me.BunifuMetroTextbox31.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox31.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.BunifuMetroTextbox31.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox31.isPassword = False
        Me.BunifuMetroTextbox31.Location = New System.Drawing.Point(123, 33)
        Me.BunifuMetroTextbox31.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox31.Name = "BunifuMetroTextbox31"
        Me.BunifuMetroTextbox31.Size = New System.Drawing.Size(226, 28)
        Me.BunifuMetroTextbox31.TabIndex = 87
        Me.BunifuMetroTextbox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel108
        '
        Me.BunifuCustomLabel108.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel108, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel108, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel108, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel108.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel108.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel108.Location = New System.Drawing.Point(122, 12)
        Me.BunifuCustomLabel108.Name = "BunifuCustomLabel108"
        Me.BunifuCustomLabel108.Size = New System.Drawing.Size(233, 17)
        Me.BunifuCustomLabel108.TabIndex = 89
        Me.BunifuCustomLabel108.Text = "Name of Graduate School Attended"
        '
        'BunifuMetroTextbox32
        '
        Me.BunifuMetroTextbox32.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox32.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox32.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox32.BorderThickness = 1
        Me.BunifuMetroTextbox32.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox32.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.BunifuMetroTextbox32.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox32.isPassword = False
        Me.BunifuMetroTextbox32.Location = New System.Drawing.Point(407, 33)
        Me.BunifuMetroTextbox32.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox32.Name = "BunifuMetroTextbox32"
        Me.BunifuMetroTextbox32.Size = New System.Drawing.Size(226, 28)
        Me.BunifuMetroTextbox32.TabIndex = 90
        Me.BunifuMetroTextbox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel109
        '
        Me.BunifuCustomLabel109.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel109, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel109, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel109, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel109.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel109.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel109.Location = New System.Drawing.Point(718, 12)
        Me.BunifuCustomLabel109.Name = "BunifuCustomLabel109"
        Me.BunifuCustomLabel109.Size = New System.Drawing.Size(88, 17)
        Me.BunifuCustomLabel109.TabIndex = 92
        Me.BunifuCustomLabel109.Text = "Graduated ?"
        '
        'BunifuDropdown25
        '
        Me.BunifuDropdown25.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown25.BorderRadius = 3
        Me.BunifuDropdown25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown25.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown25.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown25.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown25.Location = New System.Drawing.Point(689, 32)
        Me.BunifuDropdown25.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown25.Name = "BunifuDropdown25"
        Me.BunifuDropdown25.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown25.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown25.selectedIndex = -1
        Me.BunifuDropdown25.Size = New System.Drawing.Size(147, 30)
        Me.BunifuDropdown25.TabIndex = 93
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.BunifuDropdown24)
        Me.GroupBox2.Controls.Add(Me.BunifuMetroTextbox30)
        Me.GroupBox2.Controls.Add(Me.BunifuCustomLabel100)
        Me.GroupBox2.Controls.Add(Me.BunifuCustomLabel107)
        Me.GroupBox2.Controls.Add(Me.BunifuMetroTextbox24)
        Me.GroupBox2.Controls.Add(Me.BunifuCustomLabel104)
        Me.GroupBox2.Controls.Add(Me.BunifuMetroTextbox29)
        Me.GroupBox2.Controls.Add(Me.BunifuCustomLabel106)
        Me.BunifuTransition1.SetDecoration(Me.GroupBox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.GroupBox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.GroupBox2, BunifuAnimatorNS.DecorationType.None)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(15, 117)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(873, 146)
        Me.GroupBox2.TabIndex = 102
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "College"
        '
        'BunifuDropdown24
        '
        Me.BunifuDropdown24.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown24.BorderRadius = 3
        Me.BunifuDropdown24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown24.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown24.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown24.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown24.Location = New System.Drawing.Point(689, 32)
        Me.BunifuDropdown24.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown24.Name = "BunifuDropdown24"
        Me.BunifuDropdown24.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown24.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown24.selectedIndex = -1
        Me.BunifuDropdown24.Size = New System.Drawing.Size(147, 30)
        Me.BunifuDropdown24.TabIndex = 103
        '
        'BunifuMetroTextbox30
        '
        Me.BunifuMetroTextbox30.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox30.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox30.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox30.BorderThickness = 1
        Me.BunifuMetroTextbox30.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox30.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.BunifuMetroTextbox30.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox30.isPassword = False
        Me.BunifuMetroTextbox30.Location = New System.Drawing.Point(123, 91)
        Me.BunifuMetroTextbox30.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox30.Name = "BunifuMetroTextbox30"
        Me.BunifuMetroTextbox30.Size = New System.Drawing.Size(226, 28)
        Me.BunifuMetroTextbox30.TabIndex = 101
        Me.BunifuMetroTextbox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel100
        '
        Me.BunifuCustomLabel100.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel100, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel100, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel100, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel100.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel100.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel100.Location = New System.Drawing.Point(158, 70)
        Me.BunifuCustomLabel100.Name = "BunifuCustomLabel100"
        Me.BunifuCustomLabel100.Size = New System.Drawing.Size(157, 17)
        Me.BunifuCustomLabel100.TabIndex = 102
        Me.BunifuCustomLabel100.Text = "Area of Study / Degree "
        '
        'BunifuCustomLabel107
        '
        Me.BunifuCustomLabel107.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel107, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel107, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel107, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel107.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel107.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel107.Location = New System.Drawing.Point(718, 12)
        Me.BunifuCustomLabel107.Name = "BunifuCustomLabel107"
        Me.BunifuCustomLabel107.Size = New System.Drawing.Size(88, 17)
        Me.BunifuCustomLabel107.TabIndex = 99
        Me.BunifuCustomLabel107.Text = "Graduated ?"
        '
        'BunifuMetroTextbox24
        '
        Me.BunifuMetroTextbox24.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox24.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox24.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox24.BorderThickness = 1
        Me.BunifuMetroTextbox24.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox24.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.BunifuMetroTextbox24.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox24.isPassword = False
        Me.BunifuMetroTextbox24.Location = New System.Drawing.Point(123, 33)
        Me.BunifuMetroTextbox24.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox24.Name = "BunifuMetroTextbox24"
        Me.BunifuMetroTextbox24.Size = New System.Drawing.Size(226, 28)
        Me.BunifuMetroTextbox24.TabIndex = 94
        Me.BunifuMetroTextbox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel104
        '
        Me.BunifuCustomLabel104.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel104, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel104, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel104, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel104.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel104.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel104.Location = New System.Drawing.Point(120, 12)
        Me.BunifuCustomLabel104.Name = "BunifuCustomLabel104"
        Me.BunifuCustomLabel104.Size = New System.Drawing.Size(239, 17)
        Me.BunifuCustomLabel104.TabIndex = 96
        Me.BunifuCustomLabel104.Text = "Name of College/University Attended"
        '
        'BunifuMetroTextbox29
        '
        Me.BunifuMetroTextbox29.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox29.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox29.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox29.BorderThickness = 1
        Me.BunifuMetroTextbox29.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox29.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.BunifuMetroTextbox29.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox29.isPassword = False
        Me.BunifuMetroTextbox29.Location = New System.Drawing.Point(407, 33)
        Me.BunifuMetroTextbox29.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox29.Name = "BunifuMetroTextbox29"
        Me.BunifuMetroTextbox29.Size = New System.Drawing.Size(226, 28)
        Me.BunifuMetroTextbox29.TabIndex = 97
        Me.BunifuMetroTextbox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel106
        '
        Me.BunifuCustomLabel106.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel106, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel106, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel106, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel106.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel106.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel106.Location = New System.Drawing.Point(441, 12)
        Me.BunifuCustomLabel106.Name = "BunifuCustomLabel106"
        Me.BunifuCustomLabel106.Size = New System.Drawing.Size(169, 17)
        Me.BunifuCustomLabel106.TabIndex = 98
        Me.BunifuCustomLabel106.Text = "Number of Year Attended"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BunifuCustomLabel102)
        Me.GroupBox1.Controls.Add(Me.BunifuMetroTextbox22)
        Me.GroupBox1.Controls.Add(Me.BunifuCustomLabel101)
        Me.GroupBox1.Controls.Add(Me.BunifuMetroTextbox23)
        Me.GroupBox1.Controls.Add(Me.BunifuCustomLabel103)
        Me.GroupBox1.Controls.Add(Me.BunifuDropdown23)
        Me.BunifuTransition1.SetDecoration(Me.GroupBox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.GroupBox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.GroupBox1, BunifuAnimatorNS.DecorationType.None)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(15, 33)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(873, 75)
        Me.GroupBox1.TabIndex = 101
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "High School"
        '
        'BunifuCustomLabel102
        '
        Me.BunifuCustomLabel102.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel102, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel102, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel102, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel102.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel102.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel102.Location = New System.Drawing.Point(441, 12)
        Me.BunifuCustomLabel102.Name = "BunifuCustomLabel102"
        Me.BunifuCustomLabel102.Size = New System.Drawing.Size(169, 17)
        Me.BunifuCustomLabel102.TabIndex = 91
        Me.BunifuCustomLabel102.Text = "Number of Year Attended"
        '
        'BunifuMetroTextbox22
        '
        Me.BunifuMetroTextbox22.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox22.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox22.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox22.BorderThickness = 1
        Me.BunifuMetroTextbox22.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox22.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.BunifuMetroTextbox22.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox22.isPassword = False
        Me.BunifuMetroTextbox22.Location = New System.Drawing.Point(123, 33)
        Me.BunifuMetroTextbox22.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox22.Name = "BunifuMetroTextbox22"
        Me.BunifuMetroTextbox22.Size = New System.Drawing.Size(226, 28)
        Me.BunifuMetroTextbox22.TabIndex = 87
        Me.BunifuMetroTextbox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel101
        '
        Me.BunifuCustomLabel101.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel101, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel101, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel101, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel101.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel101.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel101.Location = New System.Drawing.Point(140, 12)
        Me.BunifuCustomLabel101.Name = "BunifuCustomLabel101"
        Me.BunifuCustomLabel101.Size = New System.Drawing.Size(202, 17)
        Me.BunifuCustomLabel101.TabIndex = 89
        Me.BunifuCustomLabel101.Text = "Name of High School Attended"
        '
        'BunifuMetroTextbox23
        '
        Me.BunifuMetroTextbox23.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox23.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox23.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox23.BorderThickness = 1
        Me.BunifuMetroTextbox23.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox23.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.BunifuMetroTextbox23.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox23.isPassword = False
        Me.BunifuMetroTextbox23.Location = New System.Drawing.Point(407, 33)
        Me.BunifuMetroTextbox23.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox23.Name = "BunifuMetroTextbox23"
        Me.BunifuMetroTextbox23.Size = New System.Drawing.Size(226, 28)
        Me.BunifuMetroTextbox23.TabIndex = 90
        Me.BunifuMetroTextbox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel103
        '
        Me.BunifuCustomLabel103.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel103, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel103, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel103, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel103.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel103.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel103.Location = New System.Drawing.Point(718, 12)
        Me.BunifuCustomLabel103.Name = "BunifuCustomLabel103"
        Me.BunifuCustomLabel103.Size = New System.Drawing.Size(88, 17)
        Me.BunifuCustomLabel103.TabIndex = 92
        Me.BunifuCustomLabel103.Text = "Graduated ?"
        '
        'BunifuDropdown23
        '
        Me.BunifuDropdown23.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown23.BorderRadius = 3
        Me.BunifuDropdown23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown23.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown23.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown23.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown23.Location = New System.Drawing.Point(689, 32)
        Me.BunifuDropdown23.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown23.Name = "BunifuDropdown23"
        Me.BunifuDropdown23.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown23.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown23.selectedIndex = -1
        Me.BunifuDropdown23.Size = New System.Drawing.Size(147, 30)
        Me.BunifuDropdown23.TabIndex = 93
        '
        'BunifuCustomLabel60
        '
        Me.BunifuCustomLabel60.AutoSize = True
        Me.BunifuCustomLabel60.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel60, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel60, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel60, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel60.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel60.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel60.Location = New System.Drawing.Point(3, 6)
        Me.BunifuCustomLabel60.Name = "BunifuCustomLabel60"
        Me.BunifuCustomLabel60.Size = New System.Drawing.Size(103, 23)
        Me.BunifuCustomLabel60.TabIndex = 16
        Me.BunifuCustomLabel60.Text = "Education"
        '
        'TabPage13
        '
        Me.TabPage13.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage13.Controls.Add(Me.Panel11)
        Me.BunifuTransition3.SetDecoration(Me.TabPage13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage13, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage13.Location = New System.Drawing.Point(4, 22)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage13.Size = New System.Drawing.Size(950, 434)
        Me.TabPage13.TabIndex = 3
        Me.TabPage13.Text = "TabPage13"
        '
        'Panel11
        '
        Me.Panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel11.Controls.Add(Me.GroupBox4)
        Me.Panel11.Controls.Add(Me.BunifuCustomLabel114)
        Me.Panel11.Controls.Add(Me.BunifuCustomLabel113)
        Me.Panel11.Controls.Add(Me.BunifuCustomTextbox3)
        Me.Panel11.Controls.Add(Me.BunifuCustomLabel112)
        Me.Panel11.Controls.Add(Me.BunifuCustomLabel111)
        Me.Panel11.Controls.Add(Me.BunifuCustomTextbox2)
        Me.Panel11.Controls.Add(Me.BunifuCustomLabel61)
        Me.BunifuTransition1.SetDecoration(Me.Panel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel11, BunifuAnimatorNS.DecorationType.None)
        Me.Panel11.Location = New System.Drawing.Point(6, 9)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(917, 427)
        Me.Panel11.TabIndex = 1
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.BunifuDropdown28)
        Me.GroupBox4.Controls.Add(Me.BunifuDropdown27)
        Me.GroupBox4.Controls.Add(Me.BunifuDropdown26)
        Me.GroupBox4.Controls.Add(Me.BunifuCustomLabel121)
        Me.GroupBox4.Controls.Add(Me.BunifuCustomLabel122)
        Me.GroupBox4.Controls.Add(Me.BunifuCustomLabel123)
        Me.GroupBox4.Controls.Add(Me.BunifuCustomLabel120)
        Me.GroupBox4.Controls.Add(Me.BunifuMetroTextbox37)
        Me.GroupBox4.Controls.Add(Me.BunifuCustomLabel119)
        Me.GroupBox4.Controls.Add(Me.BunifuMetroTextbox36)
        Me.GroupBox4.Controls.Add(Me.BunifuCustomLabel118)
        Me.GroupBox4.Controls.Add(Me.BunifuCustomLabel117)
        Me.GroupBox4.Controls.Add(Me.BunifuMetroTextbox35)
        Me.GroupBox4.Controls.Add(Me.BunifuCustomLabel116)
        Me.GroupBox4.Controls.Add(Me.BunifuMetroTextbox34)
        Me.GroupBox4.Controls.Add(Me.BunifuCustomLabel115)
        Me.BunifuTransition1.SetDecoration(Me.GroupBox4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.GroupBox4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.GroupBox4, BunifuAnimatorNS.DecorationType.None)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.White
        Me.GroupBox4.Location = New System.Drawing.Point(67, 216)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(840, 191)
        Me.GroupBox4.TabIndex = 95
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Current Employment:"
        '
        'BunifuDropdown28
        '
        Me.BunifuDropdown28.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown28.BorderRadius = 3
        Me.BunifuDropdown28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown28.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown28.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown28.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown28.Location = New System.Drawing.Point(285, 153)
        Me.BunifuDropdown28.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown28.Name = "BunifuDropdown28"
        Me.BunifuDropdown28.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown28.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown28.selectedIndex = -1
        Me.BunifuDropdown28.Size = New System.Drawing.Size(74, 30)
        Me.BunifuDropdown28.TabIndex = 106
        '
        'BunifuDropdown27
        '
        Me.BunifuDropdown27.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown27.BorderRadius = 3
        Me.BunifuDropdown27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown27.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown27.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown27.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown27.Location = New System.Drawing.Point(187, 153)
        Me.BunifuDropdown27.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown27.Name = "BunifuDropdown27"
        Me.BunifuDropdown27.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown27.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown27.selectedIndex = -1
        Me.BunifuDropdown27.Size = New System.Drawing.Size(74, 30)
        Me.BunifuDropdown27.TabIndex = 105
        '
        'BunifuDropdown26
        '
        Me.BunifuDropdown26.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown26.BorderRadius = 3
        Me.BunifuDropdown26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown26.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown26.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown26.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown26.Location = New System.Drawing.Point(91, 153)
        Me.BunifuDropdown26.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown26.Name = "BunifuDropdown26"
        Me.BunifuDropdown26.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown26.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown26.selectedIndex = -1
        Me.BunifuDropdown26.Size = New System.Drawing.Size(74, 30)
        Me.BunifuDropdown26.TabIndex = 104
        '
        'BunifuCustomLabel121
        '
        Me.BunifuCustomLabel121.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel121, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel121, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel121, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel121.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel121.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel121.Location = New System.Drawing.Point(303, 120)
        Me.BunifuCustomLabel121.Name = "BunifuCustomLabel121"
        Me.BunifuCustomLabel121.Size = New System.Drawing.Size(38, 17)
        Me.BunifuCustomLabel121.TabIndex = 90
        Me.BunifuCustomLabel121.Text = "Year"
        '
        'BunifuCustomLabel122
        '
        Me.BunifuCustomLabel122.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel122, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel122, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel122, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel122.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel122.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel122.Location = New System.Drawing.Point(203, 120)
        Me.BunifuCustomLabel122.Name = "BunifuCustomLabel122"
        Me.BunifuCustomLabel122.Size = New System.Drawing.Size(47, 17)
        Me.BunifuCustomLabel122.TabIndex = 89
        Me.BunifuCustomLabel122.Text = "Month"
        '
        'BunifuCustomLabel123
        '
        Me.BunifuCustomLabel123.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel123, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel123, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel123, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel123.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel123.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel123.Location = New System.Drawing.Point(114, 120)
        Me.BunifuCustomLabel123.Name = "BunifuCustomLabel123"
        Me.BunifuCustomLabel123.Size = New System.Drawing.Size(33, 17)
        Me.BunifuCustomLabel123.TabIndex = 88
        Me.BunifuCustomLabel123.Text = "Day"
        '
        'BunifuCustomLabel120
        '
        Me.BunifuCustomLabel120.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel120, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel120, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel120, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel120.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel120.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel120.Location = New System.Drawing.Point(12, 152)
        Me.BunifuCustomLabel120.Name = "BunifuCustomLabel120"
        Me.BunifuCustomLabel120.Size = New System.Drawing.Size(72, 17)
        Me.BunifuCustomLabel120.TabIndex = 31
        Me.BunifuCustomLabel120.Text = "Start Date"
        '
        'BunifuMetroTextbox37
        '
        Me.BunifuMetroTextbox37.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox37.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox37.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox37.BorderThickness = 1
        Me.BunifuMetroTextbox37.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox37, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox37.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox37.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox37.isPassword = False
        Me.BunifuMetroTextbox37.Location = New System.Drawing.Point(560, 84)
        Me.BunifuMetroTextbox37.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox37.Name = "BunifuMetroTextbox37"
        Me.BunifuMetroTextbox37.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox37.TabIndex = 30
        Me.BunifuMetroTextbox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel119
        '
        Me.BunifuCustomLabel119.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel119, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel119, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel119, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel119.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel119.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel119.Location = New System.Drawing.Point(466, 82)
        Me.BunifuCustomLabel119.Name = "BunifuCustomLabel119"
        Me.BunifuCustomLabel119.Size = New System.Drawing.Size(73, 34)
        Me.BunifuCustomLabel119.TabIndex = 29
        Me.BunifuCustomLabel119.Text = "Reason of" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Leaving?"
        '
        'BunifuMetroTextbox36
        '
        Me.BunifuMetroTextbox36.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox36.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox36.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox36.BorderThickness = 1
        Me.BunifuMetroTextbox36.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox36.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox36.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox36.isPassword = False
        Me.BunifuMetroTextbox36.Location = New System.Drawing.Point(91, 84)
        Me.BunifuMetroTextbox36.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox36.Name = "BunifuMetroTextbox36"
        Me.BunifuMetroTextbox36.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox36.TabIndex = 28
        Me.BunifuMetroTextbox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel118
        '
        Me.BunifuCustomLabel118.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel118, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel118, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel118, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel118.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel118.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel118.Location = New System.Drawing.Point(12, 91)
        Me.BunifuCustomLabel118.Name = "BunifuCustomLabel118"
        Me.BunifuCustomLabel118.Size = New System.Drawing.Size(48, 17)
        Me.BunifuCustomLabel118.TabIndex = 27
        Me.BunifuCustomLabel118.Text = "Salary"
        '
        'BunifuCustomLabel117
        '
        Me.BunifuCustomLabel117.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel117, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel117, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel117, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel117.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel117.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel117.Location = New System.Drawing.Point(96, 58)
        Me.BunifuCustomLabel117.Name = "BunifuCustomLabel117"
        Me.BunifuCustomLabel117.Size = New System.Drawing.Size(260, 13)
        Me.BunifuCustomLabel117.TabIndex = 26
        Me.BunifuCustomLabel117.Text = "( Name of Current Employer or NONE if not Employed )"
        '
        'BunifuMetroTextbox35
        '
        Me.BunifuMetroTextbox35.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox35.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox35.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox35.BorderThickness = 1
        Me.BunifuMetroTextbox35.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox35.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox35.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox35.isPassword = False
        Me.BunifuMetroTextbox35.Location = New System.Drawing.Point(560, 25)
        Me.BunifuMetroTextbox35.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox35.Name = "BunifuMetroTextbox35"
        Me.BunifuMetroTextbox35.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox35.TabIndex = 25
        Me.BunifuMetroTextbox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel116
        '
        Me.BunifuCustomLabel116.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel116, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel116, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel116, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel116.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel116.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel116.Location = New System.Drawing.Point(466, 32)
        Me.BunifuCustomLabel116.Name = "BunifuCustomLabel116"
        Me.BunifuCustomLabel116.Size = New System.Drawing.Size(58, 17)
        Me.BunifuCustomLabel116.TabIndex = 24
        Me.BunifuCustomLabel116.Text = "Position"
        '
        'BunifuMetroTextbox34
        '
        Me.BunifuMetroTextbox34.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox34.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox34.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox34.BorderThickness = 1
        Me.BunifuMetroTextbox34.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox34.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox34.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox34.isPassword = False
        Me.BunifuMetroTextbox34.Location = New System.Drawing.Point(91, 25)
        Me.BunifuMetroTextbox34.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox34.Name = "BunifuMetroTextbox34"
        Me.BunifuMetroTextbox34.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox34.TabIndex = 23
        Me.BunifuMetroTextbox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel115
        '
        Me.BunifuCustomLabel115.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel115, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel115, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel115, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel115.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel115.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel115.Location = New System.Drawing.Point(12, 23)
        Me.BunifuCustomLabel115.Name = "BunifuCustomLabel115"
        Me.BunifuCustomLabel115.Size = New System.Drawing.Size(67, 34)
        Me.BunifuCustomLabel115.TabIndex = 22
        Me.BunifuCustomLabel115.Text = " Current " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Employer"
        '
        'BunifuCustomLabel114
        '
        Me.BunifuCustomLabel114.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel114, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel114, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel114, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel114.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel114.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel114.Location = New System.Drawing.Point(440, 70)
        Me.BunifuCustomLabel114.Name = "BunifuCustomLabel114"
        Me.BunifuCustomLabel114.Size = New System.Drawing.Size(90, 17)
        Me.BunifuCustomLabel114.TabIndex = 94
        Me.BunifuCustomLabel114.Text = "Qualification "
        '
        'BunifuCustomLabel113
        '
        Me.BunifuCustomLabel113.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel113, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel113, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel113, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel113.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel113.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel113.Location = New System.Drawing.Point(618, 46)
        Me.BunifuCustomLabel113.Name = "BunifuCustomLabel113"
        Me.BunifuCustomLabel113.Size = New System.Drawing.Size(195, 17)
        Me.BunifuCustomLabel113.TabIndex = 93
        Me.BunifuCustomLabel113.Text = "List any relevant certifications"
        '
        'BunifuCustomTextbox3
        '
        Me.BunifuCustomTextbox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuCustomTextbox3.BorderColor = System.Drawing.Color.White
        Me.BunifuCustomTextbox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomTextbox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomTextbox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomTextbox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomTextbox3.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomTextbox3.Location = New System.Drawing.Point(536, 70)
        Me.BunifuCustomTextbox3.Multiline = True
        Me.BunifuCustomTextbox3.Name = "BunifuCustomTextbox3"
        Me.BunifuCustomTextbox3.Size = New System.Drawing.Size(359, 117)
        Me.BunifuCustomTextbox3.TabIndex = 92
        '
        'BunifuCustomLabel112
        '
        Me.BunifuCustomLabel112.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel112, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel112, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel112, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel112.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel112.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel112.Location = New System.Drawing.Point(25, 70)
        Me.BunifuCustomLabel112.Name = "BunifuCustomLabel112"
        Me.BunifuCustomLabel112.Size = New System.Drawing.Size(33, 17)
        Me.BunifuCustomLabel112.TabIndex = 91
        Me.BunifuCustomLabel112.Text = "Skill"
        '
        'BunifuCustomLabel111
        '
        Me.BunifuCustomLabel111.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel111, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel111, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel111, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel111.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel111.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel111.Location = New System.Drawing.Point(173, 46)
        Me.BunifuCustomLabel111.Name = "BunifuCustomLabel111"
        Me.BunifuCustomLabel111.Size = New System.Drawing.Size(146, 17)
        Me.BunifuCustomLabel111.TabIndex = 90
        Me.BunifuCustomLabel111.Text = "List any relevant skills"
        '
        'BunifuCustomTextbox2
        '
        Me.BunifuCustomTextbox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuCustomTextbox2.BorderColor = System.Drawing.Color.White
        Me.BunifuCustomTextbox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomTextbox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomTextbox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomTextbox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomTextbox2.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomTextbox2.Location = New System.Drawing.Point(67, 70)
        Me.BunifuCustomTextbox2.Multiline = True
        Me.BunifuCustomTextbox2.Name = "BunifuCustomTextbox2"
        Me.BunifuCustomTextbox2.Size = New System.Drawing.Size(359, 117)
        Me.BunifuCustomTextbox2.TabIndex = 30
        '
        'BunifuCustomLabel61
        '
        Me.BunifuCustomLabel61.AutoSize = True
        Me.BunifuCustomLabel61.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel61, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel61, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel61, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel61.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel61.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel61.Location = New System.Drawing.Point(3, 6)
        Me.BunifuCustomLabel61.Name = "BunifuCustomLabel61"
        Me.BunifuCustomLabel61.Size = New System.Drawing.Size(184, 23)
        Me.BunifuCustomLabel61.TabIndex = 16
        Me.BunifuCustomLabel61.Text = "Skill / Qualification"
        '
        'TabPage14
        '
        Me.TabPage14.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage14.Controls.Add(Me.Panel12)
        Me.BunifuTransition3.SetDecoration(Me.TabPage14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage14, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage14.Location = New System.Drawing.Point(4, 22)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage14.Size = New System.Drawing.Size(950, 434)
        Me.TabPage14.TabIndex = 4
        Me.TabPage14.Text = "TabPage14"
        '
        'Panel12
        '
        Me.Panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel12.Controls.Add(Me.GroupBox6)
        Me.Panel12.Controls.Add(Me.GroupBox5)
        Me.Panel12.Controls.Add(Me.BunifuCustomLabel62)
        Me.BunifuTransition1.SetDecoration(Me.Panel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel12, BunifuAnimatorNS.DecorationType.None)
        Me.Panel12.Location = New System.Drawing.Point(6, 9)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(903, 451)
        Me.Panel12.TabIndex = 1
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.BunifuMetroTextbox45)
        Me.GroupBox6.Controls.Add(Me.BunifuCustomLabel141)
        Me.GroupBox6.Controls.Add(Me.BunifuMetroTextbox44)
        Me.GroupBox6.Controls.Add(Me.BunifuCustomLabel140)
        Me.GroupBox6.Controls.Add(Me.BunifuDropdown35)
        Me.GroupBox6.Controls.Add(Me.BunifuCustomLabel139)
        Me.GroupBox6.Controls.Add(Me.BunifuMetroTextbox43)
        Me.GroupBox6.Controls.Add(Me.BunifuCustomLabel138)
        Me.GroupBox6.Controls.Add(Me.BunifuMetroTextbox42)
        Me.GroupBox6.Controls.Add(Me.BunifuCustomLabel137)
        Me.BunifuTransition1.SetDecoration(Me.GroupBox6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.GroupBox6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.GroupBox6, BunifuAnimatorNS.DecorationType.None)
        Me.GroupBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.ForeColor = System.Drawing.Color.White
        Me.GroupBox6.Location = New System.Drawing.Point(15, 238)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(868, 176)
        Me.GroupBox6.TabIndex = 97
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Reference"
        '
        'BunifuMetroTextbox45
        '
        Me.BunifuMetroTextbox45.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox45.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox45.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox45.BorderThickness = 1
        Me.BunifuMetroTextbox45.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox45, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox45, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox45, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox45.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox45.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox45.isPassword = False
        Me.BunifuMetroTextbox45.Location = New System.Drawing.Point(99, 126)
        Me.BunifuMetroTextbox45.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox45.Name = "BunifuMetroTextbox45"
        Me.BunifuMetroTextbox45.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox45.TabIndex = 117
        Me.BunifuMetroTextbox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel141
        '
        Me.BunifuCustomLabel141.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel141, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel141, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel141, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel141.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel141.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel141.Location = New System.Drawing.Point(20, 133)
        Me.BunifuCustomLabel141.Name = "BunifuCustomLabel141"
        Me.BunifuCustomLabel141.Size = New System.Drawing.Size(49, 17)
        Me.BunifuCustomLabel141.TabIndex = 116
        Me.BunifuCustomLabel141.Text = "Phone"
        '
        'BunifuMetroTextbox44
        '
        Me.BunifuMetroTextbox44.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox44.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox44.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox44.BorderThickness = 1
        Me.BunifuMetroTextbox44.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox44, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox44, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox44, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox44.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox44.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox44.isPassword = False
        Me.BunifuMetroTextbox44.Location = New System.Drawing.Point(489, 87)
        Me.BunifuMetroTextbox44.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox44.Name = "BunifuMetroTextbox44"
        Me.BunifuMetroTextbox44.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox44.TabIndex = 115
        Me.BunifuMetroTextbox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel140
        '
        Me.BunifuCustomLabel140.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel140, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel140, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel140, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel140.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel140.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel140.Location = New System.Drawing.Point(373, 94)
        Me.BunifuCustomLabel140.Name = "BunifuCustomLabel140"
        Me.BunifuCustomLabel140.Size = New System.Drawing.Size(42, 17)
        Me.BunifuCustomLabel140.TabIndex = 114
        Me.BunifuCustomLabel140.Text = "Email"
        '
        'BunifuDropdown35
        '
        Me.BunifuDropdown35.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown35.BorderRadius = 3
        Me.BunifuDropdown35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown35.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown35.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown35.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown35.Location = New System.Drawing.Point(99, 84)
        Me.BunifuDropdown35.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown35.Name = "BunifuDropdown35"
        Me.BunifuDropdown35.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown35.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown35.selectedIndex = -1
        Me.BunifuDropdown35.Size = New System.Drawing.Size(116, 30)
        Me.BunifuDropdown35.TabIndex = 113
        '
        'BunifuCustomLabel139
        '
        Me.BunifuCustomLabel139.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel139, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel139, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel139, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel139.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel139.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel139.Location = New System.Drawing.Point(20, 82)
        Me.BunifuCustomLabel139.Name = "BunifuCustomLabel139"
        Me.BunifuCustomLabel139.Size = New System.Drawing.Size(78, 34)
        Me.BunifuCustomLabel139.TabIndex = 28
        Me.BunifuCustomLabel139.Text = "Years" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "acquainted"
        '
        'BunifuMetroTextbox43
        '
        Me.BunifuMetroTextbox43.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox43.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox43.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox43.BorderThickness = 1
        Me.BunifuMetroTextbox43.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox43, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox43.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox43.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox43.isPassword = False
        Me.BunifuMetroTextbox43.Location = New System.Drawing.Point(489, 42)
        Me.BunifuMetroTextbox43.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox43.Name = "BunifuMetroTextbox43"
        Me.BunifuMetroTextbox43.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox43.TabIndex = 27
        Me.BunifuMetroTextbox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel138
        '
        Me.BunifuCustomLabel138.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel138, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel138, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel138, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel138.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel138.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel138.Location = New System.Drawing.Point(373, 49)
        Me.BunifuCustomLabel138.Name = "BunifuCustomLabel138"
        Me.BunifuCustomLabel138.Size = New System.Drawing.Size(86, 17)
        Me.BunifuCustomLabel138.TabIndex = 26
        Me.BunifuCustomLabel138.Text = "Relationship"
        '
        'BunifuMetroTextbox42
        '
        Me.BunifuMetroTextbox42.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox42.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox42.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox42.BorderThickness = 1
        Me.BunifuMetroTextbox42.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox42.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox42.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox42.isPassword = False
        Me.BunifuMetroTextbox42.Location = New System.Drawing.Point(99, 42)
        Me.BunifuMetroTextbox42.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox42.Name = "BunifuMetroTextbox42"
        Me.BunifuMetroTextbox42.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox42.TabIndex = 25
        Me.BunifuMetroTextbox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel137
        '
        Me.BunifuCustomLabel137.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel137, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel137, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel137, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel137.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel137.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel137.Location = New System.Drawing.Point(20, 47)
        Me.BunifuCustomLabel137.Name = "BunifuCustomLabel137"
        Me.BunifuCustomLabel137.Size = New System.Drawing.Size(74, 17)
        Me.BunifuCustomLabel137.TabIndex = 24
        Me.BunifuCustomLabel137.Text = "Reference"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.BunifuDropdown32)
        Me.GroupBox5.Controls.Add(Me.BunifuDropdown33)
        Me.GroupBox5.Controls.Add(Me.BunifuDropdown34)
        Me.GroupBox5.Controls.Add(Me.BunifuDropdown29)
        Me.GroupBox5.Controls.Add(Me.BunifuDropdown30)
        Me.GroupBox5.Controls.Add(Me.BunifuDropdown31)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel133)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel134)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel135)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel136)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel124)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel125)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel126)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel127)
        Me.GroupBox5.Controls.Add(Me.BunifuMetroTextbox38)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel128)
        Me.GroupBox5.Controls.Add(Me.BunifuMetroTextbox39)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel129)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel130)
        Me.GroupBox5.Controls.Add(Me.BunifuMetroTextbox40)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel131)
        Me.GroupBox5.Controls.Add(Me.BunifuMetroTextbox41)
        Me.GroupBox5.Controls.Add(Me.BunifuCustomLabel132)
        Me.BunifuTransition1.SetDecoration(Me.GroupBox5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.GroupBox5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.GroupBox5, BunifuAnimatorNS.DecorationType.None)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.White
        Me.GroupBox5.Location = New System.Drawing.Point(15, 33)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(868, 191)
        Me.GroupBox5.TabIndex = 96
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Current Employment:"
        '
        'BunifuDropdown32
        '
        Me.BunifuDropdown32.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown32.BorderRadius = 3
        Me.BunifuDropdown32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown32.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown32.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown32.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown32.Location = New System.Drawing.Point(781, 152)
        Me.BunifuDropdown32.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown32.Name = "BunifuDropdown32"
        Me.BunifuDropdown32.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown32.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown32.selectedIndex = -1
        Me.BunifuDropdown32.Size = New System.Drawing.Size(74, 30)
        Me.BunifuDropdown32.TabIndex = 112
        '
        'BunifuDropdown33
        '
        Me.BunifuDropdown33.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown33.BorderRadius = 3
        Me.BunifuDropdown33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown33.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown33.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown33.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown33.Location = New System.Drawing.Point(683, 152)
        Me.BunifuDropdown33.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown33.Name = "BunifuDropdown33"
        Me.BunifuDropdown33.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown33.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown33.selectedIndex = -1
        Me.BunifuDropdown33.Size = New System.Drawing.Size(74, 30)
        Me.BunifuDropdown33.TabIndex = 111
        '
        'BunifuDropdown34
        '
        Me.BunifuDropdown34.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown34.BorderRadius = 3
        Me.BunifuDropdown34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown34.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown34.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown34.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown34.Location = New System.Drawing.Point(587, 152)
        Me.BunifuDropdown34.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown34.Name = "BunifuDropdown34"
        Me.BunifuDropdown34.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown34.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown34.selectedIndex = -1
        Me.BunifuDropdown34.Size = New System.Drawing.Size(74, 30)
        Me.BunifuDropdown34.TabIndex = 110
        '
        'BunifuDropdown29
        '
        Me.BunifuDropdown29.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown29.BorderRadius = 3
        Me.BunifuDropdown29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown29.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown29.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown29.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown29.Location = New System.Drawing.Point(288, 148)
        Me.BunifuDropdown29.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown29.Name = "BunifuDropdown29"
        Me.BunifuDropdown29.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown29.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown29.selectedIndex = -1
        Me.BunifuDropdown29.Size = New System.Drawing.Size(74, 30)
        Me.BunifuDropdown29.TabIndex = 109
        '
        'BunifuDropdown30
        '
        Me.BunifuDropdown30.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown30.BorderRadius = 3
        Me.BunifuDropdown30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown30.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown30.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown30.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown30.Location = New System.Drawing.Point(190, 148)
        Me.BunifuDropdown30.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown30.Name = "BunifuDropdown30"
        Me.BunifuDropdown30.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown30.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown30.selectedIndex = -1
        Me.BunifuDropdown30.Size = New System.Drawing.Size(74, 30)
        Me.BunifuDropdown30.TabIndex = 108
        '
        'BunifuDropdown31
        '
        Me.BunifuDropdown31.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown31.BorderRadius = 3
        Me.BunifuDropdown31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition3.SetDecoration(Me.BunifuDropdown31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuDropdown31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuDropdown31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuDropdown31.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuDropdown31.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown31.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown31.Location = New System.Drawing.Point(94, 148)
        Me.BunifuDropdown31.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuDropdown31.Name = "BunifuDropdown31"
        Me.BunifuDropdown31.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown31.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown31.selectedIndex = -1
        Me.BunifuDropdown31.Size = New System.Drawing.Size(74, 30)
        Me.BunifuDropdown31.TabIndex = 107
        '
        'BunifuCustomLabel133
        '
        Me.BunifuCustomLabel133.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel133, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel133, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel133, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel133.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel133.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel133.Location = New System.Drawing.Point(799, 120)
        Me.BunifuCustomLabel133.Name = "BunifuCustomLabel133"
        Me.BunifuCustomLabel133.Size = New System.Drawing.Size(38, 17)
        Me.BunifuCustomLabel133.TabIndex = 97
        Me.BunifuCustomLabel133.Text = "Year"
        '
        'BunifuCustomLabel134
        '
        Me.BunifuCustomLabel134.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel134, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel134, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel134, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel134.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel134.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel134.Location = New System.Drawing.Point(697, 120)
        Me.BunifuCustomLabel134.Name = "BunifuCustomLabel134"
        Me.BunifuCustomLabel134.Size = New System.Drawing.Size(47, 17)
        Me.BunifuCustomLabel134.TabIndex = 96
        Me.BunifuCustomLabel134.Text = "Month"
        '
        'BunifuCustomLabel135
        '
        Me.BunifuCustomLabel135.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel135, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel135, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel135, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel135.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel135.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel135.Location = New System.Drawing.Point(608, 120)
        Me.BunifuCustomLabel135.Name = "BunifuCustomLabel135"
        Me.BunifuCustomLabel135.Size = New System.Drawing.Size(33, 17)
        Me.BunifuCustomLabel135.TabIndex = 95
        Me.BunifuCustomLabel135.Text = "Day"
        '
        'BunifuCustomLabel136
        '
        Me.BunifuCustomLabel136.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel136, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel136, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel136, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel136.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel136.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel136.Location = New System.Drawing.Point(488, 159)
        Me.BunifuCustomLabel136.Name = "BunifuCustomLabel136"
        Me.BunifuCustomLabel136.Size = New System.Drawing.Size(67, 17)
        Me.BunifuCustomLabel136.TabIndex = 91
        Me.BunifuCustomLabel136.Text = "End Date"
        '
        'BunifuCustomLabel124
        '
        Me.BunifuCustomLabel124.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel124, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel124, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel124, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel124.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel124.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel124.Location = New System.Drawing.Point(306, 120)
        Me.BunifuCustomLabel124.Name = "BunifuCustomLabel124"
        Me.BunifuCustomLabel124.Size = New System.Drawing.Size(38, 17)
        Me.BunifuCustomLabel124.TabIndex = 90
        Me.BunifuCustomLabel124.Text = "Year"
        '
        'BunifuCustomLabel125
        '
        Me.BunifuCustomLabel125.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel125, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel125, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel125, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel125.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel125.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel125.Location = New System.Drawing.Point(204, 120)
        Me.BunifuCustomLabel125.Name = "BunifuCustomLabel125"
        Me.BunifuCustomLabel125.Size = New System.Drawing.Size(47, 17)
        Me.BunifuCustomLabel125.TabIndex = 89
        Me.BunifuCustomLabel125.Text = "Month"
        '
        'BunifuCustomLabel126
        '
        Me.BunifuCustomLabel126.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel126, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel126, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel126, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel126.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel126.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel126.Location = New System.Drawing.Point(115, 120)
        Me.BunifuCustomLabel126.Name = "BunifuCustomLabel126"
        Me.BunifuCustomLabel126.Size = New System.Drawing.Size(33, 17)
        Me.BunifuCustomLabel126.TabIndex = 88
        Me.BunifuCustomLabel126.Text = "Day"
        '
        'BunifuCustomLabel127
        '
        Me.BunifuCustomLabel127.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel127, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel127, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel127, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel127.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel127.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel127.Location = New System.Drawing.Point(12, 155)
        Me.BunifuCustomLabel127.Name = "BunifuCustomLabel127"
        Me.BunifuCustomLabel127.Size = New System.Drawing.Size(72, 17)
        Me.BunifuCustomLabel127.TabIndex = 31
        Me.BunifuCustomLabel127.Text = "Start Date"
        '
        'BunifuMetroTextbox38
        '
        Me.BunifuMetroTextbox38.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox38.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox38.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox38.BorderThickness = 1
        Me.BunifuMetroTextbox38.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox38.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox38.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox38.isPassword = False
        Me.BunifuMetroTextbox38.Location = New System.Drawing.Point(582, 84)
        Me.BunifuMetroTextbox38.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox38.Name = "BunifuMetroTextbox38"
        Me.BunifuMetroTextbox38.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox38.TabIndex = 30
        Me.BunifuMetroTextbox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel128
        '
        Me.BunifuCustomLabel128.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel128, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel128, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel128, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel128.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel128.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel128.Location = New System.Drawing.Point(488, 82)
        Me.BunifuCustomLabel128.Name = "BunifuCustomLabel128"
        Me.BunifuCustomLabel128.Size = New System.Drawing.Size(73, 34)
        Me.BunifuCustomLabel128.TabIndex = 29
        Me.BunifuCustomLabel128.Text = "Reason of" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Leaving?"
        '
        'BunifuMetroTextbox39
        '
        Me.BunifuMetroTextbox39.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox39.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox39.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox39.BorderThickness = 1
        Me.BunifuMetroTextbox39.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox39.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox39.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox39.isPassword = False
        Me.BunifuMetroTextbox39.Location = New System.Drawing.Point(91, 84)
        Me.BunifuMetroTextbox39.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox39.Name = "BunifuMetroTextbox39"
        Me.BunifuMetroTextbox39.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox39.TabIndex = 28
        Me.BunifuMetroTextbox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel129
        '
        Me.BunifuCustomLabel129.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel129, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel129, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel129, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel129.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel129.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel129.Location = New System.Drawing.Point(12, 91)
        Me.BunifuCustomLabel129.Name = "BunifuCustomLabel129"
        Me.BunifuCustomLabel129.Size = New System.Drawing.Size(48, 17)
        Me.BunifuCustomLabel129.TabIndex = 27
        Me.BunifuCustomLabel129.Text = "Salary"
        '
        'BunifuCustomLabel130
        '
        Me.BunifuCustomLabel130.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel130, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel130, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel130, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel130.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel130.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel130.Location = New System.Drawing.Point(96, 58)
        Me.BunifuCustomLabel130.Name = "BunifuCustomLabel130"
        Me.BunifuCustomLabel130.Size = New System.Drawing.Size(260, 13)
        Me.BunifuCustomLabel130.TabIndex = 26
        Me.BunifuCustomLabel130.Text = "( Name of Current Employer or NONE if not Employed )"
        '
        'BunifuMetroTextbox40
        '
        Me.BunifuMetroTextbox40.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox40.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox40.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox40.BorderThickness = 1
        Me.BunifuMetroTextbox40.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox40.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox40.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox40.isPassword = False
        Me.BunifuMetroTextbox40.Location = New System.Drawing.Point(582, 25)
        Me.BunifuMetroTextbox40.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox40.Name = "BunifuMetroTextbox40"
        Me.BunifuMetroTextbox40.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox40.TabIndex = 25
        Me.BunifuMetroTextbox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel131
        '
        Me.BunifuCustomLabel131.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel131, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel131, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel131, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel131.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel131.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel131.Location = New System.Drawing.Point(488, 32)
        Me.BunifuCustomLabel131.Name = "BunifuCustomLabel131"
        Me.BunifuCustomLabel131.Size = New System.Drawing.Size(58, 17)
        Me.BunifuCustomLabel131.TabIndex = 24
        Me.BunifuCustomLabel131.Text = "Position"
        '
        'BunifuMetroTextbox41
        '
        Me.BunifuMetroTextbox41.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox41.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox41.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox41.BorderThickness = 1
        Me.BunifuMetroTextbox41.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.BunifuMetroTextbox41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuMetroTextbox41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuMetroTextbox41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuMetroTextbox41.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox41.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox41.isPassword = False
        Me.BunifuMetroTextbox41.Location = New System.Drawing.Point(91, 25)
        Me.BunifuMetroTextbox41.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox41.Name = "BunifuMetroTextbox41"
        Me.BunifuMetroTextbox41.Size = New System.Drawing.Size(268, 30)
        Me.BunifuMetroTextbox41.TabIndex = 23
        Me.BunifuMetroTextbox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel132
        '
        Me.BunifuCustomLabel132.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel132, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel132, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel132, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel132.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel132.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel132.Location = New System.Drawing.Point(12, 23)
        Me.BunifuCustomLabel132.Name = "BunifuCustomLabel132"
        Me.BunifuCustomLabel132.Size = New System.Drawing.Size(67, 34)
        Me.BunifuCustomLabel132.TabIndex = 22
        Me.BunifuCustomLabel132.Text = "Current " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Employer"
        '
        'BunifuCustomLabel62
        '
        Me.BunifuCustomLabel62.AutoSize = True
        Me.BunifuCustomLabel62.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel62, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel62, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel62, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel62.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel62.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel62.Location = New System.Drawing.Point(3, 6)
        Me.BunifuCustomLabel62.Name = "BunifuCustomLabel62"
        Me.BunifuCustomLabel62.Size = New System.Drawing.Size(207, 23)
        Me.BunifuCustomLabel62.TabIndex = 16
        Me.BunifuCustomLabel62.Text = "Previous Employment"
        '
        'TabPage16
        '
        Me.TabPage16.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage16.Controls.Add(Me.Panel14)
        Me.BunifuTransition3.SetDecoration(Me.TabPage16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage16, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage16.Location = New System.Drawing.Point(4, 22)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage16.Size = New System.Drawing.Size(950, 434)
        Me.TabPage16.TabIndex = 6
        Me.TabPage16.Text = "TabPage16"
        '
        'Panel14
        '
        Me.Panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel14.Controls.Add(Me.BunifuCustomDataGrid2)
        Me.Panel14.Controls.Add(Me.BunifuGradientPanel13)
        Me.Panel14.Controls.Add(Me.BunifuCustomLabel78)
        Me.BunifuTransition1.SetDecoration(Me.Panel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel14, BunifuAnimatorNS.DecorationType.None)
        Me.Panel14.Location = New System.Drawing.Point(6, 9)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(935, 427)
        Me.Panel14.TabIndex = 2
        '
        'BunifuCustomDataGrid2
        '
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuCustomDataGrid2.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle3
        Me.BunifuCustomDataGrid2.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.BunifuCustomDataGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BunifuCustomDataGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BunifuCustomDataGrid2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.BunifuCustomDataGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuCustomDataGrid2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomDataGrid2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomDataGrid2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomDataGrid2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomDataGrid2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BunifuCustomDataGrid2.DoubleBuffered = True
        Me.BunifuCustomDataGrid2.EnableHeadersVisualStyles = False
        Me.BunifuCustomDataGrid2.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuCustomDataGrid2.HeaderForeColor = System.Drawing.Color.White
        Me.BunifuCustomDataGrid2.Location = New System.Drawing.Point(0, 37)
        Me.BunifuCustomDataGrid2.Name = "BunifuCustomDataGrid2"
        Me.BunifuCustomDataGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.BunifuCustomDataGrid2.Size = New System.Drawing.Size(933, 388)
        Me.BunifuCustomDataGrid2.TabIndex = 18
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Name 1"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Name 2"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "Name 3"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "Name 4"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "Name 5"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'BunifuCustomLabel78
        '
        Me.BunifuCustomLabel78.AutoSize = True
        Me.BunifuCustomLabel78.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel78, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel78, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel78, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel78.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel78.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel78.Location = New System.Drawing.Point(3, 6)
        Me.BunifuCustomLabel78.Name = "BunifuCustomLabel78"
        Me.BunifuCustomLabel78.Size = New System.Drawing.Size(134, 23)
        Me.BunifuCustomLabel78.TabIndex = 16
        Me.BunifuCustomLabel78.Text = "View Records"
        '
        'TabPage15
        '
        Me.TabPage15.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage15.Controls.Add(Me.Panel13)
        Me.BunifuTransition3.SetDecoration(Me.TabPage15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage15, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage15.Location = New System.Drawing.Point(4, 22)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage15.Size = New System.Drawing.Size(950, 434)
        Me.TabPage15.TabIndex = 5
        Me.TabPage15.Text = "TabPage15"
        '
        'Panel13
        '
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuTransition1.SetDecoration(Me.Panel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel13, BunifuAnimatorNS.DecorationType.None)
        Me.Panel13.Location = New System.Drawing.Point(6, 9)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(903, 427)
        Me.Panel13.TabIndex = 2
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.TabControl4)
        Me.TabPage4.Controls.Add(Me.Panel18)
        Me.TabPage4.Controls.Add(Me.Panel17)
        Me.BunifuTransition3.SetDecoration(Me.TabPage4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage4, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(957, 606)
        Me.TabPage4.TabIndex = 7
        Me.TabPage4.Text = "TabPage4"
        '
        'TabControl4
        '
        Me.TabControl4.Controls.Add(Me.TabPage18)
        Me.TabControl4.Controls.Add(Me.TabPage19)
        Me.TabControl4.Controls.Add(Me.TabPage20)
        Me.TabControl4.Controls.Add(Me.TabPage21)
        Me.BunifuTransition1.SetDecoration(Me.TabControl4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabControl4, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl4.Location = New System.Drawing.Point(-4, 94)
        Me.TabControl4.Name = "TabControl4"
        Me.TabControl4.SelectedIndex = 0
        Me.TabControl4.Size = New System.Drawing.Size(943, 502)
        Me.TabControl4.TabIndex = 16
        '
        'TabPage18
        '
        Me.TabPage18.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage18.Controls.Add(Me.Panel19)
        Me.BunifuTransition3.SetDecoration(Me.TabPage18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage18, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage18.Location = New System.Drawing.Point(4, 22)
        Me.TabPage18.Name = "TabPage18"
        Me.TabPage18.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage18.Size = New System.Drawing.Size(935, 476)
        Me.TabPage18.TabIndex = 0
        Me.TabPage18.Text = "TabPage18"
        '
        'Panel19
        '
        Me.Panel19.Controls.Add(Me.BunifuFlatButton25)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton26)
        Me.Panel19.Controls.Add(Me.BunifuThinButton247)
        Me.Panel19.Controls.Add(Me.BunifuThinButton248)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton27)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton28)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton29)
        Me.Panel19.Controls.Add(Me.BunifuThinButton249)
        Me.Panel19.Controls.Add(Me.BunifuFlatButton30)
        Me.Panel19.Controls.Add(Me.BunifuThinButton250)
        Me.Panel19.Controls.Add(Me.BunifuThinButton251)
        Me.Panel19.Controls.Add(Me.BunifuThinButton252)
        Me.BunifuTransition1.SetDecoration(Me.Panel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel19, BunifuAnimatorNS.DecorationType.None)
        Me.Panel19.Location = New System.Drawing.Point(7, 418)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(948, 52)
        Me.Panel19.TabIndex = 100
        '
        'TabPage19
        '
        Me.TabPage19.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage19.Controls.Add(Me.BunifuCustomDataGrid4)
        Me.TabPage19.Controls.Add(Me.BunifuGradientPanel14)
        Me.BunifuTransition3.SetDecoration(Me.TabPage19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage19, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage19.Location = New System.Drawing.Point(4, 22)
        Me.TabPage19.Name = "TabPage19"
        Me.TabPage19.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage19.Size = New System.Drawing.Size(935, 476)
        Me.TabPage19.TabIndex = 1
        Me.TabPage19.Text = "TabPage19"
        '
        'BunifuCustomDataGrid4
        '
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuCustomDataGrid4.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.BunifuCustomDataGrid4.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.BunifuCustomDataGrid4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BunifuCustomDataGrid4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BunifuCustomDataGrid4.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.BunifuCustomDataGrid4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuCustomDataGrid4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18})
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomDataGrid4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomDataGrid4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomDataGrid4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomDataGrid4.DoubleBuffered = True
        Me.BunifuCustomDataGrid4.EnableHeadersVisualStyles = False
        Me.BunifuCustomDataGrid4.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuCustomDataGrid4.HeaderForeColor = System.Drawing.Color.White
        Me.BunifuCustomDataGrid4.Location = New System.Drawing.Point(10, 46)
        Me.BunifuCustomDataGrid4.Name = "BunifuCustomDataGrid4"
        Me.BunifuCustomDataGrid4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.BunifuCustomDataGrid4.Size = New System.Drawing.Size(907, 426)
        Me.BunifuCustomDataGrid4.TabIndex = 20
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.HeaderText = "Name 1"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "Name 2"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "Name 3"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "Name 4"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Name 5"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        '
        'TabPage20
        '
        Me.TabPage20.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition3.SetDecoration(Me.TabPage20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage20, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage20.Location = New System.Drawing.Point(4, 22)
        Me.TabPage20.Name = "TabPage20"
        Me.TabPage20.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage20.Size = New System.Drawing.Size(935, 476)
        Me.TabPage20.TabIndex = 2
        Me.TabPage20.Text = "TabPage20"
        '
        'TabPage21
        '
        Me.TabPage21.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition3.SetDecoration(Me.TabPage21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage21, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage21.Location = New System.Drawing.Point(4, 22)
        Me.TabPage21.Name = "TabPage21"
        Me.TabPage21.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage21.Size = New System.Drawing.Size(935, 476)
        Me.TabPage21.TabIndex = 3
        Me.TabPage21.Text = "TabPage21"
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.BunifuFlatButton19)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton20)
        Me.Panel18.Controls.Add(Me.BunifuThinButton241)
        Me.Panel18.Controls.Add(Me.BunifuThinButton242)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton21)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton22)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton23)
        Me.Panel18.Controls.Add(Me.BunifuThinButton243)
        Me.Panel18.Controls.Add(Me.BunifuFlatButton24)
        Me.Panel18.Controls.Add(Me.BunifuThinButton244)
        Me.Panel18.Controls.Add(Me.BunifuThinButton245)
        Me.Panel18.Controls.Add(Me.BunifuThinButton246)
        Me.BunifuTransition1.SetDecoration(Me.Panel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel18, BunifuAnimatorNS.DecorationType.None)
        Me.Panel18.Location = New System.Drawing.Point(-1, 45)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(948, 52)
        Me.Panel18.TabIndex = 15
        Me.Panel18.Visible = False
        '
        'Panel17
        '
        Me.BunifuTransition1.SetDecoration(Me.Panel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel17, BunifuAnimatorNS.DecorationType.None)
        Me.Panel17.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel17.Location = New System.Drawing.Point(3, 3)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(951, 45)
        Me.Panel17.TabIndex = 1
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage5.Controls.Add(Me.Panel22)
        Me.TabPage5.Controls.Add(Me.Panel20)
        Me.BunifuTransition3.SetDecoration(Me.TabPage5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage5, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(957, 606)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "TabPage5"
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.BunifuTileButton1)
        Me.Panel22.Controls.Add(Me.BunifuTileButton17)
        Me.Panel22.Controls.Add(Me.BunifuTileButton2)
        Me.Panel22.Controls.Add(Me.BunifuTileButton18)
        Me.Panel22.Controls.Add(Me.BunifuTileButton3)
        Me.Panel22.Controls.Add(Me.BunifuTileButton19)
        Me.Panel22.Controls.Add(Me.BunifuTileButton4)
        Me.Panel22.Controls.Add(Me.BunifuTileButton20)
        Me.Panel22.Controls.Add(Me.BunifuTileButton5)
        Me.Panel22.Controls.Add(Me.BunifuTileButton13)
        Me.Panel22.Controls.Add(Me.BunifuTileButton6)
        Me.Panel22.Controls.Add(Me.BunifuTileButton14)
        Me.Panel22.Controls.Add(Me.BunifuTileButton7)
        Me.Panel22.Controls.Add(Me.BunifuTileButton15)
        Me.Panel22.Controls.Add(Me.BunifuTileButton8)
        Me.Panel22.Controls.Add(Me.BunifuTileButton16)
        Me.Panel22.Controls.Add(Me.BunifuTileButton12)
        Me.Panel22.Controls.Add(Me.BunifuTileButton9)
        Me.Panel22.Controls.Add(Me.BunifuTileButton11)
        Me.Panel22.Controls.Add(Me.BunifuTileButton10)
        Me.BunifuTransition1.SetDecoration(Me.Panel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel22, BunifuAnimatorNS.DecorationType.None)
        Me.Panel22.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel22.Location = New System.Drawing.Point(3, 48)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(951, 555)
        Me.Panel22.TabIndex = 22
        '
        'Panel20
        '
        Me.Panel20.Controls.Add(Me.BunifuCustomLabel172)
        Me.BunifuTransition1.SetDecoration(Me.Panel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel20, BunifuAnimatorNS.DecorationType.None)
        Me.Panel20.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel20.Location = New System.Drawing.Point(3, 3)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(951, 45)
        Me.Panel20.TabIndex = 1
        '
        'BunifuCustomLabel172
        '
        Me.BunifuCustomLabel172.AutoSize = True
        Me.BunifuCustomLabel172.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel172, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel172, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel172, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel172.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel172.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel172.Location = New System.Drawing.Point(15, 12)
        Me.BunifuCustomLabel172.Name = "BunifuCustomLabel172"
        Me.BunifuCustomLabel172.Size = New System.Drawing.Size(80, 23)
        Me.BunifuCustomLabel172.TabIndex = 12
        Me.BunifuCustomLabel172.Text = "Masters"
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage6.Controls.Add(Me.Panel23)
        Me.BunifuTransition3.SetDecoration(Me.TabPage6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage6, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(957, 606)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "TabPage6"
        '
        'Panel23
        '
        Me.Panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel23.Controls.Add(Me.Panel27)
        Me.Panel23.Controls.Add(Me.Panel25)
        Me.Panel23.Controls.Add(Me.Panel24)
        Me.Panel23.Controls.Add(Me.TabControl5)
        Me.BunifuTransition1.SetDecoration(Me.Panel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel23, BunifuAnimatorNS.DecorationType.None)
        Me.Panel23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel23.Location = New System.Drawing.Point(3, 3)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(951, 600)
        Me.Panel23.TabIndex = 0
        '
        'Panel27
        '
        Me.Panel27.Controls.Add(Me.BunifuFlatButton38)
        Me.Panel27.Controls.Add(Me.BunifuFlatButton39)
        Me.Panel27.Controls.Add(Me.BunifuThinButton259)
        Me.Panel27.Controls.Add(Me.BunifuThinButton260)
        Me.Panel27.Controls.Add(Me.BunifuFlatButton40)
        Me.Panel27.Controls.Add(Me.BunifuFlatButton42)
        Me.Panel27.Controls.Add(Me.BunifuThinButton261)
        Me.Panel27.Controls.Add(Me.BunifuThinButton262)
        Me.BunifuTransition1.SetDecoration(Me.Panel27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel27, BunifuAnimatorNS.DecorationType.None)
        Me.Panel27.Location = New System.Drawing.Point(0, 544)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(949, 52)
        Me.Panel27.TabIndex = 18
        '
        'Panel25
        '
        Me.Panel25.Controls.Add(Me.BunifuFlatButton34)
        Me.Panel25.Controls.Add(Me.BunifuFlatButton35)
        Me.Panel25.Controls.Add(Me.BunifuFlatButton36)
        Me.Panel25.Controls.Add(Me.BunifuThinButton255)
        Me.Panel25.Controls.Add(Me.BunifuThinButton256)
        Me.Panel25.Controls.Add(Me.BunifuThinButton258)
        Me.BunifuTransition1.SetDecoration(Me.Panel25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel25, BunifuAnimatorNS.DecorationType.None)
        Me.Panel25.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel25.Location = New System.Drawing.Point(0, 45)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(949, 40)
        Me.Panel25.TabIndex = 16
        '
        'Panel24
        '
        Me.Panel24.Controls.Add(Me.BunifuCustomLabel148)
        Me.BunifuTransition1.SetDecoration(Me.Panel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel24, BunifuAnimatorNS.DecorationType.None)
        Me.Panel24.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel24.Location = New System.Drawing.Point(0, 0)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(949, 45)
        Me.Panel24.TabIndex = 1
        '
        'BunifuCustomLabel148
        '
        Me.BunifuCustomLabel148.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel148, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel148, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel148, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel148.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel148.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel148.Location = New System.Drawing.Point(18, 10)
        Me.BunifuCustomLabel148.Name = "BunifuCustomLabel148"
        Me.BunifuCustomLabel148.Size = New System.Drawing.Size(149, 26)
        Me.BunifuCustomLabel148.TabIndex = 149
        Me.BunifuCustomLabel148.Text = "Nurse Section"
        '
        'TabControl5
        '
        Me.TabControl5.Controls.Add(Me.TabPage22)
        Me.TabControl5.Controls.Add(Me.TabPage23)
        Me.TabControl5.Controls.Add(Me.TabPage24)
        Me.TabControl5.Controls.Add(Me.TabPage25)
        Me.BunifuTransition1.SetDecoration(Me.TabControl5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabControl5, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl5.Location = New System.Drawing.Point(-8, 77)
        Me.TabControl5.Name = "TabControl5"
        Me.TabControl5.SelectedIndex = 0
        Me.TabControl5.Size = New System.Drawing.Size(957, 437)
        Me.TabControl5.TabIndex = 17
        '
        'TabPage22
        '
        Me.TabPage22.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage22.Controls.Add(Me.Panel26)
        Me.BunifuTransition3.SetDecoration(Me.TabPage22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage22, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage22.Location = New System.Drawing.Point(4, 22)
        Me.TabPage22.Name = "TabPage22"
        Me.TabPage22.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage22.Size = New System.Drawing.Size(949, 411)
        Me.TabPage22.TabIndex = 0
        Me.TabPage22.Text = "TabPage22"
        '
        'Panel26
        '
        Me.Panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel26.Controls.Add(Me.txtsral)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel88)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel87)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel86)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel85)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel84)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel83)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel82)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel81)
        Me.Panel26.Controls.Add(Me.nurdate)
        Me.Panel26.Controls.Add(Me.nurpin)
        Me.Panel26.Controls.Add(Me.nurcountry)
        Me.Panel26.Controls.Add(Me.nurstate)
        Me.Panel26.Controls.Add(Me.nurcity)
        Me.Panel26.Controls.Add(Me.nuradd)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel80)
        Me.Panel26.Controls.Add(Me.nuremail)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel79)
        Me.Panel26.Controls.Add(Me.nurmob)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel76)
        Me.Panel26.Controls.Add(Me.nurgen)
        Me.Panel26.Controls.Add(Me.nurdesig)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel75)
        Me.Panel26.Controls.Add(Me.nurdob)
        Me.Panel26.Controls.Add(Me.nurdoj)
        Me.Panel26.Controls.Add(Me.nurlname)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel74)
        Me.Panel26.Controls.Add(Me.nurfname)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel73)
        Me.Panel26.Controls.Add(Me.nurid)
        Me.Panel26.Controls.Add(Me.BunifuCustomLabel72)
        Me.BunifuTransition1.SetDecoration(Me.Panel26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel26, BunifuAnimatorNS.DecorationType.None)
        Me.Panel26.Location = New System.Drawing.Point(7, 6)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(932, 466)
        Me.Panel26.TabIndex = 74
        '
        'txtsral
        '
        Me.txtsral.BorderColorFocused = System.Drawing.Color.White
        Me.txtsral.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtsral.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtsral.BorderThickness = 1
        Me.txtsral.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtsral, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtsral, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtsral, BunifuAnimatorNS.DecorationType.None)
        Me.txtsral.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtsral.ForeColor = System.Drawing.Color.White
        Me.txtsral.isPassword = False
        Me.txtsral.Location = New System.Drawing.Point(498, 310)
        Me.txtsral.Margin = New System.Windows.Forms.Padding(4)
        Me.txtsral.Name = "txtsral"
        Me.txtsral.Size = New System.Drawing.Size(332, 30)
        Me.txtsral.TabIndex = 149
        Me.txtsral.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtsral.Visible = False
        '
        'BunifuCustomLabel88
        '
        Me.BunifuCustomLabel88.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel88, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel88, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel88, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel88.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel88.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel88.Location = New System.Drawing.Point(495, 229)
        Me.BunifuCustomLabel88.Name = "BunifuCustomLabel88"
        Me.BunifuCustomLabel88.Size = New System.Drawing.Size(38, 17)
        Me.BunifuCustomLabel88.TabIndex = 148
        Me.BunifuCustomLabel88.Text = "Date"
        '
        'BunifuCustomLabel87
        '
        Me.BunifuCustomLabel87.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel87, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel87, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel87, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel87.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel87.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel87.Location = New System.Drawing.Point(495, 188)
        Me.BunifuCustomLabel87.Name = "BunifuCustomLabel87"
        Me.BunifuCustomLabel87.Size = New System.Drawing.Size(65, 17)
        Me.BunifuCustomLabel87.TabIndex = 147
        Me.BunifuCustomLabel87.Text = "Pin Code"
        '
        'BunifuCustomLabel86
        '
        Me.BunifuCustomLabel86.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel86, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel86, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel86, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel86.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel86.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel86.Location = New System.Drawing.Point(495, 148)
        Me.BunifuCustomLabel86.Name = "BunifuCustomLabel86"
        Me.BunifuCustomLabel86.Size = New System.Drawing.Size(57, 17)
        Me.BunifuCustomLabel86.TabIndex = 146
        Me.BunifuCustomLabel86.Text = "Country"
        '
        'BunifuCustomLabel85
        '
        Me.BunifuCustomLabel85.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel85, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel85, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel85, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel85.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel85.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel85.Location = New System.Drawing.Point(495, 109)
        Me.BunifuCustomLabel85.Name = "BunifuCustomLabel85"
        Me.BunifuCustomLabel85.Size = New System.Drawing.Size(41, 17)
        Me.BunifuCustomLabel85.TabIndex = 145
        Me.BunifuCustomLabel85.Text = "State"
        '
        'BunifuCustomLabel84
        '
        Me.BunifuCustomLabel84.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel84, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel84, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel84, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel84.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel84.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel84.Location = New System.Drawing.Point(495, 71)
        Me.BunifuCustomLabel84.Name = "BunifuCustomLabel84"
        Me.BunifuCustomLabel84.Size = New System.Drawing.Size(31, 17)
        Me.BunifuCustomLabel84.TabIndex = 144
        Me.BunifuCustomLabel84.Text = "City"
        '
        'BunifuCustomLabel83
        '
        Me.BunifuCustomLabel83.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel83, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel83, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel83, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel83.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel83.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel83.Location = New System.Drawing.Point(14, 267)
        Me.BunifuCustomLabel83.Name = "BunifuCustomLabel83"
        Me.BunifuCustomLabel83.Size = New System.Drawing.Size(56, 17)
        Me.BunifuCustomLabel83.TabIndex = 143
        Me.BunifuCustomLabel83.Text = "Gender"
        '
        'BunifuCustomLabel82
        '
        Me.BunifuCustomLabel82.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel82, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel82, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel82, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel82.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel82.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel82.Location = New System.Drawing.Point(14, 183)
        Me.BunifuCustomLabel82.Name = "BunifuCustomLabel82"
        Me.BunifuCustomLabel82.Size = New System.Drawing.Size(87, 17)
        Me.BunifuCustomLabel82.TabIndex = 142
        Me.BunifuCustomLabel82.Text = "Date of Birth"
        '
        'BunifuCustomLabel81
        '
        Me.BunifuCustomLabel81.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel81, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel81, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel81, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel81.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel81.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel81.Location = New System.Drawing.Point(14, 149)
        Me.BunifuCustomLabel81.Name = "BunifuCustomLabel81"
        Me.BunifuCustomLabel81.Size = New System.Drawing.Size(103, 17)
        Me.BunifuCustomLabel81.TabIndex = 141
        Me.BunifuCustomLabel81.Text = "Date of Joining"
        '
        'nurdate
        '
        Me.BunifuTransition3.SetDecoration(Me.nurdate, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurdate, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurdate, BunifuAnimatorNS.DecorationType.None)
        Me.nurdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurdate.Location = New System.Drawing.Point(566, 225)
        Me.nurdate.Name = "nurdate"
        Me.nurdate.Size = New System.Drawing.Size(332, 26)
        Me.nurdate.TabIndex = 140
        '
        'nurpin
        '
        Me.BunifuTransition1.SetDecoration(Me.nurpin, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurpin, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.nurpin, BunifuAnimatorNS.DecorationType.None)
        Me.nurpin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurpin.Location = New System.Drawing.Point(566, 184)
        Me.nurpin.Mask = "000-999"
        Me.nurpin.Name = "nurpin"
        Me.nurpin.Size = New System.Drawing.Size(332, 26)
        Me.nurpin.TabIndex = 139
        '
        'nurcountry
        '
        Me.BunifuTransition2.SetDecoration(Me.nurcountry, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurcountry, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.nurcountry, BunifuAnimatorNS.DecorationType.None)
        Me.nurcountry.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurcountry.FormattingEnabled = True
        Me.nurcountry.Items.AddRange(New Object() {"India"})
        Me.nurcountry.Location = New System.Drawing.Point(566, 143)
        Me.nurcountry.Name = "nurcountry"
        Me.nurcountry.Size = New System.Drawing.Size(332, 28)
        Me.nurcountry.TabIndex = 138
        '
        'nurstate
        '
        Me.BunifuTransition2.SetDecoration(Me.nurstate, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurstate, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.nurstate, BunifuAnimatorNS.DecorationType.None)
        Me.nurstate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurstate.FormattingEnabled = True
        Me.nurstate.Items.AddRange(New Object() {"Maharashtra"})
        Me.nurstate.Location = New System.Drawing.Point(566, 104)
        Me.nurstate.Name = "nurstate"
        Me.nurstate.Size = New System.Drawing.Size(332, 28)
        Me.nurstate.TabIndex = 137
        '
        'nurcity
        '
        Me.BunifuTransition2.SetDecoration(Me.nurcity, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurcity, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.nurcity, BunifuAnimatorNS.DecorationType.None)
        Me.nurcity.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurcity.FormattingEnabled = True
        Me.nurcity.Items.AddRange(New Object() {"Nagpur", "Wardha", "yavatmal", "Amravati", "Chandrapur"})
        Me.nurcity.Location = New System.Drawing.Point(566, 66)
        Me.nurcity.Name = "nurcity"
        Me.nurcity.Size = New System.Drawing.Size(332, 28)
        Me.nurcity.TabIndex = 136
        '
        'nuradd
        '
        Me.nuradd.BorderColorFocused = System.Drawing.Color.White
        Me.nuradd.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nuradd.BorderColorMouseHover = System.Drawing.Color.White
        Me.nuradd.BorderThickness = 1
        Me.nuradd.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nuradd, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nuradd, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nuradd, BunifuAnimatorNS.DecorationType.None)
        Me.nuradd.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nuradd.ForeColor = System.Drawing.Color.White
        Me.nuradd.isPassword = False
        Me.nuradd.Location = New System.Drawing.Point(566, 27)
        Me.nuradd.Margin = New System.Windows.Forms.Padding(4)
        Me.nuradd.Name = "nuradd"
        Me.nuradd.Size = New System.Drawing.Size(332, 30)
        Me.nuradd.TabIndex = 135
        Me.nuradd.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel80
        '
        Me.BunifuCustomLabel80.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel80, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel80, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel80, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel80.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel80.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel80.Location = New System.Drawing.Point(495, 33)
        Me.BunifuCustomLabel80.Name = "BunifuCustomLabel80"
        Me.BunifuCustomLabel80.Size = New System.Drawing.Size(60, 17)
        Me.BunifuCustomLabel80.TabIndex = 134
        Me.BunifuCustomLabel80.Text = "Address"
        '
        'nuremail
        '
        Me.nuremail.BorderColorFocused = System.Drawing.Color.White
        Me.nuremail.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nuremail.BorderColorMouseHover = System.Drawing.Color.White
        Me.nuremail.BorderThickness = 1
        Me.nuremail.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nuremail, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nuremail, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nuremail, BunifuAnimatorNS.DecorationType.None)
        Me.nuremail.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nuremail.ForeColor = System.Drawing.Color.White
        Me.nuremail.isPassword = False
        Me.nuremail.Location = New System.Drawing.Point(124, 341)
        Me.nuremail.Margin = New System.Windows.Forms.Padding(4)
        Me.nuremail.Name = "nuremail"
        Me.nuremail.Size = New System.Drawing.Size(332, 30)
        Me.nuremail.TabIndex = 133
        Me.nuremail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel79
        '
        Me.BunifuCustomLabel79.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel79, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel79, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel79, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel79.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel79.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel79.Location = New System.Drawing.Point(14, 348)
        Me.BunifuCustomLabel79.Name = "BunifuCustomLabel79"
        Me.BunifuCustomLabel79.Size = New System.Drawing.Size(57, 17)
        Me.BunifuCustomLabel79.TabIndex = 132
        Me.BunifuCustomLabel79.Text = "Email Id"
        '
        'nurmob
        '
        Me.nurmob.BorderColorFocused = System.Drawing.Color.White
        Me.nurmob.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurmob.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurmob.BorderThickness = 1
        Me.nurmob.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurmob, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurmob, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurmob, BunifuAnimatorNS.DecorationType.None)
        Me.nurmob.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurmob.ForeColor = System.Drawing.Color.White
        Me.nurmob.isPassword = False
        Me.nurmob.Location = New System.Drawing.Point(124, 303)
        Me.nurmob.Margin = New System.Windows.Forms.Padding(4)
        Me.nurmob.Name = "nurmob"
        Me.nurmob.Size = New System.Drawing.Size(332, 30)
        Me.nurmob.TabIndex = 131
        Me.nurmob.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel76
        '
        Me.BunifuCustomLabel76.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel76, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel76, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel76, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel76.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel76.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel76.Location = New System.Drawing.Point(14, 310)
        Me.BunifuCustomLabel76.Name = "BunifuCustomLabel76"
        Me.BunifuCustomLabel76.Size = New System.Drawing.Size(49, 17)
        Me.BunifuCustomLabel76.TabIndex = 130
        Me.BunifuCustomLabel76.Text = "Mobile"
        '
        'nurgen
        '
        Me.BunifuTransition2.SetDecoration(Me.nurgen, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurgen, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.nurgen, BunifuAnimatorNS.DecorationType.None)
        Me.nurgen.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurgen.FormattingEnabled = True
        Me.nurgen.Items.AddRange(New Object() {"Male", "Female"})
        Me.nurgen.Location = New System.Drawing.Point(124, 261)
        Me.nurgen.Name = "nurgen"
        Me.nurgen.Size = New System.Drawing.Size(332, 28)
        Me.nurgen.TabIndex = 129
        '
        'nurdesig
        '
        Me.nurdesig.BorderColorFocused = System.Drawing.Color.White
        Me.nurdesig.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurdesig.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurdesig.BorderThickness = 1
        Me.nurdesig.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurdesig, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurdesig, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurdesig, BunifuAnimatorNS.DecorationType.None)
        Me.nurdesig.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurdesig.ForeColor = System.Drawing.Color.White
        Me.nurdesig.isPassword = False
        Me.nurdesig.Location = New System.Drawing.Point(124, 222)
        Me.nurdesig.Margin = New System.Windows.Forms.Padding(4)
        Me.nurdesig.Name = "nurdesig"
        Me.nurdesig.Size = New System.Drawing.Size(332, 30)
        Me.nurdesig.TabIndex = 128
        Me.nurdesig.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel75
        '
        Me.BunifuCustomLabel75.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel75, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel75, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel75, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel75.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel75.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel75.Location = New System.Drawing.Point(14, 229)
        Me.BunifuCustomLabel75.Name = "BunifuCustomLabel75"
        Me.BunifuCustomLabel75.Size = New System.Drawing.Size(83, 17)
        Me.BunifuCustomLabel75.TabIndex = 127
        Me.BunifuCustomLabel75.Text = "Designation"
        '
        'nurdob
        '
        Me.BunifuTransition3.SetDecoration(Me.nurdob, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurdob, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurdob, BunifuAnimatorNS.DecorationType.None)
        Me.nurdob.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurdob.Location = New System.Drawing.Point(124, 183)
        Me.nurdob.Name = "nurdob"
        Me.nurdob.Size = New System.Drawing.Size(332, 26)
        Me.nurdob.TabIndex = 126
        '
        'nurdoj
        '
        Me.BunifuTransition3.SetDecoration(Me.nurdoj, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurdoj, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurdoj, BunifuAnimatorNS.DecorationType.None)
        Me.nurdoj.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurdoj.Location = New System.Drawing.Point(124, 144)
        Me.nurdoj.Name = "nurdoj"
        Me.nurdoj.Size = New System.Drawing.Size(332, 26)
        Me.nurdoj.TabIndex = 125
        '
        'nurlname
        '
        Me.nurlname.BorderColorFocused = System.Drawing.Color.White
        Me.nurlname.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurlname.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurlname.BorderThickness = 1
        Me.nurlname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurlname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurlname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurlname, BunifuAnimatorNS.DecorationType.None)
        Me.nurlname.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurlname.ForeColor = System.Drawing.Color.White
        Me.nurlname.isPassword = False
        Me.nurlname.Location = New System.Drawing.Point(124, 103)
        Me.nurlname.Margin = New System.Windows.Forms.Padding(4)
        Me.nurlname.Name = "nurlname"
        Me.nurlname.Size = New System.Drawing.Size(332, 30)
        Me.nurlname.TabIndex = 124
        Me.nurlname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel74
        '
        Me.BunifuCustomLabel74.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel74, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel74, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel74, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel74.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel74.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel74.Location = New System.Drawing.Point(14, 110)
        Me.BunifuCustomLabel74.Name = "BunifuCustomLabel74"
        Me.BunifuCustomLabel74.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel74.TabIndex = 123
        Me.BunifuCustomLabel74.Text = "Last Name"
        '
        'nurfname
        '
        Me.nurfname.BorderColorFocused = System.Drawing.Color.White
        Me.nurfname.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurfname.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurfname.BorderThickness = 1
        Me.nurfname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurfname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurfname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurfname, BunifuAnimatorNS.DecorationType.None)
        Me.nurfname.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurfname.ForeColor = System.Drawing.Color.White
        Me.nurfname.isPassword = False
        Me.nurfname.Location = New System.Drawing.Point(124, 65)
        Me.nurfname.Margin = New System.Windows.Forms.Padding(4)
        Me.nurfname.Name = "nurfname"
        Me.nurfname.Size = New System.Drawing.Size(332, 30)
        Me.nurfname.TabIndex = 122
        Me.nurfname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel73
        '
        Me.BunifuCustomLabel73.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel73, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel73, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel73, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel73.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel73.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel73.Location = New System.Drawing.Point(14, 72)
        Me.BunifuCustomLabel73.Name = "BunifuCustomLabel73"
        Me.BunifuCustomLabel73.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel73.TabIndex = 121
        Me.BunifuCustomLabel73.Text = "First Name"
        '
        'nurid
        '
        Me.nurid.BorderColorFocused = System.Drawing.Color.White
        Me.nurid.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurid.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurid.BorderThickness = 1
        Me.nurid.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurid, BunifuAnimatorNS.DecorationType.None)
        Me.nurid.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurid.ForeColor = System.Drawing.Color.White
        Me.nurid.isPassword = False
        Me.nurid.Location = New System.Drawing.Point(124, 27)
        Me.nurid.Margin = New System.Windows.Forms.Padding(4)
        Me.nurid.Name = "nurid"
        Me.nurid.Size = New System.Drawing.Size(332, 30)
        Me.nurid.TabIndex = 120
        Me.nurid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel72
        '
        Me.BunifuCustomLabel72.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel72, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel72, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel72, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel72.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel72.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel72.Location = New System.Drawing.Point(14, 34)
        Me.BunifuCustomLabel72.Name = "BunifuCustomLabel72"
        Me.BunifuCustomLabel72.Size = New System.Drawing.Size(61, 17)
        Me.BunifuCustomLabel72.TabIndex = 119
        Me.BunifuCustomLabel72.Text = "Nurse Id"
        '
        'TabPage23
        '
        Me.TabPage23.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage23.Controls.Add(Me.txtmsg)
        Me.TabPage23.Controls.Add(Me.BunifuCustomLabel144)
        Me.TabPage23.Controls.Add(Me.nurward1)
        Me.TabPage23.Controls.Add(Me.nurpassword)
        Me.TabPage23.Controls.Add(Me.BunifuCustomLabel147)
        Me.TabPage23.Controls.Add(Me.nurmob1)
        Me.TabPage23.Controls.Add(Me.BunifuCustomLabel146)
        Me.TabPage23.Controls.Add(Me.nurusername)
        Me.TabPage23.Controls.Add(Me.BunifuCustomLabel145)
        Me.TabPage23.Controls.Add(Me.nurdesig1)
        Me.TabPage23.Controls.Add(Me.BunifuCustomLabel143)
        Me.TabPage23.Controls.Add(Me.nurlname1)
        Me.TabPage23.Controls.Add(Me.BunifuCustomLabel142)
        Me.TabPage23.Controls.Add(Me.nurfname1)
        Me.TabPage23.Controls.Add(Me.BunifuCustomLabel91)
        Me.TabPage23.Controls.Add(Me.BunifuCustomLabel90)
        Me.TabPage23.Controls.Add(Me.nurid1)
        Me.TabPage23.Controls.Add(Me.Panel8)
        Me.TabPage23.Controls.Add(Me.BunifuFlatButton13)
        Me.TabPage23.Controls.Add(Me.BunifuFlatButton12)
        Me.BunifuTransition3.SetDecoration(Me.TabPage23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage23, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage23.Location = New System.Drawing.Point(4, 22)
        Me.TabPage23.Name = "TabPage23"
        Me.TabPage23.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage23.Size = New System.Drawing.Size(949, 411)
        Me.TabPage23.TabIndex = 1
        Me.TabPage23.Text = "TabPage23"
        '
        'txtmsg
        '
        Me.BunifuTransition3.SetDecoration(Me.txtmsg, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtmsg, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtmsg, BunifuAnimatorNS.DecorationType.None)
        Me.txtmsg.Location = New System.Drawing.Point(518, 190)
        Me.txtmsg.Multiline = True
        Me.txtmsg.Name = "txtmsg"
        Me.txtmsg.Size = New System.Drawing.Size(332, 105)
        Me.txtmsg.TabIndex = 165
        Me.txtmsg.Visible = False
        '
        'BunifuCustomLabel144
        '
        Me.BunifuCustomLabel144.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel144, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel144, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel144, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel144.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel144.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel144.Location = New System.Drawing.Point(13, 278)
        Me.BunifuCustomLabel144.Name = "BunifuCustomLabel144"
        Me.BunifuCustomLabel144.Size = New System.Drawing.Size(85, 17)
        Me.BunifuCustomLabel144.TabIndex = 161
        Me.BunifuCustomLabel144.Text = "Select Ward"
        '
        'nurward1
        '
        Me.BunifuTransition2.SetDecoration(Me.nurward1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurward1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.nurward1, BunifuAnimatorNS.DecorationType.None)
        Me.nurward1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurward1.FormattingEnabled = True
        Me.nurward1.Location = New System.Drawing.Point(123, 272)
        Me.nurward1.Name = "nurward1"
        Me.nurward1.Size = New System.Drawing.Size(332, 28)
        Me.nurward1.Sorted = True
        Me.nurward1.TabIndex = 160
        '
        'nurpassword
        '
        Me.nurpassword.BorderColorFocused = System.Drawing.Color.White
        Me.nurpassword.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurpassword.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurpassword.BorderThickness = 1
        Me.nurpassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurpassword, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurpassword, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurpassword, BunifuAnimatorNS.DecorationType.None)
        Me.nurpassword.Enabled = False
        Me.nurpassword.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurpassword.ForeColor = System.Drawing.Color.White
        Me.nurpassword.isPassword = False
        Me.nurpassword.Location = New System.Drawing.Point(123, 350)
        Me.nurpassword.Margin = New System.Windows.Forms.Padding(4)
        Me.nurpassword.Name = "nurpassword"
        Me.nurpassword.Size = New System.Drawing.Size(332, 30)
        Me.nurpassword.TabIndex = 159
        Me.nurpassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel147
        '
        Me.BunifuCustomLabel147.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel147, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel147, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel147, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel147.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel147.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel147.Location = New System.Drawing.Point(13, 357)
        Me.BunifuCustomLabel147.Name = "BunifuCustomLabel147"
        Me.BunifuCustomLabel147.Size = New System.Drawing.Size(69, 17)
        Me.BunifuCustomLabel147.TabIndex = 158
        Me.BunifuCustomLabel147.Text = "Password"
        '
        'nurmob1
        '
        Me.nurmob1.BorderColorFocused = System.Drawing.Color.White
        Me.nurmob1.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurmob1.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurmob1.BorderThickness = 1
        Me.nurmob1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurmob1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurmob1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurmob1, BunifuAnimatorNS.DecorationType.None)
        Me.nurmob1.Enabled = False
        Me.nurmob1.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurmob1.ForeColor = System.Drawing.Color.White
        Me.nurmob1.isPassword = False
        Me.nurmob1.Location = New System.Drawing.Point(123, 235)
        Me.nurmob1.Margin = New System.Windows.Forms.Padding(4)
        Me.nurmob1.Name = "nurmob1"
        Me.nurmob1.Size = New System.Drawing.Size(332, 30)
        Me.nurmob1.TabIndex = 157
        Me.nurmob1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel146
        '
        Me.BunifuCustomLabel146.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel146, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel146, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel146, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel146.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel146.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel146.Location = New System.Drawing.Point(13, 242)
        Me.BunifuCustomLabel146.Name = "BunifuCustomLabel146"
        Me.BunifuCustomLabel146.Size = New System.Drawing.Size(68, 17)
        Me.BunifuCustomLabel146.TabIndex = 156
        Me.BunifuCustomLabel146.Text = "Mobie No"
        '
        'nurusername
        '
        Me.nurusername.BorderColorFocused = System.Drawing.Color.White
        Me.nurusername.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurusername.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurusername.BorderThickness = 1
        Me.nurusername.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurusername, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurusername, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurusername, BunifuAnimatorNS.DecorationType.None)
        Me.nurusername.Enabled = False
        Me.nurusername.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurusername.ForeColor = System.Drawing.Color.White
        Me.nurusername.isPassword = False
        Me.nurusername.Location = New System.Drawing.Point(123, 312)
        Me.nurusername.Margin = New System.Windows.Forms.Padding(4)
        Me.nurusername.Name = "nurusername"
        Me.nurusername.Size = New System.Drawing.Size(332, 30)
        Me.nurusername.TabIndex = 155
        Me.nurusername.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel145
        '
        Me.BunifuCustomLabel145.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel145, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel145, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel145, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel145.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel145.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel145.Location = New System.Drawing.Point(13, 319)
        Me.BunifuCustomLabel145.Name = "BunifuCustomLabel145"
        Me.BunifuCustomLabel145.Size = New System.Drawing.Size(73, 17)
        Me.BunifuCustomLabel145.TabIndex = 154
        Me.BunifuCustomLabel145.Text = "Username"
        '
        'nurdesig1
        '
        Me.nurdesig1.BorderColorFocused = System.Drawing.Color.White
        Me.nurdesig1.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurdesig1.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurdesig1.BorderThickness = 1
        Me.nurdesig1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurdesig1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurdesig1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurdesig1, BunifuAnimatorNS.DecorationType.None)
        Me.nurdesig1.Enabled = False
        Me.nurdesig1.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurdesig1.ForeColor = System.Drawing.Color.White
        Me.nurdesig1.isPassword = False
        Me.nurdesig1.Location = New System.Drawing.Point(123, 196)
        Me.nurdesig1.Margin = New System.Windows.Forms.Padding(4)
        Me.nurdesig1.Name = "nurdesig1"
        Me.nurdesig1.Size = New System.Drawing.Size(332, 30)
        Me.nurdesig1.TabIndex = 151
        Me.nurdesig1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel143
        '
        Me.BunifuCustomLabel143.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel143, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel143, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel143, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel143.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel143.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel143.Location = New System.Drawing.Point(13, 203)
        Me.BunifuCustomLabel143.Name = "BunifuCustomLabel143"
        Me.BunifuCustomLabel143.Size = New System.Drawing.Size(83, 17)
        Me.BunifuCustomLabel143.TabIndex = 150
        Me.BunifuCustomLabel143.Text = "Designation"
        '
        'nurlname1
        '
        Me.nurlname1.BorderColorFocused = System.Drawing.Color.White
        Me.nurlname1.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurlname1.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurlname1.BorderThickness = 1
        Me.nurlname1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurlname1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurlname1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurlname1, BunifuAnimatorNS.DecorationType.None)
        Me.nurlname1.Enabled = False
        Me.nurlname1.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurlname1.ForeColor = System.Drawing.Color.White
        Me.nurlname1.isPassword = False
        Me.nurlname1.Location = New System.Drawing.Point(123, 157)
        Me.nurlname1.Margin = New System.Windows.Forms.Padding(4)
        Me.nurlname1.Name = "nurlname1"
        Me.nurlname1.Size = New System.Drawing.Size(332, 30)
        Me.nurlname1.TabIndex = 149
        Me.nurlname1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel142
        '
        Me.BunifuCustomLabel142.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel142, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel142, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel142, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel142.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel142.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel142.Location = New System.Drawing.Point(13, 164)
        Me.BunifuCustomLabel142.Name = "BunifuCustomLabel142"
        Me.BunifuCustomLabel142.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel142.TabIndex = 148
        Me.BunifuCustomLabel142.Text = "Last Name"
        '
        'nurfname1
        '
        Me.nurfname1.BorderColorFocused = System.Drawing.Color.White
        Me.nurfname1.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.nurfname1.BorderColorMouseHover = System.Drawing.Color.White
        Me.nurfname1.BorderThickness = 1
        Me.nurfname1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.nurfname1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.nurfname1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurfname1, BunifuAnimatorNS.DecorationType.None)
        Me.nurfname1.Enabled = False
        Me.nurfname1.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.nurfname1.ForeColor = System.Drawing.Color.White
        Me.nurfname1.isPassword = False
        Me.nurfname1.Location = New System.Drawing.Point(123, 118)
        Me.nurfname1.Margin = New System.Windows.Forms.Padding(4)
        Me.nurfname1.Name = "nurfname1"
        Me.nurfname1.Size = New System.Drawing.Size(332, 30)
        Me.nurfname1.TabIndex = 147
        Me.nurfname1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel91
        '
        Me.BunifuCustomLabel91.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel91, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel91, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel91, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel91.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel91.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel91.Location = New System.Drawing.Point(13, 125)
        Me.BunifuCustomLabel91.Name = "BunifuCustomLabel91"
        Me.BunifuCustomLabel91.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel91.TabIndex = 146
        Me.BunifuCustomLabel91.Text = "First Name"
        '
        'BunifuCustomLabel90
        '
        Me.BunifuCustomLabel90.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel90, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel90, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel90, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel90.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel90.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel90.Location = New System.Drawing.Point(13, 79)
        Me.BunifuCustomLabel90.Name = "BunifuCustomLabel90"
        Me.BunifuCustomLabel90.Size = New System.Drawing.Size(61, 17)
        Me.BunifuCustomLabel90.TabIndex = 145
        Me.BunifuCustomLabel90.Text = "Nurse Id"
        '
        'nurid1
        '
        Me.BunifuTransition2.SetDecoration(Me.nurid1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.nurid1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.nurid1, BunifuAnimatorNS.DecorationType.None)
        Me.nurid1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nurid1.FormattingEnabled = True
        Me.nurid1.Location = New System.Drawing.Point(123, 73)
        Me.nurid1.Name = "nurid1"
        Me.nurid1.Size = New System.Drawing.Size(332, 28)
        Me.nurid1.TabIndex = 144
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.BunifuCustomLabel89)
        Me.Panel8.Controls.Add(Me.txtCharacters)
        Me.BunifuTransition1.SetDecoration(Me.Panel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel8, BunifuAnimatorNS.DecorationType.None)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel8.Location = New System.Drawing.Point(3, 3)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(943, 45)
        Me.Panel8.TabIndex = 2
        '
        'BunifuCustomLabel89
        '
        Me.BunifuCustomLabel89.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel89, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel89, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel89, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel89.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel89.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel89.Location = New System.Drawing.Point(32, 11)
        Me.BunifuCustomLabel89.Name = "BunifuCustomLabel89"
        Me.BunifuCustomLabel89.Size = New System.Drawing.Size(107, 17)
        Me.BunifuCustomLabel89.TabIndex = 120
        Me.BunifuCustomLabel89.Text = "Ward Allocation"
        '
        'txtCharacters
        '
        Me.txtCharacters.BorderColorFocused = System.Drawing.Color.White
        Me.txtCharacters.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtCharacters.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtCharacters.BorderThickness = 1
        Me.txtCharacters.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtCharacters, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtCharacters, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtCharacters, BunifuAnimatorNS.DecorationType.None)
        Me.txtCharacters.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtCharacters.ForeColor = System.Drawing.Color.White
        Me.txtCharacters.isPassword = False
        Me.txtCharacters.Location = New System.Drawing.Point(506, 4)
        Me.txtCharacters.Margin = New System.Windows.Forms.Padding(4)
        Me.txtCharacters.Name = "txtCharacters"
        Me.txtCharacters.Size = New System.Drawing.Size(332, 30)
        Me.txtCharacters.TabIndex = 162
        Me.txtCharacters.Text = "6"
        Me.txtCharacters.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtCharacters.Visible = False
        '
        'TabPage24
        '
        Me.TabPage24.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage24.Controls.Add(Me.BunifuCustomDataGrid5)
        Me.TabPage24.Controls.Add(Me.BunifuGradientPanel15)
        Me.BunifuTransition3.SetDecoration(Me.TabPage24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage24, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage24.Location = New System.Drawing.Point(4, 22)
        Me.TabPage24.Name = "TabPage24"
        Me.TabPage24.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage24.Size = New System.Drawing.Size(949, 411)
        Me.TabPage24.TabIndex = 2
        Me.TabPage24.Text = "TabPage24"
        '
        'BunifuCustomDataGrid5
        '
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuCustomDataGrid5.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle7
        Me.BunifuCustomDataGrid5.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.BunifuCustomDataGrid5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BunifuCustomDataGrid5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BunifuCustomDataGrid5.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.BunifuCustomDataGrid5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomDataGrid5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomDataGrid5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomDataGrid5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomDataGrid5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BunifuCustomDataGrid5.DoubleBuffered = True
        Me.BunifuCustomDataGrid5.EnableHeadersVisualStyles = False
        Me.BunifuCustomDataGrid5.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuCustomDataGrid5.HeaderForeColor = System.Drawing.Color.White
        Me.BunifuCustomDataGrid5.Location = New System.Drawing.Point(3, 40)
        Me.BunifuCustomDataGrid5.Name = "BunifuCustomDataGrid5"
        Me.BunifuCustomDataGrid5.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.BunifuCustomDataGrid5.Size = New System.Drawing.Size(943, 368)
        Me.BunifuCustomDataGrid5.TabIndex = 19
        '
        'TabPage25
        '
        Me.TabPage25.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition3.SetDecoration(Me.TabPage25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage25, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage25.Location = New System.Drawing.Point(4, 22)
        Me.TabPage25.Name = "TabPage25"
        Me.TabPage25.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage25.Size = New System.Drawing.Size(949, 411)
        Me.TabPage25.TabIndex = 3
        Me.TabPage25.Text = "TabPage25"
        '
        'TabPage27
        '
        Me.TabPage27.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage27.Controls.Add(Me.Panel29)
        Me.BunifuTransition3.SetDecoration(Me.TabPage27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage27, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage27.Location = New System.Drawing.Point(4, 22)
        Me.TabPage27.Name = "TabPage27"
        Me.TabPage27.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage27.Size = New System.Drawing.Size(957, 606)
        Me.TabPage27.TabIndex = 9
        Me.TabPage27.Text = "TabPage27"
        '
        'Panel29
        '
        Me.Panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel29.Controls.Add(Me.BunifuFlatButton32)
        Me.Panel29.Controls.Add(Me.BunifuFlatButton7)
        Me.Panel29.Controls.Add(Me.BunifuCustomLabel65)
        Me.Panel29.Controls.Add(Me.BunifuCustomLabel56)
        Me.Panel29.Controls.Add(Me.Panel30)
        Me.Panel29.Controls.Add(Me.Hcom)
        Me.Panel29.Controls.Add(Me.textboxcom)
        Me.BunifuTransition1.SetDecoration(Me.Panel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel29, BunifuAnimatorNS.DecorationType.None)
        Me.Panel29.Location = New System.Drawing.Point(217, 119)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(569, 268)
        Me.Panel29.TabIndex = 0
        '
        'BunifuCustomLabel65
        '
        Me.BunifuCustomLabel65.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel65, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel65, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel65, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel65.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel65.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel65.Location = New System.Drawing.Point(27, 99)
        Me.BunifuCustomLabel65.Name = "BunifuCustomLabel65"
        Me.BunifuCustomLabel65.Size = New System.Drawing.Size(90, 17)
        Me.BunifuCustomLabel65.TabIndex = 123
        Me.BunifuCustomLabel65.Text = "Temperature"
        '
        'BunifuCustomLabel56
        '
        Me.BunifuCustomLabel56.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel56, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel56, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel56, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel56.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel56.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel56.Location = New System.Drawing.Point(27, 60)
        Me.BunifuCustomLabel56.Name = "BunifuCustomLabel56"
        Me.BunifuCustomLabel56.Size = New System.Drawing.Size(113, 17)
        Me.BunifuCustomLabel56.TabIndex = 120
        Me.BunifuCustomLabel56.Text = "Select Com Port."
        '
        'Panel30
        '
        Me.Panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel30.Controls.Add(Me.BunifuCustomLabel55)
        Me.BunifuTransition1.SetDecoration(Me.Panel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel30, BunifuAnimatorNS.DecorationType.None)
        Me.Panel30.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel30.Location = New System.Drawing.Point(0, 0)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(567, 33)
        Me.Panel30.TabIndex = 122
        '
        'BunifuCustomLabel55
        '
        Me.BunifuCustomLabel55.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel55, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel55, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel55, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel55.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel55.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel55.Location = New System.Drawing.Point(5, 7)
        Me.BunifuCustomLabel55.Name = "BunifuCustomLabel55"
        Me.BunifuCustomLabel55.Size = New System.Drawing.Size(173, 17)
        Me.BunifuCustomLabel55.TabIndex = 119
        Me.BunifuCustomLabel55.Text = "Hardware Communication "
        '
        'Hcom
        '
        Me.BunifuTransition2.SetDecoration(Me.Hcom, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.Hcom, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Hcom, BunifuAnimatorNS.DecorationType.None)
        Me.Hcom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Hcom.FormattingEnabled = True
        Me.Hcom.Location = New System.Drawing.Point(197, 54)
        Me.Hcom.Name = "Hcom"
        Me.Hcom.Size = New System.Drawing.Size(275, 28)
        Me.Hcom.TabIndex = 121
        '
        'textboxcom
        '
        Me.textboxcom.BorderColorFocused = System.Drawing.Color.White
        Me.textboxcom.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.textboxcom.BorderColorMouseHover = System.Drawing.Color.White
        Me.textboxcom.BorderThickness = 1
        Me.textboxcom.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.textboxcom, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.textboxcom, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.textboxcom, BunifuAnimatorNS.DecorationType.None)
        Me.textboxcom.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.textboxcom.ForeColor = System.Drawing.Color.White
        Me.textboxcom.isPassword = False
        Me.textboxcom.Location = New System.Drawing.Point(197, 99)
        Me.textboxcom.Margin = New System.Windows.Forms.Padding(4)
        Me.textboxcom.Name = "textboxcom"
        Me.textboxcom.Size = New System.Drawing.Size(275, 30)
        Me.textboxcom.TabIndex = 120
        Me.textboxcom.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'TabPage28
        '
        Me.TabPage28.Controls.Add(Me.Panel33)
        Me.TabPage28.Controls.Add(Me.Panel32)
        Me.TabPage28.Controls.Add(Me.Panel31)
        Me.TabPage28.Controls.Add(Me.TabControl6)
        Me.BunifuTransition3.SetDecoration(Me.TabPage28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage28, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage28.Location = New System.Drawing.Point(4, 22)
        Me.TabPage28.Name = "TabPage28"
        Me.TabPage28.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage28.Size = New System.Drawing.Size(957, 606)
        Me.TabPage28.TabIndex = 10
        Me.TabPage28.Text = "TabPage28"
        Me.TabPage28.UseVisualStyleBackColor = True
        '
        'Panel33
        '
        Me.Panel33.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Panel33.Controls.Add(Me.BunifuThinButton264)
        Me.Panel33.Controls.Add(Me.BunifuThinButton265)
        Me.Panel33.Controls.Add(Me.BunifuThinButton266)
        Me.Panel33.Controls.Add(Me.BunifuThinButton267)
        Me.Panel33.Controls.Add(Me.BunifuThinButton269)
        Me.Panel33.Controls.Add(Me.BunifuThinButton271)
        Me.Panel33.Controls.Add(Me.BunifuThinButton272)
        Me.Panel33.Controls.Add(Me.BunifuThinButton273)
        Me.Panel33.Controls.Add(Me.BunifuThinButton274)
        Me.Panel33.Controls.Add(Me.BunifuThinButton275)
        Me.BunifuTransition1.SetDecoration(Me.Panel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel33, BunifuAnimatorNS.DecorationType.None)
        Me.Panel33.Location = New System.Drawing.Point(9, 556)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(947, 49)
        Me.Panel33.TabIndex = 38
        '
        'Panel32
        '
        Me.Panel32.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Panel32.Controls.Add(Me.txtdocdelete)
        Me.Panel32.Controls.Add(Me.BunifuFlatButton33)
        Me.Panel32.Controls.Add(Me.BunifuFlatButton41)
        Me.Panel32.Controls.Add(Me.BunifuThinButton254)
        Me.Panel32.Controls.Add(Me.BunifuThinButton257)
        Me.BunifuTransition1.SetDecoration(Me.Panel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel32, BunifuAnimatorNS.DecorationType.None)
        Me.Panel32.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel32.Location = New System.Drawing.Point(3, 48)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(951, 52)
        Me.Panel32.TabIndex = 17
        '
        'txtdocdelete
        '
        Me.txtdocdelete.BorderColorFocused = System.Drawing.Color.White
        Me.txtdocdelete.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdocdelete.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdocdelete.BorderThickness = 1
        Me.txtdocdelete.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtdocdelete, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocdelete, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocdelete, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocdelete.Enabled = False
        Me.txtdocdelete.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdocdelete.ForeColor = System.Drawing.Color.White
        Me.txtdocdelete.isPassword = False
        Me.txtdocdelete.Location = New System.Drawing.Point(598, 7)
        Me.txtdocdelete.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdocdelete.Name = "txtdocdelete"
        Me.txtdocdelete.Size = New System.Drawing.Size(201, 30)
        Me.txtdocdelete.TabIndex = 121
        Me.txtdocdelete.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Panel31
        '
        Me.Panel31.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Panel31.Controls.Add(Me.BunifuCustomLabel150)
        Me.BunifuTransition1.SetDecoration(Me.Panel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel31, BunifuAnimatorNS.DecorationType.None)
        Me.Panel31.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel31.Location = New System.Drawing.Point(3, 3)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(951, 45)
        Me.Panel31.TabIndex = 2
        '
        'BunifuCustomLabel150
        '
        Me.BunifuCustomLabel150.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel150, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel150, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel150, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel150.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel150.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel150.Location = New System.Drawing.Point(18, 10)
        Me.BunifuCustomLabel150.Name = "BunifuCustomLabel150"
        Me.BunifuCustomLabel150.Size = New System.Drawing.Size(155, 26)
        Me.BunifuCustomLabel150.TabIndex = 149
        Me.BunifuCustomLabel150.Text = "Doctor Section"
        '
        'TabControl6
        '
        Me.TabControl6.Controls.Add(Me.TabPage29)
        Me.TabControl6.Controls.Add(Me.TabPage30)
        Me.BunifuTransition1.SetDecoration(Me.TabControl6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabControl6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.TabControl6, BunifuAnimatorNS.DecorationType.None)
        Me.TabControl6.Location = New System.Drawing.Point(5, 80)
        Me.TabControl6.Name = "TabControl6"
        Me.TabControl6.SelectedIndex = 0
        Me.TabControl6.Size = New System.Drawing.Size(927, 454)
        Me.TabControl6.TabIndex = 18
        '
        'TabPage29
        '
        Me.TabPage29.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage29.Controls.Add(Me.Panel34)
        Me.BunifuTransition3.SetDecoration(Me.TabPage29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage29, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage29.Location = New System.Drawing.Point(4, 22)
        Me.TabPage29.Name = "TabPage29"
        Me.TabPage29.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage29.Size = New System.Drawing.Size(919, 428)
        Me.TabPage29.TabIndex = 0
        Me.TabPage29.Text = "TabPage29"
        '
        'Panel34
        '
        Me.Panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel34.Controls.Add(Me.txtdocdob)
        Me.Panel34.Controls.Add(Me.txtdocfullname)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel153)
        Me.Panel34.Controls.Add(Me.txtdoclname)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel152)
        Me.Panel34.Controls.Add(Me.msg2)
        Me.Panel34.Controls.Add(Me.txtcharacter2)
        Me.Panel34.Controls.Add(Me.txtdocdate)
        Me.Panel34.Controls.Add(Me.txtdocpass)
        Me.Panel34.Controls.Add(Me.txtdocusername)
        Me.Panel34.Controls.Add(Me.txtdoccat)
        Me.Panel34.Controls.Add(Me.txtdocaddress)
        Me.Panel34.Controls.Add(Me.txtdocmobile)
        Me.Panel34.Controls.Add(Me.txtdocquali)
        Me.Panel34.Controls.Add(Me.txtdocfname)
        Me.Panel34.Controls.Add(Me.txtdocid1)
        Me.Panel34.Controls.Add(Me.txtdocid)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel162)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel163)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel164)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel167)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel168)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel169)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel170)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel171)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel173)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel174)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel175)
        Me.Panel34.Controls.Add(Me.BunifuCustomLabel176)
        Me.BunifuTransition1.SetDecoration(Me.Panel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.Panel34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.Panel34, BunifuAnimatorNS.DecorationType.None)
        Me.Panel34.Location = New System.Drawing.Point(-7, 4)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(933, 420)
        Me.Panel34.TabIndex = 13
        '
        'txtdocdob
        '
        Me.txtdocdob.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition3.SetDecoration(Me.txtdocdob, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocdob, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocdob, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocdob.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdocdob.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtdocdob.Location = New System.Drawing.Point(151, 238)
        Me.txtdocdob.Name = "txtdocdob"
        Me.txtdocdob.Size = New System.Drawing.Size(332, 23)
        Me.txtdocdob.TabIndex = 173
        '
        'txtdocfullname
        '
        Me.txtdocfullname.BorderColorFocused = System.Drawing.Color.White
        Me.txtdocfullname.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdocfullname.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdocfullname.BorderThickness = 1
        Me.txtdocfullname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtdocfullname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocfullname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocfullname, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocfullname.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdocfullname.ForeColor = System.Drawing.Color.White
        Me.txtdocfullname.isPassword = False
        Me.txtdocfullname.Location = New System.Drawing.Point(151, 198)
        Me.txtdocfullname.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdocfullname.Name = "txtdocfullname"
        Me.txtdocfullname.Size = New System.Drawing.Size(332, 30)
        Me.txtdocfullname.TabIndex = 172
        Me.txtdocfullname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel153
        '
        Me.BunifuCustomLabel153.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel153, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel153, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel153, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel153.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel153.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel153.Location = New System.Drawing.Point(23, 207)
        Me.BunifuCustomLabel153.Name = "BunifuCustomLabel153"
        Me.BunifuCustomLabel153.Size = New System.Drawing.Size(71, 17)
        Me.BunifuCustomLabel153.TabIndex = 171
        Me.BunifuCustomLabel153.Text = "Full Name"
        '
        'txtdoclname
        '
        Me.txtdoclname.BorderColorFocused = System.Drawing.Color.White
        Me.txtdoclname.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdoclname.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdoclname.BorderThickness = 1
        Me.txtdoclname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtdoclname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdoclname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdoclname, BunifuAnimatorNS.DecorationType.None)
        Me.txtdoclname.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdoclname.ForeColor = System.Drawing.Color.White
        Me.txtdoclname.isPassword = False
        Me.txtdoclname.Location = New System.Drawing.Point(151, 159)
        Me.txtdoclname.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdoclname.Name = "txtdoclname"
        Me.txtdoclname.Size = New System.Drawing.Size(332, 30)
        Me.txtdoclname.TabIndex = 170
        Me.txtdoclname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel152
        '
        Me.BunifuCustomLabel152.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel152, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel152, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel152, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel152.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel152.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel152.Location = New System.Drawing.Point(23, 168)
        Me.BunifuCustomLabel152.Name = "BunifuCustomLabel152"
        Me.BunifuCustomLabel152.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel152.TabIndex = 169
        Me.BunifuCustomLabel152.Text = "Last Name"
        '
        'msg2
        '
        Me.BunifuTransition3.SetDecoration(Me.msg2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.msg2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.msg2, BunifuAnimatorNS.DecorationType.None)
        Me.msg2.Location = New System.Drawing.Point(602, 225)
        Me.msg2.Multiline = True
        Me.msg2.Name = "msg2"
        Me.msg2.Size = New System.Drawing.Size(305, 105)
        Me.msg2.TabIndex = 168
        Me.msg2.Visible = False
        '
        'txtcharacter2
        '
        Me.txtcharacter2.BorderColorFocused = System.Drawing.Color.White
        Me.txtcharacter2.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtcharacter2.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtcharacter2.BorderThickness = 1
        Me.txtcharacter2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtcharacter2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtcharacter2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtcharacter2, BunifuAnimatorNS.DecorationType.None)
        Me.txtcharacter2.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtcharacter2.ForeColor = System.Drawing.Color.White
        Me.txtcharacter2.isPassword = False
        Me.txtcharacter2.Location = New System.Drawing.Point(601, 165)
        Me.txtcharacter2.Margin = New System.Windows.Forms.Padding(4)
        Me.txtcharacter2.Name = "txtcharacter2"
        Me.txtcharacter2.Size = New System.Drawing.Size(309, 30)
        Me.txtcharacter2.TabIndex = 163
        Me.txtcharacter2.Text = "6"
        Me.txtcharacter2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtcharacter2.Visible = False
        '
        'txtdocdate
        '
        Me.txtdocdate.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition3.SetDecoration(Me.txtdocdate, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocdate, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocdate, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdocdate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtdocdate.Location = New System.Drawing.Point(601, 129)
        Me.txtdocdate.Name = "txtdocdate"
        Me.txtdocdate.Size = New System.Drawing.Size(305, 23)
        Me.txtdocdate.TabIndex = 133
        '
        'txtdocpass
        '
        Me.txtdocpass.BorderColorFocused = System.Drawing.Color.White
        Me.txtdocpass.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdocpass.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdocpass.BorderThickness = 1
        Me.txtdocpass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtdocpass, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocpass, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocpass, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocpass.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdocpass.ForeColor = System.Drawing.Color.White
        Me.txtdocpass.isPassword = True
        Me.txtdocpass.Location = New System.Drawing.Point(602, 84)
        Me.txtdocpass.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdocpass.Name = "txtdocpass"
        Me.txtdocpass.Size = New System.Drawing.Size(305, 30)
        Me.txtdocpass.TabIndex = 132
        Me.txtdocpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtdocusername
        '
        Me.txtdocusername.BorderColorFocused = System.Drawing.Color.White
        Me.txtdocusername.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdocusername.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdocusername.BorderThickness = 1
        Me.txtdocusername.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtdocusername, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocusername, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocusername, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocusername.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdocusername.ForeColor = System.Drawing.Color.White
        Me.txtdocusername.isPassword = True
        Me.txtdocusername.Location = New System.Drawing.Point(602, 46)
        Me.txtdocusername.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdocusername.Name = "txtdocusername"
        Me.txtdocusername.Size = New System.Drawing.Size(305, 30)
        Me.txtdocusername.TabIndex = 131
        Me.txtdocusername.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtdoccat
        '
        Me.txtdoccat.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition2.SetDecoration(Me.txtdoccat, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdoccat, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtdoccat, BunifuAnimatorNS.DecorationType.None)
        Me.txtdoccat.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtdoccat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdoccat.ForeColor = System.Drawing.Color.White
        Me.txtdoccat.FormattingEnabled = True
        Me.txtdoccat.Items.AddRange(New Object() {"Appendix", "Arthopedic", "Teeth", "Skin"})
        Me.txtdoccat.Location = New System.Drawing.Point(151, 370)
        Me.txtdoccat.Name = "txtdoccat"
        Me.txtdoccat.Size = New System.Drawing.Size(332, 24)
        Me.txtdoccat.TabIndex = 125
        '
        'txtdocaddress
        '
        Me.txtdocaddress.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition2.SetDecoration(Me.txtdocaddress, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocaddress, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtdocaddress, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocaddress.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtdocaddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdocaddress.ForeColor = System.Drawing.Color.White
        Me.txtdocaddress.FormattingEnabled = True
        Me.txtdocaddress.Items.AddRange(New Object() {"Nagpur", "Wardha", "Chandrapur", "Amaravti", "Yavatmal"})
        Me.txtdocaddress.Location = New System.Drawing.Point(151, 339)
        Me.txtdocaddress.Name = "txtdocaddress"
        Me.txtdocaddress.Size = New System.Drawing.Size(332, 24)
        Me.txtdocaddress.TabIndex = 124
        '
        'txtdocmobile
        '
        Me.txtdocmobile.BorderColorFocused = System.Drawing.Color.White
        Me.txtdocmobile.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdocmobile.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdocmobile.BorderThickness = 1
        Me.txtdocmobile.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtdocmobile, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocmobile, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocmobile, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocmobile.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdocmobile.ForeColor = System.Drawing.Color.White
        Me.txtdocmobile.isPassword = False
        Me.txtdocmobile.Location = New System.Drawing.Point(151, 302)
        Me.txtdocmobile.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdocmobile.Name = "txtdocmobile"
        Me.txtdocmobile.Size = New System.Drawing.Size(332, 24)
        Me.txtdocmobile.TabIndex = 123
        Me.txtdocmobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtdocquali
        '
        Me.txtdocquali.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuTransition2.SetDecoration(Me.txtdocquali, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocquali, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.txtdocquali, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocquali.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtdocquali.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdocquali.ForeColor = System.Drawing.Color.White
        Me.txtdocquali.FormattingEnabled = True
        Me.txtdocquali.Items.AddRange(New Object() {"MD", "Dentist", "MBBS"})
        Me.txtdocquali.Location = New System.Drawing.Point(151, 271)
        Me.txtdocquali.Name = "txtdocquali"
        Me.txtdocquali.Size = New System.Drawing.Size(332, 24)
        Me.txtdocquali.TabIndex = 122
        '
        'txtdocfname
        '
        Me.txtdocfname.BorderColorFocused = System.Drawing.Color.White
        Me.txtdocfname.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdocfname.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdocfname.BorderThickness = 1
        Me.txtdocfname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtdocfname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocfname, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocfname, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocfname.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdocfname.ForeColor = System.Drawing.Color.White
        Me.txtdocfname.isPassword = False
        Me.txtdocfname.Location = New System.Drawing.Point(151, 120)
        Me.txtdocfname.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdocfname.Name = "txtdocfname"
        Me.txtdocfname.Size = New System.Drawing.Size(332, 30)
        Me.txtdocfname.TabIndex = 120
        Me.txtdocfname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtdocid1
        '
        Me.txtdocid1.BorderColorFocused = System.Drawing.Color.White
        Me.txtdocid1.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdocid1.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdocid1.BorderThickness = 1
        Me.txtdocid1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtdocid1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocid1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocid1, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocid1.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdocid1.ForeColor = System.Drawing.Color.White
        Me.txtdocid1.isPassword = False
        Me.txtdocid1.Location = New System.Drawing.Point(151, 83)
        Me.txtdocid1.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdocid1.Name = "txtdocid1"
        Me.txtdocid1.Size = New System.Drawing.Size(332, 30)
        Me.txtdocid1.TabIndex = 119
        Me.txtdocid1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtdocid
        '
        Me.txtdocid.BorderColorFocused = System.Drawing.Color.White
        Me.txtdocid.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.txtdocid.BorderColorMouseHover = System.Drawing.Color.White
        Me.txtdocid.BorderThickness = 1
        Me.txtdocid.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuTransition3.SetDecoration(Me.txtdocid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.txtdocid, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.txtdocid, BunifuAnimatorNS.DecorationType.None)
        Me.txtdocid.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.txtdocid.ForeColor = System.Drawing.Color.White
        Me.txtdocid.isPassword = False
        Me.txtdocid.Location = New System.Drawing.Point(151, 46)
        Me.txtdocid.Margin = New System.Windows.Forms.Padding(4)
        Me.txtdocid.Name = "txtdocid"
        Me.txtdocid.Size = New System.Drawing.Size(332, 30)
        Me.txtdocid.TabIndex = 118
        Me.txtdocid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel162
        '
        Me.BunifuCustomLabel162.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel162, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel162, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel162, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel162.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel162.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel162.Location = New System.Drawing.Point(510, 129)
        Me.BunifuCustomLabel162.Name = "BunifuCustomLabel162"
        Me.BunifuCustomLabel162.Size = New System.Drawing.Size(46, 17)
        Me.BunifuCustomLabel162.TabIndex = 116
        Me.BunifuCustomLabel162.Text = "Date1"
        '
        'BunifuCustomLabel163
        '
        Me.BunifuCustomLabel163.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel163, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel163, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel163, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel163.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel163.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel163.Location = New System.Drawing.Point(510, 91)
        Me.BunifuCustomLabel163.Name = "BunifuCustomLabel163"
        Me.BunifuCustomLabel163.Size = New System.Drawing.Size(69, 17)
        Me.BunifuCustomLabel163.TabIndex = 115
        Me.BunifuCustomLabel163.Text = "Password"
        '
        'BunifuCustomLabel164
        '
        Me.BunifuCustomLabel164.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel164, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel164, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel164, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel164.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel164.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel164.Location = New System.Drawing.Point(510, 53)
        Me.BunifuCustomLabel164.Name = "BunifuCustomLabel164"
        Me.BunifuCustomLabel164.Size = New System.Drawing.Size(73, 17)
        Me.BunifuCustomLabel164.TabIndex = 114
        Me.BunifuCustomLabel164.Text = "Username"
        '
        'BunifuCustomLabel167
        '
        Me.BunifuCustomLabel167.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel167, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel167, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel167, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel167.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel167.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel167.Location = New System.Drawing.Point(23, 374)
        Me.BunifuCustomLabel167.Name = "BunifuCustomLabel167"
        Me.BunifuCustomLabel167.Size = New System.Drawing.Size(65, 17)
        Me.BunifuCustomLabel167.TabIndex = 111
        Me.BunifuCustomLabel167.Text = "Catagory"
        '
        'BunifuCustomLabel168
        '
        Me.BunifuCustomLabel168.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel168, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel168, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel168, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel168.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel168.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel168.Location = New System.Drawing.Point(23, 343)
        Me.BunifuCustomLabel168.Name = "BunifuCustomLabel168"
        Me.BunifuCustomLabel168.Size = New System.Drawing.Size(60, 17)
        Me.BunifuCustomLabel168.TabIndex = 110
        Me.BunifuCustomLabel168.Text = "Address"
        '
        'BunifuCustomLabel169
        '
        Me.BunifuCustomLabel169.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel169, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel169, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel169, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel169.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel169.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel169.Location = New System.Drawing.Point(23, 309)
        Me.BunifuCustomLabel169.Name = "BunifuCustomLabel169"
        Me.BunifuCustomLabel169.Size = New System.Drawing.Size(49, 17)
        Me.BunifuCustomLabel169.TabIndex = 109
        Me.BunifuCustomLabel169.Text = "Mobile"
        '
        'BunifuCustomLabel170
        '
        Me.BunifuCustomLabel170.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel170, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel170, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel170, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel170.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel170.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel170.Location = New System.Drawing.Point(23, 275)
        Me.BunifuCustomLabel170.Name = "BunifuCustomLabel170"
        Me.BunifuCustomLabel170.Size = New System.Drawing.Size(86, 17)
        Me.BunifuCustomLabel170.TabIndex = 108
        Me.BunifuCustomLabel170.Text = "Qualification"
        '
        'BunifuCustomLabel171
        '
        Me.BunifuCustomLabel171.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel171, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel171, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel171, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel171.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel171.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel171.Location = New System.Drawing.Point(23, 244)
        Me.BunifuCustomLabel171.Name = "BunifuCustomLabel171"
        Me.BunifuCustomLabel171.Size = New System.Drawing.Size(38, 17)
        Me.BunifuCustomLabel171.TabIndex = 107
        Me.BunifuCustomLabel171.Text = "DOB"
        '
        'BunifuCustomLabel173
        '
        Me.BunifuCustomLabel173.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel173, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel173, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel173, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel173.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel173.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel173.Location = New System.Drawing.Point(23, 129)
        Me.BunifuCustomLabel173.Name = "BunifuCustomLabel173"
        Me.BunifuCustomLabel173.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel173.TabIndex = 106
        Me.BunifuCustomLabel173.Text = "First Name"
        '
        'BunifuCustomLabel174
        '
        Me.BunifuCustomLabel174.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel174, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel174, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel174, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel174.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel174.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel174.Location = New System.Drawing.Point(23, 91)
        Me.BunifuCustomLabel174.Name = "BunifuCustomLabel174"
        Me.BunifuCustomLabel174.Size = New System.Drawing.Size(65, 17)
        Me.BunifuCustomLabel174.TabIndex = 105
        Me.BunifuCustomLabel174.Text = "Doctor Id"
        '
        'BunifuCustomLabel175
        '
        Me.BunifuCustomLabel175.AutoSize = True
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel175, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel175, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel175, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel175.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel175.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel175.Location = New System.Drawing.Point(23, 53)
        Me.BunifuCustomLabel175.Name = "BunifuCustomLabel175"
        Me.BunifuCustomLabel175.Size = New System.Drawing.Size(19, 17)
        Me.BunifuCustomLabel175.TabIndex = 104
        Me.BunifuCustomLabel175.Text = "Id"
        '
        'BunifuCustomLabel176
        '
        Me.BunifuCustomLabel176.AutoSize = True
        Me.BunifuCustomLabel176.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel176, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel176, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel176, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel176.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel176.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel176.Location = New System.Drawing.Point(3, 4)
        Me.BunifuCustomLabel176.Name = "BunifuCustomLabel176"
        Me.BunifuCustomLabel176.Size = New System.Drawing.Size(188, 23)
        Me.BunifuCustomLabel176.TabIndex = 14
        Me.BunifuCustomLabel176.Text = "Enter Doctor Details"
        '
        'TabPage30
        '
        Me.TabPage30.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage30.Controls.Add(Me.BunifuCustomDataGrid1)
        Me.TabPage30.Controls.Add(Me.BunifuGradientPanel16)
        Me.BunifuTransition3.SetDecoration(Me.TabPage30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage30, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage30.Location = New System.Drawing.Point(4, 22)
        Me.TabPage30.Name = "TabPage30"
        Me.TabPage30.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage30.Size = New System.Drawing.Size(919, 428)
        Me.TabPage30.TabIndex = 1
        Me.TabPage30.Text = "TabPage30"
        '
        'BunifuCustomDataGrid1
        '
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle9
        Me.BunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.BunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.BunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomDataGrid1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomDataGrid1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomDataGrid1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomDataGrid1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BunifuCustomDataGrid1.DoubleBuffered = True
        Me.BunifuCustomDataGrid1.EnableHeadersVisualStyles = False
        Me.BunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.White
        Me.BunifuCustomDataGrid1.Location = New System.Drawing.Point(3, 40)
        Me.BunifuCustomDataGrid1.Name = "BunifuCustomDataGrid1"
        Me.BunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.BunifuCustomDataGrid1.Size = New System.Drawing.Size(913, 385)
        Me.BunifuCustomDataGrid1.TabIndex = 20
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 20
        Me.BunifuElipse1.TargetControl = Me
        '
        'BunifuTransition1
        '
        Me.BunifuTransition1.AnimationType = BunifuAnimatorNS.AnimationType.Leaf
        Me.BunifuTransition1.Cursor = Nothing
        Animation1.AnimateOnlyDifferences = True
        Animation1.BlindCoeff = CType(resources.GetObject("Animation1.BlindCoeff"), System.Drawing.PointF)
        Animation1.LeafCoeff = 1.0!
        Animation1.MaxTime = 1.0!
        Animation1.MinTime = 0!
        Animation1.MosaicCoeff = CType(resources.GetObject("Animation1.MosaicCoeff"), System.Drawing.PointF)
        Animation1.MosaicShift = CType(resources.GetObject("Animation1.MosaicShift"), System.Drawing.PointF)
        Animation1.MosaicSize = 0
        Animation1.Padding = New System.Windows.Forms.Padding(0)
        Animation1.RotateCoeff = 0!
        Animation1.RotateLimit = 0!
        Animation1.ScaleCoeff = CType(resources.GetObject("Animation1.ScaleCoeff"), System.Drawing.PointF)
        Animation1.SlideCoeff = CType(resources.GetObject("Animation1.SlideCoeff"), System.Drawing.PointF)
        Animation1.TimeCoeff = 0!
        Animation1.TransparencyCoeff = 0!
        Me.BunifuTransition1.DefaultAnimation = Animation1
        Me.BunifuTransition1.Interval = 100
        Me.BunifuTransition1.MaxAnimationTime = 3000
        '
        'BunifuTransition2
        '
        Me.BunifuTransition2.AnimationType = BunifuAnimatorNS.AnimationType.Leaf
        Me.BunifuTransition2.Cursor = Nothing
        Animation2.AnimateOnlyDifferences = True
        Animation2.BlindCoeff = CType(resources.GetObject("Animation2.BlindCoeff"), System.Drawing.PointF)
        Animation2.LeafCoeff = 1.0!
        Animation2.MaxTime = 1.0!
        Animation2.MinTime = 0!
        Animation2.MosaicCoeff = CType(resources.GetObject("Animation2.MosaicCoeff"), System.Drawing.PointF)
        Animation2.MosaicShift = CType(resources.GetObject("Animation2.MosaicShift"), System.Drawing.PointF)
        Animation2.MosaicSize = 0
        Animation2.Padding = New System.Windows.Forms.Padding(0)
        Animation2.RotateCoeff = 0!
        Animation2.RotateLimit = 0!
        Animation2.ScaleCoeff = CType(resources.GetObject("Animation2.ScaleCoeff"), System.Drawing.PointF)
        Animation2.SlideCoeff = CType(resources.GetObject("Animation2.SlideCoeff"), System.Drawing.PointF)
        Animation2.TimeCoeff = 0!
        Animation2.TransparencyCoeff = 0!
        Me.BunifuTransition2.DefaultAnimation = Animation2
        Me.BunifuTransition2.Interval = 100
        Me.BunifuTransition2.MaxAnimationTime = 3000
        '
        'BunifuElipse2
        '
        Me.BunifuElipse2.ElipseRadius = 25
        Me.BunifuElipse2.TargetControl = Me.BunifuGradientPanel5
        '
        'BunifuTransition3
        '
        Me.BunifuTransition3.AnimationType = BunifuAnimatorNS.AnimationType.HorizSlide
        Me.BunifuTransition3.Cursor = Nothing
        Animation3.AnimateOnlyDifferences = True
        Animation3.BlindCoeff = CType(resources.GetObject("Animation3.BlindCoeff"), System.Drawing.PointF)
        Animation3.LeafCoeff = 0!
        Animation3.MaxTime = 1.0!
        Animation3.MinTime = 0!
        Animation3.MosaicCoeff = CType(resources.GetObject("Animation3.MosaicCoeff"), System.Drawing.PointF)
        Animation3.MosaicShift = CType(resources.GetObject("Animation3.MosaicShift"), System.Drawing.PointF)
        Animation3.MosaicSize = 0
        Animation3.Padding = New System.Windows.Forms.Padding(0)
        Animation3.RotateCoeff = 0!
        Animation3.RotateLimit = 0!
        Animation3.ScaleCoeff = CType(resources.GetObject("Animation3.ScaleCoeff"), System.Drawing.PointF)
        Animation3.SlideCoeff = CType(resources.GetObject("Animation3.SlideCoeff"), System.Drawing.PointF)
        Animation3.TimeCoeff = 0!
        Animation3.TransparencyCoeff = 0!
        Me.BunifuTransition3.DefaultAnimation = Animation3
        Me.BunifuTransition3.Interval = 100
        Me.BunifuTransition3.MaxAnimationTime = 1000
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'BunifuFlatButton31
        '
        Me.BunifuFlatButton31.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton31.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton31.BorderRadius = 0
        Me.BunifuFlatButton31.ButtonText = " Masters"
        Me.BunifuFlatButton31.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton31, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton31.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton31.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton31.Iconimage = Global.officesoft2.My.Resources.Resources.target_keyword
        Me.BunifuFlatButton31.Iconimage_right = Nothing
        Me.BunifuFlatButton31.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton31.Iconimage_Selected = Nothing
        Me.BunifuFlatButton31.IconMarginLeft = 0
        Me.BunifuFlatButton31.IconMarginRight = 0
        Me.BunifuFlatButton31.IconRightVisible = True
        Me.BunifuFlatButton31.IconRightZoom = 0R
        Me.BunifuFlatButton31.IconVisible = True
        Me.BunifuFlatButton31.IconZoom = 60.0R
        Me.BunifuFlatButton31.IsTab = True
        Me.BunifuFlatButton31.Location = New System.Drawing.Point(8, 92)
        Me.BunifuFlatButton31.Name = "BunifuFlatButton31"
        Me.BunifuFlatButton31.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton31.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton31.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton31.selected = False
        Me.BunifuFlatButton31.Size = New System.Drawing.Size(174, 36)
        Me.BunifuFlatButton31.TabIndex = 13
        Me.BunifuFlatButton31.Text = " Masters"
        Me.BunifuFlatButton31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton31.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton31.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton11
        '
        Me.BunifuFlatButton11.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton11.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton11.BorderRadius = 0
        Me.BunifuFlatButton11.ButtonText = "  Accounts"
        Me.BunifuFlatButton11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton11.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton11.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton11.Iconimage = Global.officesoft2.My.Resources.Resources.accounting
        Me.BunifuFlatButton11.Iconimage_right = Nothing
        Me.BunifuFlatButton11.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton11.Iconimage_Selected = Nothing
        Me.BunifuFlatButton11.IconMarginLeft = 0
        Me.BunifuFlatButton11.IconMarginRight = 0
        Me.BunifuFlatButton11.IconRightVisible = True
        Me.BunifuFlatButton11.IconRightZoom = 0R
        Me.BunifuFlatButton11.IconVisible = True
        Me.BunifuFlatButton11.IconZoom = 60.0R
        Me.BunifuFlatButton11.IsTab = True
        Me.BunifuFlatButton11.Location = New System.Drawing.Point(8, 407)
        Me.BunifuFlatButton11.Name = "BunifuFlatButton11"
        Me.BunifuFlatButton11.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton11.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton11.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton11.selected = False
        Me.BunifuFlatButton11.Size = New System.Drawing.Size(174, 36)
        Me.BunifuFlatButton11.TabIndex = 10
        Me.BunifuFlatButton11.Text = "  Accounts"
        Me.BunifuFlatButton11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton11.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton11.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuFlatButton11.Visible = False
        '
        'BunifuFlatButton10
        '
        Me.BunifuFlatButton10.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton10.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton10.BorderRadius = 0
        Me.BunifuFlatButton10.ButtonText = "Salary Details"
        Me.BunifuFlatButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton10.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton10.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton10.Iconimage = Global.officesoft2.My.Resources.Resources.salary
        Me.BunifuFlatButton10.Iconimage_right = Nothing
        Me.BunifuFlatButton10.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton10.Iconimage_Selected = Nothing
        Me.BunifuFlatButton10.IconMarginLeft = 0
        Me.BunifuFlatButton10.IconMarginRight = 0
        Me.BunifuFlatButton10.IconRightVisible = True
        Me.BunifuFlatButton10.IconRightZoom = 0R
        Me.BunifuFlatButton10.IconVisible = True
        Me.BunifuFlatButton10.IconZoom = 60.0R
        Me.BunifuFlatButton10.IsTab = True
        Me.BunifuFlatButton10.Location = New System.Drawing.Point(8, 368)
        Me.BunifuFlatButton10.Name = "BunifuFlatButton10"
        Me.BunifuFlatButton10.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuFlatButton10.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton10.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton10.selected = False
        Me.BunifuFlatButton10.Size = New System.Drawing.Size(174, 36)
        Me.BunifuFlatButton10.TabIndex = 9
        Me.BunifuFlatButton10.Text = "Salary Details"
        Me.BunifuFlatButton10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton10.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton10.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuFlatButton10.Visible = False
        '
        'bunifuFlatButton8
        '
        Me.bunifuFlatButton8.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton8.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton8.BorderRadius = 0
        Me.bunifuFlatButton8.ButtonText = " Back"
        Me.bunifuFlatButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton8, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton8.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton8.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton8.Iconimage = Global.officesoft2.My.Resources.Resources.back
        Me.bunifuFlatButton8.Iconimage_right = Nothing
        Me.bunifuFlatButton8.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton8.Iconimage_Selected = Nothing
        Me.bunifuFlatButton8.IconMarginLeft = 0
        Me.bunifuFlatButton8.IconMarginRight = 0
        Me.bunifuFlatButton8.IconRightVisible = True
        Me.bunifuFlatButton8.IconRightZoom = 0R
        Me.bunifuFlatButton8.IconVisible = True
        Me.bunifuFlatButton8.IconZoom = 60.0R
        Me.bunifuFlatButton8.IsTab = True
        Me.bunifuFlatButton8.Location = New System.Drawing.Point(8, 449)
        Me.bunifuFlatButton8.Name = "bunifuFlatButton8"
        Me.bunifuFlatButton8.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton8.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton8.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton8.selected = False
        Me.bunifuFlatButton8.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton8.TabIndex = 8
        Me.bunifuFlatButton8.Text = " Back"
        Me.bunifuFlatButton8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton8.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton8.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bunifuFlatButton8.Visible = False
        '
        'bunifuFlatButton6
        '
        Me.bunifuFlatButton6.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton6.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton6.BorderRadius = 0
        Me.bunifuFlatButton6.ButtonText = "Add Doctors"
        Me.bunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton6, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton6.Iconimage = Global.officesoft2.My.Resources.Resources.university
        Me.bunifuFlatButton6.Iconimage_right = Nothing
        Me.bunifuFlatButton6.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton6.Iconimage_Selected = Nothing
        Me.bunifuFlatButton6.IconMarginLeft = 0
        Me.bunifuFlatButton6.IconMarginRight = 0
        Me.bunifuFlatButton6.IconRightVisible = True
        Me.bunifuFlatButton6.IconRightZoom = 0R
        Me.bunifuFlatButton6.IconVisible = True
        Me.bunifuFlatButton6.IconZoom = 60.0R
        Me.bunifuFlatButton6.IsTab = True
        Me.bunifuFlatButton6.Location = New System.Drawing.Point(8, 329)
        Me.bunifuFlatButton6.Name = "bunifuFlatButton6"
        Me.bunifuFlatButton6.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton6.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton6.selected = False
        Me.bunifuFlatButton6.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton6.TabIndex = 6
        Me.bunifuFlatButton6.Text = "Add Doctors"
        Me.bunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton6.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton6.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'bunifuImageButton1
        '
        Me.bunifuImageButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuImageButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition1.SetDecoration(Me.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuImageButton1.Image = Global.officesoft2.My.Resources.Resources.menu1
        Me.bunifuImageButton1.ImageActive = Nothing
        Me.bunifuImageButton1.Location = New System.Drawing.Point(160, 5)
        Me.bunifuImageButton1.Name = "bunifuImageButton1"
        Me.bunifuImageButton1.Size = New System.Drawing.Size(35, 23)
        Me.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bunifuImageButton1.TabIndex = 5
        Me.bunifuImageButton1.TabStop = False
        Me.bunifuImageButton1.Zoom = -10
        '
        'bunifuThinButton21
        '
        Me.bunifuThinButton21.ActiveBorderThickness = 1
        Me.bunifuThinButton21.ActiveCornerRadius = 30
        Me.bunifuThinButton21.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.White
        Me.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.White
        Me.bunifuThinButton21.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuThinButton21.BackgroundImage = CType(resources.GetObject("bunifuThinButton21.BackgroundImage"), System.Drawing.Image)
        Me.bunifuThinButton21.ButtonText = "Dashboard"
        Me.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.bunifuThinButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.bunifuThinButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuThinButton21, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuThinButton21.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bunifuThinButton21.ForeColor = System.Drawing.Color.Black
        Me.bunifuThinButton21.IdleBorderThickness = 1
        Me.bunifuThinButton21.IdleCornerRadius = 30
        Me.bunifuThinButton21.IdleFillColor = System.Drawing.Color.White
        Me.bunifuThinButton21.IdleForecolor = System.Drawing.Color.Black
        Me.bunifuThinButton21.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.bunifuThinButton21.Location = New System.Drawing.Point(16, 42)
        Me.bunifuThinButton21.Margin = New System.Windows.Forms.Padding(5)
        Me.bunifuThinButton21.Name = "bunifuThinButton21"
        Me.bunifuThinButton21.Size = New System.Drawing.Size(177, 51)
        Me.bunifuThinButton21.TabIndex = 5
        Me.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'bunifuFlatButton5
        '
        Me.bunifuFlatButton5.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton5.BorderRadius = 0
        Me.bunifuFlatButton5.ButtonText = "Add Ward Type"
        Me.bunifuFlatButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton5, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton5.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton5.Iconimage = Global.officesoft2.My.Resources.Resources.study
        Me.bunifuFlatButton5.Iconimage_right = Nothing
        Me.bunifuFlatButton5.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton5.Iconimage_Selected = Nothing
        Me.bunifuFlatButton5.IconMarginLeft = 0
        Me.bunifuFlatButton5.IconMarginRight = 0
        Me.bunifuFlatButton5.IconRightVisible = True
        Me.bunifuFlatButton5.IconRightZoom = 0R
        Me.bunifuFlatButton5.IconVisible = True
        Me.bunifuFlatButton5.IconZoom = 60.0R
        Me.bunifuFlatButton5.IsTab = True
        Me.bunifuFlatButton5.Location = New System.Drawing.Point(8, 290)
        Me.bunifuFlatButton5.Name = "bunifuFlatButton5"
        Me.bunifuFlatButton5.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton5.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton5.selected = False
        Me.bunifuFlatButton5.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton5.TabIndex = 4
        Me.bunifuFlatButton5.Text = "Add Ward Type"
        Me.bunifuFlatButton5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton5.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton5.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'bunifuFlatButton1
        '
        Me.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton1.BorderRadius = 0
        Me.bunifuFlatButton1.ButtonText = " Add  Patient"
        Me.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton1, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton1.Iconimage = Global.officesoft2.My.Resources.Resources.staff
        Me.bunifuFlatButton1.Iconimage_right = Nothing
        Me.bunifuFlatButton1.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton1.Iconimage_Selected = Nothing
        Me.bunifuFlatButton1.IconMarginLeft = 0
        Me.bunifuFlatButton1.IconMarginRight = 0
        Me.bunifuFlatButton1.IconRightVisible = True
        Me.bunifuFlatButton1.IconRightZoom = 0R
        Me.bunifuFlatButton1.IconVisible = True
        Me.bunifuFlatButton1.IconZoom = 60.0R
        Me.bunifuFlatButton1.IsTab = True
        Me.bunifuFlatButton1.Location = New System.Drawing.Point(8, 134)
        Me.bunifuFlatButton1.Name = "bunifuFlatButton1"
        Me.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton1.selected = False
        Me.bunifuFlatButton1.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton1.TabIndex = 1
        Me.bunifuFlatButton1.Text = " Add  Patient"
        Me.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton1.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'bunifuFlatButton4
        '
        Me.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton4.BorderRadius = 0
        Me.bunifuFlatButton4.ButtonText = " Add Ward"
        Me.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton4, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton4.Iconimage = Global.officesoft2.My.Resources.Resources.tuition_and_fees
        Me.bunifuFlatButton4.Iconimage_right = Nothing
        Me.bunifuFlatButton4.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton4.Iconimage_Selected = Nothing
        Me.bunifuFlatButton4.IconMarginLeft = 0
        Me.bunifuFlatButton4.IconMarginRight = 0
        Me.bunifuFlatButton4.IconRightVisible = True
        Me.bunifuFlatButton4.IconRightZoom = 0R
        Me.bunifuFlatButton4.IconVisible = True
        Me.bunifuFlatButton4.IconZoom = 60.0R
        Me.bunifuFlatButton4.IsTab = True
        Me.bunifuFlatButton4.Location = New System.Drawing.Point(8, 251)
        Me.bunifuFlatButton4.Name = "bunifuFlatButton4"
        Me.bunifuFlatButton4.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton4.selected = False
        Me.bunifuFlatButton4.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton4.TabIndex = 2
        Me.bunifuFlatButton4.Text = " Add Ward"
        Me.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton4.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton4.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'bunifuFlatButton2
        '
        Me.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton2.BorderRadius = 0
        Me.bunifuFlatButton2.ButtonText = " Add Nurse"
        Me.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton2, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton2.Iconimage = Global.officesoft2.My.Resources.Resources.business_people_meeting
        Me.bunifuFlatButton2.Iconimage_right = Nothing
        Me.bunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton2.Iconimage_Selected = Nothing
        Me.bunifuFlatButton2.IconMarginLeft = 0
        Me.bunifuFlatButton2.IconMarginRight = 0
        Me.bunifuFlatButton2.IconRightVisible = True
        Me.bunifuFlatButton2.IconRightZoom = 0R
        Me.bunifuFlatButton2.IconVisible = True
        Me.bunifuFlatButton2.IconZoom = 60.0R
        Me.bunifuFlatButton2.IsTab = True
        Me.bunifuFlatButton2.Location = New System.Drawing.Point(8, 173)
        Me.bunifuFlatButton2.Name = "bunifuFlatButton2"
        Me.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton2.selected = False
        Me.bunifuFlatButton2.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton2.TabIndex = 2
        Me.bunifuFlatButton2.Text = " Add Nurse"
        Me.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'bunifuFlatButton3
        '
        Me.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.bunifuFlatButton3.BorderRadius = 0
        Me.bunifuFlatButton3.ButtonText = " Add Medical"
        Me.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.bunifuFlatButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.bunifuFlatButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.bunifuFlatButton3, BunifuAnimatorNS.DecorationType.None)
        Me.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray
        Me.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent
        Me.bunifuFlatButton3.Iconimage = Global.officesoft2.My.Resources.Resources.group_of_males
        Me.bunifuFlatButton3.Iconimage_right = Nothing
        Me.bunifuFlatButton3.Iconimage_right_Selected = Nothing
        Me.bunifuFlatButton3.Iconimage_Selected = Nothing
        Me.bunifuFlatButton3.IconMarginLeft = 0
        Me.bunifuFlatButton3.IconMarginRight = 0
        Me.bunifuFlatButton3.IconRightVisible = True
        Me.bunifuFlatButton3.IconRightZoom = 0R
        Me.bunifuFlatButton3.IconVisible = True
        Me.bunifuFlatButton3.IconZoom = 60.0R
        Me.bunifuFlatButton3.IsTab = True
        Me.bunifuFlatButton3.Location = New System.Drawing.Point(8, 212)
        Me.bunifuFlatButton3.Name = "bunifuFlatButton3"
        Me.bunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White
        Me.bunifuFlatButton3.selected = False
        Me.bunifuFlatButton3.Size = New System.Drawing.Size(174, 36)
        Me.bunifuFlatButton3.TabIndex = 3
        Me.bunifuFlatButton3.Text = " Add Medical"
        Me.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bunifuFlatButton3.Textcolor = System.Drawing.Color.White
        Me.bunifuFlatButton3.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuImageButton2
        '
        Me.BunifuImageButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.BunifuTransition1.SetDecoration(Me.BunifuImageButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuImageButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuImageButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuImageButton2.Image = Global.officesoft2.My.Resources.Resources.close
        Me.BunifuImageButton2.ImageActive = Nothing
        Me.BunifuImageButton2.Location = New System.Drawing.Point(1119, 8)
        Me.BunifuImageButton2.Name = "BunifuImageButton2"
        Me.BunifuImageButton2.Size = New System.Drawing.Size(21, 30)
        Me.BunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuImageButton2.TabIndex = 12
        Me.BunifuImageButton2.TabStop = False
        Me.BunifuImageButton2.Zoom = 10
        '
        'BunifuGradientPanel8
        '
        Me.BunifuGradientPanel8.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel8.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel8.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel8.Controls.Add(Me.BunifuCustomLabel71)
        Me.BunifuGradientPanel8.Controls.Add(Me.BunifuCustomLabel44)
        Me.BunifuGradientPanel8.Controls.Add(Me.PictureBox6)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel8.GradientBottomLeft = System.Drawing.Color.WhiteSmoke
        Me.BunifuGradientPanel8.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuGradientPanel8.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.BunifuGradientPanel8.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel8.Location = New System.Drawing.Point(496, 157)
        Me.BunifuGradientPanel8.Name = "BunifuGradientPanel8"
        Me.BunifuGradientPanel8.Quality = 10
        Me.BunifuGradientPanel8.Size = New System.Drawing.Size(423, 118)
        Me.BunifuGradientPanel8.TabIndex = 18
        '
        'BunifuCustomLabel71
        '
        Me.BunifuCustomLabel71.AutoSize = True
        Me.BunifuCustomLabel71.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel71, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel71, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel71, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel71.Font = New System.Drawing.Font("Century Gothic", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel71.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel71.Location = New System.Drawing.Point(232, 54)
        Me.BunifuCustomLabel71.Name = "BunifuCustomLabel71"
        Me.BunifuCustomLabel71.Size = New System.Drawing.Size(45, 32)
        Me.BunifuCustomLabel71.TabIndex = 13
        Me.BunifuCustomLabel71.Text = "24"
        '
        'BunifuCustomLabel44
        '
        Me.BunifuCustomLabel44.AutoSize = True
        Me.BunifuCustomLabel44.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel44, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel44, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel44, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel44.Font = New System.Drawing.Font("Century Gothic", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel44.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel44.Location = New System.Drawing.Point(154, 10)
        Me.BunifuCustomLabel44.Name = "BunifuCustomLabel44"
        Me.BunifuCustomLabel44.Size = New System.Drawing.Size(209, 32)
        Me.BunifuCustomLabel44.TabIndex = 12
        Me.BunifuCustomLabel44.Text = "Total AC Ward "
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.PictureBox6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PictureBox6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.PictureBox6, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox6.Image = Global.officesoft2.My.Resources.Resources.accounting
        Me.PictureBox6.Location = New System.Drawing.Point(50, 13)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(47, 43)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 11
        Me.PictureBox6.TabStop = False
        '
        'BunifuGradientPanel7
        '
        Me.BunifuGradientPanel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel7.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel7.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel7.Controls.Add(Me.BunifuCustomLabel67)
        Me.BunifuGradientPanel7.Controls.Add(Me.BunifuCustomLabel52)
        Me.BunifuGradientPanel7.Controls.Add(Me.PictureBox5)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel7.GradientBottomLeft = System.Drawing.Color.WhiteSmoke
        Me.BunifuGradientPanel7.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuGradientPanel7.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.BunifuGradientPanel7.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel7.Location = New System.Drawing.Point(40, 157)
        Me.BunifuGradientPanel7.Name = "BunifuGradientPanel7"
        Me.BunifuGradientPanel7.Quality = 10
        Me.BunifuGradientPanel7.Size = New System.Drawing.Size(429, 118)
        Me.BunifuGradientPanel7.TabIndex = 17
        '
        'BunifuCustomLabel67
        '
        Me.BunifuCustomLabel67.AutoSize = True
        Me.BunifuCustomLabel67.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel67, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel67, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel67, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel67.Font = New System.Drawing.Font("Century Gothic", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel67.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel67.Location = New System.Drawing.Point(218, 54)
        Me.BunifuCustomLabel67.Name = "BunifuCustomLabel67"
        Me.BunifuCustomLabel67.Size = New System.Drawing.Size(45, 32)
        Me.BunifuCustomLabel67.TabIndex = 12
        Me.BunifuCustomLabel67.Text = "24"
        '
        'BunifuCustomLabel52
        '
        Me.BunifuCustomLabel52.AutoSize = True
        Me.BunifuCustomLabel52.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel52, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel52, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel52, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel52.Font = New System.Drawing.Font("Century Gothic", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel52.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel52.Location = New System.Drawing.Point(149, 9)
        Me.BunifuCustomLabel52.Name = "BunifuCustomLabel52"
        Me.BunifuCustomLabel52.Size = New System.Drawing.Size(266, 32)
        Me.BunifuCustomLabel52.TabIndex = 10
        Me.BunifuCustomLabel52.Text = "Total General Ward"
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.PictureBox5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PictureBox5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.PictureBox5, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox5.Image = Global.officesoft2.My.Resources.Resources.accounting
        Me.PictureBox5.Location = New System.Drawing.Point(20, 14)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(94, 75)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 1
        Me.PictureBox5.TabStop = False
        '
        'BunifuGradientPanel12
        '
        Me.BunifuGradientPanel12.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel12.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel12.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel12.Controls.Add(Me.BunifuCustomLabel53)
        Me.BunifuGradientPanel12.Controls.Add(Me.PictureBox10)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel12.GradientBottomLeft = System.Drawing.Color.WhiteSmoke
        Me.BunifuGradientPanel12.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuGradientPanel12.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.BunifuGradientPanel12.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel12.Location = New System.Drawing.Point(757, 167)
        Me.BunifuGradientPanel12.Name = "BunifuGradientPanel12"
        Me.BunifuGradientPanel12.Quality = 10
        Me.BunifuGradientPanel12.Size = New System.Drawing.Size(138, 104)
        Me.BunifuGradientPanel12.TabIndex = 18
        Me.BunifuGradientPanel12.Visible = False
        '
        'BunifuCustomLabel53
        '
        Me.BunifuCustomLabel53.AutoSize = True
        Me.BunifuCustomLabel53.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel53, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel53, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel53, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel53.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel53.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel53.Location = New System.Drawing.Point(38, 69)
        Me.BunifuCustomLabel53.Name = "BunifuCustomLabel53"
        Me.BunifuCustomLabel53.Size = New System.Drawing.Size(55, 17)
        Me.BunifuCustomLabel53.TabIndex = 18
        Me.BunifuCustomLabel53.Text = "Ward 6"
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.PictureBox10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PictureBox10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.PictureBox10, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox10.Image = Global.officesoft2.My.Resources.Resources.accounting
        Me.PictureBox10.Location = New System.Drawing.Point(40, 13)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(47, 43)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox10.TabIndex = 15
        Me.PictureBox10.TabStop = False
        '
        'BunifuGradientPanel9
        '
        Me.BunifuGradientPanel9.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel9.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel9.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel9.Controls.Add(Me.BunifuCustomLabel46)
        Me.BunifuGradientPanel9.Controls.Add(Me.PictureBox7)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel9.GradientBottomLeft = System.Drawing.Color.WhiteSmoke
        Me.BunifuGradientPanel9.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuGradientPanel9.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.BunifuGradientPanel9.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel9.Location = New System.Drawing.Point(757, 163)
        Me.BunifuGradientPanel9.Name = "BunifuGradientPanel9"
        Me.BunifuGradientPanel9.Quality = 10
        Me.BunifuGradientPanel9.Size = New System.Drawing.Size(138, 104)
        Me.BunifuGradientPanel9.TabIndex = 18
        Me.BunifuGradientPanel9.Visible = False
        '
        'BunifuCustomLabel46
        '
        Me.BunifuCustomLabel46.AutoSize = True
        Me.BunifuCustomLabel46.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel46, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel46, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel46, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel46.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel46.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel46.Location = New System.Drawing.Point(43, 69)
        Me.BunifuCustomLabel46.Name = "BunifuCustomLabel46"
        Me.BunifuCustomLabel46.Size = New System.Drawing.Size(55, 17)
        Me.BunifuCustomLabel46.TabIndex = 14
        Me.BunifuCustomLabel46.Text = "Ward 3"
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.PictureBox7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PictureBox7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.PictureBox7, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox7.Image = Global.officesoft2.My.Resources.Resources.accounting
        Me.PictureBox7.Location = New System.Drawing.Point(45, 13)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(47, 43)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 12
        Me.PictureBox7.TabStop = False
        '
        'BunifuGradientPanel10
        '
        Me.BunifuGradientPanel10.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel10.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel10.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel10.Controls.Add(Me.BunifuCustomLabel48)
        Me.BunifuGradientPanel10.Controls.Add(Me.PictureBox8)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel10.GradientBottomLeft = System.Drawing.Color.WhiteSmoke
        Me.BunifuGradientPanel10.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuGradientPanel10.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.BunifuGradientPanel10.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel10.Location = New System.Drawing.Point(757, 167)
        Me.BunifuGradientPanel10.Name = "BunifuGradientPanel10"
        Me.BunifuGradientPanel10.Quality = 10
        Me.BunifuGradientPanel10.Size = New System.Drawing.Size(138, 104)
        Me.BunifuGradientPanel10.TabIndex = 18
        Me.BunifuGradientPanel10.Visible = False
        '
        'BunifuCustomLabel48
        '
        Me.BunifuCustomLabel48.AutoSize = True
        Me.BunifuCustomLabel48.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel48, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel48, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel48, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel48.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel48.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel48.Location = New System.Drawing.Point(42, 69)
        Me.BunifuCustomLabel48.Name = "BunifuCustomLabel48"
        Me.BunifuCustomLabel48.Size = New System.Drawing.Size(55, 17)
        Me.BunifuCustomLabel48.TabIndex = 14
        Me.BunifuCustomLabel48.Text = "Ward 4"
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.PictureBox8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PictureBox8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.PictureBox8, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox8.Image = Global.officesoft2.My.Resources.Resources.accounting
        Me.PictureBox8.Location = New System.Drawing.Point(44, 13)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(47, 43)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox8.TabIndex = 13
        Me.PictureBox8.TabStop = False
        '
        'BunifuGradientPanel11
        '
        Me.BunifuGradientPanel11.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel11.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel11.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel11.Controls.Add(Me.BunifuCustomLabel50)
        Me.BunifuGradientPanel11.Controls.Add(Me.PictureBox9)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel11.GradientBottomLeft = System.Drawing.Color.WhiteSmoke
        Me.BunifuGradientPanel11.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuGradientPanel11.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.BunifuGradientPanel11.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel11.Location = New System.Drawing.Point(757, 167)
        Me.BunifuGradientPanel11.Name = "BunifuGradientPanel11"
        Me.BunifuGradientPanel11.Quality = 10
        Me.BunifuGradientPanel11.Size = New System.Drawing.Size(138, 104)
        Me.BunifuGradientPanel11.TabIndex = 19
        Me.BunifuGradientPanel11.Visible = False
        '
        'BunifuCustomLabel50
        '
        Me.BunifuCustomLabel50.AutoSize = True
        Me.BunifuCustomLabel50.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel50, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel50, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel50, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel50.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel50.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel50.Location = New System.Drawing.Point(48, 69)
        Me.BunifuCustomLabel50.Name = "BunifuCustomLabel50"
        Me.BunifuCustomLabel50.Size = New System.Drawing.Size(55, 17)
        Me.BunifuCustomLabel50.TabIndex = 16
        Me.BunifuCustomLabel50.Text = "Ward 5"
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.PictureBox9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PictureBox9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.PictureBox9, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox9.Image = Global.officesoft2.My.Resources.Resources.accounting
        Me.PictureBox9.Location = New System.Drawing.Point(50, 13)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(47, 43)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 14
        Me.PictureBox9.TabStop = False
        '
        'BunifuCircleProgressbar6
        '
        Me.BunifuCircleProgressbar6.animated = False
        Me.BunifuCircleProgressbar6.animationIterval = 5
        Me.BunifuCircleProgressbar6.animationSpeed = 300
        Me.BunifuCircleProgressbar6.BackColor = System.Drawing.Color.White
        Me.BunifuCircleProgressbar6.BackgroundImage = CType(resources.GetObject("BunifuCircleProgressbar6.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCircleProgressbar6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCircleProgressbar6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCircleProgressbar6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCircleProgressbar6.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!)
        Me.BunifuCircleProgressbar6.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar6.LabelVisible = False
        Me.BunifuCircleProgressbar6.LineProgressThickness = 8
        Me.BunifuCircleProgressbar6.LineThickness = 5
        Me.BunifuCircleProgressbar6.Location = New System.Drawing.Point(820, 475)
        Me.BunifuCircleProgressbar6.Margin = New System.Windows.Forms.Padding(10, 9, 10, 9)
        Me.BunifuCircleProgressbar6.MaxValue = 100
        Me.BunifuCircleProgressbar6.Name = "BunifuCircleProgressbar6"
        Me.BunifuCircleProgressbar6.ProgressBackColor = System.Drawing.Color.Gainsboro
        Me.BunifuCircleProgressbar6.ProgressColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar6.Size = New System.Drawing.Size(111, 111)
        Me.BunifuCircleProgressbar6.TabIndex = 25
        Me.BunifuCircleProgressbar6.Value = 50
        Me.BunifuCircleProgressbar6.Visible = False
        '
        'BunifuCircleProgressbar5
        '
        Me.BunifuCircleProgressbar5.animated = False
        Me.BunifuCircleProgressbar5.animationIterval = 5
        Me.BunifuCircleProgressbar5.animationSpeed = 300
        Me.BunifuCircleProgressbar5.BackColor = System.Drawing.Color.White
        Me.BunifuCircleProgressbar5.BackgroundImage = CType(resources.GetObject("BunifuCircleProgressbar5.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCircleProgressbar5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCircleProgressbar5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCircleProgressbar5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCircleProgressbar5.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!)
        Me.BunifuCircleProgressbar5.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar5.LabelVisible = False
        Me.BunifuCircleProgressbar5.LineProgressThickness = 8
        Me.BunifuCircleProgressbar5.LineThickness = 5
        Me.BunifuCircleProgressbar5.Location = New System.Drawing.Point(703, 475)
        Me.BunifuCircleProgressbar5.Margin = New System.Windows.Forms.Padding(10, 9, 10, 9)
        Me.BunifuCircleProgressbar5.MaxValue = 100
        Me.BunifuCircleProgressbar5.Name = "BunifuCircleProgressbar5"
        Me.BunifuCircleProgressbar5.ProgressBackColor = System.Drawing.Color.Gainsboro
        Me.BunifuCircleProgressbar5.ProgressColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar5.Size = New System.Drawing.Size(111, 111)
        Me.BunifuCircleProgressbar5.TabIndex = 24
        Me.BunifuCircleProgressbar5.Value = 65
        Me.BunifuCircleProgressbar5.Visible = False
        '
        'BunifuCircleProgressbar4
        '
        Me.BunifuCircleProgressbar4.animated = False
        Me.BunifuCircleProgressbar4.animationIterval = 5
        Me.BunifuCircleProgressbar4.animationSpeed = 300
        Me.BunifuCircleProgressbar4.BackColor = System.Drawing.Color.White
        Me.BunifuCircleProgressbar4.BackgroundImage = CType(resources.GetObject("BunifuCircleProgressbar4.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCircleProgressbar4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCircleProgressbar4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCircleProgressbar4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCircleProgressbar4.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!)
        Me.BunifuCircleProgressbar4.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar4.LabelVisible = False
        Me.BunifuCircleProgressbar4.LineProgressThickness = 8
        Me.BunifuCircleProgressbar4.LineThickness = 5
        Me.BunifuCircleProgressbar4.Location = New System.Drawing.Point(583, 475)
        Me.BunifuCircleProgressbar4.Margin = New System.Windows.Forms.Padding(10, 9, 10, 9)
        Me.BunifuCircleProgressbar4.MaxValue = 100
        Me.BunifuCircleProgressbar4.Name = "BunifuCircleProgressbar4"
        Me.BunifuCircleProgressbar4.ProgressBackColor = System.Drawing.Color.Gainsboro
        Me.BunifuCircleProgressbar4.ProgressColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar4.Size = New System.Drawing.Size(111, 111)
        Me.BunifuCircleProgressbar4.TabIndex = 23
        Me.BunifuCircleProgressbar4.Value = 100
        Me.BunifuCircleProgressbar4.Visible = False
        '
        'BunifuCircleProgressbar3
        '
        Me.BunifuCircleProgressbar3.animated = False
        Me.BunifuCircleProgressbar3.animationIterval = 5
        Me.BunifuCircleProgressbar3.animationSpeed = 300
        Me.BunifuCircleProgressbar3.BackColor = System.Drawing.Color.White
        Me.BunifuCircleProgressbar3.BackgroundImage = CType(resources.GetObject("BunifuCircleProgressbar3.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCircleProgressbar3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCircleProgressbar3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCircleProgressbar3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCircleProgressbar3.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!)
        Me.BunifuCircleProgressbar3.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar3.LabelVisible = False
        Me.BunifuCircleProgressbar3.LineProgressThickness = 8
        Me.BunifuCircleProgressbar3.LineThickness = 5
        Me.BunifuCircleProgressbar3.Location = New System.Drawing.Point(818, 341)
        Me.BunifuCircleProgressbar3.Margin = New System.Windows.Forms.Padding(10, 9, 10, 9)
        Me.BunifuCircleProgressbar3.MaxValue = 100
        Me.BunifuCircleProgressbar3.Name = "BunifuCircleProgressbar3"
        Me.BunifuCircleProgressbar3.ProgressBackColor = System.Drawing.Color.Gainsboro
        Me.BunifuCircleProgressbar3.ProgressColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar3.Size = New System.Drawing.Size(111, 111)
        Me.BunifuCircleProgressbar3.TabIndex = 22
        Me.BunifuCircleProgressbar3.Value = 75
        Me.BunifuCircleProgressbar3.Visible = False
        '
        'BunifuCircleProgressbar2
        '
        Me.BunifuCircleProgressbar2.animated = False
        Me.BunifuCircleProgressbar2.animationIterval = 5
        Me.BunifuCircleProgressbar2.animationSpeed = 300
        Me.BunifuCircleProgressbar2.BackColor = System.Drawing.Color.White
        Me.BunifuCircleProgressbar2.BackgroundImage = CType(resources.GetObject("BunifuCircleProgressbar2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCircleProgressbar2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCircleProgressbar2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCircleProgressbar2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCircleProgressbar2.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!)
        Me.BunifuCircleProgressbar2.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar2.LabelVisible = False
        Me.BunifuCircleProgressbar2.LineProgressThickness = 8
        Me.BunifuCircleProgressbar2.LineThickness = 5
        Me.BunifuCircleProgressbar2.Location = New System.Drawing.Point(703, 341)
        Me.BunifuCircleProgressbar2.Margin = New System.Windows.Forms.Padding(10, 9, 10, 9)
        Me.BunifuCircleProgressbar2.MaxValue = 100
        Me.BunifuCircleProgressbar2.Name = "BunifuCircleProgressbar2"
        Me.BunifuCircleProgressbar2.ProgressBackColor = System.Drawing.Color.Gainsboro
        Me.BunifuCircleProgressbar2.ProgressColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar2.Size = New System.Drawing.Size(111, 111)
        Me.BunifuCircleProgressbar2.TabIndex = 21
        Me.BunifuCircleProgressbar2.Value = 45
        Me.BunifuCircleProgressbar2.Visible = False
        '
        'BunifuCircleProgressbar1
        '
        Me.BunifuCircleProgressbar1.animated = False
        Me.BunifuCircleProgressbar1.animationIterval = 5
        Me.BunifuCircleProgressbar1.animationSpeed = 300
        Me.BunifuCircleProgressbar1.BackColor = System.Drawing.Color.White
        Me.BunifuCircleProgressbar1.BackgroundImage = CType(resources.GetObject("BunifuCircleProgressbar1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCircleProgressbar1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCircleProgressbar1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuCircleProgressbar1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCircleProgressbar1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!)
        Me.BunifuCircleProgressbar1.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar1.LabelVisible = False
        Me.BunifuCircleProgressbar1.LineProgressThickness = 8
        Me.BunifuCircleProgressbar1.LineThickness = 5
        Me.BunifuCircleProgressbar1.Location = New System.Drawing.Point(583, 341)
        Me.BunifuCircleProgressbar1.Margin = New System.Windows.Forms.Padding(10, 9, 10, 9)
        Me.BunifuCircleProgressbar1.MaxValue = 100
        Me.BunifuCircleProgressbar1.Name = "BunifuCircleProgressbar1"
        Me.BunifuCircleProgressbar1.ProgressBackColor = System.Drawing.Color.Gainsboro
        Me.BunifuCircleProgressbar1.ProgressColor = System.Drawing.Color.SeaGreen
        Me.BunifuCircleProgressbar1.Size = New System.Drawing.Size(111, 111)
        Me.BunifuCircleProgressbar1.TabIndex = 20
        Me.BunifuCircleProgressbar1.Value = 35
        Me.BunifuCircleProgressbar1.Visible = False
        '
        'BunifuGradientPanel1
        '
        Me.BunifuGradientPanel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel1.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel1.Controls.Add(Me.BunifuCustomLabel3)
        Me.BunifuGradientPanel1.Controls.Add(Me.BunifuCustomLabel2)
        Me.BunifuGradientPanel1.Controls.Add(Me.PictureBox1)
        Me.BunifuGradientPanel1.Controls.Add(Me.BunifuCustomLabel1)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.BunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel1.Location = New System.Drawing.Point(40, 15)
        Me.BunifuGradientPanel1.Name = "BunifuGradientPanel1"
        Me.BunifuGradientPanel1.Quality = 10
        Me.BunifuGradientPanel1.Size = New System.Drawing.Size(272, 118)
        Me.BunifuGradientPanel1.TabIndex = 13
        '
        'BunifuCustomLabel3
        '
        Me.BunifuCustomLabel3.AutoSize = True
        Me.BunifuCustomLabel3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel3.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel3.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel3.Location = New System.Drawing.Point(13, 80)
        Me.BunifuCustomLabel3.Name = "BunifuCustomLabel3"
        Me.BunifuCustomLabel3.Size = New System.Drawing.Size(142, 19)
        Me.BunifuCustomLabel3.TabIndex = 11
        Me.BunifuCustomLabel3.Text = "Dummy Text for Info"
        Me.BunifuCustomLabel3.Visible = False
        '
        'BunifuCustomLabel2
        '
        Me.BunifuCustomLabel2.AutoSize = True
        Me.BunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel2.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel2.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel2.Location = New System.Drawing.Point(13, 57)
        Me.BunifuCustomLabel2.Name = "BunifuCustomLabel2"
        Me.BunifuCustomLabel2.Size = New System.Drawing.Size(131, 23)
        Me.BunifuCustomLabel2.TabIndex = 10
        Me.BunifuCustomLabel2.Text = "Total Patients"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.PictureBox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PictureBox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.PictureBox1, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox1.Image = Global.officesoft2.My.Resources.Resources.staff
        Me.PictureBox1.Location = New System.Drawing.Point(152, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(47, 43)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'BunifuCustomLabel1
        '
        Me.BunifuCustomLabel1.AutoSize = True
        Me.BunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel1.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel1.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel1.Location = New System.Drawing.Point(13, 28)
        Me.BunifuCustomLabel1.Name = "BunifuCustomLabel1"
        Me.BunifuCustomLabel1.Size = New System.Drawing.Size(32, 23)
        Me.BunifuCustomLabel1.TabIndex = 9
        Me.BunifuCustomLabel1.Text = "24"
        '
        'BunifuGradientPanel5
        '
        Me.BunifuGradientPanel5.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel5.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel28)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel27)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel26)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel25)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel24)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel23)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel22)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel21)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel20)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel19)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel18)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator5)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator4)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator3)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator2)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuSeparator1)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel17)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel16)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel15)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel14)
        Me.BunifuGradientPanel5.Controls.Add(Me.BunifuCustomLabel13)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel5.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel5.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel5.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel5.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel5.Location = New System.Drawing.Point(10, 333)
        Me.BunifuGradientPanel5.Name = "BunifuGradientPanel5"
        Me.BunifuGradientPanel5.Quality = 10
        Me.BunifuGradientPanel5.Size = New System.Drawing.Size(535, 233)
        Me.BunifuGradientPanel5.TabIndex = 0
        Me.BunifuGradientPanel5.Visible = False
        '
        'BunifuCustomLabel28
        '
        Me.BunifuCustomLabel28.AutoSize = True
        Me.BunifuCustomLabel28.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel28.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel28.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel28.Location = New System.Drawing.Point(446, 194)
        Me.BunifuCustomLabel28.Name = "BunifuCustomLabel28"
        Me.BunifuCustomLabel28.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel28.TabIndex = 32
        Me.BunifuCustomLabel28.Text = "24"
        Me.BunifuCustomLabel28.Visible = False
        '
        'BunifuCustomLabel27
        '
        Me.BunifuCustomLabel27.AutoSize = True
        Me.BunifuCustomLabel27.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel27.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel27.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel27.Location = New System.Drawing.Point(446, 159)
        Me.BunifuCustomLabel27.Name = "BunifuCustomLabel27"
        Me.BunifuCustomLabel27.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel27.TabIndex = 31
        Me.BunifuCustomLabel27.Text = "24"
        '
        'BunifuCustomLabel26
        '
        Me.BunifuCustomLabel26.AutoSize = True
        Me.BunifuCustomLabel26.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel26.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel26.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel26.Location = New System.Drawing.Point(446, 124)
        Me.BunifuCustomLabel26.Name = "BunifuCustomLabel26"
        Me.BunifuCustomLabel26.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel26.TabIndex = 30
        Me.BunifuCustomLabel26.Text = "24"
        '
        'BunifuCustomLabel25
        '
        Me.BunifuCustomLabel25.AutoSize = True
        Me.BunifuCustomLabel25.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel25.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel25.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel25.Location = New System.Drawing.Point(446, 89)
        Me.BunifuCustomLabel25.Name = "BunifuCustomLabel25"
        Me.BunifuCustomLabel25.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel25.TabIndex = 29
        Me.BunifuCustomLabel25.Text = "24"
        '
        'BunifuCustomLabel24
        '
        Me.BunifuCustomLabel24.AutoSize = True
        Me.BunifuCustomLabel24.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel24.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel24.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel24.Location = New System.Drawing.Point(446, 50)
        Me.BunifuCustomLabel24.Name = "BunifuCustomLabel24"
        Me.BunifuCustomLabel24.Size = New System.Drawing.Size(27, 19)
        Me.BunifuCustomLabel24.TabIndex = 28
        Me.BunifuCustomLabel24.Text = "24"
        '
        'BunifuCustomLabel23
        '
        Me.BunifuCustomLabel23.AutoSize = True
        Me.BunifuCustomLabel23.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel23.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel23.ForeColor = System.Drawing.Color.Black
        Me.BunifuCustomLabel23.Location = New System.Drawing.Point(8, 14)
        Me.BunifuCustomLabel23.Name = "BunifuCustomLabel23"
        Me.BunifuCustomLabel23.Size = New System.Drawing.Size(142, 19)
        Me.BunifuCustomLabel23.TabIndex = 27
        Me.BunifuCustomLabel23.Text = "# Sub Dashboard"
        '
        'BunifuCustomLabel22
        '
        Me.BunifuCustomLabel22.AutoSize = True
        Me.BunifuCustomLabel22.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel22.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel22.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel22.Location = New System.Drawing.Point(4, 194)
        Me.BunifuCustomLabel22.Name = "BunifuCustomLabel22"
        Me.BunifuCustomLabel22.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel22.TabIndex = 26
        Me.BunifuCustomLabel22.Text = "5.)"
        Me.BunifuCustomLabel22.Visible = False
        '
        'BunifuCustomLabel21
        '
        Me.BunifuCustomLabel21.AutoSize = True
        Me.BunifuCustomLabel21.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel21.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel21.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel21.Location = New System.Drawing.Point(4, 159)
        Me.BunifuCustomLabel21.Name = "BunifuCustomLabel21"
        Me.BunifuCustomLabel21.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel21.TabIndex = 25
        Me.BunifuCustomLabel21.Text = "4.)"
        '
        'BunifuCustomLabel20
        '
        Me.BunifuCustomLabel20.AutoSize = True
        Me.BunifuCustomLabel20.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel20.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel20.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel20.Location = New System.Drawing.Point(4, 124)
        Me.BunifuCustomLabel20.Name = "BunifuCustomLabel20"
        Me.BunifuCustomLabel20.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel20.TabIndex = 24
        Me.BunifuCustomLabel20.Text = "3.)"
        '
        'BunifuCustomLabel19
        '
        Me.BunifuCustomLabel19.AutoSize = True
        Me.BunifuCustomLabel19.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel19.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel19.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel19.Location = New System.Drawing.Point(4, 89)
        Me.BunifuCustomLabel19.Name = "BunifuCustomLabel19"
        Me.BunifuCustomLabel19.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel19.TabIndex = 23
        Me.BunifuCustomLabel19.Text = "2.)"
        '
        'BunifuCustomLabel18
        '
        Me.BunifuCustomLabel18.AutoSize = True
        Me.BunifuCustomLabel18.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel18.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel18.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel18.Location = New System.Drawing.Point(4, 54)
        Me.BunifuCustomLabel18.Name = "BunifuCustomLabel18"
        Me.BunifuCustomLabel18.Size = New System.Drawing.Size(28, 19)
        Me.BunifuCustomLabel18.TabIndex = 22
        Me.BunifuCustomLabel18.Text = "1.)"
        '
        'BunifuSeparator5
        '
        Me.BunifuSeparator5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator5.LineThickness = 1
        Me.BunifuSeparator5.Location = New System.Drawing.Point(11, 216)
        Me.BunifuSeparator5.Name = "BunifuSeparator5"
        Me.BunifuSeparator5.Size = New System.Drawing.Size(513, 10)
        Me.BunifuSeparator5.TabIndex = 21
        Me.BunifuSeparator5.Transparency = 255
        Me.BunifuSeparator5.Vertical = False
        '
        'BunifuSeparator4
        '
        Me.BunifuSeparator4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator4.LineThickness = 1
        Me.BunifuSeparator4.Location = New System.Drawing.Point(14, 180)
        Me.BunifuSeparator4.Name = "BunifuSeparator4"
        Me.BunifuSeparator4.Size = New System.Drawing.Size(513, 10)
        Me.BunifuSeparator4.TabIndex = 20
        Me.BunifuSeparator4.Transparency = 255
        Me.BunifuSeparator4.Vertical = False
        '
        'BunifuSeparator3
        '
        Me.BunifuSeparator3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator3.LineThickness = 1
        Me.BunifuSeparator3.Location = New System.Drawing.Point(14, 144)
        Me.BunifuSeparator3.Name = "BunifuSeparator3"
        Me.BunifuSeparator3.Size = New System.Drawing.Size(513, 10)
        Me.BunifuSeparator3.TabIndex = 19
        Me.BunifuSeparator3.Transparency = 255
        Me.BunifuSeparator3.Vertical = False
        '
        'BunifuSeparator2
        '
        Me.BunifuSeparator2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator2.LineThickness = 1
        Me.BunifuSeparator2.Location = New System.Drawing.Point(14, 108)
        Me.BunifuSeparator2.Name = "BunifuSeparator2"
        Me.BunifuSeparator2.Size = New System.Drawing.Size(513, 10)
        Me.BunifuSeparator2.TabIndex = 18
        Me.BunifuSeparator2.Transparency = 255
        Me.BunifuSeparator2.Vertical = False
        '
        'BunifuSeparator1
        '
        Me.BunifuSeparator1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition1.SetDecoration(Me.BunifuSeparator1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuSeparator1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuSeparator1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.BunifuSeparator1.LineThickness = 1
        Me.BunifuSeparator1.Location = New System.Drawing.Point(14, 72)
        Me.BunifuSeparator1.Name = "BunifuSeparator1"
        Me.BunifuSeparator1.Size = New System.Drawing.Size(513, 10)
        Me.BunifuSeparator1.TabIndex = 17
        Me.BunifuSeparator1.Transparency = 255
        Me.BunifuSeparator1.Vertical = False
        '
        'BunifuCustomLabel17
        '
        Me.BunifuCustomLabel17.AutoSize = True
        Me.BunifuCustomLabel17.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel17.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel17.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel17.Location = New System.Drawing.Point(27, 194)
        Me.BunifuCustomLabel17.Name = "BunifuCustomLabel17"
        Me.BunifuCustomLabel17.Size = New System.Drawing.Size(123, 19)
        Me.BunifuCustomLabel17.TabIndex = 16
        Me.BunifuCustomLabel17.Text = "Total Expences"
        Me.BunifuCustomLabel17.Visible = False
        '
        'BunifuCustomLabel16
        '
        Me.BunifuCustomLabel16.AutoSize = True
        Me.BunifuCustomLabel16.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel16.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel16.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel16.Location = New System.Drawing.Point(27, 159)
        Me.BunifuCustomLabel16.Name = "BunifuCustomLabel16"
        Me.BunifuCustomLabel16.Size = New System.Drawing.Size(100, 19)
        Me.BunifuCustomLabel16.TabIndex = 15
        Me.BunifuCustomLabel16.Text = "Total Rooms"
        '
        'BunifuCustomLabel15
        '
        Me.BunifuCustomLabel15.AutoSize = True
        Me.BunifuCustomLabel15.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel15.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel15.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel15.Location = New System.Drawing.Point(27, 124)
        Me.BunifuCustomLabel15.Name = "BunifuCustomLabel15"
        Me.BunifuCustomLabel15.Size = New System.Drawing.Size(108, 19)
        Me.BunifuCustomLabel15.TabIndex = 14
        Me.BunifuCustomLabel15.Text = "Total inquirys"
        '
        'BunifuCustomLabel14
        '
        Me.BunifuCustomLabel14.AutoSize = True
        Me.BunifuCustomLabel14.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel14.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel14.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel14.Location = New System.Drawing.Point(27, 89)
        Me.BunifuCustomLabel14.Name = "BunifuCustomLabel14"
        Me.BunifuCustomLabel14.Size = New System.Drawing.Size(125, 19)
        Me.BunifuCustomLabel14.TabIndex = 13
        Me.BunifuCustomLabel14.Text = "Fees Collection"
        '
        'BunifuCustomLabel13
        '
        Me.BunifuCustomLabel13.AutoSize = True
        Me.BunifuCustomLabel13.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel13.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel13.ForeColor = System.Drawing.Color.Gray
        Me.BunifuCustomLabel13.Location = New System.Drawing.Point(27, 54)
        Me.BunifuCustomLabel13.Name = "BunifuCustomLabel13"
        Me.BunifuCustomLabel13.Size = New System.Drawing.Size(127, 19)
        Me.BunifuCustomLabel13.TabIndex = 12
        Me.BunifuCustomLabel13.Text = "Total Collection"
        '
        'BunifuGradientPanel2
        '
        Me.BunifuGradientPanel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel2.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel2.Controls.Add(Me.BunifuCustomLabel4)
        Me.BunifuGradientPanel2.Controls.Add(Me.PictureBox2)
        Me.BunifuGradientPanel2.Controls.Add(Me.BunifuCustomLabel5)
        Me.BunifuGradientPanel2.Controls.Add(Me.BunifuCustomLabel6)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.BunifuGradientPanel2.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel2.Location = New System.Drawing.Point(337, 15)
        Me.BunifuGradientPanel2.Name = "BunifuGradientPanel2"
        Me.BunifuGradientPanel2.Quality = 10
        Me.BunifuGradientPanel2.Size = New System.Drawing.Size(272, 118)
        Me.BunifuGradientPanel2.TabIndex = 16
        '
        'BunifuCustomLabel4
        '
        Me.BunifuCustomLabel4.AutoSize = True
        Me.BunifuCustomLabel4.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel4.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel4.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel4.Location = New System.Drawing.Point(15, 80)
        Me.BunifuCustomLabel4.Name = "BunifuCustomLabel4"
        Me.BunifuCustomLabel4.Size = New System.Drawing.Size(142, 19)
        Me.BunifuCustomLabel4.TabIndex = 11
        Me.BunifuCustomLabel4.Text = "Dummy Text for Info"
        Me.BunifuCustomLabel4.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.PictureBox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PictureBox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.PictureBox2, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox2.Image = Global.officesoft2.My.Resources.Resources.group_of_males
        Me.PictureBox2.Location = New System.Drawing.Point(152, 3)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(47, 43)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'BunifuCustomLabel5
        '
        Me.BunifuCustomLabel5.AutoSize = True
        Me.BunifuCustomLabel5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel5.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel5.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel5.Location = New System.Drawing.Point(15, 57)
        Me.BunifuCustomLabel5.Name = "BunifuCustomLabel5"
        Me.BunifuCustomLabel5.Size = New System.Drawing.Size(110, 23)
        Me.BunifuCustomLabel5.TabIndex = 10
        Me.BunifuCustomLabel5.Text = "Total Nurse"
        '
        'BunifuCustomLabel6
        '
        Me.BunifuCustomLabel6.AutoSize = True
        Me.BunifuCustomLabel6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel6.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel6.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel6.Location = New System.Drawing.Point(15, 28)
        Me.BunifuCustomLabel6.Name = "BunifuCustomLabel6"
        Me.BunifuCustomLabel6.Size = New System.Drawing.Size(21, 23)
        Me.BunifuCustomLabel6.TabIndex = 9
        Me.BunifuCustomLabel6.Text = "0"
        '
        'BunifuGradientPanel3
        '
        Me.BunifuGradientPanel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel3.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel3.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel3.Controls.Add(Me.PictureBox3)
        Me.BunifuGradientPanel3.Controls.Add(Me.BunifuCustomLabel7)
        Me.BunifuGradientPanel3.Controls.Add(Me.BunifuCustomLabel8)
        Me.BunifuGradientPanel3.Controls.Add(Me.BunifuCustomLabel9)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel3.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel3.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.BunifuGradientPanel3.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.BunifuGradientPanel3.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.BunifuGradientPanel3.Location = New System.Drawing.Point(634, 15)
        Me.BunifuGradientPanel3.Name = "BunifuGradientPanel3"
        Me.BunifuGradientPanel3.Quality = 10
        Me.BunifuGradientPanel3.Size = New System.Drawing.Size(272, 118)
        Me.BunifuGradientPanel3.TabIndex = 15
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.PictureBox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.PictureBox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.PictureBox3, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox3.Image = Global.officesoft2.My.Resources.Resources.multiple_users_silhouette
        Me.PictureBox3.Location = New System.Drawing.Point(152, -1)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(47, 43)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 3
        Me.PictureBox3.TabStop = False
        '
        'BunifuCustomLabel7
        '
        Me.BunifuCustomLabel7.AutoSize = True
        Me.BunifuCustomLabel7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel7.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel7.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel7.Location = New System.Drawing.Point(15, 80)
        Me.BunifuCustomLabel7.Name = "BunifuCustomLabel7"
        Me.BunifuCustomLabel7.Size = New System.Drawing.Size(142, 19)
        Me.BunifuCustomLabel7.TabIndex = 11
        Me.BunifuCustomLabel7.Text = "Dummy Text for Info"
        Me.BunifuCustomLabel7.Visible = False
        '
        'BunifuCustomLabel8
        '
        Me.BunifuCustomLabel8.AutoSize = True
        Me.BunifuCustomLabel8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel8.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel8.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel8.Location = New System.Drawing.Point(15, 57)
        Me.BunifuCustomLabel8.Name = "BunifuCustomLabel8"
        Me.BunifuCustomLabel8.Size = New System.Drawing.Size(128, 23)
        Me.BunifuCustomLabel8.TabIndex = 10
        Me.BunifuCustomLabel8.Text = "Total Doctors"
        '
        'BunifuCustomLabel9
        '
        Me.BunifuCustomLabel9.AutoSize = True
        Me.BunifuCustomLabel9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuTransition3.SetDecoration(Me.BunifuCustomLabel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuCustomLabel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuCustomLabel9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuCustomLabel9.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel9.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel9.Location = New System.Drawing.Point(15, 28)
        Me.BunifuCustomLabel9.Name = "BunifuCustomLabel9"
        Me.BunifuCustomLabel9.Size = New System.Drawing.Size(21, 23)
        Me.BunifuCustomLabel9.TabIndex = 9
        Me.BunifuCustomLabel9.Text = "0"
        '
        'BunifuThinButton210
        '
        Me.BunifuThinButton210.ActiveBorderThickness = 1
        Me.BunifuThinButton210.ActiveCornerRadius = 3
        Me.BunifuThinButton210.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton210.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton210.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton210.AutoSize = True
        Me.BunifuThinButton210.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton210.BackgroundImage = CType(resources.GetObject("BunifuThinButton210.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton210.ButtonText = "Sensor Connection"
        Me.BunifuThinButton210.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton210, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton210, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton210, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton210.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton210.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton210.IdleBorderThickness = 1
        Me.BunifuThinButton210.IdleCornerRadius = 1
        Me.BunifuThinButton210.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton210.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton210.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton210.Location = New System.Drawing.Point(593, 1)
        Me.BunifuThinButton210.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton210.Name = "BunifuThinButton210"
        Me.BunifuThinButton210.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton210.TabIndex = 40
        Me.BunifuThinButton210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton253
        '
        Me.BunifuThinButton253.ActiveBorderThickness = 1
        Me.BunifuThinButton253.ActiveCornerRadius = 2
        Me.BunifuThinButton253.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton253.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton253.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton253.AutoSize = True
        Me.BunifuThinButton253.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton253.BackgroundImage = CType(resources.GetObject("BunifuThinButton253.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton253.ButtonText = "Sign Up"
        Me.BunifuThinButton253.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton253, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton253, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton253, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton253.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton253.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton253.IdleBorderThickness = 1
        Me.BunifuThinButton253.IdleCornerRadius = 1
        Me.BunifuThinButton253.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton253.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton253.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton253.Location = New System.Drawing.Point(593, 0)
        Me.BunifuThinButton253.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton253.Name = "BunifuThinButton253"
        Me.BunifuThinButton253.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton253.TabIndex = 39
        Me.BunifuThinButton253.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton219
        '
        Me.BunifuThinButton219.ActiveBorderThickness = 1
        Me.BunifuThinButton219.ActiveCornerRadius = 3
        Me.BunifuThinButton219.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton219.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton219.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton219.AutoSize = True
        Me.BunifuThinButton219.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton219.BackgroundImage = CType(resources.GetObject("BunifuThinButton219.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton219.ButtonText = "Home"
        Me.BunifuThinButton219.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton219, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton219, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton219, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton219.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton219.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton219.IdleBorderThickness = 1
        Me.BunifuThinButton219.IdleCornerRadius = 1
        Me.BunifuThinButton219.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton219.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton219.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton219.Location = New System.Drawing.Point(739, 1)
        Me.BunifuThinButton219.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton219.Name = "BunifuThinButton219"
        Me.BunifuThinButton219.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton219.TabIndex = 38
        Me.BunifuThinButton219.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton221
        '
        Me.BunifuThinButton221.ActiveBorderThickness = 1
        Me.BunifuThinButton221.ActiveCornerRadius = 2
        Me.BunifuThinButton221.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton221.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton221.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton221.AutoSize = True
        Me.BunifuThinButton221.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton221.BackgroundImage = CType(resources.GetObject("BunifuThinButton221.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton221.ButtonText = "Sign Up"
        Me.BunifuThinButton221.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton221, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton221, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton221, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton221.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton221.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton221.IdleBorderThickness = 1
        Me.BunifuThinButton221.IdleCornerRadius = 1
        Me.BunifuThinButton221.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton221.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton221.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton221.Location = New System.Drawing.Point(739, 0)
        Me.BunifuThinButton221.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton221.Name = "BunifuThinButton221"
        Me.BunifuThinButton221.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton221.TabIndex = 37
        Me.BunifuThinButton221.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton211
        '
        Me.BunifuThinButton211.ActiveBorderThickness = 1
        Me.BunifuThinButton211.ActiveCornerRadius = 3
        Me.BunifuThinButton211.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton211.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton211.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton211.AutoSize = True
        Me.BunifuThinButton211.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton211.BackgroundImage = CType(resources.GetObject("BunifuThinButton211.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton211.ButtonText = "View Record"
        Me.BunifuThinButton211.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton211, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton211, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton211, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton211.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton211.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton211.IdleBorderThickness = 1
        Me.BunifuThinButton211.IdleCornerRadius = 1
        Me.BunifuThinButton211.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton211.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton211.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton211.Location = New System.Drawing.Point(445, 1)
        Me.BunifuThinButton211.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton211.Name = "BunifuThinButton211"
        Me.BunifuThinButton211.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton211.TabIndex = 36
        Me.BunifuThinButton211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton217
        '
        Me.BunifuThinButton217.ActiveBorderThickness = 1
        Me.BunifuThinButton217.ActiveCornerRadius = 2
        Me.BunifuThinButton217.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton217.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton217.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton217.AutoSize = True
        Me.BunifuThinButton217.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton217.BackgroundImage = CType(resources.GetObject("BunifuThinButton217.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton217.ButtonText = "Sign Up"
        Me.BunifuThinButton217.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton217, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton217, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton217, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton217.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton217.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton217.IdleBorderThickness = 1
        Me.BunifuThinButton217.IdleCornerRadius = 1
        Me.BunifuThinButton217.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton217.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton217.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton217.Location = New System.Drawing.Point(445, 0)
        Me.BunifuThinButton217.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton217.Name = "BunifuThinButton217"
        Me.BunifuThinButton217.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton217.TabIndex = 35
        Me.BunifuThinButton217.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton26
        '
        Me.BunifuThinButton26.ActiveBorderThickness = 1
        Me.BunifuThinButton26.ActiveCornerRadius = 3
        Me.BunifuThinButton26.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton26.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton26.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton26.AutoSize = True
        Me.BunifuThinButton26.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton26.BackgroundImage = CType(resources.GetObject("BunifuThinButton26.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton26.ButtonText = "Submit"
        Me.BunifuThinButton26.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton26.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton26.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton26.IdleBorderThickness = 1
        Me.BunifuThinButton26.IdleCornerRadius = 1
        Me.BunifuThinButton26.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton26.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton26.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton26.Location = New System.Drawing.Point(3, 1)
        Me.BunifuThinButton26.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton26.Name = "BunifuThinButton26"
        Me.BunifuThinButton26.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton26.TabIndex = 28
        Me.BunifuThinButton26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton214
        '
        Me.BunifuThinButton214.ActiveBorderThickness = 1
        Me.BunifuThinButton214.ActiveCornerRadius = 3
        Me.BunifuThinButton214.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton214.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton214.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton214.AutoSize = True
        Me.BunifuThinButton214.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton214.BackgroundImage = CType(resources.GetObject("BunifuThinButton214.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton214.ButtonText = "Clear"
        Me.BunifuThinButton214.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton214, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton214, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton214, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton214.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton214.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton214.IdleBorderThickness = 1
        Me.BunifuThinButton214.IdleCornerRadius = 1
        Me.BunifuThinButton214.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton214.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton214.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton214.Location = New System.Drawing.Point(297, 1)
        Me.BunifuThinButton214.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton214.Name = "BunifuThinButton214"
        Me.BunifuThinButton214.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton214.TabIndex = 34
        Me.BunifuThinButton214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton27
        '
        Me.BunifuThinButton27.ActiveBorderThickness = 1
        Me.BunifuThinButton27.ActiveCornerRadius = 2
        Me.BunifuThinButton27.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton27.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton27.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton27.AutoSize = True
        Me.BunifuThinButton27.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton27.BackgroundImage = CType(resources.GetObject("BunifuThinButton27.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton27.ButtonText = "Sign Up"
        Me.BunifuThinButton27.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton27.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton27.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton27.IdleBorderThickness = 1
        Me.BunifuThinButton27.IdleCornerRadius = 1
        Me.BunifuThinButton27.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton27.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton27.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton27.Location = New System.Drawing.Point(3, 0)
        Me.BunifuThinButton27.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton27.Name = "BunifuThinButton27"
        Me.BunifuThinButton27.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton27.TabIndex = 27
        Me.BunifuThinButton27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton212
        '
        Me.BunifuThinButton212.ActiveBorderThickness = 1
        Me.BunifuThinButton212.ActiveCornerRadius = 3
        Me.BunifuThinButton212.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton212.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton212.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton212.AutoSize = True
        Me.BunifuThinButton212.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton212.BackgroundImage = CType(resources.GetObject("BunifuThinButton212.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton212.ButtonText = "Delete"
        Me.BunifuThinButton212.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton212, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton212, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton212, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton212.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton212.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton212.IdleBorderThickness = 1
        Me.BunifuThinButton212.IdleCornerRadius = 1
        Me.BunifuThinButton212.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton212.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton212.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton212.Location = New System.Drawing.Point(149, 1)
        Me.BunifuThinButton212.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton212.Name = "BunifuThinButton212"
        Me.BunifuThinButton212.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton212.TabIndex = 32
        Me.BunifuThinButton212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton213
        '
        Me.BunifuThinButton213.ActiveBorderThickness = 1
        Me.BunifuThinButton213.ActiveCornerRadius = 2
        Me.BunifuThinButton213.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton213.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton213.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton213.AutoSize = True
        Me.BunifuThinButton213.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton213.BackgroundImage = CType(resources.GetObject("BunifuThinButton213.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton213.ButtonText = "Sign Up"
        Me.BunifuThinButton213.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton213, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton213, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton213, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton213.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton213.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton213.IdleBorderThickness = 1
        Me.BunifuThinButton213.IdleCornerRadius = 1
        Me.BunifuThinButton213.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton213.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton213.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton213.Location = New System.Drawing.Point(149, 0)
        Me.BunifuThinButton213.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton213.Name = "BunifuThinButton213"
        Me.BunifuThinButton213.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton213.TabIndex = 31
        Me.BunifuThinButton213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton215
        '
        Me.BunifuThinButton215.ActiveBorderThickness = 1
        Me.BunifuThinButton215.ActiveCornerRadius = 2
        Me.BunifuThinButton215.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton215.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton215.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton215.AutoSize = True
        Me.BunifuThinButton215.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton215.BackgroundImage = CType(resources.GetObject("BunifuThinButton215.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton215.ButtonText = "Sign Up"
        Me.BunifuThinButton215.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton215, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton215, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton215, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton215.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton215.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton215.IdleBorderThickness = 1
        Me.BunifuThinButton215.IdleCornerRadius = 1
        Me.BunifuThinButton215.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton215.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton215.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton215.Location = New System.Drawing.Point(297, 0)
        Me.BunifuThinButton215.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton215.Name = "BunifuThinButton215"
        Me.BunifuThinButton215.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton215.TabIndex = 33
        Me.BunifuThinButton215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton29
        '
        Me.BunifuThinButton29.ActiveBorderThickness = 1
        Me.BunifuThinButton29.ActiveCornerRadius = 3
        Me.BunifuThinButton29.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton29.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton29.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton29.AutoSize = True
        Me.BunifuThinButton29.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton29.BackgroundImage = CType(resources.GetObject("BunifuThinButton29.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton29.ButtonText = "Hide"
        Me.BunifuThinButton29.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton29.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton29.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton29.IdleBorderThickness = 1
        Me.BunifuThinButton29.IdleCornerRadius = 1
        Me.BunifuThinButton29.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton29.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton29.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton29.Location = New System.Drawing.Point(210, 1)
        Me.BunifuThinButton29.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton29.Name = "BunifuThinButton29"
        Me.BunifuThinButton29.Size = New System.Drawing.Size(63, 36)
        Me.BunifuThinButton29.TabIndex = 34
        Me.BunifuThinButton29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton28
        '
        Me.BunifuThinButton28.ActiveBorderThickness = 1
        Me.BunifuThinButton28.ActiveCornerRadius = 3
        Me.BunifuThinButton28.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton28.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton28.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton28.AutoSize = True
        Me.BunifuThinButton28.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton28.BackgroundImage = CType(resources.GetObject("BunifuThinButton28.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton28.ButtonText = "Delete"
        Me.BunifuThinButton28.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton28.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton28.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton28.IdleBorderThickness = 1
        Me.BunifuThinButton28.IdleCornerRadius = 1
        Me.BunifuThinButton28.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton28.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton28.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton28.Location = New System.Drawing.Point(139, 1)
        Me.BunifuThinButton28.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton28.Name = "BunifuThinButton28"
        Me.BunifuThinButton28.Size = New System.Drawing.Size(63, 36)
        Me.BunifuThinButton28.TabIndex = 33
        Me.BunifuThinButton28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton239
        '
        Me.BunifuThinButton239.ActiveBorderThickness = 1
        Me.BunifuThinButton239.ActiveCornerRadius = 3
        Me.BunifuThinButton239.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton239.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton239.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton239.AutoSize = True
        Me.BunifuThinButton239.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton239.BackgroundImage = CType(resources.GetObject("BunifuThinButton239.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton239.ButtonText = "Print"
        Me.BunifuThinButton239.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton239, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton239, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton239, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton239.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton239.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton239.IdleBorderThickness = 1
        Me.BunifuThinButton239.IdleCornerRadius = 1
        Me.BunifuThinButton239.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton239.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton239.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton239.Location = New System.Drawing.Point(455, 4)
        Me.BunifuThinButton239.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton239.Name = "BunifuThinButton239"
        Me.BunifuThinButton239.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton239.TabIndex = 30
        Me.BunifuThinButton239.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton240
        '
        Me.BunifuThinButton240.ActiveBorderThickness = 1
        Me.BunifuThinButton240.ActiveCornerRadius = 2
        Me.BunifuThinButton240.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton240.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton240.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton240.AutoSize = True
        Me.BunifuThinButton240.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton240.BackgroundImage = CType(resources.GetObject("BunifuThinButton240.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton240.ButtonText = "Sign Up"
        Me.BunifuThinButton240.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton240, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton240, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton240, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton240.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton240.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton240.IdleBorderThickness = 1
        Me.BunifuThinButton240.IdleCornerRadius = 1
        Me.BunifuThinButton240.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton240.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton240.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton240.Location = New System.Drawing.Point(455, 7)
        Me.BunifuThinButton240.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton240.Name = "BunifuThinButton240"
        Me.BunifuThinButton240.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton240.TabIndex = 29
        Me.BunifuThinButton240.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton223
        '
        Me.BunifuThinButton223.ActiveBorderThickness = 1
        Me.BunifuThinButton223.ActiveCornerRadius = 3
        Me.BunifuThinButton223.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton223.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton223.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton223.AutoSize = True
        Me.BunifuThinButton223.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton223.BackgroundImage = CType(resources.GetObject("BunifuThinButton223.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton223.ButtonText = "Report"
        Me.BunifuThinButton223.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton223, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton223, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton223, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton223.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton223.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton223.IdleBorderThickness = 1
        Me.BunifuThinButton223.IdleCornerRadius = 1
        Me.BunifuThinButton223.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton223.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton223.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton223.Location = New System.Drawing.Point(307, 4)
        Me.BunifuThinButton223.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton223.Name = "BunifuThinButton223"
        Me.BunifuThinButton223.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton223.TabIndex = 28
        Me.BunifuThinButton223.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton225
        '
        Me.BunifuThinButton225.ActiveBorderThickness = 1
        Me.BunifuThinButton225.ActiveCornerRadius = 2
        Me.BunifuThinButton225.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton225.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton225.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton225.AutoSize = True
        Me.BunifuThinButton225.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton225.BackgroundImage = CType(resources.GetObject("BunifuThinButton225.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton225.ButtonText = "Sign Up"
        Me.BunifuThinButton225.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton225, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton225, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton225, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton225.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton225.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton225.IdleBorderThickness = 1
        Me.BunifuThinButton225.IdleCornerRadius = 1
        Me.BunifuThinButton225.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton225.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton225.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton225.Location = New System.Drawing.Point(307, 3)
        Me.BunifuThinButton225.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton225.Name = "BunifuThinButton225"
        Me.BunifuThinButton225.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton225.TabIndex = 27
        Me.BunifuThinButton225.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton24
        '
        Me.BunifuThinButton24.ActiveBorderThickness = 1
        Me.BunifuThinButton24.ActiveCornerRadius = 3
        Me.BunifuThinButton24.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton24.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton24.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton24.AutoSize = True
        Me.BunifuThinButton24.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton24.BackgroundImage = CType(resources.GetObject("BunifuThinButton24.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton24.ButtonText = "Patient Record"
        Me.BunifuThinButton24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton24.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton24.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton24.IdleBorderThickness = 1
        Me.BunifuThinButton24.IdleCornerRadius = 1
        Me.BunifuThinButton24.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton24.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton24.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton24.Location = New System.Drawing.Point(159, 4)
        Me.BunifuThinButton24.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton24.Name = "BunifuThinButton24"
        Me.BunifuThinButton24.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton24.TabIndex = 26
        Me.BunifuThinButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton25
        '
        Me.BunifuThinButton25.ActiveBorderThickness = 1
        Me.BunifuThinButton25.ActiveCornerRadius = 2
        Me.BunifuThinButton25.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton25.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton25.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton25.AutoSize = True
        Me.BunifuThinButton25.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton25.BackgroundImage = CType(resources.GetObject("BunifuThinButton25.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton25.ButtonText = "Sign Up"
        Me.BunifuThinButton25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton25.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton25.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton25.IdleBorderThickness = 1
        Me.BunifuThinButton25.IdleCornerRadius = 1
        Me.BunifuThinButton25.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton25.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton25.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton25.Location = New System.Drawing.Point(159, 3)
        Me.BunifuThinButton25.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton25.Name = "BunifuThinButton25"
        Me.BunifuThinButton25.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton25.TabIndex = 25
        Me.BunifuThinButton25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton22
        '
        Me.BunifuThinButton22.ActiveBorderThickness = 1
        Me.BunifuThinButton22.ActiveCornerRadius = 3
        Me.BunifuThinButton22.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton22.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton22.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton22.AutoSize = True
        Me.BunifuThinButton22.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton22.BackgroundImage = CType(resources.GetObject("BunifuThinButton22.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BunifuThinButton22.ButtonText = "Add Patient"
        Me.BunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton22.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton22.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton22.IdleBorderThickness = 1
        Me.BunifuThinButton22.IdleCornerRadius = 1
        Me.BunifuThinButton22.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton22.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton22.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton22.Location = New System.Drawing.Point(11, 4)
        Me.BunifuThinButton22.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton22.Name = "BunifuThinButton22"
        Me.BunifuThinButton22.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton22.TabIndex = 24
        Me.BunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton23
        '
        Me.BunifuThinButton23.ActiveBorderThickness = 1
        Me.BunifuThinButton23.ActiveCornerRadius = 2
        Me.BunifuThinButton23.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton23.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton23.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton23.AutoSize = True
        Me.BunifuThinButton23.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton23.BackgroundImage = CType(resources.GetObject("BunifuThinButton23.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton23.ButtonText = "Sign Up"
        Me.BunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton23.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton23.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton23.IdleBorderThickness = 1
        Me.BunifuThinButton23.IdleCornerRadius = 1
        Me.BunifuThinButton23.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton23.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton23.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton23.Location = New System.Drawing.Point(11, 2)
        Me.BunifuThinButton23.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton23.Name = "BunifuThinButton23"
        Me.BunifuThinButton23.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton23.TabIndex = 23
        Me.BunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuGradientPanel6
        '
        Me.BunifuGradientPanel6.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel6.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel6.Controls.Add(Me.BunifuTextbox1)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel6.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel6.Name = "BunifuGradientPanel6"
        Me.BunifuGradientPanel6.Quality = 10
        Me.BunifuGradientPanel6.Size = New System.Drawing.Size(947, 37)
        Me.BunifuGradientPanel6.TabIndex = 1
        '
        'BunifuTextbox1
        '
        Me.BunifuTextbox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTextbox1.BackgroundImage = CType(resources.GetObject("BunifuTextbox1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition1.SetDecoration(Me.BunifuTextbox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuTextbox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTextbox1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTextbox1.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox1.Icon = CType(resources.GetObject("BunifuTextbox1.Icon"), System.Drawing.Image)
        Me.BunifuTextbox1.Location = New System.Drawing.Point(12, 1)
        Me.BunifuTextbox1.Name = "BunifuTextbox1"
        Me.BunifuTextbox1.Size = New System.Drawing.Size(239, 31)
        Me.BunifuTextbox1.TabIndex = 0
        Me.BunifuTextbox1.text = "Search Id, ward,room"
        '
        'BunifuThinButton227
        '
        Me.BunifuThinButton227.ActiveBorderThickness = 1
        Me.BunifuThinButton227.ActiveCornerRadius = 3
        Me.BunifuThinButton227.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton227.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton227.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton227.AutoSize = True
        Me.BunifuThinButton227.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton227.BackgroundImage = CType(resources.GetObject("BunifuThinButton227.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton227.ButtonText = "Home"
        Me.BunifuThinButton227.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton227, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton227, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton227, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton227.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton227.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton227.IdleBorderThickness = 1
        Me.BunifuThinButton227.IdleCornerRadius = 1
        Me.BunifuThinButton227.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton227.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton227.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton227.Location = New System.Drawing.Point(743, 4)
        Me.BunifuThinButton227.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton227.Name = "BunifuThinButton227"
        Me.BunifuThinButton227.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton227.TabIndex = 38
        Me.BunifuThinButton227.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton228
        '
        Me.BunifuThinButton228.ActiveBorderThickness = 1
        Me.BunifuThinButton228.ActiveCornerRadius = 2
        Me.BunifuThinButton228.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton228.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton228.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton228.AutoSize = True
        Me.BunifuThinButton228.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton228.BackgroundImage = CType(resources.GetObject("BunifuThinButton228.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton228.ButtonText = "Sign Up"
        Me.BunifuThinButton228.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton228, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton228, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton228, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton228.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton228.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton228.IdleBorderThickness = 1
        Me.BunifuThinButton228.IdleCornerRadius = 1
        Me.BunifuThinButton228.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton228.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton228.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton228.Location = New System.Drawing.Point(743, 3)
        Me.BunifuThinButton228.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton228.Name = "BunifuThinButton228"
        Me.BunifuThinButton228.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton228.TabIndex = 37
        Me.BunifuThinButton228.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton229
        '
        Me.BunifuThinButton229.ActiveBorderThickness = 1
        Me.BunifuThinButton229.ActiveCornerRadius = 3
        Me.BunifuThinButton229.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton229.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton229.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton229.AutoSize = True
        Me.BunifuThinButton229.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton229.BackgroundImage = CType(resources.GetObject("BunifuThinButton229.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton229.ButtonText = "View Record"
        Me.BunifuThinButton229.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton229, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton229, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton229, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton229.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton229.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton229.IdleBorderThickness = 1
        Me.BunifuThinButton229.IdleCornerRadius = 1
        Me.BunifuThinButton229.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton229.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton229.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton229.Location = New System.Drawing.Point(595, 4)
        Me.BunifuThinButton229.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton229.Name = "BunifuThinButton229"
        Me.BunifuThinButton229.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton229.TabIndex = 36
        Me.BunifuThinButton229.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton230
        '
        Me.BunifuThinButton230.ActiveBorderThickness = 1
        Me.BunifuThinButton230.ActiveCornerRadius = 2
        Me.BunifuThinButton230.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton230.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton230.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton230.AutoSize = True
        Me.BunifuThinButton230.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton230.BackgroundImage = CType(resources.GetObject("BunifuThinButton230.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton230.ButtonText = "Sign Up"
        Me.BunifuThinButton230.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton230, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton230, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton230, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton230.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton230.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton230.IdleBorderThickness = 1
        Me.BunifuThinButton230.IdleCornerRadius = 1
        Me.BunifuThinButton230.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton230.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton230.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton230.Location = New System.Drawing.Point(595, 3)
        Me.BunifuThinButton230.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton230.Name = "BunifuThinButton230"
        Me.BunifuThinButton230.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton230.TabIndex = 35
        Me.BunifuThinButton230.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton231
        '
        Me.BunifuThinButton231.ActiveBorderThickness = 1
        Me.BunifuThinButton231.ActiveCornerRadius = 3
        Me.BunifuThinButton231.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton231.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton231.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton231.AutoSize = True
        Me.BunifuThinButton231.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton231.BackgroundImage = CType(resources.GetObject("BunifuThinButton231.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton231.ButtonText = "Update"
        Me.BunifuThinButton231.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton231, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton231, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton231, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton231.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton231.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton231.IdleBorderThickness = 1
        Me.BunifuThinButton231.IdleCornerRadius = 1
        Me.BunifuThinButton231.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton231.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton231.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton231.Location = New System.Drawing.Point(151, 4)
        Me.BunifuThinButton231.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton231.Name = "BunifuThinButton231"
        Me.BunifuThinButton231.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton231.TabIndex = 30
        Me.BunifuThinButton231.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton232
        '
        Me.BunifuThinButton232.ActiveBorderThickness = 1
        Me.BunifuThinButton232.ActiveCornerRadius = 3
        Me.BunifuThinButton232.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton232.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton232.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton232.AutoSize = True
        Me.BunifuThinButton232.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton232.BackgroundImage = CType(resources.GetObject("BunifuThinButton232.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton232.ButtonText = "Submit"
        Me.BunifuThinButton232.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton232, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton232, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton232, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton232.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton232.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton232.IdleBorderThickness = 1
        Me.BunifuThinButton232.IdleCornerRadius = 1
        Me.BunifuThinButton232.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton232.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton232.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton232.Location = New System.Drawing.Point(3, 4)
        Me.BunifuThinButton232.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton232.Name = "BunifuThinButton232"
        Me.BunifuThinButton232.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton232.TabIndex = 28
        Me.BunifuThinButton232.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton233
        '
        Me.BunifuThinButton233.ActiveBorderThickness = 1
        Me.BunifuThinButton233.ActiveCornerRadius = 2
        Me.BunifuThinButton233.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton233.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton233.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton233.AutoSize = True
        Me.BunifuThinButton233.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton233.BackgroundImage = CType(resources.GetObject("BunifuThinButton233.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton233.ButtonText = "Sign Up"
        Me.BunifuThinButton233.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton233, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton233, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton233, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton233.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton233.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton233.IdleBorderThickness = 1
        Me.BunifuThinButton233.IdleCornerRadius = 1
        Me.BunifuThinButton233.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton233.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton233.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton233.Location = New System.Drawing.Point(151, 3)
        Me.BunifuThinButton233.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton233.Name = "BunifuThinButton233"
        Me.BunifuThinButton233.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton233.TabIndex = 29
        Me.BunifuThinButton233.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton234
        '
        Me.BunifuThinButton234.ActiveBorderThickness = 1
        Me.BunifuThinButton234.ActiveCornerRadius = 3
        Me.BunifuThinButton234.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton234.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton234.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton234.AutoSize = True
        Me.BunifuThinButton234.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton234.BackgroundImage = CType(resources.GetObject("BunifuThinButton234.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton234.ButtonText = "Clear"
        Me.BunifuThinButton234.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton234, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton234, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton234, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton234.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton234.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton234.IdleBorderThickness = 1
        Me.BunifuThinButton234.IdleCornerRadius = 1
        Me.BunifuThinButton234.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton234.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton234.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton234.Location = New System.Drawing.Point(447, 4)
        Me.BunifuThinButton234.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton234.Name = "BunifuThinButton234"
        Me.BunifuThinButton234.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton234.TabIndex = 34
        Me.BunifuThinButton234.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton235
        '
        Me.BunifuThinButton235.ActiveBorderThickness = 1
        Me.BunifuThinButton235.ActiveCornerRadius = 2
        Me.BunifuThinButton235.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton235.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton235.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton235.AutoSize = True
        Me.BunifuThinButton235.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton235.BackgroundImage = CType(resources.GetObject("BunifuThinButton235.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton235.ButtonText = "Sign Up"
        Me.BunifuThinButton235.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton235, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton235, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton235, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton235.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton235.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton235.IdleBorderThickness = 1
        Me.BunifuThinButton235.IdleCornerRadius = 1
        Me.BunifuThinButton235.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton235.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton235.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton235.Location = New System.Drawing.Point(3, 3)
        Me.BunifuThinButton235.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton235.Name = "BunifuThinButton235"
        Me.BunifuThinButton235.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton235.TabIndex = 27
        Me.BunifuThinButton235.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton236
        '
        Me.BunifuThinButton236.ActiveBorderThickness = 1
        Me.BunifuThinButton236.ActiveCornerRadius = 3
        Me.BunifuThinButton236.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton236.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton236.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton236.AutoSize = True
        Me.BunifuThinButton236.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton236.BackgroundImage = CType(resources.GetObject("BunifuThinButton236.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton236.ButtonText = "Delete"
        Me.BunifuThinButton236.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton236, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton236, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton236, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton236.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton236.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton236.IdleBorderThickness = 1
        Me.BunifuThinButton236.IdleCornerRadius = 1
        Me.BunifuThinButton236.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton236.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton236.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton236.Location = New System.Drawing.Point(299, 4)
        Me.BunifuThinButton236.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton236.Name = "BunifuThinButton236"
        Me.BunifuThinButton236.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton236.TabIndex = 32
        Me.BunifuThinButton236.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton237
        '
        Me.BunifuThinButton237.ActiveBorderThickness = 1
        Me.BunifuThinButton237.ActiveCornerRadius = 2
        Me.BunifuThinButton237.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton237.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton237.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton237.AutoSize = True
        Me.BunifuThinButton237.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton237.BackgroundImage = CType(resources.GetObject("BunifuThinButton237.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton237.ButtonText = "Sign Up"
        Me.BunifuThinButton237.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton237, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton237, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton237, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton237.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton237.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton237.IdleBorderThickness = 1
        Me.BunifuThinButton237.IdleCornerRadius = 1
        Me.BunifuThinButton237.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton237.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton237.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton237.Location = New System.Drawing.Point(299, 3)
        Me.BunifuThinButton237.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton237.Name = "BunifuThinButton237"
        Me.BunifuThinButton237.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton237.TabIndex = 31
        Me.BunifuThinButton237.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton238
        '
        Me.BunifuThinButton238.ActiveBorderThickness = 1
        Me.BunifuThinButton238.ActiveCornerRadius = 2
        Me.BunifuThinButton238.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton238.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton238.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton238.AutoSize = True
        Me.BunifuThinButton238.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton238.BackgroundImage = CType(resources.GetObject("BunifuThinButton238.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton238.ButtonText = "Sign Up"
        Me.BunifuThinButton238.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton238, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton238, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton238, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton238.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton238.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton238.IdleBorderThickness = 1
        Me.BunifuThinButton238.IdleCornerRadius = 1
        Me.BunifuThinButton238.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton238.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton238.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton238.Location = New System.Drawing.Point(447, 3)
        Me.BunifuThinButton238.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton238.Name = "BunifuThinButton238"
        Me.BunifuThinButton238.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton238.TabIndex = 33
        Me.BunifuThinButton238.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton18
        '
        Me.BunifuFlatButton18.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton18.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton18.BorderRadius = 0
        Me.BunifuFlatButton18.ButtonText = "References"
        Me.BunifuFlatButton18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton18.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton18.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton18.Iconimage = Global.officesoft2.My.Resources.Resources.hand_touching_tablet_screen
        Me.BunifuFlatButton18.Iconimage_right = Nothing
        Me.BunifuFlatButton18.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton18.Iconimage_Selected = Nothing
        Me.BunifuFlatButton18.IconMarginLeft = 0
        Me.BunifuFlatButton18.IconMarginRight = 0
        Me.BunifuFlatButton18.IconRightVisible = False
        Me.BunifuFlatButton18.IconRightZoom = 0R
        Me.BunifuFlatButton18.IconVisible = False
        Me.BunifuFlatButton18.IconZoom = 60.0R
        Me.BunifuFlatButton18.IsTab = False
        Me.BunifuFlatButton18.Location = New System.Drawing.Point(787, 6)
        Me.BunifuFlatButton18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton18.Name = "BunifuFlatButton18"
        Me.BunifuFlatButton18.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton18.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton18.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton18.selected = False
        Me.BunifuFlatButton18.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton18.TabIndex = 17
        Me.BunifuFlatButton18.Text = "References"
        Me.BunifuFlatButton18.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton18.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton18.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton17
        '
        Me.BunifuFlatButton17.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton17.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton17.BorderRadius = 0
        Me.BunifuFlatButton17.ButtonText = "Employment"
        Me.BunifuFlatButton17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton17.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton17.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton17.Iconimage = Global.officesoft2.My.Resources.Resources.employee
        Me.BunifuFlatButton17.Iconimage_right = Nothing
        Me.BunifuFlatButton17.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton17.Iconimage_Selected = Nothing
        Me.BunifuFlatButton17.IconMarginLeft = 0
        Me.BunifuFlatButton17.IconMarginRight = 0
        Me.BunifuFlatButton17.IconRightVisible = False
        Me.BunifuFlatButton17.IconRightZoom = 0R
        Me.BunifuFlatButton17.IconVisible = False
        Me.BunifuFlatButton17.IconZoom = 60.0R
        Me.BunifuFlatButton17.IsTab = False
        Me.BunifuFlatButton17.Location = New System.Drawing.Point(631, 6)
        Me.BunifuFlatButton17.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton17.Name = "BunifuFlatButton17"
        Me.BunifuFlatButton17.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton17.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton17.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton17.selected = False
        Me.BunifuFlatButton17.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton17.TabIndex = 17
        Me.BunifuFlatButton17.Text = "Employment"
        Me.BunifuFlatButton17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton17.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton17.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton224
        '
        Me.BunifuThinButton224.ActiveBorderThickness = 1
        Me.BunifuThinButton224.ActiveCornerRadius = 2
        Me.BunifuThinButton224.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton224.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton224.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton224.AutoSize = True
        Me.BunifuThinButton224.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton224.BackgroundImage = CType(resources.GetObject("BunifuThinButton224.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton224.ButtonText = "Sign Up"
        Me.BunifuThinButton224.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton224, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton224, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton224, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton224.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton224.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton224.IdleBorderThickness = 1
        Me.BunifuThinButton224.IdleCornerRadius = 1
        Me.BunifuThinButton224.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton224.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton224.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton224.Location = New System.Drawing.Point(787, 14)
        Me.BunifuThinButton224.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton224.Name = "BunifuThinButton224"
        Me.BunifuThinButton224.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton224.TabIndex = 25
        Me.BunifuThinButton224.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton216
        '
        Me.BunifuThinButton216.ActiveBorderThickness = 1
        Me.BunifuThinButton216.ActiveCornerRadius = 2
        Me.BunifuThinButton216.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton216.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton216.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton216.AutoSize = True
        Me.BunifuThinButton216.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton216.BackgroundImage = CType(resources.GetObject("BunifuThinButton216.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton216.ButtonText = "Sign Up"
        Me.BunifuThinButton216.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton216, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton216, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton216, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton216.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton216.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton216.IdleBorderThickness = 1
        Me.BunifuThinButton216.IdleCornerRadius = 1
        Me.BunifuThinButton216.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton216.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton216.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton216.Location = New System.Drawing.Point(631, 14)
        Me.BunifuThinButton216.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton216.Name = "BunifuThinButton216"
        Me.BunifuThinButton216.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton216.TabIndex = 33
        Me.BunifuThinButton216.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton14
        '
        Me.BunifuFlatButton14.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton14.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton14.BorderRadius = 0
        Me.BunifuFlatButton14.ButtonText = "Desired"
        Me.BunifuFlatButton14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton14.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton14.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton14.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton14.Iconimage_right = Nothing
        Me.BunifuFlatButton14.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton14.Iconimage_Selected = Nothing
        Me.BunifuFlatButton14.IconMarginLeft = 0
        Me.BunifuFlatButton14.IconMarginRight = 0
        Me.BunifuFlatButton14.IconRightVisible = False
        Me.BunifuFlatButton14.IconRightZoom = 0R
        Me.BunifuFlatButton14.IconVisible = False
        Me.BunifuFlatButton14.IconZoom = 60.0R
        Me.BunifuFlatButton14.IsTab = False
        Me.BunifuFlatButton14.Location = New System.Drawing.Point(166, 6)
        Me.BunifuFlatButton14.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton14.Name = "BunifuFlatButton14"
        Me.BunifuFlatButton14.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton14.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton14.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton14.selected = False
        Me.BunifuFlatButton14.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton14.TabIndex = 34
        Me.BunifuFlatButton14.Text = "Desired"
        Me.BunifuFlatButton14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton14.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton14.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton16
        '
        Me.BunifuFlatButton16.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton16.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton16.BorderRadius = 0
        Me.BunifuFlatButton16.ButtonText = "Qualification"
        Me.BunifuFlatButton16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton16.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton16.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton16.Iconimage = Global.officesoft2.My.Resources.Resources.diploma
        Me.BunifuFlatButton16.Iconimage_right = Nothing
        Me.BunifuFlatButton16.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton16.Iconimage_Selected = Nothing
        Me.BunifuFlatButton16.IconMarginLeft = 0
        Me.BunifuFlatButton16.IconMarginRight = 0
        Me.BunifuFlatButton16.IconRightVisible = False
        Me.BunifuFlatButton16.IconRightZoom = 0R
        Me.BunifuFlatButton16.IconVisible = False
        Me.BunifuFlatButton16.IconZoom = 60.0R
        Me.BunifuFlatButton16.IsTab = False
        Me.BunifuFlatButton16.Location = New System.Drawing.Point(476, 6)
        Me.BunifuFlatButton16.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton16.Name = "BunifuFlatButton16"
        Me.BunifuFlatButton16.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton16.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton16.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton16.selected = False
        Me.BunifuFlatButton16.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton16.TabIndex = 35
        Me.BunifuFlatButton16.Text = "Qualification"
        Me.BunifuFlatButton16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton16.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton16.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton9
        '
        Me.BunifuFlatButton9.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton9.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton9.BorderRadius = 0
        Me.BunifuFlatButton9.ButtonText = "Personal Info"
        Me.BunifuFlatButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton9.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton9.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton9.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton9.Iconimage_right = Nothing
        Me.BunifuFlatButton9.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton9.Iconimage_Selected = Nothing
        Me.BunifuFlatButton9.IconMarginLeft = 0
        Me.BunifuFlatButton9.IconMarginRight = 0
        Me.BunifuFlatButton9.IconRightVisible = False
        Me.BunifuFlatButton9.IconRightZoom = 0R
        Me.BunifuFlatButton9.IconVisible = False
        Me.BunifuFlatButton9.IconZoom = 60.0R
        Me.BunifuFlatButton9.IsTab = False
        Me.BunifuFlatButton9.Location = New System.Drawing.Point(11, 6)
        Me.BunifuFlatButton9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton9.Name = "BunifuFlatButton9"
        Me.BunifuFlatButton9.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton9.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton9.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton9.selected = False
        Me.BunifuFlatButton9.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton9.TabIndex = 15
        Me.BunifuFlatButton9.Text = "Personal Info"
        Me.BunifuFlatButton9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton9.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton9.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton222
        '
        Me.BunifuThinButton222.ActiveBorderThickness = 1
        Me.BunifuThinButton222.ActiveCornerRadius = 2
        Me.BunifuThinButton222.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton222.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton222.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton222.AutoSize = True
        Me.BunifuThinButton222.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton222.BackgroundImage = CType(resources.GetObject("BunifuThinButton222.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton222.ButtonText = "Sign Up"
        Me.BunifuThinButton222.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton222, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton222, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton222, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton222.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton222.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton222.IdleBorderThickness = 1
        Me.BunifuThinButton222.IdleCornerRadius = 1
        Me.BunifuThinButton222.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton222.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton222.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton222.Location = New System.Drawing.Point(166, 14)
        Me.BunifuThinButton222.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton222.Name = "BunifuThinButton222"
        Me.BunifuThinButton222.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton222.TabIndex = 27
        Me.BunifuThinButton222.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton15
        '
        Me.BunifuFlatButton15.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton15.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton15.BorderRadius = 0
        Me.BunifuFlatButton15.ButtonText = "Education"
        Me.BunifuFlatButton15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton15.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton15.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton15.Iconimage = Global.officesoft2.My.Resources.Resources.education
        Me.BunifuFlatButton15.Iconimage_right = Nothing
        Me.BunifuFlatButton15.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton15.Iconimage_Selected = Nothing
        Me.BunifuFlatButton15.IconMarginLeft = 0
        Me.BunifuFlatButton15.IconMarginRight = 0
        Me.BunifuFlatButton15.IconRightVisible = False
        Me.BunifuFlatButton15.IconRightZoom = 0R
        Me.BunifuFlatButton15.IconVisible = False
        Me.BunifuFlatButton15.IconZoom = 60.0R
        Me.BunifuFlatButton15.IsTab = False
        Me.BunifuFlatButton15.Location = New System.Drawing.Point(321, 6)
        Me.BunifuFlatButton15.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton15.Name = "BunifuFlatButton15"
        Me.BunifuFlatButton15.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton15.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton15.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton15.selected = False
        Me.BunifuFlatButton15.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton15.TabIndex = 16
        Me.BunifuFlatButton15.Text = "Education"
        Me.BunifuFlatButton15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton15.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton15.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton226
        '
        Me.BunifuThinButton226.ActiveBorderThickness = 1
        Me.BunifuThinButton226.ActiveCornerRadius = 2
        Me.BunifuThinButton226.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton226.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton226.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton226.AutoSize = True
        Me.BunifuThinButton226.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton226.BackgroundImage = CType(resources.GetObject("BunifuThinButton226.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton226.ButtonText = "Sign Up"
        Me.BunifuThinButton226.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton226, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton226, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton226, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton226.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton226.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton226.IdleBorderThickness = 1
        Me.BunifuThinButton226.IdleCornerRadius = 1
        Me.BunifuThinButton226.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton226.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton226.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton226.Location = New System.Drawing.Point(11, 14)
        Me.BunifuThinButton226.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton226.Name = "BunifuThinButton226"
        Me.BunifuThinButton226.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton226.TabIndex = 23
        Me.BunifuThinButton226.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton220
        '
        Me.BunifuThinButton220.ActiveBorderThickness = 1
        Me.BunifuThinButton220.ActiveCornerRadius = 2
        Me.BunifuThinButton220.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton220.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton220.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton220.AutoSize = True
        Me.BunifuThinButton220.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton220.BackgroundImage = CType(resources.GetObject("BunifuThinButton220.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton220.ButtonText = "Sign Up"
        Me.BunifuThinButton220.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton220, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton220, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton220, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton220.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton220.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton220.IdleBorderThickness = 1
        Me.BunifuThinButton220.IdleCornerRadius = 1
        Me.BunifuThinButton220.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton220.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton220.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton220.Location = New System.Drawing.Point(321, 14)
        Me.BunifuThinButton220.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton220.Name = "BunifuThinButton220"
        Me.BunifuThinButton220.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton220.TabIndex = 29
        Me.BunifuThinButton220.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton218
        '
        Me.BunifuThinButton218.ActiveBorderThickness = 1
        Me.BunifuThinButton218.ActiveCornerRadius = 2
        Me.BunifuThinButton218.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton218.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton218.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton218.AutoSize = True
        Me.BunifuThinButton218.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton218.BackgroundImage = CType(resources.GetObject("BunifuThinButton218.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton218.ButtonText = "Sign Up"
        Me.BunifuThinButton218.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton218, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton218, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton218, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton218.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton218.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton218.IdleBorderThickness = 1
        Me.BunifuThinButton218.IdleCornerRadius = 1
        Me.BunifuThinButton218.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton218.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton218.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton218.Location = New System.Drawing.Point(476, 6)
        Me.BunifuThinButton218.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton218.Name = "BunifuThinButton218"
        Me.BunifuThinButton218.Size = New System.Drawing.Size(149, 44)
        Me.BunifuThinButton218.TabIndex = 31
        Me.BunifuThinButton218.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuGradientPanel13
        '
        Me.BunifuGradientPanel13.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel13.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel13.Controls.Add(Me.BunifuTextbox2)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel13.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel13.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel13.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel13.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel13.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel13.Location = New System.Drawing.Point(0, 0)
        Me.BunifuGradientPanel13.Name = "BunifuGradientPanel13"
        Me.BunifuGradientPanel13.Quality = 10
        Me.BunifuGradientPanel13.Size = New System.Drawing.Size(933, 37)
        Me.BunifuGradientPanel13.TabIndex = 17
        '
        'BunifuTextbox2
        '
        Me.BunifuTextbox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTextbox2.BackgroundImage = CType(resources.GetObject("BunifuTextbox2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition1.SetDecoration(Me.BunifuTextbox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuTextbox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTextbox2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTextbox2.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox2.Icon = CType(resources.GetObject("BunifuTextbox2.Icon"), System.Drawing.Image)
        Me.BunifuTextbox2.Location = New System.Drawing.Point(12, 1)
        Me.BunifuTextbox2.Name = "BunifuTextbox2"
        Me.BunifuTextbox2.Size = New System.Drawing.Size(239, 31)
        Me.BunifuTextbox2.TabIndex = 0
        Me.BunifuTextbox2.text = "Search Id, Name, Class "
        '
        'BunifuFlatButton25
        '
        Me.BunifuFlatButton25.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton25.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton25.BorderRadius = 0
        Me.BunifuFlatButton25.ButtonText = "Home"
        Me.BunifuFlatButton25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton25, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton25.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton25.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton25.Iconimage = Global.officesoft2.My.Resources.Resources.hand_touching_tablet_screen
        Me.BunifuFlatButton25.Iconimage_right = Nothing
        Me.BunifuFlatButton25.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton25.Iconimage_Selected = Nothing
        Me.BunifuFlatButton25.IconMarginLeft = 0
        Me.BunifuFlatButton25.IconMarginRight = 0
        Me.BunifuFlatButton25.IconRightVisible = False
        Me.BunifuFlatButton25.IconRightZoom = 0R
        Me.BunifuFlatButton25.IconVisible = False
        Me.BunifuFlatButton25.IconZoom = 60.0R
        Me.BunifuFlatButton25.IsTab = False
        Me.BunifuFlatButton25.Location = New System.Drawing.Point(762, 6)
        Me.BunifuFlatButton25.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton25.Name = "BunifuFlatButton25"
        Me.BunifuFlatButton25.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton25.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton25.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton25.selected = False
        Me.BunifuFlatButton25.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton25.TabIndex = 17
        Me.BunifuFlatButton25.Text = "Home"
        Me.BunifuFlatButton25.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton25.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton25.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton26
        '
        Me.BunifuFlatButton26.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton26.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton26.BorderRadius = 0
        Me.BunifuFlatButton26.ButtonText = "Print"
        Me.BunifuFlatButton26.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton26.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton26.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton26.Iconimage = Global.officesoft2.My.Resources.Resources.employee
        Me.BunifuFlatButton26.Iconimage_right = Nothing
        Me.BunifuFlatButton26.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton26.Iconimage_Selected = Nothing
        Me.BunifuFlatButton26.IconMarginLeft = 0
        Me.BunifuFlatButton26.IconMarginRight = 0
        Me.BunifuFlatButton26.IconRightVisible = False
        Me.BunifuFlatButton26.IconRightZoom = 0R
        Me.BunifuFlatButton26.IconVisible = False
        Me.BunifuFlatButton26.IconZoom = 60.0R
        Me.BunifuFlatButton26.IsTab = False
        Me.BunifuFlatButton26.Location = New System.Drawing.Point(613, 6)
        Me.BunifuFlatButton26.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton26.Name = "BunifuFlatButton26"
        Me.BunifuFlatButton26.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton26.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton26.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton26.selected = False
        Me.BunifuFlatButton26.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton26.TabIndex = 17
        Me.BunifuFlatButton26.Text = "Print"
        Me.BunifuFlatButton26.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton26.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton26.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton247
        '
        Me.BunifuThinButton247.ActiveBorderThickness = 1
        Me.BunifuThinButton247.ActiveCornerRadius = 2
        Me.BunifuThinButton247.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton247.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton247.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton247.AutoSize = True
        Me.BunifuThinButton247.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton247.BackgroundImage = CType(resources.GetObject("BunifuThinButton247.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton247.ButtonText = "Sign Up"
        Me.BunifuThinButton247.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton247, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton247, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton247, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton247.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton247.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton247.IdleBorderThickness = 1
        Me.BunifuThinButton247.IdleCornerRadius = 1
        Me.BunifuThinButton247.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton247.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton247.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton247.Location = New System.Drawing.Point(762, 14)
        Me.BunifuThinButton247.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton247.Name = "BunifuThinButton247"
        Me.BunifuThinButton247.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton247.TabIndex = 25
        Me.BunifuThinButton247.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton248
        '
        Me.BunifuThinButton248.ActiveBorderThickness = 1
        Me.BunifuThinButton248.ActiveCornerRadius = 2
        Me.BunifuThinButton248.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton248.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton248.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton248.AutoSize = True
        Me.BunifuThinButton248.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton248.BackgroundImage = CType(resources.GetObject("BunifuThinButton248.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton248.ButtonText = "Sign Up"
        Me.BunifuThinButton248.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton248, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton248, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton248, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton248.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton248.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton248.IdleBorderThickness = 1
        Me.BunifuThinButton248.IdleCornerRadius = 1
        Me.BunifuThinButton248.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton248.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton248.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton248.Location = New System.Drawing.Point(613, 14)
        Me.BunifuThinButton248.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton248.Name = "BunifuThinButton248"
        Me.BunifuThinButton248.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton248.TabIndex = 33
        Me.BunifuThinButton248.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton27
        '
        Me.BunifuFlatButton27.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton27.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton27.BorderRadius = 0
        Me.BunifuFlatButton27.ButtonText = "Save"
        Me.BunifuFlatButton27.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton27, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton27.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton27.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton27.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton27.Iconimage_right = Nothing
        Me.BunifuFlatButton27.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton27.Iconimage_Selected = Nothing
        Me.BunifuFlatButton27.IconMarginLeft = 0
        Me.BunifuFlatButton27.IconMarginRight = 0
        Me.BunifuFlatButton27.IconRightVisible = False
        Me.BunifuFlatButton27.IconRightZoom = 0R
        Me.BunifuFlatButton27.IconVisible = False
        Me.BunifuFlatButton27.IconZoom = 60.0R
        Me.BunifuFlatButton27.IsTab = False
        Me.BunifuFlatButton27.Location = New System.Drawing.Point(163, 6)
        Me.BunifuFlatButton27.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton27.Name = "BunifuFlatButton27"
        Me.BunifuFlatButton27.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton27.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton27.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton27.selected = False
        Me.BunifuFlatButton27.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton27.TabIndex = 34
        Me.BunifuFlatButton27.Text = "Save"
        Me.BunifuFlatButton27.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton27.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton27.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton28
        '
        Me.BunifuFlatButton28.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton28.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton28.BorderRadius = 0
        Me.BunifuFlatButton28.ButtonText = "Update"
        Me.BunifuFlatButton28.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton28, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton28.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton28.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton28.Iconimage = Global.officesoft2.My.Resources.Resources.diploma
        Me.BunifuFlatButton28.Iconimage_right = Nothing
        Me.BunifuFlatButton28.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton28.Iconimage_Selected = Nothing
        Me.BunifuFlatButton28.IconMarginLeft = 0
        Me.BunifuFlatButton28.IconMarginRight = 0
        Me.BunifuFlatButton28.IconRightVisible = False
        Me.BunifuFlatButton28.IconRightZoom = 0R
        Me.BunifuFlatButton28.IconVisible = False
        Me.BunifuFlatButton28.IconZoom = 60.0R
        Me.BunifuFlatButton28.IsTab = False
        Me.BunifuFlatButton28.Location = New System.Drawing.Point(462, 6)
        Me.BunifuFlatButton28.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton28.Name = "BunifuFlatButton28"
        Me.BunifuFlatButton28.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton28.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton28.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton28.selected = False
        Me.BunifuFlatButton28.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton28.TabIndex = 35
        Me.BunifuFlatButton28.Text = "Update"
        Me.BunifuFlatButton28.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton28.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton28.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton29
        '
        Me.BunifuFlatButton29.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton29.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton29.BorderRadius = 0
        Me.BunifuFlatButton29.ButtonText = "New"
        Me.BunifuFlatButton29.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton29, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton29.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton29.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton29.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton29.Iconimage_right = Nothing
        Me.BunifuFlatButton29.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton29.Iconimage_Selected = Nothing
        Me.BunifuFlatButton29.IconMarginLeft = 0
        Me.BunifuFlatButton29.IconMarginRight = 0
        Me.BunifuFlatButton29.IconRightVisible = False
        Me.BunifuFlatButton29.IconRightZoom = 0R
        Me.BunifuFlatButton29.IconVisible = False
        Me.BunifuFlatButton29.IconZoom = 60.0R
        Me.BunifuFlatButton29.IsTab = False
        Me.BunifuFlatButton29.Location = New System.Drawing.Point(14, 6)
        Me.BunifuFlatButton29.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton29.Name = "BunifuFlatButton29"
        Me.BunifuFlatButton29.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton29.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton29.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton29.selected = False
        Me.BunifuFlatButton29.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton29.TabIndex = 15
        Me.BunifuFlatButton29.Text = "New"
        Me.BunifuFlatButton29.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton29.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton29.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton249
        '
        Me.BunifuThinButton249.ActiveBorderThickness = 1
        Me.BunifuThinButton249.ActiveCornerRadius = 2
        Me.BunifuThinButton249.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton249.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton249.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton249.AutoSize = True
        Me.BunifuThinButton249.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton249.BackgroundImage = CType(resources.GetObject("BunifuThinButton249.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton249.ButtonText = "Sign Up"
        Me.BunifuThinButton249.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton249, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton249, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton249, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton249.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton249.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton249.IdleBorderThickness = 1
        Me.BunifuThinButton249.IdleCornerRadius = 1
        Me.BunifuThinButton249.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton249.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton249.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton249.Location = New System.Drawing.Point(163, 14)
        Me.BunifuThinButton249.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton249.Name = "BunifuThinButton249"
        Me.BunifuThinButton249.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton249.TabIndex = 27
        Me.BunifuThinButton249.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton30
        '
        Me.BunifuFlatButton30.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton30.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton30.BorderRadius = 0
        Me.BunifuFlatButton30.ButtonText = "Delete"
        Me.BunifuFlatButton30.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton30, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton30.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton30.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton30.Iconimage = Global.officesoft2.My.Resources.Resources.education
        Me.BunifuFlatButton30.Iconimage_right = Nothing
        Me.BunifuFlatButton30.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton30.Iconimage_Selected = Nothing
        Me.BunifuFlatButton30.IconMarginLeft = 0
        Me.BunifuFlatButton30.IconMarginRight = 0
        Me.BunifuFlatButton30.IconRightVisible = False
        Me.BunifuFlatButton30.IconRightZoom = 0R
        Me.BunifuFlatButton30.IconVisible = False
        Me.BunifuFlatButton30.IconZoom = 60.0R
        Me.BunifuFlatButton30.IsTab = False
        Me.BunifuFlatButton30.Location = New System.Drawing.Point(312, 6)
        Me.BunifuFlatButton30.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton30.Name = "BunifuFlatButton30"
        Me.BunifuFlatButton30.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton30.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton30.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton30.selected = False
        Me.BunifuFlatButton30.Size = New System.Drawing.Size(141, 36)
        Me.BunifuFlatButton30.TabIndex = 16
        Me.BunifuFlatButton30.Text = "Delete"
        Me.BunifuFlatButton30.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton30.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton30.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton250
        '
        Me.BunifuThinButton250.ActiveBorderThickness = 1
        Me.BunifuThinButton250.ActiveCornerRadius = 2
        Me.BunifuThinButton250.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton250.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton250.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton250.AutoSize = True
        Me.BunifuThinButton250.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton250.BackgroundImage = CType(resources.GetObject("BunifuThinButton250.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton250.ButtonText = "Sign Up"
        Me.BunifuThinButton250.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton250, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton250, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton250, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton250.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton250.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton250.IdleBorderThickness = 1
        Me.BunifuThinButton250.IdleCornerRadius = 1
        Me.BunifuThinButton250.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton250.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton250.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton250.Location = New System.Drawing.Point(14, 14)
        Me.BunifuThinButton250.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton250.Name = "BunifuThinButton250"
        Me.BunifuThinButton250.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton250.TabIndex = 23
        Me.BunifuThinButton250.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton251
        '
        Me.BunifuThinButton251.ActiveBorderThickness = 1
        Me.BunifuThinButton251.ActiveCornerRadius = 2
        Me.BunifuThinButton251.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton251.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton251.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton251.AutoSize = True
        Me.BunifuThinButton251.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton251.BackgroundImage = CType(resources.GetObject("BunifuThinButton251.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton251.ButtonText = "Sign Up"
        Me.BunifuThinButton251.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton251, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton251, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton251, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton251.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton251.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton251.IdleBorderThickness = 1
        Me.BunifuThinButton251.IdleCornerRadius = 1
        Me.BunifuThinButton251.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton251.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton251.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton251.Location = New System.Drawing.Point(312, 14)
        Me.BunifuThinButton251.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton251.Name = "BunifuThinButton251"
        Me.BunifuThinButton251.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton251.TabIndex = 29
        Me.BunifuThinButton251.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton252
        '
        Me.BunifuThinButton252.ActiveBorderThickness = 1
        Me.BunifuThinButton252.ActiveCornerRadius = 2
        Me.BunifuThinButton252.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton252.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton252.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton252.AutoSize = True
        Me.BunifuThinButton252.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton252.BackgroundImage = CType(resources.GetObject("BunifuThinButton252.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton252.ButtonText = "Sign Up"
        Me.BunifuThinButton252.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton252, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton252, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton252, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton252.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton252.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton252.IdleBorderThickness = 1
        Me.BunifuThinButton252.IdleCornerRadius = 1
        Me.BunifuThinButton252.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton252.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton252.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton252.Location = New System.Drawing.Point(462, 14)
        Me.BunifuThinButton252.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton252.Name = "BunifuThinButton252"
        Me.BunifuThinButton252.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton252.TabIndex = 31
        Me.BunifuThinButton252.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuGradientPanel14
        '
        Me.BunifuGradientPanel14.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel14.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel14.Controls.Add(Me.BunifuTextbox3)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel14.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel14.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel14.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel14.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel14.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel14.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel14.Name = "BunifuGradientPanel14"
        Me.BunifuGradientPanel14.Quality = 10
        Me.BunifuGradientPanel14.Size = New System.Drawing.Size(929, 37)
        Me.BunifuGradientPanel14.TabIndex = 2
        '
        'BunifuTextbox3
        '
        Me.BunifuTextbox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTextbox3.BackgroundImage = CType(resources.GetObject("BunifuTextbox3.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition1.SetDecoration(Me.BunifuTextbox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuTextbox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTextbox3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTextbox3.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox3.Icon = CType(resources.GetObject("BunifuTextbox3.Icon"), System.Drawing.Image)
        Me.BunifuTextbox3.Location = New System.Drawing.Point(8, 1)
        Me.BunifuTextbox3.Name = "BunifuTextbox3"
        Me.BunifuTextbox3.Size = New System.Drawing.Size(316, 31)
        Me.BunifuTextbox3.TabIndex = 0
        Me.BunifuTextbox3.text = "Search Section, Fees No"
        '
        'BunifuFlatButton19
        '
        Me.BunifuFlatButton19.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton19.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton19.BorderRadius = 0
        Me.BunifuFlatButton19.ButtonText = "References"
        Me.BunifuFlatButton19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton19.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton19.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton19.Iconimage = Global.officesoft2.My.Resources.Resources.hand_touching_tablet_screen
        Me.BunifuFlatButton19.Iconimage_right = Nothing
        Me.BunifuFlatButton19.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton19.Iconimage_Selected = Nothing
        Me.BunifuFlatButton19.IconMarginLeft = 0
        Me.BunifuFlatButton19.IconMarginRight = 0
        Me.BunifuFlatButton19.IconRightVisible = False
        Me.BunifuFlatButton19.IconRightZoom = 0R
        Me.BunifuFlatButton19.IconVisible = False
        Me.BunifuFlatButton19.IconZoom = 60.0R
        Me.BunifuFlatButton19.IsTab = False
        Me.BunifuFlatButton19.Location = New System.Drawing.Point(787, 6)
        Me.BunifuFlatButton19.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton19.Name = "BunifuFlatButton19"
        Me.BunifuFlatButton19.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton19.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton19.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton19.selected = False
        Me.BunifuFlatButton19.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton19.TabIndex = 17
        Me.BunifuFlatButton19.Text = "References"
        Me.BunifuFlatButton19.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton19.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton19.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton20
        '
        Me.BunifuFlatButton20.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton20.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton20.BorderRadius = 0
        Me.BunifuFlatButton20.ButtonText = "Employment"
        Me.BunifuFlatButton20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton20.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton20.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton20.Iconimage = Global.officesoft2.My.Resources.Resources.employee
        Me.BunifuFlatButton20.Iconimage_right = Nothing
        Me.BunifuFlatButton20.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton20.Iconimage_Selected = Nothing
        Me.BunifuFlatButton20.IconMarginLeft = 0
        Me.BunifuFlatButton20.IconMarginRight = 0
        Me.BunifuFlatButton20.IconRightVisible = False
        Me.BunifuFlatButton20.IconRightZoom = 0R
        Me.BunifuFlatButton20.IconVisible = False
        Me.BunifuFlatButton20.IconZoom = 60.0R
        Me.BunifuFlatButton20.IsTab = False
        Me.BunifuFlatButton20.Location = New System.Drawing.Point(631, 6)
        Me.BunifuFlatButton20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton20.Name = "BunifuFlatButton20"
        Me.BunifuFlatButton20.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton20.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton20.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton20.selected = False
        Me.BunifuFlatButton20.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton20.TabIndex = 17
        Me.BunifuFlatButton20.Text = "Employment"
        Me.BunifuFlatButton20.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton20.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton20.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton241
        '
        Me.BunifuThinButton241.ActiveBorderThickness = 1
        Me.BunifuThinButton241.ActiveCornerRadius = 2
        Me.BunifuThinButton241.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton241.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton241.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton241.AutoSize = True
        Me.BunifuThinButton241.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton241.BackgroundImage = CType(resources.GetObject("BunifuThinButton241.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton241.ButtonText = "Sign Up"
        Me.BunifuThinButton241.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton241, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton241, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton241, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton241.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton241.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton241.IdleBorderThickness = 1
        Me.BunifuThinButton241.IdleCornerRadius = 1
        Me.BunifuThinButton241.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton241.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton241.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton241.Location = New System.Drawing.Point(787, 14)
        Me.BunifuThinButton241.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton241.Name = "BunifuThinButton241"
        Me.BunifuThinButton241.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton241.TabIndex = 25
        Me.BunifuThinButton241.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton242
        '
        Me.BunifuThinButton242.ActiveBorderThickness = 1
        Me.BunifuThinButton242.ActiveCornerRadius = 2
        Me.BunifuThinButton242.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton242.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton242.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton242.AutoSize = True
        Me.BunifuThinButton242.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton242.BackgroundImage = CType(resources.GetObject("BunifuThinButton242.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton242.ButtonText = "Sign Up"
        Me.BunifuThinButton242.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton242, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton242, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton242, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton242.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton242.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton242.IdleBorderThickness = 1
        Me.BunifuThinButton242.IdleCornerRadius = 1
        Me.BunifuThinButton242.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton242.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton242.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton242.Location = New System.Drawing.Point(631, 14)
        Me.BunifuThinButton242.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton242.Name = "BunifuThinButton242"
        Me.BunifuThinButton242.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton242.TabIndex = 33
        Me.BunifuThinButton242.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton21
        '
        Me.BunifuFlatButton21.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton21.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton21.BorderRadius = 0
        Me.BunifuFlatButton21.ButtonText = "Receipt details"
        Me.BunifuFlatButton21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton21, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton21.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton21.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton21.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton21.Iconimage_right = Nothing
        Me.BunifuFlatButton21.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton21.Iconimage_Selected = Nothing
        Me.BunifuFlatButton21.IconMarginLeft = 0
        Me.BunifuFlatButton21.IconMarginRight = 0
        Me.BunifuFlatButton21.IconRightVisible = False
        Me.BunifuFlatButton21.IconRightZoom = 0R
        Me.BunifuFlatButton21.IconVisible = False
        Me.BunifuFlatButton21.IconZoom = 60.0R
        Me.BunifuFlatButton21.IsTab = False
        Me.BunifuFlatButton21.Location = New System.Drawing.Point(166, 6)
        Me.BunifuFlatButton21.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton21.Name = "BunifuFlatButton21"
        Me.BunifuFlatButton21.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton21.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton21.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton21.selected = False
        Me.BunifuFlatButton21.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton21.TabIndex = 34
        Me.BunifuFlatButton21.Text = "Receipt details"
        Me.BunifuFlatButton21.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton21.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton21.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuFlatButton21.Visible = False
        '
        'BunifuFlatButton22
        '
        Me.BunifuFlatButton22.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton22.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton22.BorderRadius = 0
        Me.BunifuFlatButton22.ButtonText = "Qualification"
        Me.BunifuFlatButton22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton22, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton22.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton22.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton22.Iconimage = Global.officesoft2.My.Resources.Resources.diploma
        Me.BunifuFlatButton22.Iconimage_right = Nothing
        Me.BunifuFlatButton22.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton22.Iconimage_Selected = Nothing
        Me.BunifuFlatButton22.IconMarginLeft = 0
        Me.BunifuFlatButton22.IconMarginRight = 0
        Me.BunifuFlatButton22.IconRightVisible = False
        Me.BunifuFlatButton22.IconRightZoom = 0R
        Me.BunifuFlatButton22.IconVisible = False
        Me.BunifuFlatButton22.IconZoom = 60.0R
        Me.BunifuFlatButton22.IsTab = False
        Me.BunifuFlatButton22.Location = New System.Drawing.Point(476, 6)
        Me.BunifuFlatButton22.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton22.Name = "BunifuFlatButton22"
        Me.BunifuFlatButton22.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton22.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton22.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton22.selected = False
        Me.BunifuFlatButton22.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton22.TabIndex = 35
        Me.BunifuFlatButton22.Text = "Qualification"
        Me.BunifuFlatButton22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton22.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton22.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton23
        '
        Me.BunifuFlatButton23.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton23.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton23.BorderRadius = 0
        Me.BunifuFlatButton23.ButtonText = "Fee Details"
        Me.BunifuFlatButton23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton23, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton23.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton23.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton23.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton23.Iconimage_right = Nothing
        Me.BunifuFlatButton23.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton23.Iconimage_Selected = Nothing
        Me.BunifuFlatButton23.IconMarginLeft = 0
        Me.BunifuFlatButton23.IconMarginRight = 0
        Me.BunifuFlatButton23.IconRightVisible = False
        Me.BunifuFlatButton23.IconRightZoom = 0R
        Me.BunifuFlatButton23.IconVisible = False
        Me.BunifuFlatButton23.IconZoom = 60.0R
        Me.BunifuFlatButton23.IsTab = False
        Me.BunifuFlatButton23.Location = New System.Drawing.Point(11, 6)
        Me.BunifuFlatButton23.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton23.Name = "BunifuFlatButton23"
        Me.BunifuFlatButton23.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton23.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton23.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton23.selected = False
        Me.BunifuFlatButton23.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton23.TabIndex = 15
        Me.BunifuFlatButton23.Text = "Fee Details"
        Me.BunifuFlatButton23.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton23.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton23.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton243
        '
        Me.BunifuThinButton243.ActiveBorderThickness = 1
        Me.BunifuThinButton243.ActiveCornerRadius = 2
        Me.BunifuThinButton243.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton243.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton243.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton243.AutoSize = True
        Me.BunifuThinButton243.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton243.BackgroundImage = CType(resources.GetObject("BunifuThinButton243.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton243.ButtonText = "Sign Up"
        Me.BunifuThinButton243.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton243, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton243, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton243, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton243.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton243.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton243.IdleBorderThickness = 1
        Me.BunifuThinButton243.IdleCornerRadius = 1
        Me.BunifuThinButton243.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton243.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton243.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton243.Location = New System.Drawing.Point(166, 14)
        Me.BunifuThinButton243.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton243.Name = "BunifuThinButton243"
        Me.BunifuThinButton243.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton243.TabIndex = 27
        Me.BunifuThinButton243.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton24
        '
        Me.BunifuFlatButton24.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton24.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton24.BorderRadius = 0
        Me.BunifuFlatButton24.ButtonText = "View Record"
        Me.BunifuFlatButton24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton24, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton24.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton24.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton24.Iconimage = Global.officesoft2.My.Resources.Resources.education
        Me.BunifuFlatButton24.Iconimage_right = Nothing
        Me.BunifuFlatButton24.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton24.Iconimage_Selected = Nothing
        Me.BunifuFlatButton24.IconMarginLeft = 0
        Me.BunifuFlatButton24.IconMarginRight = 0
        Me.BunifuFlatButton24.IconRightVisible = False
        Me.BunifuFlatButton24.IconRightZoom = 0R
        Me.BunifuFlatButton24.IconVisible = False
        Me.BunifuFlatButton24.IconZoom = 60.0R
        Me.BunifuFlatButton24.IsTab = False
        Me.BunifuFlatButton24.Location = New System.Drawing.Point(321, 6)
        Me.BunifuFlatButton24.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton24.Name = "BunifuFlatButton24"
        Me.BunifuFlatButton24.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton24.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton24.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton24.selected = False
        Me.BunifuFlatButton24.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton24.TabIndex = 16
        Me.BunifuFlatButton24.Text = "View Record"
        Me.BunifuFlatButton24.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton24.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton24.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton244
        '
        Me.BunifuThinButton244.ActiveBorderThickness = 1
        Me.BunifuThinButton244.ActiveCornerRadius = 2
        Me.BunifuThinButton244.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton244.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton244.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton244.AutoSize = True
        Me.BunifuThinButton244.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton244.BackgroundImage = CType(resources.GetObject("BunifuThinButton244.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton244.ButtonText = "Sign Up"
        Me.BunifuThinButton244.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton244, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton244, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton244, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton244.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton244.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton244.IdleBorderThickness = 1
        Me.BunifuThinButton244.IdleCornerRadius = 1
        Me.BunifuThinButton244.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton244.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton244.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton244.Location = New System.Drawing.Point(11, 14)
        Me.BunifuThinButton244.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton244.Name = "BunifuThinButton244"
        Me.BunifuThinButton244.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton244.TabIndex = 23
        Me.BunifuThinButton244.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton245
        '
        Me.BunifuThinButton245.ActiveBorderThickness = 1
        Me.BunifuThinButton245.ActiveCornerRadius = 2
        Me.BunifuThinButton245.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton245.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton245.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton245.AutoSize = True
        Me.BunifuThinButton245.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton245.BackgroundImage = CType(resources.GetObject("BunifuThinButton245.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton245.ButtonText = "Sign Up"
        Me.BunifuThinButton245.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton245, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton245, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton245, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton245.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton245.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton245.IdleBorderThickness = 1
        Me.BunifuThinButton245.IdleCornerRadius = 1
        Me.BunifuThinButton245.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton245.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton245.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton245.Location = New System.Drawing.Point(321, 14)
        Me.BunifuThinButton245.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton245.Name = "BunifuThinButton245"
        Me.BunifuThinButton245.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton245.TabIndex = 29
        Me.BunifuThinButton245.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton246
        '
        Me.BunifuThinButton246.ActiveBorderThickness = 1
        Me.BunifuThinButton246.ActiveCornerRadius = 2
        Me.BunifuThinButton246.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton246.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton246.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton246.AutoSize = True
        Me.BunifuThinButton246.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton246.BackgroundImage = CType(resources.GetObject("BunifuThinButton246.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton246.ButtonText = "Sign Up"
        Me.BunifuThinButton246.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton246, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton246, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton246, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton246.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton246.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton246.IdleBorderThickness = 1
        Me.BunifuThinButton246.IdleCornerRadius = 1
        Me.BunifuThinButton246.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton246.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton246.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton246.Location = New System.Drawing.Point(476, 6)
        Me.BunifuThinButton246.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton246.Name = "BunifuThinButton246"
        Me.BunifuThinButton246.Size = New System.Drawing.Size(149, 44)
        Me.BunifuThinButton246.TabIndex = 31
        Me.BunifuThinButton246.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuTileButton1
        '
        Me.BunifuTileButton1.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton1.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton1.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton1, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton1.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton1.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton1.Image = Global.officesoft2.My.Resources.Resources.calendar_with_a_clock_time_tools
        Me.BunifuTileButton1.ImagePosition = 5
        Me.BunifuTileButton1.ImageZoom = 25
        Me.BunifuTileButton1.LabelPosition = 26
        Me.BunifuTileButton1.LabelText = "Blood Group"
        Me.BunifuTileButton1.Location = New System.Drawing.Point(58, 17)
        Me.BunifuTileButton1.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuTileButton1.Name = "BunifuTileButton1"
        Me.BunifuTileButton1.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton1.TabIndex = 2
        '
        'BunifuTileButton17
        '
        Me.BunifuTileButton17.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton17.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton17.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton17, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton17.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton17.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton17.Image = CType(resources.GetObject("BunifuTileButton17.Image"), System.Drawing.Image)
        Me.BunifuTileButton17.ImagePosition = 5
        Me.BunifuTileButton17.ImageZoom = 25
        Me.BunifuTileButton17.LabelPosition = 26
        Me.BunifuTileButton17.LabelText = "Student Master"
        Me.BunifuTileButton17.Location = New System.Drawing.Point(689, 363)
        Me.BunifuTileButton17.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton17.Name = "BunifuTileButton17"
        Me.BunifuTileButton17.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton17.TabIndex = 21
        Me.BunifuTileButton17.Visible = False
        '
        'BunifuTileButton2
        '
        Me.BunifuTileButton2.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton2.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton2.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton2, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton2.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton2.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton2.Image = Global.officesoft2.My.Resources.Resources.month
        Me.BunifuTileButton2.ImagePosition = 5
        Me.BunifuTileButton2.ImageZoom = 25
        Me.BunifuTileButton2.LabelPosition = 26
        Me.BunifuTileButton2.LabelText = "Ward"
        Me.BunifuTileButton2.Location = New System.Drawing.Point(269, 17)
        Me.BunifuTileButton2.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BunifuTileButton2.Name = "BunifuTileButton2"
        Me.BunifuTileButton2.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton2.TabIndex = 3
        '
        'BunifuTileButton18
        '
        Me.BunifuTileButton18.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton18.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton18.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton18, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton18.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton18.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton18.Image = CType(resources.GetObject("BunifuTileButton18.Image"), System.Drawing.Image)
        Me.BunifuTileButton18.ImagePosition = 5
        Me.BunifuTileButton18.ImageZoom = 25
        Me.BunifuTileButton18.LabelPosition = 26
        Me.BunifuTileButton18.LabelText = "Payment Mode"
        Me.BunifuTileButton18.Location = New System.Drawing.Point(479, 363)
        Me.BunifuTileButton18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton18.Name = "BunifuTileButton18"
        Me.BunifuTileButton18.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton18.TabIndex = 20
        Me.BunifuTileButton18.Visible = False
        '
        'BunifuTileButton3
        '
        Me.BunifuTileButton3.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton3.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton3.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton3, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton3.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton3.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton3.Image = Global.officesoft2.My.Resources.Resources._class
        Me.BunifuTileButton3.ImagePosition = 5
        Me.BunifuTileButton3.ImageZoom = 25
        Me.BunifuTileButton3.LabelPosition = 26
        Me.BunifuTileButton3.LabelText = "Rooms"
        Me.BunifuTileButton3.Location = New System.Drawing.Point(689, 17)
        Me.BunifuTileButton3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton3.Name = "BunifuTileButton3"
        Me.BunifuTileButton3.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton3.TabIndex = 4
        '
        'BunifuTileButton19
        '
        Me.BunifuTileButton19.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton19.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton19.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton19, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton19.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton19.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton19.Image = CType(resources.GetObject("BunifuTileButton19.Image"), System.Drawing.Image)
        Me.BunifuTileButton19.ImagePosition = 5
        Me.BunifuTileButton19.ImageZoom = 25
        Me.BunifuTileButton19.LabelPosition = 26
        Me.BunifuTileButton19.LabelText = "Holiday Master"
        Me.BunifuTileButton19.Location = New System.Drawing.Point(269, 363)
        Me.BunifuTileButton19.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton19.Name = "BunifuTileButton19"
        Me.BunifuTileButton19.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton19.TabIndex = 19
        Me.BunifuTileButton19.Visible = False
        '
        'BunifuTileButton4
        '
        Me.BunifuTileButton4.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton4.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton4.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton4.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton4.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton4.Image = Global.officesoft2.My.Resources.Resources.subject
        Me.BunifuTileButton4.ImagePosition = 5
        Me.BunifuTileButton4.ImageZoom = 25
        Me.BunifuTileButton4.LabelPosition = 26
        Me.BunifuTileButton4.LabelText = "Ward Type"
        Me.BunifuTileButton4.Location = New System.Drawing.Point(479, 17)
        Me.BunifuTileButton4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton4.Name = "BunifuTileButton4"
        Me.BunifuTileButton4.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton4.TabIndex = 5
        '
        'BunifuTileButton20
        '
        Me.BunifuTileButton20.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton20.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton20.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton20, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton20.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton20.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton20.Image = CType(resources.GetObject("BunifuTileButton20.Image"), System.Drawing.Image)
        Me.BunifuTileButton20.ImagePosition = 5
        Me.BunifuTileButton20.ImageZoom = 25
        Me.BunifuTileButton20.LabelPosition = 26
        Me.BunifuTileButton20.LabelText = "Account Head"
        Me.BunifuTileButton20.Location = New System.Drawing.Point(58, 363)
        Me.BunifuTileButton20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton20.Name = "BunifuTileButton20"
        Me.BunifuTileButton20.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton20.TabIndex = 18
        Me.BunifuTileButton20.Visible = False
        '
        'BunifuTileButton5
        '
        Me.BunifuTileButton5.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton5.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton5.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton5.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton5.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton5.Image = CType(resources.GetObject("BunifuTileButton5.Image"), System.Drawing.Image)
        Me.BunifuTileButton5.ImagePosition = 5
        Me.BunifuTileButton5.ImageZoom = 25
        Me.BunifuTileButton5.LabelPosition = 26
        Me.BunifuTileButton5.LabelText = "State"
        Me.BunifuTileButton5.Location = New System.Drawing.Point(58, 103)
        Me.BunifuTileButton5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton5.Name = "BunifuTileButton5"
        Me.BunifuTileButton5.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton5.TabIndex = 6
        '
        'BunifuTileButton13
        '
        Me.BunifuTileButton13.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton13.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton13.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton13.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton13.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton13.Image = CType(resources.GetObject("BunifuTileButton13.Image"), System.Drawing.Image)
        Me.BunifuTileButton13.ImagePosition = 5
        Me.BunifuTileButton13.ImageZoom = 25
        Me.BunifuTileButton13.LabelPosition = 26
        Me.BunifuTileButton13.LabelText = "Blood Group"
        Me.BunifuTileButton13.Location = New System.Drawing.Point(689, 276)
        Me.BunifuTileButton13.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton13.Name = "BunifuTileButton13"
        Me.BunifuTileButton13.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton13.TabIndex = 17
        Me.BunifuTileButton13.Visible = False
        '
        'BunifuTileButton6
        '
        Me.BunifuTileButton6.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton6.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton6.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton6, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton6.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton6.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton6.Image = CType(resources.GetObject("BunifuTileButton6.Image"), System.Drawing.Image)
        Me.BunifuTileButton6.ImagePosition = 5
        Me.BunifuTileButton6.ImageZoom = 25
        Me.BunifuTileButton6.LabelPosition = 26
        Me.BunifuTileButton6.LabelText = "City"
        Me.BunifuTileButton6.Location = New System.Drawing.Point(269, 103)
        Me.BunifuTileButton6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton6.Name = "BunifuTileButton6"
        Me.BunifuTileButton6.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton6.TabIndex = 7
        '
        'BunifuTileButton14
        '
        Me.BunifuTileButton14.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton14.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton14.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton14, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton14.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton14.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton14.Image = CType(resources.GetObject("BunifuTileButton14.Image"), System.Drawing.Image)
        Me.BunifuTileButton14.ImagePosition = 5
        Me.BunifuTileButton14.ImageZoom = 25
        Me.BunifuTileButton14.LabelPosition = 26
        Me.BunifuTileButton14.LabelText = "Blood Group"
        Me.BunifuTileButton14.Location = New System.Drawing.Point(479, 276)
        Me.BunifuTileButton14.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton14.Name = "BunifuTileButton14"
        Me.BunifuTileButton14.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton14.TabIndex = 16
        Me.BunifuTileButton14.Visible = False
        '
        'BunifuTileButton7
        '
        Me.BunifuTileButton7.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton7.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton7.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton7.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton7.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton7.Image = CType(resources.GetObject("BunifuTileButton7.Image"), System.Drawing.Image)
        Me.BunifuTileButton7.ImagePosition = 5
        Me.BunifuTileButton7.ImageZoom = 25
        Me.BunifuTileButton7.LabelPosition = 26
        Me.BunifuTileButton7.LabelText = "Blood Group"
        Me.BunifuTileButton7.Location = New System.Drawing.Point(479, 103)
        Me.BunifuTileButton7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton7.Name = "BunifuTileButton7"
        Me.BunifuTileButton7.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton7.TabIndex = 8
        Me.BunifuTileButton7.Visible = False
        '
        'BunifuTileButton15
        '
        Me.BunifuTileButton15.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton15.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton15.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton15.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton15.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton15.Image = CType(resources.GetObject("BunifuTileButton15.Image"), System.Drawing.Image)
        Me.BunifuTileButton15.ImagePosition = 5
        Me.BunifuTileButton15.ImageZoom = 25
        Me.BunifuTileButton15.LabelPosition = 26
        Me.BunifuTileButton15.LabelText = "Blood Group"
        Me.BunifuTileButton15.Location = New System.Drawing.Point(269, 276)
        Me.BunifuTileButton15.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton15.Name = "BunifuTileButton15"
        Me.BunifuTileButton15.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton15.TabIndex = 15
        Me.BunifuTileButton15.Visible = False
        '
        'BunifuTileButton8
        '
        Me.BunifuTileButton8.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton8.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton8.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton8, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton8.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton8.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton8.Image = CType(resources.GetObject("BunifuTileButton8.Image"), System.Drawing.Image)
        Me.BunifuTileButton8.ImagePosition = 5
        Me.BunifuTileButton8.ImageZoom = 25
        Me.BunifuTileButton8.LabelPosition = 26
        Me.BunifuTileButton8.LabelText = "Blood Group"
        Me.BunifuTileButton8.Location = New System.Drawing.Point(689, 103)
        Me.BunifuTileButton8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton8.Name = "BunifuTileButton8"
        Me.BunifuTileButton8.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton8.TabIndex = 9
        Me.BunifuTileButton8.Visible = False
        '
        'BunifuTileButton16
        '
        Me.BunifuTileButton16.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton16.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton16.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton16.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton16.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton16.Image = CType(resources.GetObject("BunifuTileButton16.Image"), System.Drawing.Image)
        Me.BunifuTileButton16.ImagePosition = 5
        Me.BunifuTileButton16.ImageZoom = 25
        Me.BunifuTileButton16.LabelPosition = 26
        Me.BunifuTileButton16.LabelText = "Blood Group"
        Me.BunifuTileButton16.Location = New System.Drawing.Point(58, 276)
        Me.BunifuTileButton16.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton16.Name = "BunifuTileButton16"
        Me.BunifuTileButton16.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton16.TabIndex = 14
        Me.BunifuTileButton16.Visible = False
        '
        'BunifuTileButton12
        '
        Me.BunifuTileButton12.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton12.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton12.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton12.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton12.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton12.Image = CType(resources.GetObject("BunifuTileButton12.Image"), System.Drawing.Image)
        Me.BunifuTileButton12.ImagePosition = 5
        Me.BunifuTileButton12.ImageZoom = 25
        Me.BunifuTileButton12.LabelPosition = 26
        Me.BunifuTileButton12.LabelText = "Blood Group"
        Me.BunifuTileButton12.Location = New System.Drawing.Point(58, 189)
        Me.BunifuTileButton12.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton12.Name = "BunifuTileButton12"
        Me.BunifuTileButton12.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton12.TabIndex = 10
        Me.BunifuTileButton12.Visible = False
        '
        'BunifuTileButton9
        '
        Me.BunifuTileButton9.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton9.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton9.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton9, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton9.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton9.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton9.Image = CType(resources.GetObject("BunifuTileButton9.Image"), System.Drawing.Image)
        Me.BunifuTileButton9.ImagePosition = 5
        Me.BunifuTileButton9.ImageZoom = 25
        Me.BunifuTileButton9.LabelPosition = 26
        Me.BunifuTileButton9.LabelText = "Blood Group"
        Me.BunifuTileButton9.Location = New System.Drawing.Point(689, 189)
        Me.BunifuTileButton9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton9.Name = "BunifuTileButton9"
        Me.BunifuTileButton9.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton9.TabIndex = 13
        Me.BunifuTileButton9.Visible = False
        '
        'BunifuTileButton11
        '
        Me.BunifuTileButton11.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton11.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton11.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton11, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton11.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton11.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton11.Image = CType(resources.GetObject("BunifuTileButton11.Image"), System.Drawing.Image)
        Me.BunifuTileButton11.ImagePosition = 5
        Me.BunifuTileButton11.ImageZoom = 25
        Me.BunifuTileButton11.LabelPosition = 26
        Me.BunifuTileButton11.LabelText = "Blood Group"
        Me.BunifuTileButton11.Location = New System.Drawing.Point(269, 189)
        Me.BunifuTileButton11.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton11.Name = "BunifuTileButton11"
        Me.BunifuTileButton11.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton11.TabIndex = 11
        Me.BunifuTileButton11.Visible = False
        '
        'BunifuTileButton10
        '
        Me.BunifuTileButton10.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton10.color = System.Drawing.Color.SeaGreen
        Me.BunifuTileButton10.colorActive = System.Drawing.Color.MediumSeaGreen
        Me.BunifuTileButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition2.SetDecoration(Me.BunifuTileButton10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuTileButton10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTileButton10, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTileButton10.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.BunifuTileButton10.ForeColor = System.Drawing.Color.White
        Me.BunifuTileButton10.Image = CType(resources.GetObject("BunifuTileButton10.Image"), System.Drawing.Image)
        Me.BunifuTileButton10.ImagePosition = 5
        Me.BunifuTileButton10.ImageZoom = 25
        Me.BunifuTileButton10.LabelPosition = 26
        Me.BunifuTileButton10.LabelText = "Blood Group"
        Me.BunifuTileButton10.Location = New System.Drawing.Point(479, 189)
        Me.BunifuTileButton10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuTileButton10.Name = "BunifuTileButton10"
        Me.BunifuTileButton10.Size = New System.Drawing.Size(207, 84)
        Me.BunifuTileButton10.TabIndex = 12
        Me.BunifuTileButton10.Visible = False
        '
        'BunifuFlatButton38
        '
        Me.BunifuFlatButton38.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton38.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton38.BorderRadius = 0
        Me.BunifuFlatButton38.ButtonText = "Home"
        Me.BunifuFlatButton38.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton38, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton38.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton38.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton38.Iconimage = Global.officesoft2.My.Resources.Resources.hand_touching_tablet_screen
        Me.BunifuFlatButton38.Iconimage_right = Nothing
        Me.BunifuFlatButton38.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton38.Iconimage_Selected = Nothing
        Me.BunifuFlatButton38.IconMarginLeft = 0
        Me.BunifuFlatButton38.IconMarginRight = 0
        Me.BunifuFlatButton38.IconRightVisible = False
        Me.BunifuFlatButton38.IconRightZoom = 0R
        Me.BunifuFlatButton38.IconVisible = False
        Me.BunifuFlatButton38.IconZoom = 60.0R
        Me.BunifuFlatButton38.IsTab = False
        Me.BunifuFlatButton38.Location = New System.Drawing.Point(478, 7)
        Me.BunifuFlatButton38.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton38.Name = "BunifuFlatButton38"
        Me.BunifuFlatButton38.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton38.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton38.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton38.selected = False
        Me.BunifuFlatButton38.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton38.TabIndex = 17
        Me.BunifuFlatButton38.Text = "Home"
        Me.BunifuFlatButton38.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton38.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton38.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton39
        '
        Me.BunifuFlatButton39.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton39.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton39.BorderRadius = 0
        Me.BunifuFlatButton39.ButtonText = "Clear"
        Me.BunifuFlatButton39.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton39, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton39.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton39.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton39.Iconimage = Global.officesoft2.My.Resources.Resources.employee
        Me.BunifuFlatButton39.Iconimage_right = Nothing
        Me.BunifuFlatButton39.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton39.Iconimage_Selected = Nothing
        Me.BunifuFlatButton39.IconMarginLeft = 0
        Me.BunifuFlatButton39.IconMarginRight = 0
        Me.BunifuFlatButton39.IconRightVisible = False
        Me.BunifuFlatButton39.IconRightZoom = 0R
        Me.BunifuFlatButton39.IconVisible = False
        Me.BunifuFlatButton39.IconZoom = 60.0R
        Me.BunifuFlatButton39.IsTab = False
        Me.BunifuFlatButton39.Location = New System.Drawing.Point(322, 7)
        Me.BunifuFlatButton39.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton39.Name = "BunifuFlatButton39"
        Me.BunifuFlatButton39.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton39.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton39.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton39.selected = False
        Me.BunifuFlatButton39.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton39.TabIndex = 17
        Me.BunifuFlatButton39.Text = "Clear"
        Me.BunifuFlatButton39.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton39.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton39.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton259
        '
        Me.BunifuThinButton259.ActiveBorderThickness = 1
        Me.BunifuThinButton259.ActiveCornerRadius = 2
        Me.BunifuThinButton259.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton259.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton259.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton259.AutoSize = True
        Me.BunifuThinButton259.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton259.BackgroundImage = CType(resources.GetObject("BunifuThinButton259.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton259.ButtonText = "Sign Up"
        Me.BunifuThinButton259.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton259, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton259, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton259, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton259.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton259.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton259.IdleBorderThickness = 1
        Me.BunifuThinButton259.IdleCornerRadius = 1
        Me.BunifuThinButton259.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton259.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton259.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton259.Location = New System.Drawing.Point(478, 15)
        Me.BunifuThinButton259.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton259.Name = "BunifuThinButton259"
        Me.BunifuThinButton259.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton259.TabIndex = 25
        Me.BunifuThinButton259.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton260
        '
        Me.BunifuThinButton260.ActiveBorderThickness = 1
        Me.BunifuThinButton260.ActiveCornerRadius = 2
        Me.BunifuThinButton260.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton260.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton260.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton260.AutoSize = True
        Me.BunifuThinButton260.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton260.BackgroundImage = CType(resources.GetObject("BunifuThinButton260.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton260.ButtonText = "Sign Up"
        Me.BunifuThinButton260.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton260, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton260, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton260, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton260.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton260.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton260.IdleBorderThickness = 1
        Me.BunifuThinButton260.IdleCornerRadius = 1
        Me.BunifuThinButton260.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton260.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton260.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton260.Location = New System.Drawing.Point(322, 15)
        Me.BunifuThinButton260.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton260.Name = "BunifuThinButton260"
        Me.BunifuThinButton260.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton260.TabIndex = 33
        Me.BunifuThinButton260.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton40
        '
        Me.BunifuFlatButton40.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton40.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton40.BorderRadius = 0
        Me.BunifuFlatButton40.ButtonText = "Save"
        Me.BunifuFlatButton40.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton40, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton40.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton40.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton40.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton40.Iconimage_right = Nothing
        Me.BunifuFlatButton40.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton40.Iconimage_Selected = Nothing
        Me.BunifuFlatButton40.IconMarginLeft = 0
        Me.BunifuFlatButton40.IconMarginRight = 0
        Me.BunifuFlatButton40.IconRightVisible = False
        Me.BunifuFlatButton40.IconRightZoom = 0R
        Me.BunifuFlatButton40.IconVisible = False
        Me.BunifuFlatButton40.IconZoom = 60.0R
        Me.BunifuFlatButton40.IsTab = False
        Me.BunifuFlatButton40.Location = New System.Drawing.Point(166, 6)
        Me.BunifuFlatButton40.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton40.Name = "BunifuFlatButton40"
        Me.BunifuFlatButton40.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton40.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton40.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton40.selected = False
        Me.BunifuFlatButton40.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton40.TabIndex = 34
        Me.BunifuFlatButton40.Text = "Save"
        Me.BunifuFlatButton40.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton40.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton40.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton42
        '
        Me.BunifuFlatButton42.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton42.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton42.BorderRadius = 0
        Me.BunifuFlatButton42.ButtonText = "New"
        Me.BunifuFlatButton42.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton42, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton42.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton42.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton42.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton42.Iconimage_right = Nothing
        Me.BunifuFlatButton42.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton42.Iconimage_Selected = Nothing
        Me.BunifuFlatButton42.IconMarginLeft = 0
        Me.BunifuFlatButton42.IconMarginRight = 0
        Me.BunifuFlatButton42.IconRightVisible = False
        Me.BunifuFlatButton42.IconRightZoom = 0R
        Me.BunifuFlatButton42.IconVisible = False
        Me.BunifuFlatButton42.IconZoom = 60.0R
        Me.BunifuFlatButton42.IsTab = False
        Me.BunifuFlatButton42.Location = New System.Drawing.Point(11, 6)
        Me.BunifuFlatButton42.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton42.Name = "BunifuFlatButton42"
        Me.BunifuFlatButton42.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton42.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton42.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton42.selected = False
        Me.BunifuFlatButton42.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton42.TabIndex = 15
        Me.BunifuFlatButton42.Text = "New"
        Me.BunifuFlatButton42.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton42.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton42.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton261
        '
        Me.BunifuThinButton261.ActiveBorderThickness = 1
        Me.BunifuThinButton261.ActiveCornerRadius = 2
        Me.BunifuThinButton261.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton261.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton261.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton261.AutoSize = True
        Me.BunifuThinButton261.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton261.BackgroundImage = CType(resources.GetObject("BunifuThinButton261.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton261.ButtonText = "Sign Up"
        Me.BunifuThinButton261.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton261, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton261, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton261, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton261.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton261.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton261.IdleBorderThickness = 1
        Me.BunifuThinButton261.IdleCornerRadius = 1
        Me.BunifuThinButton261.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton261.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton261.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton261.Location = New System.Drawing.Point(166, 14)
        Me.BunifuThinButton261.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton261.Name = "BunifuThinButton261"
        Me.BunifuThinButton261.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton261.TabIndex = 27
        Me.BunifuThinButton261.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton262
        '
        Me.BunifuThinButton262.ActiveBorderThickness = 1
        Me.BunifuThinButton262.ActiveCornerRadius = 2
        Me.BunifuThinButton262.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton262.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton262.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton262.AutoSize = True
        Me.BunifuThinButton262.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton262.BackgroundImage = CType(resources.GetObject("BunifuThinButton262.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton262.ButtonText = "Sign Up"
        Me.BunifuThinButton262.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton262, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton262, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton262, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton262.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton262.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton262.IdleBorderThickness = 1
        Me.BunifuThinButton262.IdleCornerRadius = 1
        Me.BunifuThinButton262.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton262.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton262.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton262.Location = New System.Drawing.Point(11, 14)
        Me.BunifuThinButton262.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton262.Name = "BunifuThinButton262"
        Me.BunifuThinButton262.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton262.TabIndex = 23
        Me.BunifuThinButton262.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton34
        '
        Me.BunifuFlatButton34.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton34.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton34.BorderRadius = 0
        Me.BunifuFlatButton34.ButtonText = "Ward Allocation"
        Me.BunifuFlatButton34.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton34, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton34.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton34.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton34.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton34.Iconimage_right = Nothing
        Me.BunifuFlatButton34.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton34.Iconimage_Selected = Nothing
        Me.BunifuFlatButton34.IconMarginLeft = 0
        Me.BunifuFlatButton34.IconMarginRight = 0
        Me.BunifuFlatButton34.IconRightVisible = False
        Me.BunifuFlatButton34.IconRightZoom = 0R
        Me.BunifuFlatButton34.IconVisible = False
        Me.BunifuFlatButton34.IconZoom = 60.0R
        Me.BunifuFlatButton34.IsTab = False
        Me.BunifuFlatButton34.Location = New System.Drawing.Point(166, 6)
        Me.BunifuFlatButton34.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton34.Name = "BunifuFlatButton34"
        Me.BunifuFlatButton34.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton34.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton34.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton34.selected = False
        Me.BunifuFlatButton34.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton34.TabIndex = 34
        Me.BunifuFlatButton34.Text = "Ward Allocation"
        Me.BunifuFlatButton34.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton34.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton34.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton35
        '
        Me.BunifuFlatButton35.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton35.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton35.BorderRadius = 0
        Me.BunifuFlatButton35.ButtonText = "View Data"
        Me.BunifuFlatButton35.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton35, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton35.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton35.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton35.Iconimage = Global.officesoft2.My.Resources.Resources.diploma
        Me.BunifuFlatButton35.Iconimage_right = Nothing
        Me.BunifuFlatButton35.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton35.Iconimage_Selected = Nothing
        Me.BunifuFlatButton35.IconMarginLeft = 0
        Me.BunifuFlatButton35.IconMarginRight = 0
        Me.BunifuFlatButton35.IconRightVisible = False
        Me.BunifuFlatButton35.IconRightZoom = 0R
        Me.BunifuFlatButton35.IconVisible = False
        Me.BunifuFlatButton35.IconZoom = 60.0R
        Me.BunifuFlatButton35.IsTab = False
        Me.BunifuFlatButton35.Location = New System.Drawing.Point(320, 6)
        Me.BunifuFlatButton35.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton35.Name = "BunifuFlatButton35"
        Me.BunifuFlatButton35.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton35.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton35.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton35.selected = False
        Me.BunifuFlatButton35.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton35.TabIndex = 35
        Me.BunifuFlatButton35.Text = "View Data"
        Me.BunifuFlatButton35.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton35.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton35.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton36
        '
        Me.BunifuFlatButton36.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton36.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton36.BorderRadius = 0
        Me.BunifuFlatButton36.ButtonText = "Add Nurse"
        Me.BunifuFlatButton36.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton36, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton36.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton36.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton36.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton36.Iconimage_right = Nothing
        Me.BunifuFlatButton36.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton36.Iconimage_Selected = Nothing
        Me.BunifuFlatButton36.IconMarginLeft = 0
        Me.BunifuFlatButton36.IconMarginRight = 0
        Me.BunifuFlatButton36.IconRightVisible = False
        Me.BunifuFlatButton36.IconRightZoom = 0R
        Me.BunifuFlatButton36.IconVisible = False
        Me.BunifuFlatButton36.IconZoom = 60.0R
        Me.BunifuFlatButton36.IsTab = False
        Me.BunifuFlatButton36.Location = New System.Drawing.Point(11, 6)
        Me.BunifuFlatButton36.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton36.Name = "BunifuFlatButton36"
        Me.BunifuFlatButton36.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton36.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton36.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton36.selected = False
        Me.BunifuFlatButton36.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton36.TabIndex = 15
        Me.BunifuFlatButton36.Text = "Add Nurse"
        Me.BunifuFlatButton36.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BunifuFlatButton36.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton36.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton255
        '
        Me.BunifuThinButton255.ActiveBorderThickness = 1
        Me.BunifuThinButton255.ActiveCornerRadius = 2
        Me.BunifuThinButton255.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton255.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton255.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton255.AutoSize = True
        Me.BunifuThinButton255.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton255.BackgroundImage = CType(resources.GetObject("BunifuThinButton255.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton255.ButtonText = "Sign Up"
        Me.BunifuThinButton255.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton255, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton255, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton255, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton255.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton255.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton255.IdleBorderThickness = 1
        Me.BunifuThinButton255.IdleCornerRadius = 1
        Me.BunifuThinButton255.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton255.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton255.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton255.Location = New System.Drawing.Point(166, 14)
        Me.BunifuThinButton255.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton255.Name = "BunifuThinButton255"
        Me.BunifuThinButton255.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton255.TabIndex = 27
        Me.BunifuThinButton255.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton256
        '
        Me.BunifuThinButton256.ActiveBorderThickness = 1
        Me.BunifuThinButton256.ActiveCornerRadius = 2
        Me.BunifuThinButton256.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton256.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton256.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton256.AutoSize = True
        Me.BunifuThinButton256.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton256.BackgroundImage = CType(resources.GetObject("BunifuThinButton256.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton256.ButtonText = "Sign Up"
        Me.BunifuThinButton256.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton256, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton256, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton256, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton256.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton256.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton256.IdleBorderThickness = 1
        Me.BunifuThinButton256.IdleCornerRadius = 1
        Me.BunifuThinButton256.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton256.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton256.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton256.Location = New System.Drawing.Point(11, 14)
        Me.BunifuThinButton256.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton256.Name = "BunifuThinButton256"
        Me.BunifuThinButton256.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton256.TabIndex = 23
        Me.BunifuThinButton256.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton258
        '
        Me.BunifuThinButton258.ActiveBorderThickness = 1
        Me.BunifuThinButton258.ActiveCornerRadius = 2
        Me.BunifuThinButton258.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton258.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton258.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton258.AutoSize = True
        Me.BunifuThinButton258.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton258.BackgroundImage = CType(resources.GetObject("BunifuThinButton258.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton258.ButtonText = "Sign Up"
        Me.BunifuThinButton258.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton258, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton258, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton258, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton258.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton258.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton258.IdleBorderThickness = 1
        Me.BunifuThinButton258.IdleCornerRadius = 1
        Me.BunifuThinButton258.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton258.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton258.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton258.Location = New System.Drawing.Point(320, 6)
        Me.BunifuThinButton258.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton258.Name = "BunifuThinButton258"
        Me.BunifuThinButton258.Size = New System.Drawing.Size(149, 44)
        Me.BunifuThinButton258.TabIndex = 31
        Me.BunifuThinButton258.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton13
        '
        Me.BunifuFlatButton13.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton13.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton13.BorderRadius = 0
        Me.BunifuFlatButton13.ButtonText = "Clear"
        Me.BunifuFlatButton13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton13, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton13.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton13.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton13.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton13.Iconimage_right = Nothing
        Me.BunifuFlatButton13.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton13.Iconimage_Selected = Nothing
        Me.BunifuFlatButton13.IconMarginLeft = 0
        Me.BunifuFlatButton13.IconMarginRight = 0
        Me.BunifuFlatButton13.IconRightVisible = False
        Me.BunifuFlatButton13.IconRightZoom = 0R
        Me.BunifuFlatButton13.IconVisible = False
        Me.BunifuFlatButton13.IconZoom = 60.0R
        Me.BunifuFlatButton13.IsTab = False
        Me.BunifuFlatButton13.Location = New System.Drawing.Point(700, 118)
        Me.BunifuFlatButton13.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton13.Name = "BunifuFlatButton13"
        Me.BunifuFlatButton13.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton13.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton13.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton13.selected = False
        Me.BunifuFlatButton13.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton13.TabIndex = 163
        Me.BunifuFlatButton13.Text = "Clear"
        Me.BunifuFlatButton13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton13.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton13.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton12
        '
        Me.BunifuFlatButton12.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton12.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton12.BorderRadius = 0
        Me.BunifuFlatButton12.ButtonText = "Submit"
        Me.BunifuFlatButton12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton12, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton12.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton12.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton12.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton12.Iconimage_right = Nothing
        Me.BunifuFlatButton12.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton12.Iconimage_Selected = Nothing
        Me.BunifuFlatButton12.IconMarginLeft = 0
        Me.BunifuFlatButton12.IconMarginRight = 0
        Me.BunifuFlatButton12.IconRightVisible = False
        Me.BunifuFlatButton12.IconRightZoom = 0R
        Me.BunifuFlatButton12.IconVisible = False
        Me.BunifuFlatButton12.IconZoom = 60.0R
        Me.BunifuFlatButton12.IsTab = False
        Me.BunifuFlatButton12.Location = New System.Drawing.Point(518, 118)
        Me.BunifuFlatButton12.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton12.Name = "BunifuFlatButton12"
        Me.BunifuFlatButton12.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton12.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton12.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton12.selected = False
        Me.BunifuFlatButton12.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton12.TabIndex = 36
        Me.BunifuFlatButton12.Text = "Submit"
        Me.BunifuFlatButton12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton12.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton12.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuGradientPanel15
        '
        Me.BunifuGradientPanel15.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel15.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel15.Controls.Add(Me.BunifuTextbox4)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel15, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel15.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel15.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel15.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel15.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel15.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel15.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel15.Name = "BunifuGradientPanel15"
        Me.BunifuGradientPanel15.Quality = 10
        Me.BunifuGradientPanel15.Size = New System.Drawing.Size(943, 37)
        Me.BunifuGradientPanel15.TabIndex = 18
        '
        'BunifuTextbox4
        '
        Me.BunifuTextbox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTextbox4.BackgroundImage = CType(resources.GetObject("BunifuTextbox4.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition1.SetDecoration(Me.BunifuTextbox4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuTextbox4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTextbox4, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTextbox4.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox4.Icon = CType(resources.GetObject("BunifuTextbox4.Icon"), System.Drawing.Image)
        Me.BunifuTextbox4.Location = New System.Drawing.Point(12, 1)
        Me.BunifuTextbox4.Name = "BunifuTextbox4"
        Me.BunifuTextbox4.Size = New System.Drawing.Size(239, 31)
        Me.BunifuTextbox4.TabIndex = 0
        Me.BunifuTextbox4.text = "Search Here"
        '
        'TabPage26
        '
        Me.TabPage26.BackgroundImage = Global.officesoft2.My.Resources.Resources.doctor_5
        Me.TabPage26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition3.SetDecoration(Me.TabPage26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.TabPage26, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.TabPage26, BunifuAnimatorNS.DecorationType.None)
        Me.TabPage26.Location = New System.Drawing.Point(4, 22)
        Me.TabPage26.Name = "TabPage26"
        Me.TabPage26.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage26.Size = New System.Drawing.Size(957, 606)
        Me.TabPage26.TabIndex = 8
        Me.TabPage26.Text = "TabPage26"
        Me.TabPage26.UseVisualStyleBackColor = True
        '
        'BunifuFlatButton32
        '
        Me.BunifuFlatButton32.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton32.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton32.BorderRadius = 0
        Me.BunifuFlatButton32.ButtonText = "Disconnect"
        Me.BunifuFlatButton32.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton32, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton32.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton32.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton32.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton32.Iconimage_right = Nothing
        Me.BunifuFlatButton32.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton32.Iconimage_Selected = Nothing
        Me.BunifuFlatButton32.IconMarginLeft = 0
        Me.BunifuFlatButton32.IconMarginRight = 0
        Me.BunifuFlatButton32.IconRightVisible = False
        Me.BunifuFlatButton32.IconRightZoom = 0R
        Me.BunifuFlatButton32.IconVisible = False
        Me.BunifuFlatButton32.IconZoom = 60.0R
        Me.BunifuFlatButton32.IsTab = False
        Me.BunifuFlatButton32.Location = New System.Drawing.Point(351, 153)
        Me.BunifuFlatButton32.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton32.Name = "BunifuFlatButton32"
        Me.BunifuFlatButton32.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton32.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton32.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton32.selected = False
        Me.BunifuFlatButton32.Size = New System.Drawing.Size(121, 36)
        Me.BunifuFlatButton32.TabIndex = 127
        Me.BunifuFlatButton32.Text = "Disconnect"
        Me.BunifuFlatButton32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton32.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton32.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton7
        '
        Me.BunifuFlatButton7.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton7.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton7.BorderRadius = 0
        Me.BunifuFlatButton7.ButtonText = "Connect"
        Me.BunifuFlatButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton7, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton7.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton7.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton7.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton7.Iconimage_right = Nothing
        Me.BunifuFlatButton7.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton7.Iconimage_Selected = Nothing
        Me.BunifuFlatButton7.IconMarginLeft = 0
        Me.BunifuFlatButton7.IconMarginRight = 0
        Me.BunifuFlatButton7.IconRightVisible = False
        Me.BunifuFlatButton7.IconRightZoom = 0R
        Me.BunifuFlatButton7.IconVisible = False
        Me.BunifuFlatButton7.IconZoom = 60.0R
        Me.BunifuFlatButton7.IsTab = False
        Me.BunifuFlatButton7.Location = New System.Drawing.Point(197, 153)
        Me.BunifuFlatButton7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton7.Name = "BunifuFlatButton7"
        Me.BunifuFlatButton7.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton7.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton7.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton7.selected = False
        Me.BunifuFlatButton7.Size = New System.Drawing.Size(121, 36)
        Me.BunifuFlatButton7.TabIndex = 126
        Me.BunifuFlatButton7.Text = "Connect"
        Me.BunifuFlatButton7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton7.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton7.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton264
        '
        Me.BunifuThinButton264.ActiveBorderThickness = 1
        Me.BunifuThinButton264.ActiveCornerRadius = 3
        Me.BunifuThinButton264.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton264.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton264.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton264.AutoSize = True
        Me.BunifuThinButton264.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton264.BackgroundImage = CType(resources.GetObject("BunifuThinButton264.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton264.ButtonText = "Home"
        Me.BunifuThinButton264.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton264, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton264, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton264, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton264.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton264.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton264.IdleBorderThickness = 1
        Me.BunifuThinButton264.IdleCornerRadius = 1
        Me.BunifuThinButton264.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton264.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton264.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton264.Location = New System.Drawing.Point(592, 4)
        Me.BunifuThinButton264.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton264.Name = "BunifuThinButton264"
        Me.BunifuThinButton264.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton264.TabIndex = 38
        Me.BunifuThinButton264.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton265
        '
        Me.BunifuThinButton265.ActiveBorderThickness = 1
        Me.BunifuThinButton265.ActiveCornerRadius = 2
        Me.BunifuThinButton265.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton265.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton265.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton265.AutoSize = True
        Me.BunifuThinButton265.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton265.BackgroundImage = CType(resources.GetObject("BunifuThinButton265.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton265.ButtonText = "Sign Up"
        Me.BunifuThinButton265.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton265, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton265, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton265, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton265.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton265.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton265.IdleBorderThickness = 1
        Me.BunifuThinButton265.IdleCornerRadius = 1
        Me.BunifuThinButton265.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton265.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton265.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton265.Location = New System.Drawing.Point(592, 3)
        Me.BunifuThinButton265.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton265.Name = "BunifuThinButton265"
        Me.BunifuThinButton265.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton265.TabIndex = 37
        Me.BunifuThinButton265.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton266
        '
        Me.BunifuThinButton266.ActiveBorderThickness = 1
        Me.BunifuThinButton266.ActiveCornerRadius = 3
        Me.BunifuThinButton266.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton266.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton266.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton266.AutoSize = True
        Me.BunifuThinButton266.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton266.BackgroundImage = CType(resources.GetObject("BunifuThinButton266.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton266.ButtonText = "View Record"
        Me.BunifuThinButton266.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton266, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton266, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton266, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton266.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton266.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton266.IdleBorderThickness = 1
        Me.BunifuThinButton266.IdleCornerRadius = 1
        Me.BunifuThinButton266.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton266.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton266.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton266.Location = New System.Drawing.Point(444, 4)
        Me.BunifuThinButton266.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton266.Name = "BunifuThinButton266"
        Me.BunifuThinButton266.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton266.TabIndex = 36
        Me.BunifuThinButton266.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton267
        '
        Me.BunifuThinButton267.ActiveBorderThickness = 1
        Me.BunifuThinButton267.ActiveCornerRadius = 2
        Me.BunifuThinButton267.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton267.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton267.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton267.AutoSize = True
        Me.BunifuThinButton267.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton267.BackgroundImage = CType(resources.GetObject("BunifuThinButton267.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton267.ButtonText = "Sign Up"
        Me.BunifuThinButton267.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton267, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton267, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton267, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton267.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton267.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton267.IdleBorderThickness = 1
        Me.BunifuThinButton267.IdleCornerRadius = 1
        Me.BunifuThinButton267.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton267.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton267.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton267.Location = New System.Drawing.Point(444, 3)
        Me.BunifuThinButton267.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton267.Name = "BunifuThinButton267"
        Me.BunifuThinButton267.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton267.TabIndex = 35
        Me.BunifuThinButton267.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton269
        '
        Me.BunifuThinButton269.ActiveBorderThickness = 1
        Me.BunifuThinButton269.ActiveCornerRadius = 3
        Me.BunifuThinButton269.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton269.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton269.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton269.AutoSize = True
        Me.BunifuThinButton269.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton269.BackgroundImage = CType(resources.GetObject("BunifuThinButton269.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton269.ButtonText = "Submit"
        Me.BunifuThinButton269.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton269, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton269, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton269, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton269.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton269.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton269.IdleBorderThickness = 1
        Me.BunifuThinButton269.IdleCornerRadius = 1
        Me.BunifuThinButton269.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton269.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton269.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton269.Location = New System.Drawing.Point(3, 4)
        Me.BunifuThinButton269.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton269.Name = "BunifuThinButton269"
        Me.BunifuThinButton269.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton269.TabIndex = 28
        Me.BunifuThinButton269.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton271
        '
        Me.BunifuThinButton271.ActiveBorderThickness = 1
        Me.BunifuThinButton271.ActiveCornerRadius = 3
        Me.BunifuThinButton271.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton271.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton271.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton271.AutoSize = True
        Me.BunifuThinButton271.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton271.BackgroundImage = CType(resources.GetObject("BunifuThinButton271.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton271.ButtonText = "Clear"
        Me.BunifuThinButton271.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton271, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton271, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton271, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton271.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton271.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton271.IdleBorderThickness = 1
        Me.BunifuThinButton271.IdleCornerRadius = 1
        Me.BunifuThinButton271.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton271.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton271.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton271.Location = New System.Drawing.Point(300, 4)
        Me.BunifuThinButton271.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton271.Name = "BunifuThinButton271"
        Me.BunifuThinButton271.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton271.TabIndex = 34
        Me.BunifuThinButton271.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton272
        '
        Me.BunifuThinButton272.ActiveBorderThickness = 1
        Me.BunifuThinButton272.ActiveCornerRadius = 2
        Me.BunifuThinButton272.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton272.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton272.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton272.AutoSize = True
        Me.BunifuThinButton272.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton272.BackgroundImage = CType(resources.GetObject("BunifuThinButton272.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton272.ButtonText = "Sign Up"
        Me.BunifuThinButton272.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton272, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton272, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton272, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton272.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton272.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton272.IdleBorderThickness = 1
        Me.BunifuThinButton272.IdleCornerRadius = 1
        Me.BunifuThinButton272.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton272.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton272.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton272.Location = New System.Drawing.Point(3, 3)
        Me.BunifuThinButton272.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton272.Name = "BunifuThinButton272"
        Me.BunifuThinButton272.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton272.TabIndex = 27
        Me.BunifuThinButton272.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton273
        '
        Me.BunifuThinButton273.ActiveBorderThickness = 1
        Me.BunifuThinButton273.ActiveCornerRadius = 3
        Me.BunifuThinButton273.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton273.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton273.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton273.AutoSize = True
        Me.BunifuThinButton273.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton273.BackgroundImage = CType(resources.GetObject("BunifuThinButton273.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton273.ButtonText = "Delete"
        Me.BunifuThinButton273.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton273, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton273, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton273, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton273.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton273.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton273.IdleBorderThickness = 1
        Me.BunifuThinButton273.IdleCornerRadius = 1
        Me.BunifuThinButton273.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton273.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton273.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton273.Location = New System.Drawing.Point(153, 4)
        Me.BunifuThinButton273.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton273.Name = "BunifuThinButton273"
        Me.BunifuThinButton273.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton273.TabIndex = 32
        Me.BunifuThinButton273.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton274
        '
        Me.BunifuThinButton274.ActiveBorderThickness = 1
        Me.BunifuThinButton274.ActiveCornerRadius = 2
        Me.BunifuThinButton274.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton274.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton274.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton274.AutoSize = True
        Me.BunifuThinButton274.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton274.BackgroundImage = CType(resources.GetObject("BunifuThinButton274.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton274.ButtonText = "Sign Up"
        Me.BunifuThinButton274.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton274, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton274, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton274, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton274.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton274.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton274.IdleBorderThickness = 1
        Me.BunifuThinButton274.IdleCornerRadius = 1
        Me.BunifuThinButton274.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton274.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton274.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton274.Location = New System.Drawing.Point(153, 3)
        Me.BunifuThinButton274.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton274.Name = "BunifuThinButton274"
        Me.BunifuThinButton274.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton274.TabIndex = 31
        Me.BunifuThinButton274.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton275
        '
        Me.BunifuThinButton275.ActiveBorderThickness = 1
        Me.BunifuThinButton275.ActiveCornerRadius = 2
        Me.BunifuThinButton275.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton275.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton275.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton275.AutoSize = True
        Me.BunifuThinButton275.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton275.BackgroundImage = CType(resources.GetObject("BunifuThinButton275.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton275.ButtonText = "Sign Up"
        Me.BunifuThinButton275.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton275, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton275, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton275, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton275.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton275.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton275.IdleBorderThickness = 1
        Me.BunifuThinButton275.IdleCornerRadius = 1
        Me.BunifuThinButton275.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton275.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton275.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton275.Location = New System.Drawing.Point(300, 3)
        Me.BunifuThinButton275.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton275.Name = "BunifuThinButton275"
        Me.BunifuThinButton275.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton275.TabIndex = 33
        Me.BunifuThinButton275.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuFlatButton33
        '
        Me.BunifuFlatButton33.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton33.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton33.BorderRadius = 0
        Me.BunifuFlatButton33.ButtonText = "View Doctor"
        Me.BunifuFlatButton33.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton33, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton33.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton33.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton33.Iconimage = Global.officesoft2.My.Resources.Resources.job_search
        Me.BunifuFlatButton33.Iconimage_right = Nothing
        Me.BunifuFlatButton33.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton33.Iconimage_Selected = Nothing
        Me.BunifuFlatButton33.IconMarginLeft = 0
        Me.BunifuFlatButton33.IconMarginRight = 0
        Me.BunifuFlatButton33.IconRightVisible = False
        Me.BunifuFlatButton33.IconRightZoom = 0R
        Me.BunifuFlatButton33.IconVisible = False
        Me.BunifuFlatButton33.IconZoom = 60.0R
        Me.BunifuFlatButton33.IsTab = False
        Me.BunifuFlatButton33.Location = New System.Drawing.Point(166, 6)
        Me.BunifuFlatButton33.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton33.Name = "BunifuFlatButton33"
        Me.BunifuFlatButton33.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton33.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton33.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton33.selected = False
        Me.BunifuFlatButton33.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton33.TabIndex = 34
        Me.BunifuFlatButton33.Text = "View Doctor"
        Me.BunifuFlatButton33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton33.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton33.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton41
        '
        Me.BunifuFlatButton41.Activecolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton41.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton41.BorderRadius = 0
        Me.BunifuFlatButton41.ButtonText = "Add Doctor"
        Me.BunifuFlatButton41.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition3.SetDecoration(Me.BunifuFlatButton41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuFlatButton41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me.BunifuFlatButton41, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuFlatButton41.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton41.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton41.Iconimage = Global.officesoft2.My.Resources.Resources.business_card_of_a_man_with_contact_info
        Me.BunifuFlatButton41.Iconimage_right = Nothing
        Me.BunifuFlatButton41.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton41.Iconimage_Selected = Nothing
        Me.BunifuFlatButton41.IconMarginLeft = 0
        Me.BunifuFlatButton41.IconMarginRight = 0
        Me.BunifuFlatButton41.IconRightVisible = False
        Me.BunifuFlatButton41.IconRightZoom = 0R
        Me.BunifuFlatButton41.IconVisible = False
        Me.BunifuFlatButton41.IconZoom = 60.0R
        Me.BunifuFlatButton41.IsTab = False
        Me.BunifuFlatButton41.Location = New System.Drawing.Point(11, 6)
        Me.BunifuFlatButton41.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuFlatButton41.Name = "BunifuFlatButton41"
        Me.BunifuFlatButton41.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton41.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuFlatButton41.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton41.selected = False
        Me.BunifuFlatButton41.Size = New System.Drawing.Size(150, 36)
        Me.BunifuFlatButton41.TabIndex = 15
        Me.BunifuFlatButton41.Text = "Add Doctor"
        Me.BunifuFlatButton41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton41.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton41.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuThinButton254
        '
        Me.BunifuThinButton254.ActiveBorderThickness = 1
        Me.BunifuThinButton254.ActiveCornerRadius = 2
        Me.BunifuThinButton254.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton254.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton254.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton254.AutoSize = True
        Me.BunifuThinButton254.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton254.BackgroundImage = CType(resources.GetObject("BunifuThinButton254.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton254.ButtonText = "Sign Up"
        Me.BunifuThinButton254.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton254, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton254, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton254, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton254.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton254.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton254.IdleBorderThickness = 1
        Me.BunifuThinButton254.IdleCornerRadius = 1
        Me.BunifuThinButton254.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton254.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton254.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton254.Location = New System.Drawing.Point(166, 14)
        Me.BunifuThinButton254.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton254.Name = "BunifuThinButton254"
        Me.BunifuThinButton254.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton254.TabIndex = 27
        Me.BunifuThinButton254.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton257
        '
        Me.BunifuThinButton257.ActiveBorderThickness = 1
        Me.BunifuThinButton257.ActiveCornerRadius = 2
        Me.BunifuThinButton257.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton257.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton257.ActiveLineColor = System.Drawing.Color.White
        Me.BunifuThinButton257.AutoSize = True
        Me.BunifuThinButton257.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton257.BackgroundImage = CType(resources.GetObject("BunifuThinButton257.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton257.ButtonText = "Sign Up"
        Me.BunifuThinButton257.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuTransition1.SetDecoration(Me.BunifuThinButton257, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuThinButton257, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuThinButton257, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuThinButton257.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton257.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton257.IdleBorderThickness = 1
        Me.BunifuThinButton257.IdleCornerRadius = 1
        Me.BunifuThinButton257.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton257.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton257.IdleLineColor = System.Drawing.Color.White
        Me.BunifuThinButton257.Location = New System.Drawing.Point(11, 14)
        Me.BunifuThinButton257.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton257.Name = "BunifuThinButton257"
        Me.BunifuThinButton257.Size = New System.Drawing.Size(149, 36)
        Me.BunifuThinButton257.TabIndex = 23
        Me.BunifuThinButton257.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuGradientPanel16
        '
        Me.BunifuGradientPanel16.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel16.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel16.Controls.Add(Me.BunifuTextbox5)
        Me.BunifuTransition1.SetDecoration(Me.BunifuGradientPanel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuGradientPanel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuGradientPanel16, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuGradientPanel16.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel16.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel16.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel16.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel16.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel16.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel16.Name = "BunifuGradientPanel16"
        Me.BunifuGradientPanel16.Quality = 10
        Me.BunifuGradientPanel16.Size = New System.Drawing.Size(913, 37)
        Me.BunifuGradientPanel16.TabIndex = 19
        '
        'BunifuTextbox5
        '
        Me.BunifuTextbox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTextbox5.BackgroundImage = CType(resources.GetObject("BunifuTextbox5.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTransition1.SetDecoration(Me.BunifuTextbox5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition2.SetDecoration(Me.BunifuTextbox5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me.BunifuTextbox5, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTextbox5.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox5.Icon = CType(resources.GetObject("BunifuTextbox5.Icon"), System.Drawing.Image)
        Me.BunifuTextbox5.Location = New System.Drawing.Point(12, 1)
        Me.BunifuTextbox5.Name = "BunifuTextbox5"
        Me.BunifuTextbox5.Size = New System.Drawing.Size(239, 31)
        Me.BunifuTextbox5.TabIndex = 0
        Me.BunifuTextbox5.text = "Search Here"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1150, 658)
        Me.Controls.Add(Me.panel1)
        Me.Controls.Add(Me.header)
        Me.Controls.Add(Me.Panel2)
        Me.BunifuTransition2.SetDecoration(Me, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition1.SetDecoration(Me, BunifuAnimatorNS.DecorationType.None)
        Me.BunifuTransition3.SetDecoration(Me, BunifuAnimatorNS.DecorationType.None)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.header.ResumeLayout(False)
        Me.header.PerformLayout()
        Me.panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage17.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage10.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage13.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.TabPage14.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.TabPage16.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        CType(Me.BunifuCustomDataGrid2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage15.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabControl4.ResumeLayout(False)
        Me.TabPage18.ResumeLayout(False)
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.TabPage19.ResumeLayout(False)
        CType(Me.BunifuCustomDataGrid4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.Panel22.ResumeLayout(False)
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.Panel23.ResumeLayout(False)
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.TabControl5.ResumeLayout(False)
        Me.TabPage22.ResumeLayout(False)
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.TabPage23.ResumeLayout(False)
        Me.TabPage23.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.TabPage24.ResumeLayout(False)
        CType(Me.BunifuCustomDataGrid5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage27.ResumeLayout(False)
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.Panel30.ResumeLayout(False)
        Me.Panel30.PerformLayout()
        Me.TabPage28.ResumeLayout(False)
        Me.Panel33.ResumeLayout(False)
        Me.Panel33.PerformLayout()
        Me.Panel32.ResumeLayout(False)
        Me.Panel32.PerformLayout()
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout()
        Me.TabControl6.ResumeLayout(False)
        Me.TabPage29.ResumeLayout(False)
        Me.Panel34.ResumeLayout(False)
        Me.Panel34.PerformLayout()
        Me.TabPage30.ResumeLayout(False)
        CType(Me.BunifuCustomDataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bunifuImageButton1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BunifuImageButton2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel8.ResumeLayout(False)
        Me.BunifuGradientPanel8.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel7.ResumeLayout(False)
        Me.BunifuGradientPanel7.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel12.ResumeLayout(False)
        Me.BunifuGradientPanel12.PerformLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel9.ResumeLayout(False)
        Me.BunifuGradientPanel9.PerformLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel10.ResumeLayout(False)
        Me.BunifuGradientPanel10.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel11.ResumeLayout(False)
        Me.BunifuGradientPanel11.PerformLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel1.ResumeLayout(False)
        Me.BunifuGradientPanel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel5.ResumeLayout(False)
        Me.BunifuGradientPanel5.PerformLayout()
        Me.BunifuGradientPanel2.ResumeLayout(False)
        Me.BunifuGradientPanel2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel3.ResumeLayout(False)
        Me.BunifuGradientPanel3.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuGradientPanel6.ResumeLayout(False)
        Me.BunifuGradientPanel13.ResumeLayout(False)
        Me.BunifuGradientPanel14.ResumeLayout(False)
        Me.BunifuGradientPanel15.ResumeLayout(False)
        Me.BunifuGradientPanel16.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents header As Panel
    Private WithEvents label1 As Label
    Private WithEvents bunifuDragControl1 As Bunifu.Framework.UI.BunifuDragControl
    Private WithEvents panel1 As Panel
    Private WithEvents bunifuFlatButton8 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuFlatButton6 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuImageButton1 As Bunifu.Framework.UI.BunifuImageButton
    Private WithEvents bunifuThinButton21 As Bunifu.Framework.UI.BunifuThinButton2
    Private WithEvents bunifuFlatButton5 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuFlatButton1 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuFlatButton4 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuFlatButton2 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents bunifuFlatButton3 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents BunifuGradientPanel5 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuCustomLabel28 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel27 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel26 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel25 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel24 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel23 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel22 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel21 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel20 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel19 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel18 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuSeparator5 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator4 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator3 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator2 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuSeparator1 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents BunifuCustomLabel17 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel16 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel15 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel14 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel13 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuGradientPanel3 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents BunifuCustomLabel7 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel8 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel9 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuGradientPanel2 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuCustomLabel4 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents BunifuCustomLabel5 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel6 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuGradientPanel1 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuCustomLabel3 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel2 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents BunifuCustomLabel1 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents BunifuCustomLabel29 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents BunifuImageButton2 As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents BunifuCustomLabel31 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents BunifuCustomLabel38 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel5 As Panel
    Friend WithEvents DataGridView1 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents BunifuGradientPanel6 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuTextbox1 As Bunifu.Framework.UI.BunifuTextbox
    Private WithEvents BunifuFlatButton11 As Bunifu.Framework.UI.BunifuFlatButton
    Private WithEvents BunifuFlatButton10 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton26 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton27 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton24 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton25 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton22 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton23 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton214 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton215 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton212 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton213 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuGradientPanel12 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuGradientPanel11 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuGradientPanel10 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuGradientPanel9 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuGradientPanel8 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuGradientPanel7 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuCustomLabel52 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents BunifuTransition1 As BunifuAnimatorNS.BunifuTransition
    Friend WithEvents BunifuTransition2 As BunifuAnimatorNS.BunifuTransition
    Friend WithEvents BunifuElipse2 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents Panel7 As Panel
    Friend WithEvents BunifuFlatButton18 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton17 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton16 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton15 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton14 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton9 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton216 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton218 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton220 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton222 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton224 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton226 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabControl3 As TabControl
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents Panel9 As Panel
    Friend WithEvents TabPage12 As TabPage
    Friend WithEvents Panel10 As Panel
    Friend WithEvents TabPage13 As TabPage
    Friend WithEvents Panel11 As Panel
    Friend WithEvents TabPage14 As TabPage
    Friend WithEvents Panel12 As Panel
    Friend WithEvents BunifuCustomLabel59 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel60 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel61 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel62 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage15 As TabPage
    Friend WithEvents Panel13 As Panel
    Friend WithEvents TabPage16 As TabPage
    Friend WithEvents Panel14 As Panel
    Friend WithEvents BunifuCustomLabel78 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown22 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel99 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown21 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel98 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel97 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox21 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel93 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel94 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel95 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown18 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown19 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown20 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel96 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown17 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel92 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents BunifuMetroTextbox33 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel110 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel105 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox31 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel108 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox32 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel109 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown25 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents BunifuMetroTextbox30 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel100 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel107 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox24 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel104 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox29 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel106 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents BunifuCustomLabel102 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox22 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel101 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox23 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel103 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown23 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown24 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents BunifuCustomLabel121 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel122 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel123 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel120 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox37 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel119 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox36 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel118 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel117 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox35 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel116 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox34 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel115 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel114 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel113 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomTextbox3 As WindowsFormsControlLibrary1.BunifuCustomTextbox
    Friend WithEvents BunifuCustomLabel112 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel111 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomTextbox2 As WindowsFormsControlLibrary1.BunifuCustomTextbox
    Friend WithEvents Panel15 As Panel
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents BunifuCustomLabel133 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel134 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel135 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel136 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel124 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel125 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel126 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel127 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox38 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel128 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox39 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel129 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel130 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox40 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel131 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox41 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel132 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuThinButton219 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton221 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton211 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton217 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton223 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton225 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents TabPage17 As TabPage
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents BunifuDropdown28 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown27 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown26 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuMetroTextbox45 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel141 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox44 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel140 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown35 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel139 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox43 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel138 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox42 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel137 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown32 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown33 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown34 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown29 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown30 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuDropdown31 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents Panel16 As Panel
    Friend WithEvents BunifuThinButton227 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton228 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton229 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton230 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton231 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton232 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton233 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton234 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton235 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton236 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton237 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton238 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuCustomDataGrid2 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents BunifuGradientPanel13 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuTextbox2 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents BunifuThinButton239 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton240 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents TabControl4 As TabControl
    Friend WithEvents TabPage18 As TabPage
    Friend WithEvents Panel19 As Panel
    Friend WithEvents BunifuFlatButton25 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton26 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton247 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton248 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton27 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton28 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton29 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton249 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton30 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton250 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton251 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton252 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents TabPage19 As TabPage
    Friend WithEvents BunifuCustomDataGrid4 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents BunifuGradientPanel14 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuTextbox3 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents TabPage20 As TabPage
    Friend WithEvents TabPage21 As TabPage
    Friend WithEvents Panel18 As Panel
    Friend WithEvents BunifuFlatButton19 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton20 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton241 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton242 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton21 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton22 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton23 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton243 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton24 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton244 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton245 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton246 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Panel17 As Panel
    Friend WithEvents BunifuTileButton17 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton18 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton19 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton20 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton13 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton14 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton15 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton16 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton9 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton10 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton11 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton12 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton8 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton7 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton6 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton5 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton4 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton3 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton2 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents BunifuTileButton1 As Bunifu.Framework.UI.BunifuTileButton
    Friend WithEvents Panel20 As Panel
    Friend WithEvents BunifuCustomLabel172 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel21 As Panel
    Friend WithEvents BunifuTransition3 As BunifuAnimatorNS.BunifuTransition
    Private WithEvents BunifuFlatButton31 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Panel22 As Panel
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Panel25 As Panel
    Friend WithEvents BunifuFlatButton34 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton35 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton36 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton255 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton256 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton258 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Panel24 As Panel
    Friend WithEvents TabControl5 As TabControl
    Friend WithEvents TabPage22 As TabPage
    Friend WithEvents Panel26 As Panel
    Friend WithEvents TabPage23 As TabPage
    Friend WithEvents TabPage24 As TabPage
    Friend WithEvents TabPage25 As TabPage
    Friend WithEvents BunifuCustomDataGrid5 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents BunifuGradientPanel15 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuTextbox4 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents Panel27 As Panel
    Friend WithEvents BunifuFlatButton38 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton39 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton259 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton260 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuFlatButton40 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton42 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton261 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton262 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents TabPage26 As TabPage
    Friend WithEvents txtemail As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel77 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtdate1 As DateTimePicker
    Friend WithEvents txtheight As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtweight As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtselectward As ComboBox
    Friend WithEvents txtbloodgroup As ComboBox
    Friend WithEvents BunifuCustomLabel70 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtuid As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtmobile As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtgender As ComboBox
    Friend WithEvents txtcity As ComboBox
    Friend WithEvents txtadd As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtage As ComboBox
    Friend WithEvents txtname As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtlastname As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtfirstname As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtid As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel69 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel68 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel64 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel63 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel43 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel42 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel41 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel40 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel36 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel35 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel34 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel33 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel32 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel30 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage27 As TabPage
    Friend WithEvents txtmoble2 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel149 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtfees As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel154 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtselectwardno As ComboBox
    Friend WithEvents BunifuCustomLabel151 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel53 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents BunifuCustomLabel50 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents BunifuCustomLabel48 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents BunifuCustomLabel46 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents BunifuCustomLabel44 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Panel28 As Panel
    Friend WithEvents BunifuThinButton28 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents cmbpid As ComboBox
    Friend WithEvents BunifuThinButton29 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuCustomLabel37 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCircleProgressbar6 As Bunifu.Framework.UI.BunifuCircleProgressbar
    Friend WithEvents BunifuCircleProgressbar5 As Bunifu.Framework.UI.BunifuCircleProgressbar
    Friend WithEvents BunifuCircleProgressbar4 As Bunifu.Framework.UI.BunifuCircleProgressbar
    Friend WithEvents BunifuCircleProgressbar3 As Bunifu.Framework.UI.BunifuCircleProgressbar
    Friend WithEvents BunifuCircleProgressbar2 As Bunifu.Framework.UI.BunifuCircleProgressbar
    Friend WithEvents BunifuCircleProgressbar1 As Bunifu.Framework.UI.BunifuCircleProgressbar
    Friend WithEvents BunifuCustomLabel54 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel51 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel49 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel47 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel45 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel39 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel29 As Panel
    Friend WithEvents BunifuCustomLabel65 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel56 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel30 As Panel
    Friend WithEvents BunifuCustomLabel55 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Hcom As ComboBox
    Friend WithEvents textboxcom As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuFlatButton32 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton7 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Timer1 As Timer
    Friend WithEvents BunifuThinButton210 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton253 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuCustomLabel66 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel58 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel57 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel71 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel67 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel88 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel87 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel86 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel85 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel84 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel83 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel82 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel81 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurdate As DateTimePicker
    Friend WithEvents nurpin As MaskedTextBox
    Friend WithEvents nurcountry As ComboBox
    Friend WithEvents nurstate As ComboBox
    Friend WithEvents nurcity As ComboBox
    Friend WithEvents nuradd As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel80 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nuremail As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel79 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurmob As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel76 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurgen As ComboBox
    Friend WithEvents nurdesig As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel75 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurdob As DateTimePicker
    Friend WithEvents nurdoj As DateTimePicker
    Friend WithEvents nurlname As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel74 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurfname As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel73 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurid As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel72 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents BunifuCustomLabel89 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel144 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurward1 As ComboBox
    Friend WithEvents nurpassword As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel147 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurmob1 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel146 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurusername As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel145 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurdesig1 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel143 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurlname1 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel142 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurfname1 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel91 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel90 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents nurid1 As ComboBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents txtCharacters As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuFlatButton13 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton12 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents txtmsg As TextBox
    Friend WithEvents BunifuCustomLabel148 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtsral As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents TabPage28 As TabPage
    Friend WithEvents Panel33 As Panel
    Friend WithEvents BunifuThinButton264 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton265 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton266 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton267 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton269 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton271 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton272 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton273 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton274 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton275 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Panel32 As Panel
    Friend WithEvents BunifuFlatButton33 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton41 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuThinButton254 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton257 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Panel31 As Panel
    Friend WithEvents BunifuCustomLabel150 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabControl6 As TabControl
    Friend WithEvents TabPage29 As TabPage
    Friend WithEvents Panel34 As Panel
    Friend WithEvents txtdocdate As DateTimePicker
    Friend WithEvents txtdocpass As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtdocusername As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtdoccat As ComboBox
    Friend WithEvents txtdocaddress As ComboBox
    Friend WithEvents txtdocmobile As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtdocquali As ComboBox
    Friend WithEvents txtdocfname As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtdocid1 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents txtdocid As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel162 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel163 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel164 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel167 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel168 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel169 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel170 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel171 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel173 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel174 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel175 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel176 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage30 As TabPage
    Friend WithEvents txtcharacter2 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents msg2 As TextBox
    Friend WithEvents txtdocdob As DateTimePicker
    Friend WithEvents txtdocfullname As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel153 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents txtdoclname As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel152 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomDataGrid1 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents BunifuGradientPanel16 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuTextbox5 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents txtdocdelete As Bunifu.Framework.UI.BunifuMetroTextbox
End Class
