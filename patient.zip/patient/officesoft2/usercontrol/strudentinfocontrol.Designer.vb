﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class strudentinfocontrol
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(strudentinfocontrol))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.BunifuThinButton214 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton215 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton212 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton213 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton28 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton29 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton26 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton27 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton24 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton25 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton22 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton23 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuCustomLabel29 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.BunifuDropdown1 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel76 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel66 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDatepicker2 = New Bunifu.Framework.UI.BunifuDatepicker()
        Me.BunifuDropdown14 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel73 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown13 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel72 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown12 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel71 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown11 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel44 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox6 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel43 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox5 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel42 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox4 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel41 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox3 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel37 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown9 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel35 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown10 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel36 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox2 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel34 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown8 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel33 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown5 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel63 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox27 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel70 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox26 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel69 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox25 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel68 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown7 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel65 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown6 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel64 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox8 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel40 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox1 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel32 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox7 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel31 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel30 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.BunifuThinButton210 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuDropdown3 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel50 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDropdown2 = New Bunifu.Framework.UI.BunifuDropdown()
        Me.BunifuCustomLabel49 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox28 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel75 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox14 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel74 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox13 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel48 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox12 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel47 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox11 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel46 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox10 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel45 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuMetroTextbox9 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.BunifuCustomLabel39 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuCustomLabel67 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.BunifuDatepicker3 = New Bunifu.Framework.UI.BunifuDatepicker()
        Me.BunifuCustomLabel38 = New Bunifu.Framework.UI.BunifuCustomLabel()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.BunifuGradientPanel6 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.BunifuTextbox1 = New Bunifu.Framework.UI.BunifuTextbox()
        Me.BunifuCustomDataGrid1 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel4.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.BunifuGradientPanel6.SuspendLayout()
        CType(Me.BunifuCustomDataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.BunifuThinButton214)
        Me.Panel4.Controls.Add(Me.BunifuThinButton215)
        Me.Panel4.Controls.Add(Me.BunifuThinButton212)
        Me.Panel4.Controls.Add(Me.BunifuThinButton213)
        Me.Panel4.Controls.Add(Me.BunifuThinButton28)
        Me.Panel4.Controls.Add(Me.BunifuThinButton29)
        Me.Panel4.Controls.Add(Me.BunifuThinButton26)
        Me.Panel4.Controls.Add(Me.BunifuThinButton27)
        Me.Panel4.Controls.Add(Me.BunifuThinButton24)
        Me.Panel4.Controls.Add(Me.BunifuThinButton25)
        Me.Panel4.Controls.Add(Me.BunifuThinButton22)
        Me.Panel4.Controls.Add(Me.BunifuThinButton23)
        Me.Panel4.Location = New System.Drawing.Point(0, 30)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(921, 50)
        Me.Panel4.TabIndex = 15
        '
        'BunifuThinButton214
        '
        Me.BunifuThinButton214.ActiveBorderThickness = 1
        Me.BunifuThinButton214.ActiveCornerRadius = 3
        Me.BunifuThinButton214.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton214.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton214.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton214.AutoSize = True
        Me.BunifuThinButton214.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton214.BackgroundImage = CType(resources.GetObject("BunifuThinButton214.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton214.ButtonText = "View Record"
        Me.BunifuThinButton214.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton214.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton214.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton214.IdleBorderThickness = 1
        Me.BunifuThinButton214.IdleCornerRadius = 1
        Me.BunifuThinButton214.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton214.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton214.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton214.Location = New System.Drawing.Point(751, -1)
        Me.BunifuThinButton214.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton214.Name = "BunifuThinButton214"
        Me.BunifuThinButton214.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton214.TabIndex = 34
        Me.BunifuThinButton214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton215
        '
        Me.BunifuThinButton215.ActiveBorderThickness = 1
        Me.BunifuThinButton215.ActiveCornerRadius = 2
        Me.BunifuThinButton215.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton215.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton215.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton215.AutoSize = True
        Me.BunifuThinButton215.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton215.BackgroundImage = CType(resources.GetObject("BunifuThinButton215.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton215.ButtonText = "Sign Up"
        Me.BunifuThinButton215.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton215.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton215.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton215.IdleBorderThickness = 1
        Me.BunifuThinButton215.IdleCornerRadius = 1
        Me.BunifuThinButton215.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton215.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton215.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton215.Location = New System.Drawing.Point(751, -7)
        Me.BunifuThinButton215.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton215.Name = "BunifuThinButton215"
        Me.BunifuThinButton215.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton215.TabIndex = 33
        Me.BunifuThinButton215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton212
        '
        Me.BunifuThinButton212.ActiveBorderThickness = 1
        Me.BunifuThinButton212.ActiveCornerRadius = 3
        Me.BunifuThinButton212.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton212.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton212.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton212.AutoSize = True
        Me.BunifuThinButton212.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton212.BackgroundImage = CType(resources.GetObject("BunifuThinButton212.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton212.ButtonText = "Delete"
        Me.BunifuThinButton212.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton212.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton212.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton212.IdleBorderThickness = 1
        Me.BunifuThinButton212.IdleCornerRadius = 1
        Me.BunifuThinButton212.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton212.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton212.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton212.Location = New System.Drawing.Point(603, -1)
        Me.BunifuThinButton212.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton212.Name = "BunifuThinButton212"
        Me.BunifuThinButton212.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton212.TabIndex = 32
        Me.BunifuThinButton212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton213
        '
        Me.BunifuThinButton213.ActiveBorderThickness = 1
        Me.BunifuThinButton213.ActiveCornerRadius = 2
        Me.BunifuThinButton213.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton213.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton213.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton213.AutoSize = True
        Me.BunifuThinButton213.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton213.BackgroundImage = CType(resources.GetObject("BunifuThinButton213.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton213.ButtonText = "Sign Up"
        Me.BunifuThinButton213.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton213.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton213.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton213.IdleBorderThickness = 1
        Me.BunifuThinButton213.IdleCornerRadius = 1
        Me.BunifuThinButton213.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton213.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton213.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton213.Location = New System.Drawing.Point(603, -7)
        Me.BunifuThinButton213.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton213.Name = "BunifuThinButton213"
        Me.BunifuThinButton213.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton213.TabIndex = 31
        Me.BunifuThinButton213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton28
        '
        Me.BunifuThinButton28.ActiveBorderThickness = 1
        Me.BunifuThinButton28.ActiveCornerRadius = 3
        Me.BunifuThinButton28.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton28.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton28.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton28.AutoSize = True
        Me.BunifuThinButton28.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton28.BackgroundImage = CType(resources.GetObject("BunifuThinButton28.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton28.ButtonText = "Update"
        Me.BunifuThinButton28.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton28.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton28.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton28.IdleBorderThickness = 1
        Me.BunifuThinButton28.IdleCornerRadius = 1
        Me.BunifuThinButton28.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton28.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton28.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton28.Location = New System.Drawing.Point(455, -1)
        Me.BunifuThinButton28.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton28.Name = "BunifuThinButton28"
        Me.BunifuThinButton28.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton28.TabIndex = 30
        Me.BunifuThinButton28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton29
        '
        Me.BunifuThinButton29.ActiveBorderThickness = 1
        Me.BunifuThinButton29.ActiveCornerRadius = 2
        Me.BunifuThinButton29.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton29.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton29.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton29.AutoSize = True
        Me.BunifuThinButton29.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton29.BackgroundImage = CType(resources.GetObject("BunifuThinButton29.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton29.ButtonText = "Sign Up"
        Me.BunifuThinButton29.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton29.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton29.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton29.IdleBorderThickness = 1
        Me.BunifuThinButton29.IdleCornerRadius = 1
        Me.BunifuThinButton29.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton29.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton29.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton29.Location = New System.Drawing.Point(455, -7)
        Me.BunifuThinButton29.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton29.Name = "BunifuThinButton29"
        Me.BunifuThinButton29.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton29.TabIndex = 29
        Me.BunifuThinButton29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton26
        '
        Me.BunifuThinButton26.ActiveBorderThickness = 1
        Me.BunifuThinButton26.ActiveCornerRadius = 3
        Me.BunifuThinButton26.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton26.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton26.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton26.AutoSize = True
        Me.BunifuThinButton26.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton26.BackgroundImage = CType(resources.GetObject("BunifuThinButton26.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton26.ButtonText = "Submit"
        Me.BunifuThinButton26.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton26.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton26.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton26.IdleBorderThickness = 1
        Me.BunifuThinButton26.IdleCornerRadius = 1
        Me.BunifuThinButton26.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton26.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton26.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton26.Location = New System.Drawing.Point(307, -1)
        Me.BunifuThinButton26.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton26.Name = "BunifuThinButton26"
        Me.BunifuThinButton26.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton26.TabIndex = 28
        Me.BunifuThinButton26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton27
        '
        Me.BunifuThinButton27.ActiveBorderThickness = 1
        Me.BunifuThinButton27.ActiveCornerRadius = 2
        Me.BunifuThinButton27.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton27.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton27.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton27.AutoSize = True
        Me.BunifuThinButton27.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton27.BackgroundImage = CType(resources.GetObject("BunifuThinButton27.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton27.ButtonText = "Sign Up"
        Me.BunifuThinButton27.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton27.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton27.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton27.IdleBorderThickness = 1
        Me.BunifuThinButton27.IdleCornerRadius = 1
        Me.BunifuThinButton27.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton27.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton27.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton27.Location = New System.Drawing.Point(307, -7)
        Me.BunifuThinButton27.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton27.Name = "BunifuThinButton27"
        Me.BunifuThinButton27.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton27.TabIndex = 27
        Me.BunifuThinButton27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton24
        '
        Me.BunifuThinButton24.ActiveBorderThickness = 1
        Me.BunifuThinButton24.ActiveCornerRadius = 3
        Me.BunifuThinButton24.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton24.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton24.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton24.AutoSize = True
        Me.BunifuThinButton24.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton24.BackgroundImage = CType(resources.GetObject("BunifuThinButton24.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton24.ButtonText = "Fees Info"
        Me.BunifuThinButton24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton24.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton24.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton24.IdleBorderThickness = 1
        Me.BunifuThinButton24.IdleCornerRadius = 1
        Me.BunifuThinButton24.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton24.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton24.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton24.Location = New System.Drawing.Point(159, -1)
        Me.BunifuThinButton24.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton24.Name = "BunifuThinButton24"
        Me.BunifuThinButton24.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton24.TabIndex = 26
        Me.BunifuThinButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton25
        '
        Me.BunifuThinButton25.ActiveBorderThickness = 1
        Me.BunifuThinButton25.ActiveCornerRadius = 2
        Me.BunifuThinButton25.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton25.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton25.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton25.AutoSize = True
        Me.BunifuThinButton25.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton25.BackgroundImage = CType(resources.GetObject("BunifuThinButton25.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton25.ButtonText = "Sign Up"
        Me.BunifuThinButton25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton25.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton25.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton25.IdleBorderThickness = 1
        Me.BunifuThinButton25.IdleCornerRadius = 1
        Me.BunifuThinButton25.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton25.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton25.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton25.Location = New System.Drawing.Point(159, -7)
        Me.BunifuThinButton25.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton25.Name = "BunifuThinButton25"
        Me.BunifuThinButton25.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton25.TabIndex = 25
        Me.BunifuThinButton25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton22
        '
        Me.BunifuThinButton22.ActiveBorderThickness = 1
        Me.BunifuThinButton22.ActiveCornerRadius = 3
        Me.BunifuThinButton22.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton22.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton22.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton22.AutoSize = True
        Me.BunifuThinButton22.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton22.BackgroundImage = CType(resources.GetObject("BunifuThinButton22.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BunifuThinButton22.ButtonText = "Student Info"
        Me.BunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton22.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton22.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton22.IdleBorderThickness = 1
        Me.BunifuThinButton22.IdleCornerRadius = 1
        Me.BunifuThinButton22.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton22.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton22.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton22.Location = New System.Drawing.Point(11, -1)
        Me.BunifuThinButton22.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton22.Name = "BunifuThinButton22"
        Me.BunifuThinButton22.Size = New System.Drawing.Size(140, 36)
        Me.BunifuThinButton22.TabIndex = 24
        Me.BunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton23
        '
        Me.BunifuThinButton23.ActiveBorderThickness = 1
        Me.BunifuThinButton23.ActiveCornerRadius = 2
        Me.BunifuThinButton23.ActiveFillColor = System.Drawing.Color.SeaShell
        Me.BunifuThinButton23.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton23.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton23.AutoSize = True
        Me.BunifuThinButton23.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton23.BackgroundImage = CType(resources.GetObject("BunifuThinButton23.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton23.ButtonText = "Sign Up"
        Me.BunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton23.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton23.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton23.IdleBorderThickness = 1
        Me.BunifuThinButton23.IdleCornerRadius = 1
        Me.BunifuThinButton23.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.BunifuThinButton23.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton23.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton23.Location = New System.Drawing.Point(11, -7)
        Me.BunifuThinButton23.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton23.Name = "BunifuThinButton23"
        Me.BunifuThinButton23.Size = New System.Drawing.Size(140, 46)
        Me.BunifuThinButton23.TabIndex = 23
        Me.BunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuCustomLabel29
        '
        Me.BunifuCustomLabel29.AutoSize = True
        Me.BunifuCustomLabel29.BackColor = System.Drawing.Color.Transparent
        Me.BunifuCustomLabel29.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel29.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel29.Location = New System.Drawing.Point(10, 4)
        Me.BunifuCustomLabel29.Name = "BunifuCustomLabel29"
        Me.BunifuCustomLabel29.Size = New System.Drawing.Size(104, 23)
        Me.BunifuCustomLabel29.TabIndex = 14
        Me.BunifuCustomLabel29.Text = "Admission"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Controls.Add(Me.TabPage11)
        Me.TabControl2.Location = New System.Drawing.Point(-4, 58)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(939, 496)
        Me.TabControl2.TabIndex = 16
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage7.Controls.Add(Me.Panel3)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(931, 470)
        Me.TabPage7.TabIndex = 0
        Me.TabPage7.Text = "TabPage7"
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.BunifuDropdown1)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel76)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel66)
        Me.Panel3.Controls.Add(Me.BunifuDatepicker2)
        Me.Panel3.Controls.Add(Me.BunifuDropdown14)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel73)
        Me.Panel3.Controls.Add(Me.BunifuDropdown13)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel72)
        Me.Panel3.Controls.Add(Me.BunifuDropdown12)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel71)
        Me.Panel3.Controls.Add(Me.BunifuDropdown11)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel44)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox6)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel43)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox5)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel42)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox4)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel41)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox3)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel37)
        Me.Panel3.Controls.Add(Me.BunifuDropdown9)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel35)
        Me.Panel3.Controls.Add(Me.BunifuDropdown10)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel36)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox2)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel34)
        Me.Panel3.Controls.Add(Me.BunifuDropdown8)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel33)
        Me.Panel3.Controls.Add(Me.BunifuDropdown5)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel63)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox27)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel70)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox26)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel69)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox25)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel68)
        Me.Panel3.Controls.Add(Me.BunifuDropdown7)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel65)
        Me.Panel3.Controls.Add(Me.BunifuDropdown6)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel64)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox8)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel40)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox1)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel32)
        Me.Panel3.Controls.Add(Me.BunifuMetroTextbox7)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel31)
        Me.Panel3.Controls.Add(Me.BunifuCustomLabel30)
        Me.Panel3.Location = New System.Drawing.Point(6, 9)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(903, 427)
        Me.Panel3.TabIndex = 12
        '
        'BunifuDropdown1
        '
        Me.BunifuDropdown1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown1.BorderRadius = 3
        Me.BunifuDropdown1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown1.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown1.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown1.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown1.Location = New System.Drawing.Point(708, 331)
        Me.BunifuDropdown1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown1.Name = "BunifuDropdown1"
        Me.BunifuDropdown1.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown1.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown1.selectedIndex = -1
        Me.BunifuDropdown1.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown1.TabIndex = 99
        '
        'BunifuCustomLabel76
        '
        Me.BunifuCustomLabel76.AutoSize = True
        Me.BunifuCustomLabel76.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel76.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel76.Location = New System.Drawing.Point(629, 338)
        Me.BunifuCustomLabel76.Name = "BunifuCustomLabel76"
        Me.BunifuCustomLabel76.Size = New System.Drawing.Size(74, 17)
        Me.BunifuCustomLabel76.TabIndex = 100
        Me.BunifuCustomLabel76.Text = "Nationality"
        '
        'BunifuCustomLabel66
        '
        Me.BunifuCustomLabel66.AutoSize = True
        Me.BunifuCustomLabel66.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel66.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel66.Location = New System.Drawing.Point(629, 302)
        Me.BunifuCustomLabel66.Name = "BunifuCustomLabel66"
        Me.BunifuCustomLabel66.Size = New System.Drawing.Size(38, 17)
        Me.BunifuCustomLabel66.TabIndex = 98
        Me.BunifuCustomLabel66.Text = "DOB"
        '
        'BunifuDatepicker2
        '
        Me.BunifuDatepicker2.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDatepicker2.BorderRadius = 1
        Me.BunifuDatepicker2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDatepicker2.ForeColor = System.Drawing.Color.White
        Me.BunifuDatepicker2.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        Me.BunifuDatepicker2.FormatCustom = Nothing
        Me.BunifuDatepicker2.Location = New System.Drawing.Point(708, 295)
        Me.BunifuDatepicker2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDatepicker2.Name = "BunifuDatepicker2"
        Me.BunifuDatepicker2.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDatepicker2.TabIndex = 97
        Me.BunifuDatepicker2.Value = New Date(2018, 8, 25, 3, 53, 53, 609)
        '
        'BunifuDropdown14
        '
        Me.BunifuDropdown14.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown14.BorderRadius = 3
        Me.BunifuDropdown14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown14.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown14.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown14.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown14.Location = New System.Drawing.Point(708, 263)
        Me.BunifuDropdown14.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown14.Name = "BunifuDropdown14"
        Me.BunifuDropdown14.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown14.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown14.selectedIndex = -1
        Me.BunifuDropdown14.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown14.TabIndex = 95
        '
        'BunifuCustomLabel73
        '
        Me.BunifuCustomLabel73.AutoSize = True
        Me.BunifuCustomLabel73.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel73.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel73.Location = New System.Drawing.Point(629, 270)
        Me.BunifuCustomLabel73.Name = "BunifuCustomLabel73"
        Me.BunifuCustomLabel73.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel73.TabIndex = 96
        Me.BunifuCustomLabel73.Text = "Birth Place"
        '
        'BunifuDropdown13
        '
        Me.BunifuDropdown13.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown13.BorderRadius = 3
        Me.BunifuDropdown13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown13.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown13.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown13.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown13.Location = New System.Drawing.Point(708, 228)
        Me.BunifuDropdown13.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown13.Name = "BunifuDropdown13"
        Me.BunifuDropdown13.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown13.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown13.selectedIndex = -1
        Me.BunifuDropdown13.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown13.TabIndex = 93
        '
        'BunifuCustomLabel72
        '
        Me.BunifuCustomLabel72.AutoSize = True
        Me.BunifuCustomLabel72.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel72.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel72.Location = New System.Drawing.Point(629, 235)
        Me.BunifuCustomLabel72.Name = "BunifuCustomLabel72"
        Me.BunifuCustomLabel72.Size = New System.Drawing.Size(64, 17)
        Me.BunifuCustomLabel72.TabIndex = 94
        Me.BunifuCustomLabel72.Text = "Blood Gr"
        '
        'BunifuDropdown12
        '
        Me.BunifuDropdown12.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown12.BorderRadius = 3
        Me.BunifuDropdown12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown12.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown12.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown12.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown12.Location = New System.Drawing.Point(708, 195)
        Me.BunifuDropdown12.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown12.Name = "BunifuDropdown12"
        Me.BunifuDropdown12.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown12.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown12.selectedIndex = -1
        Me.BunifuDropdown12.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown12.TabIndex = 91
        '
        'BunifuCustomLabel71
        '
        Me.BunifuCustomLabel71.AutoSize = True
        Me.BunifuCustomLabel71.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel71.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel71.Location = New System.Drawing.Point(629, 202)
        Me.BunifuCustomLabel71.Name = "BunifuCustomLabel71"
        Me.BunifuCustomLabel71.Size = New System.Drawing.Size(59, 17)
        Me.BunifuCustomLabel71.TabIndex = 92
        Me.BunifuCustomLabel71.Text = "Religion"
        '
        'BunifuDropdown11
        '
        Me.BunifuDropdown11.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown11.BorderRadius = 3
        Me.BunifuDropdown11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown11.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown11.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown11.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown11.Location = New System.Drawing.Point(708, 160)
        Me.BunifuDropdown11.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown11.Name = "BunifuDropdown11"
        Me.BunifuDropdown11.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown11.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown11.selectedIndex = -1
        Me.BunifuDropdown11.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown11.TabIndex = 89
        '
        'BunifuCustomLabel44
        '
        Me.BunifuCustomLabel44.AutoSize = True
        Me.BunifuCustomLabel44.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel44.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel44.Location = New System.Drawing.Point(629, 167)
        Me.BunifuCustomLabel44.Name = "BunifuCustomLabel44"
        Me.BunifuCustomLabel44.Size = New System.Drawing.Size(65, 17)
        Me.BunifuCustomLabel44.TabIndex = 90
        Me.BunifuCustomLabel44.Text = "Catagory"
        '
        'BunifuMetroTextbox6
        '
        Me.BunifuMetroTextbox6.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox6.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox6.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox6.BorderThickness = 1
        Me.BunifuMetroTextbox6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox6.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox6.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox6.isPassword = False
        Me.BunifuMetroTextbox6.Location = New System.Drawing.Point(112, 364)
        Me.BunifuMetroTextbox6.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox6.Name = "BunifuMetroTextbox6"
        Me.BunifuMetroTextbox6.Size = New System.Drawing.Size(516, 30)
        Me.BunifuMetroTextbox6.TabIndex = 88
        Me.BunifuMetroTextbox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel43
        '
        Me.BunifuCustomLabel43.AutoSize = True
        Me.BunifuCustomLabel43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel43.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel43.Location = New System.Drawing.Point(6, 371)
        Me.BunifuCustomLabel43.Name = "BunifuCustomLabel43"
        Me.BunifuCustomLabel43.Size = New System.Drawing.Size(82, 17)
        Me.BunifuCustomLabel43.TabIndex = 87
        Me.BunifuCustomLabel43.Text = "Last School"
        '
        'BunifuMetroTextbox5
        '
        Me.BunifuMetroTextbox5.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox5.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox5.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox5.BorderThickness = 1
        Me.BunifuMetroTextbox5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox5.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox5.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox5.isPassword = False
        Me.BunifuMetroTextbox5.Location = New System.Drawing.Point(438, 331)
        Me.BunifuMetroTextbox5.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox5.Name = "BunifuMetroTextbox5"
        Me.BunifuMetroTextbox5.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox5.TabIndex = 86
        Me.BunifuMetroTextbox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel42
        '
        Me.BunifuCustomLabel42.AutoSize = True
        Me.BunifuCustomLabel42.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel42.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel42.Location = New System.Drawing.Point(338, 340)
        Me.BunifuCustomLabel42.Name = "BunifuCustomLabel42"
        Me.BunifuCustomLabel42.Size = New System.Drawing.Size(71, 17)
        Me.BunifuCustomLabel42.TabIndex = 85
        Me.BunifuCustomLabel42.Text = "Mobile No"
        '
        'BunifuMetroTextbox4
        '
        Me.BunifuMetroTextbox4.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox4.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox4.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox4.BorderThickness = 1
        Me.BunifuMetroTextbox4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox4.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox4.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox4.isPassword = False
        Me.BunifuMetroTextbox4.Location = New System.Drawing.Point(112, 331)
        Me.BunifuMetroTextbox4.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox4.Name = "BunifuMetroTextbox4"
        Me.BunifuMetroTextbox4.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox4.TabIndex = 84
        Me.BunifuMetroTextbox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel41
        '
        Me.BunifuCustomLabel41.AutoSize = True
        Me.BunifuCustomLabel41.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel41.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel41.Location = New System.Drawing.Point(6, 340)
        Me.BunifuCustomLabel41.Name = "BunifuCustomLabel41"
        Me.BunifuCustomLabel41.Size = New System.Drawing.Size(71, 17)
        Me.BunifuCustomLabel41.TabIndex = 83
        Me.BunifuCustomLabel41.Text = "Phone No"
        '
        'BunifuMetroTextbox3
        '
        Me.BunifuMetroTextbox3.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox3.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox3.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox3.BorderThickness = 1
        Me.BunifuMetroTextbox3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox3.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox3.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox3.isPassword = False
        Me.BunifuMetroTextbox3.Location = New System.Drawing.Point(112, 296)
        Me.BunifuMetroTextbox3.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox3.Name = "BunifuMetroTextbox3"
        Me.BunifuMetroTextbox3.Size = New System.Drawing.Size(513, 30)
        Me.BunifuMetroTextbox3.TabIndex = 82
        Me.BunifuMetroTextbox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel37
        '
        Me.BunifuCustomLabel37.AutoSize = True
        Me.BunifuCustomLabel37.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel37.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel37.Location = New System.Drawing.Point(6, 304)
        Me.BunifuCustomLabel37.Name = "BunifuCustomLabel37"
        Me.BunifuCustomLabel37.Size = New System.Drawing.Size(64, 17)
        Me.BunifuCustomLabel37.TabIndex = 81
        Me.BunifuCustomLabel37.Text = " Address"
        '
        'BunifuDropdown9
        '
        Me.BunifuDropdown9.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown9.BorderRadius = 3
        Me.BunifuDropdown9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown9.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown9.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown9.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown9.Location = New System.Drawing.Point(438, 263)
        Me.BunifuDropdown9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown9.Name = "BunifuDropdown9"
        Me.BunifuDropdown9.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown9.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown9.selectedIndex = -1
        Me.BunifuDropdown9.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown9.TabIndex = 79
        '
        'BunifuCustomLabel35
        '
        Me.BunifuCustomLabel35.AutoSize = True
        Me.BunifuCustomLabel35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel35.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel35.Location = New System.Drawing.Point(338, 268)
        Me.BunifuCustomLabel35.Name = "BunifuCustomLabel35"
        Me.BunifuCustomLabel35.Size = New System.Drawing.Size(75, 17)
        Me.BunifuCustomLabel35.TabIndex = 80
        Me.BunifuCustomLabel35.Text = "Profession"
        '
        'BunifuDropdown10
        '
        Me.BunifuDropdown10.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown10.BorderRadius = 3
        Me.BunifuDropdown10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown10.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown10.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown10.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown10.Location = New System.Drawing.Point(112, 263)
        Me.BunifuDropdown10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown10.Name = "BunifuDropdown10"
        Me.BunifuDropdown10.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown10.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown10.selectedIndex = -1
        Me.BunifuDropdown10.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown10.TabIndex = 77
        '
        'BunifuCustomLabel36
        '
        Me.BunifuCustomLabel36.AutoSize = True
        Me.BunifuCustomLabel36.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel36.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel36.Location = New System.Drawing.Point(6, 268)
        Me.BunifuCustomLabel36.Name = "BunifuCustomLabel36"
        Me.BunifuCustomLabel36.Size = New System.Drawing.Size(86, 17)
        Me.BunifuCustomLabel36.TabIndex = 78
        Me.BunifuCustomLabel36.Text = "Qualification"
        '
        'BunifuMetroTextbox2
        '
        Me.BunifuMetroTextbox2.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox2.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox2.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox2.BorderThickness = 1
        Me.BunifuMetroTextbox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox2.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox2.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox2.isPassword = False
        Me.BunifuMetroTextbox2.Location = New System.Drawing.Point(112, 228)
        Me.BunifuMetroTextbox2.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox2.Name = "BunifuMetroTextbox2"
        Me.BunifuMetroTextbox2.Size = New System.Drawing.Size(513, 30)
        Me.BunifuMetroTextbox2.TabIndex = 76
        Me.BunifuMetroTextbox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel34
        '
        Me.BunifuCustomLabel34.AutoSize = True
        Me.BunifuCustomLabel34.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel34.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel34.Location = New System.Drawing.Point(6, 236)
        Me.BunifuCustomLabel34.Name = "BunifuCustomLabel34"
        Me.BunifuCustomLabel34.Size = New System.Drawing.Size(93, 17)
        Me.BunifuCustomLabel34.TabIndex = 75
        Me.BunifuCustomLabel34.Text = "Mother Name"
        '
        'BunifuDropdown8
        '
        Me.BunifuDropdown8.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown8.BorderRadius = 3
        Me.BunifuDropdown8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown8.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown8.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown8.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown8.Location = New System.Drawing.Point(438, 195)
        Me.BunifuDropdown8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown8.Name = "BunifuDropdown8"
        Me.BunifuDropdown8.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown8.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown8.selectedIndex = -1
        Me.BunifuDropdown8.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown8.TabIndex = 73
        '
        'BunifuCustomLabel33
        '
        Me.BunifuCustomLabel33.AutoSize = True
        Me.BunifuCustomLabel33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel33.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel33.Location = New System.Drawing.Point(338, 202)
        Me.BunifuCustomLabel33.Name = "BunifuCustomLabel33"
        Me.BunifuCustomLabel33.Size = New System.Drawing.Size(75, 17)
        Me.BunifuCustomLabel33.TabIndex = 74
        Me.BunifuCustomLabel33.Text = "Profession"
        '
        'BunifuDropdown5
        '
        Me.BunifuDropdown5.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown5.BorderRadius = 3
        Me.BunifuDropdown5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown5.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown5.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown5.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown5.Location = New System.Drawing.Point(112, 195)
        Me.BunifuDropdown5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown5.Name = "BunifuDropdown5"
        Me.BunifuDropdown5.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown5.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown5.selectedIndex = -1
        Me.BunifuDropdown5.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown5.TabIndex = 71
        '
        'BunifuCustomLabel63
        '
        Me.BunifuCustomLabel63.AutoSize = True
        Me.BunifuCustomLabel63.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel63.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel63.Location = New System.Drawing.Point(6, 197)
        Me.BunifuCustomLabel63.Name = "BunifuCustomLabel63"
        Me.BunifuCustomLabel63.Size = New System.Drawing.Size(86, 17)
        Me.BunifuCustomLabel63.TabIndex = 72
        Me.BunifuCustomLabel63.Text = "Qualification"
        '
        'BunifuMetroTextbox27
        '
        Me.BunifuMetroTextbox27.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox27.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox27.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox27.BorderThickness = 1
        Me.BunifuMetroTextbox27.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox27.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox27.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox27.isPassword = False
        Me.BunifuMetroTextbox27.Location = New System.Drawing.Point(112, 160)
        Me.BunifuMetroTextbox27.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox27.Name = "BunifuMetroTextbox27"
        Me.BunifuMetroTextbox27.Size = New System.Drawing.Size(513, 30)
        Me.BunifuMetroTextbox27.TabIndex = 70
        Me.BunifuMetroTextbox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel70
        '
        Me.BunifuCustomLabel70.AutoSize = True
        Me.BunifuCustomLabel70.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel70.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel70.Location = New System.Drawing.Point(6, 168)
        Me.BunifuCustomLabel70.Name = "BunifuCustomLabel70"
        Me.BunifuCustomLabel70.Size = New System.Drawing.Size(90, 17)
        Me.BunifuCustomLabel70.TabIndex = 69
        Me.BunifuCustomLabel70.Text = "Father Name"
        '
        'BunifuMetroTextbox26
        '
        Me.BunifuMetroTextbox26.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox26.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox26.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox26.BorderThickness = 1
        Me.BunifuMetroTextbox26.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox26.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox26.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox26.isPassword = False
        Me.BunifuMetroTextbox26.Location = New System.Drawing.Point(708, 93)
        Me.BunifuMetroTextbox26.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox26.Name = "BunifuMetroTextbox26"
        Me.BunifuMetroTextbox26.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox26.TabIndex = 68
        Me.BunifuMetroTextbox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel69
        '
        Me.BunifuCustomLabel69.AutoSize = True
        Me.BunifuCustomLabel69.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel69.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel69.Location = New System.Drawing.Point(629, 97)
        Me.BunifuCustomLabel69.Name = "BunifuCustomLabel69"
        Me.BunifuCustomLabel69.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel69.TabIndex = 67
        Me.BunifuCustomLabel69.Text = "Last Name"
        '
        'BunifuMetroTextbox25
        '
        Me.BunifuMetroTextbox25.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox25.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox25.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox25.BorderThickness = 1
        Me.BunifuMetroTextbox25.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox25.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox25.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox25.isPassword = False
        Me.BunifuMetroTextbox25.Location = New System.Drawing.Point(438, 93)
        Me.BunifuMetroTextbox25.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox25.Name = "BunifuMetroTextbox25"
        Me.BunifuMetroTextbox25.Size = New System.Drawing.Size(187, 30)
        Me.BunifuMetroTextbox25.TabIndex = 66
        Me.BunifuMetroTextbox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel68
        '
        Me.BunifuCustomLabel68.AutoSize = True
        Me.BunifuCustomLabel68.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel68.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel68.Location = New System.Drawing.Point(338, 97)
        Me.BunifuCustomLabel68.Name = "BunifuCustomLabel68"
        Me.BunifuCustomLabel68.Size = New System.Drawing.Size(90, 17)
        Me.BunifuCustomLabel68.TabIndex = 65
        Me.BunifuCustomLabel68.Text = "Middle Name"
        '
        'BunifuDropdown7
        '
        Me.BunifuDropdown7.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown7.BorderRadius = 3
        Me.BunifuDropdown7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown7.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown7.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown7.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown7.Location = New System.Drawing.Point(708, 127)
        Me.BunifuDropdown7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown7.Name = "BunifuDropdown7"
        Me.BunifuDropdown7.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown7.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown7.selectedIndex = -1
        Me.BunifuDropdown7.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown7.TabIndex = 48
        '
        'BunifuCustomLabel65
        '
        Me.BunifuCustomLabel65.AutoSize = True
        Me.BunifuCustomLabel65.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel65.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel65.Location = New System.Drawing.Point(629, 131)
        Me.BunifuCustomLabel65.Name = "BunifuCustomLabel65"
        Me.BunifuCustomLabel65.Size = New System.Drawing.Size(44, 17)
        Me.BunifuCustomLabel65.TabIndex = 49
        Me.BunifuCustomLabel65.Text = "Caste"
        '
        'BunifuDropdown6
        '
        Me.BunifuDropdown6.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown6.BorderRadius = 3
        Me.BunifuDropdown6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown6.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown6.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown6.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown6.Location = New System.Drawing.Point(438, 127)
        Me.BunifuDropdown6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown6.Name = "BunifuDropdown6"
        Me.BunifuDropdown6.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown6.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown6.selectedIndex = -1
        Me.BunifuDropdown6.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown6.TabIndex = 46
        '
        'BunifuCustomLabel64
        '
        Me.BunifuCustomLabel64.AutoSize = True
        Me.BunifuCustomLabel64.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel64.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel64.Location = New System.Drawing.Point(338, 133)
        Me.BunifuCustomLabel64.Name = "BunifuCustomLabel64"
        Me.BunifuCustomLabel64.Size = New System.Drawing.Size(56, 17)
        Me.BunifuCustomLabel64.TabIndex = 47
        Me.BunifuCustomLabel64.Text = "Gender"
        '
        'BunifuMetroTextbox8
        '
        Me.BunifuMetroTextbox8.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox8.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox8.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox8.BorderThickness = 1
        Me.BunifuMetroTextbox8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox8.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox8.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox8.isPassword = False
        Me.BunifuMetroTextbox8.Location = New System.Drawing.Point(112, 127)
        Me.BunifuMetroTextbox8.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox8.Name = "BunifuMetroTextbox8"
        Me.BunifuMetroTextbox8.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox8.TabIndex = 35
        Me.BunifuMetroTextbox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel40
        '
        Me.BunifuCustomLabel40.AutoSize = True
        Me.BunifuCustomLabel40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel40.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel40.Location = New System.Drawing.Point(6, 131)
        Me.BunifuCustomLabel40.Name = "BunifuCustomLabel40"
        Me.BunifuCustomLabel40.Size = New System.Drawing.Size(71, 17)
        Me.BunifuCustomLabel40.TabIndex = 34
        Me.BunifuCustomLabel40.Text = "Phone No"
        '
        'BunifuMetroTextbox1
        '
        Me.BunifuMetroTextbox1.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox1.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox1.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox1.BorderThickness = 1
        Me.BunifuMetroTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox1.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox1.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox1.isPassword = False
        Me.BunifuMetroTextbox1.Location = New System.Drawing.Point(112, 93)
        Me.BunifuMetroTextbox1.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox1.Name = "BunifuMetroTextbox1"
        Me.BunifuMetroTextbox1.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox1.TabIndex = 23
        Me.BunifuMetroTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel32
        '
        Me.BunifuCustomLabel32.AutoSize = True
        Me.BunifuCustomLabel32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel32.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel32.Location = New System.Drawing.Point(6, 97)
        Me.BunifuCustomLabel32.Name = "BunifuCustomLabel32"
        Me.BunifuCustomLabel32.Size = New System.Drawing.Size(76, 17)
        Me.BunifuCustomLabel32.TabIndex = 22
        Me.BunifuCustomLabel32.Text = "First Name"
        '
        'BunifuMetroTextbox7
        '
        Me.BunifuMetroTextbox7.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox7.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox7.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox7.BorderThickness = 1
        Me.BunifuMetroTextbox7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox7.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox7.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox7.isPassword = False
        Me.BunifuMetroTextbox7.Location = New System.Drawing.Point(112, 59)
        Me.BunifuMetroTextbox7.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox7.Name = "BunifuMetroTextbox7"
        Me.BunifuMetroTextbox7.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox7.TabIndex = 21
        Me.BunifuMetroTextbox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel31
        '
        Me.BunifuCustomLabel31.AutoSize = True
        Me.BunifuCustomLabel31.BackColor = System.Drawing.Color.Transparent
        Me.BunifuCustomLabel31.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel31.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel31.Location = New System.Drawing.Point(3, 6)
        Me.BunifuCustomLabel31.Name = "BunifuCustomLabel31"
        Me.BunifuCustomLabel31.Size = New System.Drawing.Size(117, 23)
        Me.BunifuCustomLabel31.TabIndex = 14
        Me.BunifuCustomLabel31.Text = "Student info"
        '
        'BunifuCustomLabel30
        '
        Me.BunifuCustomLabel30.AutoSize = True
        Me.BunifuCustomLabel30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel30.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel30.Location = New System.Drawing.Point(6, 64)
        Me.BunifuCustomLabel30.Name = "BunifuCustomLabel30"
        Me.BunifuCustomLabel30.Size = New System.Drawing.Size(65, 17)
        Me.BunifuCustomLabel30.TabIndex = 0
        Me.BunifuCustomLabel30.Text = "Gr No/ Id"
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage8.Controls.Add(Me.Panel5)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(931, 470)
        Me.TabPage8.TabIndex = 1
        Me.TabPage8.Text = "TabPage8"
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.BunifuThinButton210)
        Me.Panel5.Controls.Add(Me.BunifuDropdown3)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel50)
        Me.Panel5.Controls.Add(Me.BunifuDropdown2)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel49)
        Me.Panel5.Controls.Add(Me.BunifuMetroTextbox28)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel75)
        Me.Panel5.Controls.Add(Me.BunifuMetroTextbox14)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel74)
        Me.Panel5.Controls.Add(Me.BunifuMetroTextbox13)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel48)
        Me.Panel5.Controls.Add(Me.BunifuMetroTextbox12)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel47)
        Me.Panel5.Controls.Add(Me.BunifuMetroTextbox11)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel46)
        Me.Panel5.Controls.Add(Me.BunifuMetroTextbox10)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel45)
        Me.Panel5.Controls.Add(Me.BunifuMetroTextbox9)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel39)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel67)
        Me.Panel5.Controls.Add(Me.BunifuDatepicker3)
        Me.Panel5.Controls.Add(Me.BunifuCustomLabel38)
        Me.Panel5.Location = New System.Drawing.Point(6, 6)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(824, 343)
        Me.Panel5.TabIndex = 0
        '
        'BunifuThinButton210
        '
        Me.BunifuThinButton210.ActiveBorderThickness = 1
        Me.BunifuThinButton210.ActiveCornerRadius = 3
        Me.BunifuThinButton210.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton210.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton210.ActiveLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton210.AutoSize = True
        Me.BunifuThinButton210.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuThinButton210.BackgroundImage = CType(resources.GetObject("BunifuThinButton210.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton210.ButtonText = "Reset"
        Me.BunifuThinButton210.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton210.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton210.ForeColor = System.Drawing.Color.White
        Me.BunifuThinButton210.IdleBorderThickness = 1
        Me.BunifuThinButton210.IdleCornerRadius = 1
        Me.BunifuThinButton210.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuThinButton210.IdleForecolor = System.Drawing.Color.White
        Me.BunifuThinButton210.IdleLineColor = System.Drawing.Color.Transparent
        Me.BunifuThinButton210.Location = New System.Drawing.Point(119, 289)
        Me.BunifuThinButton210.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton210.Name = "BunifuThinButton210"
        Me.BunifuThinButton210.Size = New System.Drawing.Size(189, 36)
        Me.BunifuThinButton210.TabIndex = 87
        Me.BunifuThinButton210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuDropdown3
        '
        Me.BunifuDropdown3.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown3.BorderRadius = 3
        Me.BunifuDropdown3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown3.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown3.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown3.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown3.Location = New System.Drawing.Point(454, 139)
        Me.BunifuDropdown3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown3.Name = "BunifuDropdown3"
        Me.BunifuDropdown3.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown3.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown3.selectedIndex = -1
        Me.BunifuDropdown3.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown3.TabIndex = 85
        '
        'BunifuCustomLabel50
        '
        Me.BunifuCustomLabel50.AutoSize = True
        Me.BunifuCustomLabel50.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel50.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel50.Location = New System.Drawing.Point(341, 146)
        Me.BunifuCustomLabel50.Name = "BunifuCustomLabel50"
        Me.BunifuCustomLabel50.Size = New System.Drawing.Size(98, 17)
        Me.BunifuCustomLabel50.TabIndex = 86
        Me.BunifuCustomLabel50.Text = "Select Section"
        '
        'BunifuDropdown2
        '
        Me.BunifuDropdown2.BackColor = System.Drawing.Color.Transparent
        Me.BunifuDropdown2.BorderRadius = 3
        Me.BunifuDropdown2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDropdown2.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuDropdown2.ForeColor = System.Drawing.Color.White
        Me.BunifuDropdown2.Items = New String() {"Engineering", "Polytechnic", "BCA", "MCA", "Bsc(comp.)", "Msc(comp.)", "M-Tech", "Other"}
        Me.BunifuDropdown2.Location = New System.Drawing.Point(454, 102)
        Me.BunifuDropdown2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDropdown2.Name = "BunifuDropdown2"
        Me.BunifuDropdown2.NomalColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDropdown2.onHoverColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuDropdown2.selectedIndex = -1
        Me.BunifuDropdown2.Size = New System.Drawing.Size(187, 30)
        Me.BunifuDropdown2.TabIndex = 83
        '
        'BunifuCustomLabel49
        '
        Me.BunifuCustomLabel49.AutoSize = True
        Me.BunifuCustomLabel49.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel49.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel49.Location = New System.Drawing.Point(341, 109)
        Me.BunifuCustomLabel49.Name = "BunifuCustomLabel49"
        Me.BunifuCustomLabel49.Size = New System.Drawing.Size(85, 17)
        Me.BunifuCustomLabel49.TabIndex = 84
        Me.BunifuCustomLabel49.Text = "Select Class"
        '
        'BunifuMetroTextbox28
        '
        Me.BunifuMetroTextbox28.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox28.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox28.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox28.BorderThickness = 1
        Me.BunifuMetroTextbox28.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox28.Font = New System.Drawing.Font("Century Gothic", 22.0!)
        Me.BunifuMetroTextbox28.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox28.isPassword = False
        Me.BunifuMetroTextbox28.Location = New System.Drawing.Point(395, 213)
        Me.BunifuMetroTextbox28.Margin = New System.Windows.Forms.Padding(6)
        Me.BunifuMetroTextbox28.Name = "BunifuMetroTextbox28"
        Me.BunifuMetroTextbox28.Size = New System.Drawing.Size(352, 71)
        Me.BunifuMetroTextbox28.TabIndex = 82
        Me.BunifuMetroTextbox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BunifuCustomLabel75
        '
        Me.BunifuCustomLabel75.AutoSize = True
        Me.BunifuCustomLabel75.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel75.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel75.Location = New System.Drawing.Point(504, 189)
        Me.BunifuCustomLabel75.Name = "BunifuCustomLabel75"
        Me.BunifuCustomLabel75.Size = New System.Drawing.Size(130, 17)
        Me.BunifuCustomLabel75.TabIndex = 81
        Me.BunifuCustomLabel75.Text = "Remaining Balance"
        '
        'BunifuMetroTextbox14
        '
        Me.BunifuMetroTextbox14.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox14.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox14.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox14.BorderThickness = 1
        Me.BunifuMetroTextbox14.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox14.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox14.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox14.isPassword = False
        Me.BunifuMetroTextbox14.Location = New System.Drawing.Point(119, 250)
        Me.BunifuMetroTextbox14.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox14.Name = "BunifuMetroTextbox14"
        Me.BunifuMetroTextbox14.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox14.TabIndex = 80
        Me.BunifuMetroTextbox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel74
        '
        Me.BunifuCustomLabel74.AutoSize = True
        Me.BunifuCustomLabel74.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel74.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel74.Location = New System.Drawing.Point(12, 257)
        Me.BunifuCustomLabel74.Name = "BunifuCustomLabel74"
        Me.BunifuCustomLabel74.Size = New System.Drawing.Size(99, 17)
        Me.BunifuCustomLabel74.TabIndex = 79
        Me.BunifuCustomLabel74.Text = "5th Installment"
        '
        'BunifuMetroTextbox13
        '
        Me.BunifuMetroTextbox13.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox13.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox13.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox13.BorderThickness = 1
        Me.BunifuMetroTextbox13.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox13.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox13.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox13.isPassword = False
        Me.BunifuMetroTextbox13.Location = New System.Drawing.Point(119, 213)
        Me.BunifuMetroTextbox13.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox13.Name = "BunifuMetroTextbox13"
        Me.BunifuMetroTextbox13.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox13.TabIndex = 78
        Me.BunifuMetroTextbox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel48
        '
        Me.BunifuCustomLabel48.AutoSize = True
        Me.BunifuCustomLabel48.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel48.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel48.Location = New System.Drawing.Point(12, 220)
        Me.BunifuCustomLabel48.Name = "BunifuCustomLabel48"
        Me.BunifuCustomLabel48.Size = New System.Drawing.Size(99, 17)
        Me.BunifuCustomLabel48.TabIndex = 77
        Me.BunifuCustomLabel48.Text = "4th Installment"
        '
        'BunifuMetroTextbox12
        '
        Me.BunifuMetroTextbox12.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox12.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox12.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox12.BorderThickness = 1
        Me.BunifuMetroTextbox12.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox12.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox12.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox12.isPassword = False
        Me.BunifuMetroTextbox12.Location = New System.Drawing.Point(119, 176)
        Me.BunifuMetroTextbox12.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox12.Name = "BunifuMetroTextbox12"
        Me.BunifuMetroTextbox12.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox12.TabIndex = 76
        Me.BunifuMetroTextbox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel47
        '
        Me.BunifuCustomLabel47.AutoSize = True
        Me.BunifuCustomLabel47.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel47.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel47.Location = New System.Drawing.Point(12, 183)
        Me.BunifuCustomLabel47.Name = "BunifuCustomLabel47"
        Me.BunifuCustomLabel47.Size = New System.Drawing.Size(100, 17)
        Me.BunifuCustomLabel47.TabIndex = 75
        Me.BunifuCustomLabel47.Text = "3rd Installment"
        '
        'BunifuMetroTextbox11
        '
        Me.BunifuMetroTextbox11.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox11.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox11.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox11.BorderThickness = 1
        Me.BunifuMetroTextbox11.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox11.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox11.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox11.isPassword = False
        Me.BunifuMetroTextbox11.Location = New System.Drawing.Point(119, 139)
        Me.BunifuMetroTextbox11.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox11.Name = "BunifuMetroTextbox11"
        Me.BunifuMetroTextbox11.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox11.TabIndex = 74
        Me.BunifuMetroTextbox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel46
        '
        Me.BunifuCustomLabel46.AutoSize = True
        Me.BunifuCustomLabel46.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel46.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel46.Location = New System.Drawing.Point(12, 146)
        Me.BunifuCustomLabel46.Name = "BunifuCustomLabel46"
        Me.BunifuCustomLabel46.Size = New System.Drawing.Size(103, 17)
        Me.BunifuCustomLabel46.TabIndex = 73
        Me.BunifuCustomLabel46.Text = "2nd Installment"
        '
        'BunifuMetroTextbox10
        '
        Me.BunifuMetroTextbox10.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox10.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox10.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox10.BorderThickness = 1
        Me.BunifuMetroTextbox10.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox10.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox10.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox10.isPassword = False
        Me.BunifuMetroTextbox10.Location = New System.Drawing.Point(119, 102)
        Me.BunifuMetroTextbox10.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox10.Name = "BunifuMetroTextbox10"
        Me.BunifuMetroTextbox10.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox10.TabIndex = 72
        Me.BunifuMetroTextbox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel45
        '
        Me.BunifuCustomLabel45.AutoSize = True
        Me.BunifuCustomLabel45.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel45.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel45.Location = New System.Drawing.Point(12, 109)
        Me.BunifuCustomLabel45.Name = "BunifuCustomLabel45"
        Me.BunifuCustomLabel45.Size = New System.Drawing.Size(98, 17)
        Me.BunifuCustomLabel45.TabIndex = 71
        Me.BunifuCustomLabel45.Text = "1st Installment"
        '
        'BunifuMetroTextbox9
        '
        Me.BunifuMetroTextbox9.BorderColorFocused = System.Drawing.Color.White
        Me.BunifuMetroTextbox9.BorderColorIdle = System.Drawing.Color.DarkGray
        Me.BunifuMetroTextbox9.BorderColorMouseHover = System.Drawing.Color.White
        Me.BunifuMetroTextbox9.BorderThickness = 1
        Me.BunifuMetroTextbox9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BunifuMetroTextbox9.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.BunifuMetroTextbox9.ForeColor = System.Drawing.Color.White
        Me.BunifuMetroTextbox9.isPassword = False
        Me.BunifuMetroTextbox9.Location = New System.Drawing.Point(119, 65)
        Me.BunifuMetroTextbox9.Margin = New System.Windows.Forms.Padding(4)
        Me.BunifuMetroTextbox9.Name = "BunifuMetroTextbox9"
        Me.BunifuMetroTextbox9.Size = New System.Drawing.Size(189, 30)
        Me.BunifuMetroTextbox9.TabIndex = 70
        Me.BunifuMetroTextbox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'BunifuCustomLabel39
        '
        Me.BunifuCustomLabel39.AutoSize = True
        Me.BunifuCustomLabel39.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel39.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel39.Location = New System.Drawing.Point(12, 72)
        Me.BunifuCustomLabel39.Name = "BunifuCustomLabel39"
        Me.BunifuCustomLabel39.Size = New System.Drawing.Size(107, 17)
        Me.BunifuCustomLabel39.TabIndex = 69
        Me.BunifuCustomLabel39.Text = "Admission Fees"
        '
        'BunifuCustomLabel67
        '
        Me.BunifuCustomLabel67.AutoSize = True
        Me.BunifuCustomLabel67.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel67.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel67.Location = New System.Drawing.Point(341, 72)
        Me.BunifuCustomLabel67.Name = "BunifuCustomLabel67"
        Me.BunifuCustomLabel67.Size = New System.Drawing.Size(106, 17)
        Me.BunifuCustomLabel67.TabIndex = 68
        Me.BunifuCustomLabel67.Text = "Admission Date"
        '
        'BunifuDatepicker3
        '
        Me.BunifuDatepicker3.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuDatepicker3.BorderRadius = 1
        Me.BunifuDatepicker3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuDatepicker3.ForeColor = System.Drawing.Color.White
        Me.BunifuDatepicker3.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        Me.BunifuDatepicker3.FormatCustom = Nothing
        Me.BunifuDatepicker3.Location = New System.Drawing.Point(454, 62)
        Me.BunifuDatepicker3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuDatepicker3.Name = "BunifuDatepicker3"
        Me.BunifuDatepicker3.Size = New System.Drawing.Size(187, 36)
        Me.BunifuDatepicker3.TabIndex = 67
        Me.BunifuDatepicker3.Value = New Date(2018, 8, 25, 3, 53, 53, 609)
        '
        'BunifuCustomLabel38
        '
        Me.BunifuCustomLabel38.AutoSize = True
        Me.BunifuCustomLabel38.BackColor = System.Drawing.Color.Transparent
        Me.BunifuCustomLabel38.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuCustomLabel38.ForeColor = System.Drawing.Color.White
        Me.BunifuCustomLabel38.Location = New System.Drawing.Point(3, 17)
        Me.BunifuCustomLabel38.Name = "BunifuCustomLabel38"
        Me.BunifuCustomLabel38.Size = New System.Drawing.Size(89, 23)
        Me.BunifuCustomLabel38.TabIndex = 15
        Me.BunifuCustomLabel38.Text = "Fees Info"
        '
        'TabPage11
        '
        Me.TabPage11.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage11.Controls.Add(Me.BunifuGradientPanel6)
        Me.TabPage11.Controls.Add(Me.BunifuCustomDataGrid1)
        Me.TabPage11.Location = New System.Drawing.Point(4, 22)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(931, 470)
        Me.TabPage11.TabIndex = 4
        Me.TabPage11.Text = "TabPage11"
        '
        'BunifuGradientPanel6
        '
        Me.BunifuGradientPanel6.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel6.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.BunifuGradientPanel6.Controls.Add(Me.BunifuTextbox1)
        Me.BunifuGradientPanel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuGradientPanel6.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BunifuGradientPanel6.Location = New System.Drawing.Point(3, 3)
        Me.BunifuGradientPanel6.Name = "BunifuGradientPanel6"
        Me.BunifuGradientPanel6.Quality = 10
        Me.BunifuGradientPanel6.Size = New System.Drawing.Size(925, 37)
        Me.BunifuGradientPanel6.TabIndex = 1
        '
        'BunifuTextbox1
        '
        Me.BunifuTextbox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuTextbox1.BackgroundImage = CType(resources.GetObject("BunifuTextbox1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuTextbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuTextbox1.ForeColor = System.Drawing.Color.White
        Me.BunifuTextbox1.Icon = CType(resources.GetObject("BunifuTextbox1.Icon"), System.Drawing.Image)
        Me.BunifuTextbox1.Location = New System.Drawing.Point(12, 1)
        Me.BunifuTextbox1.Name = "BunifuTextbox1"
        Me.BunifuTextbox1.Size = New System.Drawing.Size(239, 31)
        Me.BunifuTextbox1.TabIndex = 0
        Me.BunifuTextbox1.text = "Search Id, Name, Class "
        '
        'BunifuCustomDataGrid1
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.BunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.BunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.BunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.BunifuCustomDataGrid1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6})
        Me.BunifuCustomDataGrid1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BunifuCustomDataGrid1.DoubleBuffered = True
        Me.BunifuCustomDataGrid1.EnableHeadersVisualStyles = False
        Me.BunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(132, Byte), Integer))
        Me.BunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.White
        Me.BunifuCustomDataGrid1.Location = New System.Drawing.Point(3, 42)
        Me.BunifuCustomDataGrid1.Name = "BunifuCustomDataGrid1"
        Me.BunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.BunifuCustomDataGrid1.Size = New System.Drawing.Size(925, 425)
        Me.BunifuCustomDataGrid1.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Id"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Name 1"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "Name 2"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "Name 3"
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.HeaderText = "Name 4"
        Me.Column5.Name = "Column5"
        '
        'Column6
        '
        Me.Column6.HeaderText = "Name 5"
        Me.Column6.Name = "Column6"
        '
        'strudentinfocontrol
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.BunifuCustomLabel29)
        Me.Controls.Add(Me.TabControl2)
        Me.Name = "strudentinfocontrol"
        Me.Size = New System.Drawing.Size(921, 538)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.BunifuGradientPanel6.ResumeLayout(False)
        CType(Me.BunifuCustomDataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel4 As Panel
    Friend WithEvents BunifuThinButton214 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton215 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton212 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton213 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton28 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton29 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton26 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton27 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton24 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton25 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton22 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton23 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuCustomLabel29 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents Panel3 As Panel
    Friend WithEvents BunifuDropdown1 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel76 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel66 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDatepicker2 As Bunifu.Framework.UI.BunifuDatepicker
    Friend WithEvents BunifuDropdown14 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel73 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown13 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel72 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown12 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel71 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown11 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel44 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox6 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel43 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox5 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel42 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox4 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel41 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox3 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel37 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown9 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel35 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown10 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel36 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox2 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel34 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown8 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel33 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown5 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel63 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox27 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel70 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox26 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel69 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox25 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel68 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown7 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel65 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown6 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel64 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox8 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel40 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox1 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel32 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox7 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel31 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel30 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents Panel5 As Panel
    Friend WithEvents BunifuThinButton210 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuDropdown3 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel50 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDropdown2 As Bunifu.Framework.UI.BunifuDropdown
    Friend WithEvents BunifuCustomLabel49 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox28 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel75 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox14 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel74 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox13 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel48 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox12 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel47 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox11 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel46 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox10 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel45 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuMetroTextbox9 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents BunifuCustomLabel39 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuCustomLabel67 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents BunifuDatepicker3 As Bunifu.Framework.UI.BunifuDatepicker
    Friend WithEvents BunifuCustomLabel38 As Bunifu.Framework.UI.BunifuCustomLabel
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents BunifuGradientPanel6 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuTextbox1 As Bunifu.Framework.UI.BunifuTextbox
    Friend WithEvents BunifuCustomDataGrid1 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
End Class
