﻿Public Class strudentinfocontrol
    Private Sub BunifuThinButton24_Click(sender As Object, e As EventArgs) Handles BunifuThinButton24.Click
        BunifuThinButton23.Visible = False
        BunifuThinButton25.Visible = True
        BunifuThinButton27.Visible = False
        BunifuThinButton29.Visible = False
        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = False
        TabControl2.SelectedTab = TabPage8

    End Sub

    Private Sub BunifuThinButton22_Click(sender As Object, e As EventArgs) Handles BunifuThinButton22.Click
        BunifuThinButton23.Visible = True
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = False
        BunifuThinButton29.Visible = False
        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = False

        TabControl2.SelectedTab = TabPage7
    End Sub

    Private Sub BunifuThinButton26_Click(sender As Object, e As EventArgs) Handles BunifuThinButton26.Click
        BunifuThinButton23.Visible = False
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = True
        BunifuThinButton29.Visible = False
        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = False
    End Sub

    Private Sub BunifuThinButton28_Click(sender As Object, e As EventArgs) Handles BunifuThinButton28.Click
        BunifuThinButton23.Visible = False
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = False
        BunifuThinButton29.Visible = True
        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = False
    End Sub

    Private Sub BunifuThinButton212_Click(sender As Object, e As EventArgs) Handles BunifuThinButton212.Click
        BunifuThinButton23.Visible = False
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = False
        BunifuThinButton29.Visible = False
        BunifuThinButton213.Visible = True
        BunifuThinButton215.Visible = False
    End Sub

    Private Sub BunifuThinButton214_Click(sender As Object, e As EventArgs) Handles BunifuThinButton214.Click
        BunifuThinButton23.Visible = False
        BunifuThinButton25.Visible = False
        BunifuThinButton27.Visible = False
        BunifuThinButton29.Visible = False
        BunifuThinButton213.Visible = False
        BunifuThinButton215.Visible = True

        TabControl2.SelectedTab = TabPage11
    End Sub
End Class
